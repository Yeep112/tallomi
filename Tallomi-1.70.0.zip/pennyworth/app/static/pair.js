'use strict';
const form = document.getElementById('pair-form'), msg = document.getElementById('msg'), code = document.getElementById('code'), name = document.getElementById('devname');
if (!name.value) {
  const ua = navigator.userAgent;
  name.placeholder = /iPhone/.test(ua) ? '我的 iPhone' : /iPad/.test(ua) ? '我的 iPad' : /Android/.test(ua) ? '我的 Android 手機' : '我的手機';
}
// What follows the # tells two things apart: the QR code carries the 8 digits (/pair#12345678), while a quick-entry link opened before pairing keeps its own
// address (#/add?...) so the form can open once the phone is paired. Only a bare run of digits is a code: numbers inside a link (an amount, a date) are not.
const hashRaw = (location.hash || '').replace(/^#/, '');
let hashText = hashRaw;
try { hashText = decodeURIComponent(hashRaw); } catch { /* keep it as it is */ }
let next = '';
if (/^[\d\s-]{8,16}$/.test(hashText) && hashText.replace(/\D/g, '').length === 8) { code.value = hashText.replace(/\D/g, ''); history.replaceState(null, '', '/pair'); }
else if (/^\/add(\?|$)/.test(hashRaw) && hashRaw.length < 1200) next = '#' + hashRaw;                  // the link goes back out exactly as it came in
if (/iPhone|iPad|iPod/.test(navigator.userAgent) && !navigator.standalone) document.getElementById('ios-hint').hidden = false;
code.addEventListener('input', () => { code.value = code.value.replace(/[^0-9]/g, '').slice(0, 8); });
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  msg.textContent = '';
  const go = document.getElementById('go');
  go.disabled = true;
  try {
    const r = await fetch('/api/pair', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Pennyworth': '1' },
      body: JSON.stringify({ code: code.value, name: name.value || name.placeholder }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || `連接失敗（${r.status}）`);
    location.replace('/' + next);                                  // then straight to the form the link asked for, if there was one
  } catch (err) {
    msg.textContent = err.message || '連接失敗';
    go.disabled = false;
  }
});
