"""Flask app: JSON API + the static single-page UI. Bound to 127.0.0.1 only."""
import json
import csv
import gzip
import hashlib
import logging
import os
import re
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime
from urllib.parse import urlparse

from flask import Flask, Response, jsonify, make_response, redirect, request, send_from_directory
from werkzeug.exceptions import HTTPException

from . import lazyroutes
lazyroutes.install()                  # before the first route is added (see lazyroutes.py)
from . import autostart, config, importer, localcopy, reports, updater as updater_mod
from .book import Book, BookError
from .autobackup import AutoBackup
from .locks import AppLock, IDLE_CHOICES, LockError, OwnerLock
from .fxauto import FxAuto
from .remote import COOKIE, COOKIE_DAYS, PairError, Remote
from .stockauto import StockAuto
from .market import MarketData, MarketError
from .sheets import SheetsSync

log = logging.getLogger("pennyworth")
LOCAL_HOSTS = {"127.0.0.1", "localhost"}
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
PROXY_HEADERS = ("X-Forwarded-For", "X-Forwarded-Host", "Forwarded", "Tailscale-User-Login", "X-Real-Ip")
# What a paired phone may NOT do: things that touch this computer's files, the Google connection, or the program itself.
LOCAL_ONLY = ("/api/shutdown", "/api/app-mode", "/api/owner-lock", "/api/update", "/api/open-folder", "/api/export", "/api/import", "/api/backups", "/api/autobackup", "/api/autostart", "/api/clear-all",
              "/api/remote", "/api/sheets/")
# What anybody may fetch before pairing (no data in any of it).
PUBLIC_REMOTE = ("/pair", "/api/pair", "/sw.js", "/static/pair.js", "/static/style.css", "/static/theme.js", "/static/favicon.ico",
                 "/static/manifest.webmanifest", "/static/vendor/fonts/")
PUBLIC_REMOTE_PREFIX = ("/static/icon-",)
# The phone version has no computer behind it, so everything that needs one is simply not there.
PHONE_BLOCKED = ("/api/shutdown", "/api/open-folder", "/api/autostart", "/api/autobackup", "/api/remote", "/api/pair", "/api/app-mode",
                 "/api/owner-lock", "/api/update", "/api/sheets/", "/api/local/")
UNLOCKED_API = ("/api/ping", "/api/pair", "/api/lock/")          # reachable while the PIN lock is closed
UNLOCK_COOKIE = "pw_unlock"


def _int(name, default=None, lo=None, hi=None):
    raw = request.args.get(name)
    if raw in (None, ""):
        return default
    try:
        v = int(raw)
    except ValueError:
        raise BookError(f"參數 {name} 必須是整數") from None
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise BookError(f"參數 {name} 超出範圍")
    return v


_waiters = threading.BoundedSemaphore(4)
_build_cache = {"at": 0.0, "id": ""}


def build_id():
    """A short fingerprint of the program's own files (size + modified time of everything in static/) and its version.
    It changes whenever an update is copied over, so open windows and phones can tell that a newer program is waiting.
    The bundled libraries and the ~300 icon pictures are left out: they never change without a version bump, which is in the hash
    (and walking them took longer than all the program's own files together)."""
    now = time.time()
    if now - _build_cache["at"] > 2:
        h = hashlib.sha1(config.VERSION.encode())
        root = config.STATIC_DIR
        for f in sorted(root.iterdir()):
            if f.is_file():
                st = f.stat()
                h.update(f"{f.name}:{st.st_size}:{st.st_mtime_ns}".encode())
        _build_cache.update(at=now, id=h.hexdigest()[:12])
    return _build_cache["id"]


# The page's own scripts and style sheet: the served page gets "?v=<build>" on them, so the browser can keep them for good
# (the address changes when the program does) instead of asking the computer for ~500 KB again on every launch.
_STATIC_REF = re.compile(r'((?:src|href)=")(/static/[^"?]+\.(?:js|css))(")')
# What is worth compressing when a phone asks for it (pictures and zip files are already compressed)
_GZIP_TYPES = ("text/", "application/json", "application/javascript", "application/manifest+json", "image/svg+xml")
_gzip_cache = {}


def create_app(data_dir=None, sheets_client_factory=None):
    app = Flask(__name__, static_folder=None)
    app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
    book = Book(data_dir or config.book_dir())
    sheets = SheetsSync(book, client_factory=sheets_client_factory)
    app.config["book"], app.config["sheets"] = book, sheets
    fxauto = FxAuto(book, fetcher_getter=lambda: app.config.get("fx_fetcher"))
    app.config["fxauto"] = fxauto
    autobackup = AutoBackup(book)
    app.config["autobackup"] = autobackup
    stockauto = StockAuto(book, fetcher_getter=lambda: app.config.get("price_fetcher"))
    app.config["stockauto"] = stockauto
    market = MarketData(book.db_path.parent / "market_list.json", getter_fn=lambda: app.config.get("market_getter"))
    app.config["market"] = market
    if book.changed_on_start:
        sheets.request_sync()          # balances changed during an upgrade: refresh the sheet too
    else:
        sheets.resume_pending()        # changes made while offline / before the last exit still need uploading
    book.maybe_run_recurring(force=True)    # anything that came due while the program was closed is recorded now
    app.config["last_ping"] = None
    app.config["shutdown_cb"] = None
    app.config["restart_cb"] = None
    app.config["updater"] = None
    if config.updates_enabled():
        def _auto_on():
            with book.session() as c:
                return book.get_setting(c, "update_auto", "1") == "1"
        app.config["updater"] = updater_mod.Updater(book_dir=book.data_dir, auto_get=_auto_on)
        app.config["updateworker"] = updater_mod.UpdateWorker(app.config["updater"], enabled=_auto_on)

    def update_info():
        u = app.config.get("updater")
        if not u:
            return {"enabled": False, "current": config.VERSION}
        with book.session() as c:
            auto = book.get_setting(c, "update_auto", "1") == "1"
        return dict(u.snapshot(), auto=auto, url=config.UPDATE_URL)
    def _site_origin():
        u = urlparse(config.UPDATE_URL)
        return f"{u.scheme}://{u.netloc}" if u.scheme and u.netloc else ""

    remote = Remote(book)
    app.config["remote"] = remote
    applock = AppLock(book.data_dir / "applock.json")
    ownerlock = OwnerLock(config.data_dir() / "owner_lock.json")
    app.config["applock"], app.config["ownerlock"] = applock, ownerlock

    def is_remote():
        """Did this request come through the phone route rather than straight from this computer's own window?"""
        if any(request.headers.get(k) for k in PROXY_HEADERS):
            return True
        host = (request.host or "").rsplit(":", 1)[0].strip("[]").lower()
        return host not in LOCAL_HOSTS or request.remote_addr not in ("127.0.0.1", "::1", None)

    # ------------------------------------------------------------ security
    @app.before_request
    def guard():
        # Direct requests only ever answer to localhost names (blocks DNS-rebinding), and writes need a custom
        # header (a web page you happen to visit can't send it). Requests coming through the phone route additionally
        # need the phone to be paired (see remote.py).
        host = (request.host or "").rsplit(":", 1)[0].strip("[]").lower()
        path = request.path
        if not is_remote():
            if host not in LOCAL_HOSTS:
                return jsonify(error="不允許的主機名稱"), 403
            origin = request.headers.get("Origin")
            if origin and (urlparse(origin).hostname or "") not in LOCAL_HOSTS:
                return jsonify(error="不允許的來源"), 403
        else:
            if not remote.enabled():
                return jsonify(error="沒有開啟手機連線（請在電腦的「設定 → 手機連線」開啟）"), 403
            fwd = (request.headers.get("X-Forwarded-Host") or "").rsplit(":", 1)[0].strip("[]").lower()
            # (a proxy may also hand the request over with the Host rewritten to the local address: that is fine, the
            # pairing cookie below is what lets a phone in)
            if not (remote.allowed_host(host) or (fwd and remote.allowed_host(fwd)) or host in LOCAL_HOSTS):
                return jsonify(error="不允許的主機名稱"), 403
            origin = request.headers.get("Origin")
            if origin and not remote.allowed_host(urlparse(origin).hostname or ""):
                return jsonify(error="不允許的來源"), 403
            if any(path == x or path.startswith(x) for x in LOCAL_ONLY) and not (path == "/api/sheets" and request.method == "GET"):
                return jsonify(error="這個功能只能在電腦上使用"), 403
            public = path in PUBLIC_REMOTE or any(path.startswith(x) for x in PUBLIC_REMOTE if x.endswith("/")) \
                or any(path.startswith(x) for x in PUBLIC_REMOTE_PREFIX)
            if not public and not remote.check(request.cookies.get(COOKIE)):
                if path.startswith("/api/"):
                    return jsonify(error="這支手機還沒配對，或已被移除", pair=True), 401
                return redirect("/pair")
        if config.PHONE and any(path == x or path.startswith(x) for x in PHONE_BLOCKED):
            return jsonify(error="手機版沒有這個功能"), 404
        if request.method not in SAFE_METHODS \
                and request.headers.get("X-Pennyworth") != "1":
            return jsonify(error="缺少必要的標頭"), 403
        if path.startswith("/api/") and applock.enabled() and not any(path == x or path.startswith(x) for x in UNLOCKED_API) \
                and not applock.valid(request.cookies.get(UNLOCK_COOKIE)):
            return jsonify(error="已上鎖，請先輸入 PIN", locked=True), 401

    @app.after_request
    def compress(resp):
        """Phones reach the computer over a slower link than the window on the computer itself: send text smaller (about a third)."""
        if resp.status_code != 200 or request.method != "GET" or resp.headers.get("Content-Encoding") or "gzip" not in request.headers.get("Accept-Encoding", ""):
            return resp
        if not resp.mimetype.startswith(_GZIP_TYPES) or not is_remote():
            return resp
        resp.direct_passthrough = False
        data = resp.get_data()
        if len(data) < 600:
            return resp
        etag = resp.headers.get("ETag")
        key = (request.path, etag, len(data)) if etag else None
        packed = _gzip_cache.get(key) if key else None
        if packed is None:
            packed = gzip.compress(data, compresslevel=5, mtime=0)
            if key:
                if len(_gzip_cache) > 400:
                    _gzip_cache.clear()
                _gzip_cache[key] = packed
        resp.set_data(packed)
        resp.headers["Content-Encoding"] = "gzip"
        resp.headers["Vary"] = "Accept-Encoding"
        if etag and not etag.startswith("W/"):
            resp.headers["ETag"] = "W/" + etag                  # same file, different bytes on the wire
        return resp

    @app.after_request
    def no_cache(resp):
        path = request.path
        if path.startswith("/static/"):
            # asked for by the address this build's page uses: keep it. Anything else: always check with the computer first
            # (a "not changed" answer is a few hundred bytes), so a fresh program is never shown with an old script.
            v = request.args.get("v")
            resp.headers["Cache-Control"] = "private, max-age=31536000, immutable" if v and v == build_id() else "no-cache"
        elif path == "/" or path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Rev"] = str(book.rev)
        resp.headers["Access-Control-Expose-Headers"] = "X-Rev"
        site = _site_origin()
        if request.path == "/static/local-worker.js":
            # the phone's own copy of the program (1.63.0): it runs the runtime from the public phone site and looks up rates and prices itself
            resp.headers["Content-Security-Policy"] = f"default-src 'self'; script-src 'self' {site} 'wasm-unsafe-eval'; connect-src *"
        else:
            resp.headers["Content-Security-Policy"] = (
                "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                f"script-src 'self'; font-src 'self'; connect-src 'self' {site}; frame-ancestors 'none'")
        return resp

    @app.errorhandler(BookError)
    def on_book_error(e):
        return jsonify(error=str(e)), e.status

    @app.errorhandler(404)
    def on_404(e):
        return jsonify(error="找不到"), 404

    @app.errorhandler(413)
    def on_413(e):
        return jsonify(error="檔案太大（上限 25 MB）"), 413

    @app.errorhandler(Exception)
    def on_error(e):
        if isinstance(e, HTTPException):          # 405 etc: pass through, not a crash
            return jsonify(error=e.description), e.code
        log.exception("unhandled error")
        return jsonify(error=f"發生未預期的錯誤：{type(e).__name__}。詳情請見 pennyworth.log"), 500

    def body():
        data = request.get_json(silent=True)
        return data if isinstance(data, dict) else {}

    # -------------------------------------------------------------- static
    @app.get("/")
    def index():
        # the page carries the fingerprint of the program files it was loaded with (see build_id / revWatch in app.js)
        bid = build_id()
        text = (config.STATIC_DIR / "index.html").read_text(encoding="utf-8").replace("__BUILD__", bid)
        text = _STATIC_REF.sub(lambda m: f"{m.group(1)}{m.group(2)}?v={bid}{m.group(3)}", text)
        resp = make_response(text)
        resp.headers["Content-Type"] = "text/html; charset=utf-8"
        return resp

    @app.get("/static/<path:name>")
    def static_files(name):
        return send_from_directory(config.STATIC_DIR, name)

    @app.get("/pair")
    def pair_page():
        if not is_remote():
            return redirect("/")
        return send_from_directory(config.STATIC_DIR, "pair.html")

    @app.get("/sw.js")
    def service_worker():
        text = (config.STATIC_DIR / "sw.js").read_text(encoding="utf-8").replace("__VERSION__", config.VERSION)
        emoji = sorted(f"/static/emoji/{f.name}" for f in (config.STATIC_DIR / "emoji").glob("*.svg"))
        text = text.replace("__EMOJI__", json.dumps(emoji))
        resp = make_response(text)
        resp.headers["Content-Type"] = "text/javascript; charset=utf-8"
        resp.headers["Cache-Control"] = "no-cache"
        resp.headers["Service-Worker-Allowed"] = "/"
        return resp

    @app.post("/api/pair")
    def pair():
        d = body()
        try:
            token = remote.pair(d.get("code"), d.get("name"), request.headers.get("User-Agent", ""))
        except PairError as e:
            return jsonify(error=str(e)), 403
        resp = make_response(jsonify(ok=True))
        secure = request.is_secure or request.headers.get("X-Forwarded-Proto", "").lower() == "https"
        resp.set_cookie(COOKIE, token, max_age=COOKIE_DAYS * 86400, httponly=True, samesite="Strict", secure=secure, path="/")
        return resp

    @app.get("/api/rev")
    def rev():
        """Long poll: answers as soon as anything was written after `since`, or after `wait` seconds."""
        since = _int("since", -1)
        wait = min(max(_int("wait", 0, 0, 25), 0), 25)
        slots = _waiters                                       # the same one is released that was taken
        if wait and not slots.acquire(blocking=False):         # never let waiting phones use up every server thread
            wait = 0
        try:
            r = book.wait_rev(since, wait) if wait else book.rev
        finally:
            if wait:
                slots.release()
        return jsonify(rev=r, waited=bool(wait), build=build_id(), version=config.VERSION)

    @app.get("/api/ping")
    def ping():
        book.maybe_run_recurring()
        if not is_remote():                                     # a phone being open must not keep (or close) the program
            app.config["last_ping"] = time.time()
        return jsonify(app="pennyworth", version=config.VERSION, mode=config.MODE)

    @app.post("/api/shutdown")
    def shutdown():
        cb = app.config.get("shutdown_cb")
        if cb:
            cb()
        return jsonify(ok=True)

    @app.get("/api/update")
    def update_status():
        return jsonify(update_info())

    @app.post("/api/update/check")
    def update_check():
        u = app.config.get("updater")
        if not u:
            return jsonify(error="這份程式沒有自動更新功能"), 400
        u.check()
        return jsonify(update_info())

    @app.put("/api/update/settings")
    def update_settings():
        d = request.get_json(silent=True) or {}
        with book.session(notify=True) as c:
            book.set_setting(c, "update_auto", "1" if d.get("auto", True) else "0")
        return jsonify(update_info())

    @app.post("/api/update/apply")
    def update_apply():
        u = app.config.get("updater")
        if not u or u.snapshot()["state"] != "ready":
            return jsonify(error="目前沒有已下載好的新版"), 400
        cb = app.config.get("restart_cb")
        if cb:
            threading.Timer(0.6, cb).start()
        return jsonify(ok=True, restarting=bool(cb), version=u.snapshot()["ready"])

    # ---- PIN lock of the book
    def lock_info():
        return dict(enabled=applock.enabled(), idle_min=applock.idle_min(), choices=list(IDLE_CHOICES), biometric=applock.biometric())

    @app.get("/api/lock/status")
    def lock_status():
        return jsonify(enabled=applock.enabled(), locked=applock.enabled() and not applock.valid(request.cookies.get(UNLOCK_COOKIE)), biometric=config.PHONE and applock.biometric())

    @app.post("/api/lock/unlock")
    def lock_unlock():
        d = request.get_json(silent=True) or {}
        try:
            token = applock.unlock(d.get("pin"))
        except LockError as e:
            return jsonify(error=str(e)), e.status
        resp = jsonify(ok=True)
        if token:
            resp.set_cookie(UNLOCK_COOKIE, token, httponly=True, samesite="Strict", path="/")
        return resp

    @app.post("/api/lock/unlock-biometric")
    def lock_unlock_biometric():
        """Phone only. The phone has already checked Face ID / fingerprint itself (WebAuthn); this just opens the book.
        It is a convenience for the person holding the phone, like the PIN screen: it hides the book, it does not encrypt it."""
        if not config.PHONE or not applock.biometric():
            return jsonify(error="沒有開啟 Face ID／指紋解鎖"), 403
        resp = jsonify(ok=True)
        resp.set_cookie(UNLOCK_COOKIE, applock.unlock_trusted(), httponly=True, samesite="Strict", path="/")
        return resp

    @app.post("/api/lock/lock")
    def lock_now():
        applock.lock(request.cookies.get(UNLOCK_COOKIE))
        return jsonify(ok=True)

    @app.put("/api/lock")
    def lock_settings():
        """Set / change / turn off the PIN, or change the idle time. Needs the current PIN when one is already set."""
        d = request.get_json(silent=True) or {}
        try:
            resp = None
            if "idle_min" in d:
                applock.set_idle(int(d["idle_min"]))
            if "biometric" in d:
                if not config.PHONE:
                    raise LockError("只有手機版能用 Face ID／指紋")
                applock.set_biometric(bool(d["biometric"]))
            if d.get("disable"):
                applock.disable(d.get("current_pin"))
            elif d.get("pin") is not None:
                applock.set_pin(d["pin"], d.get("current_pin"))
                token = applock.unlock(d["pin"])
                resp = jsonify(lock_info())
                resp.set_cookie(UNLOCK_COOKIE, token, httponly=True, samesite="Strict", path="/")
        except (LockError, ValueError) as e:
            return jsonify(error=str(e)), getattr(e, "status", 400)
        return resp or jsonify(lock_info())

    # ---- account + password that guard "back to my own book"
    @app.put("/api/owner-lock")
    def owner_lock_settings():
        if not config.HAS_PROFILE or config.MODE != "owner":
            return jsonify(error="只能在你自己的帳本裡設定"), 403
        d = request.get_json(silent=True) or {}
        try:
            if d.get("remove"):
                ownerlock.clear(d.get("current_password"))
            else:
                ownerlock.set(d.get("account"), d.get("password"), d.get("current_password"))
        except LockError as e:
            return jsonify(error=str(e)), e.status
        return jsonify(set=ownerlock.is_set(), account=ownerlock.account())

    @app.post("/api/app-mode")
    def app_mode():
        """Owner's copy only: switch between my own book and the empty book other people start with (a restart follows)."""
        d = request.get_json(silent=True) or {}
        if not config.HAS_PROFILE:
            return jsonify(error="這份程式沒有切換功能"), 400
        mode = d.get("mode")
        try:
            if mode == "owner" and config.MODE != "owner":          # back to the real book: only with the owner's account and password
                ownerlock.verify(d.get("account"), d.get("password"))
            config.set_mode(mode, reset=bool(d.get("reset")))
        except LockError as e:
            return jsonify(error=str(e)), e.status
        except ValueError as e:
            return jsonify(error=str(e)), 400
        cb = app.config.get("restart_cb")
        if cb:
            threading.Timer(0.6, cb).start()
        return jsonify(ok=True, mode=mode, restarting=bool(cb))

    # --------------------------------------------------------------- state
    def sheets_info():
        cfg = sheets.config()
        return {**cfg, "status": dict(sheets.status)}

    def book_part(c):
        """Everything in the state call that comes out of the book itself. It changes only when something is written (or the day turns), so it is
        made once and handed out again until then: the page asks for the state after every change, on every start and whenever a window comes
        back to the front, and the same numbers need not be worked out again each time."""
        book.share_ledger(c)
        accounts = book.list_accounts(c)
        adv = book.advances(c)
        return dict(
            base=book.base_currency(c), accounts=accounts, used=sorted({a["currency"] for a in accounts}),
            categories=book.categories(c), cat_info=book.category_info(c), budgets=book.budgets(c), tag_list=book.tag_list(c), receipt_stats=book.receipt_stats(c), cat_icons=book.category_icons(c), icon_lib=book.icon_library(c), years=book.years(c), summary=book.summary(c),
            rates=book.rates_info(c), prefs=book.ui_prefs(c), templates=book.templates(c), cat_rules=book.cat_rules(c), frequent=book.frequent(c), recurring_alerts=book.recurring_alerts(c), owed=adv["by_party"], owed_alerts=adv["alerts"], friend_names=book.friend_names(c))

    @app.get("/api/state")
    def state():
        book.maybe_run_recurring()                              # entries that came due since the last look are recorded before the page is built
        with book.session() as c:
            part = dict(book.kept(c, "state", lambda: book_part(c)))
            used = part.pop("used")
            return jsonify(
                version=config.VERSION, notice=book.notice, mode=app.config.get("mode", "window"), **part, sheets=sheets_info(),
                currencies=list(dict.fromkeys(config.COMMON_CURRENCIES + used)), banks=config.BANKS, bank_order=list(config.BANKS),
                remote=is_remote() or config.LOCAL_COPY, remote_enabled=remote.enabled(), phone=config.PHONE and not config.LOCAL_COPY, local_runtime=config.UPDATE_URL.rstrip('/') + '/app/' if not config.PHONE else '', feedback_url=config.FEEDBACK_URL, share_url=config.UPDATE_URL, onboarding=(not (config.HAS_PROFILE and config.MODE == "owner")) and not is_remote() and not config.LOCAL_COPY and book.onboarding_needed(c), app_mode=dict(mode=config.MODE, can_switch=config.HAS_PROFILE and not config.PHONE, lock_set=ownerlock.is_set(), lock_account=ownerlock.account()), update=update_info(), lock=lock_info(),
            )

    # ------------------------------------------------- the answer after a change, made before it is asked for
    warm = {"rev": -1, "pending": False}
    warm_lock = threading.Lock()

    def warm_state():
        """Phone only. A change made on the phone is followed, one network round trip later, by the question for the new state.
        The answer is worked out here, in the background, so it is already waiting when the question arrives."""
        with warm_lock:
            warm["pending"] = False
        try:
            with book.session() as c:
                book.kept(c, "state", lambda: book_part(c))
        except Exception:                                       # a closed book, a restore in progress: the real question will say so
            pass

    @app.after_request
    def warm_after_write(resp):
        if request.method in ("POST", "PUT", "PATCH", "DELETE") and resp.status_code < 400 and request.path.startswith("/api/") \
                and book.rev != warm["rev"] and is_remote():
            with warm_lock:
                if not warm["pending"]:
                    warm["pending"], warm["rev"] = True, book.rev
                    timer = threading.Timer(0.02, warm_state)
                    timer.daemon = True
                    timer.start()
        return resp

    @app.put("/api/settings")
    def put_settings():
        d = body()
        if "base_currency" in d:
            book.set_base_currency(d["base_currency"])
        if d.get("onboarded"):
            book.mark_onboarded()
        if any(k in d for k in ("ui_color", "ui_hide", "ui_hide_pages")):
            book.set_ui_prefs(color=d.get("ui_color"), hide=d.get("ui_hide"), pages=d.get("ui_hide_pages"))
        if "count_transfers" in d:
            book.set_count_transfers(bool(d["count_transfers"]))
        if "home_layout" in d:
            book.set_home_layout(d["home_layout"])
        if "tile_order" in d:
            to = d["tile_order"] if isinstance(d["tile_order"], dict) else {}
            for k in ("expense", "income"):
                if k in to:
                    book.set_tile_order(k, to[k])
        return jsonify(ok=True)

    # ----------------------------------------------------- categories
    @app.post("/api/categories")
    def post_category():
        d = body()
        book.add_category(d.get("name"), d.get("kind") or "both")
        return jsonify(ok=True)

    @app.put("/api/budgets")
    def put_budget():
        d = body()
        book.set_budget(d.get("category"), d.get("amount"))
        return jsonify(ok=True)

    @app.put("/api/categories")
    def put_category():
        d = body()
        return jsonify(ok=True, **book.rename_category(d.get("name"), d.get("new_name"), d.get("kind")))

    @app.delete("/api/categories")
    def delete_category():
        return jsonify(ok=True, **book.delete_category(body().get("name")))

    # ----------------------------------------------------- category icons
    @app.put("/api/category-icons")
    def put_category_icon():
        d = body()
        book.set_category_icon(d.get("category"), d.get("icon"), d.get("color"))      # both empty = back to automatic
        return jsonify(ok=True)

    @app.post("/api/icon-library")
    def add_icon_library():
        book.add_library_icon(body().get("icon"))
        return jsonify(ok=True), 201

    @app.delete("/api/icon-library")
    def remove_icon_library():
        book.remove_library_icon(body().get("icon"))
        return jsonify(ok=True)

    # ------------------------------------------------------------ accounts
    @app.post("/api/accounts")
    def create_account():
        d = body()
        aid = book.create_account(d.get("name"), d.get("currency") or config.DEFAULT_BASE_CURRENCY,
                                  d.get("opening") or 0, d.get("icon"), d.get("color"))
        return jsonify(id=aid), 201

    @app.put("/api/accounts/order")
    def order_accounts():
        book.reorder_accounts(body().get("ids"))
        return jsonify(ok=True)

    @app.put("/api/accounts/<int:aid>")
    def update_account(aid):
        book.update_account(aid, body())
        return jsonify(ok=True)

    @app.delete("/api/accounts/<int:aid>")
    def delete_account(aid):
        book.delete_account(aid)
        return jsonify(ok=True)

    @app.get("/api/accounts/<int:aid>/wipe-preview")
    def wipe_preview(aid):
        return jsonify(book.wipe_preview(aid))

    @app.post("/api/accounts/<int:aid>/calibrate")
    def calibrate_account(aid):
        b = body()
        return jsonify(book.calibrate_account(aid, b.get("actual"), b.get("current")))

    @app.post("/api/accounts/<int:aid>/reset")
    def reset_account(aid):
        return jsonify(book.reset_account(aid, body().get("mode", "adjust")))

    # -------------------------------------------------------- transactions
    @app.get("/api/transactions")
    def list_tx():
        with book.session() as c:
            return jsonify(book.list_transactions(
                c, q=request.args.get("q", ""), typ=request.args.get("type", ""),
                account_id=_int("account_id"), category=request.args.get("category", ""),
                date_from=request.args.get("from", ""), date_to=request.args.get("to", ""),
                limit=_int("limit", 200, 1, 1000), offset=_int("offset", 0, 0),
                transfers=request.args.get("transfers", "1") != "0", tag=request.args.get("tag", ""),
                group=request.args.get("group", "")))

    @app.post("/api/transactions")
    def add_tx():
        d = body()
        cid = d.get("client_id")
        if isinstance(cid, str) and 0 < len(cid) <= 64:
            seen = book.client_op(cid)
            if seen is not None:                       # an offline phone sending the same entry again: it is already in the book
                return jsonify(id=seen, duplicate=True), 200
            tx_id = book.add_transaction(d)
            book.remember_client_op(cid, tx_id)
            book.maybe_run_recurring(force=True)
            return jsonify(id=tx_id), 201
        tx_id = book.add_transaction(d)
        book.maybe_run_recurring(force=True)                 # an advance whose due day has already come is received right away
        return jsonify(id=tx_id), 201

    @app.put("/api/transactions/<int:tid>")
    def update_tx(tid):
        book.update_transaction(tid, body())
        book.maybe_run_recurring(force=True)                 # an advance whose due day has already come is received right away
        return jsonify(ok=True)

    @app.delete("/api/transactions/<int:tid>")
    def delete_tx(tid):
        return jsonify(ok=True, undo=book.delete_transaction(tid))

    @app.post("/api/transactions/bulk")
    def bulk_tx():
        d = body()
        return jsonify(ok=True, **book.bulk_transactions(d.get("ids"), d.get("action"), category=d.get("category"), tag=d.get("tag")))

    # ------------------------------------------- advances (paid for a friend / reimbursement)
    @app.get("/api/advances")
    def get_advances():
        with book.session() as c:
            return jsonify(book.advances(c, request.args.get("state", "open")))

    @app.post("/api/advances/count-friends")
    def count_friend_advances():
        return jsonify(book.count_friend_advances(bool(body().get("on", True))))

    @app.post("/api/advances/<int:tid>/settle")
    def settle_advance(tid):
        return jsonify(book.settle_advance(tid, body())), 201

    @app.post("/api/bills")
    def create_bill():
        return jsonify(book.create_bill(body())), 201

    @app.put("/api/bills/<int:bid>")
    def rename_bill(bid):
        book.rename_bill(bid, body())
        return jsonify(ok=True)

    @app.delete("/api/bills/<int:bid>")
    def delete_bill(bid):
        return jsonify(ok=True, undo=book.delete_bill(bid))

    @app.post("/api/advances/delete")
    def delete_advances():
        return jsonify(book.delete_advances(body().get("ids")))

    @app.post("/api/advances/<int:tid>/write-off")
    def write_off_advance(tid):
        book.write_off_advance(tid)
        return jsonify(ok=True)

    @app.post("/api/advances/<int:tid>/reopen")
    def reopen_advance(tid):
        book.reopen_advance(tid)
        return jsonify(ok=True)

    # ------------------------------------------------------------ quick templates
    @app.get("/api/templates")
    def get_templates():
        with book.session() as c:
            return jsonify(items=book.templates(c))

    @app.get("/api/frequent")
    def get_frequent():
        """Entries typed before (not yet saved as templates), most repeated first."""
        try:
            limit = max(1, min(100, int(request.args.get("limit", 50))))
        except ValueError:
            limit = 50
        with book.session() as c:
            return jsonify(items=book.frequent(c, limit), hidden=len(book.hidden_frequent(c)))

    @app.post("/api/frequent/hide")
    def hide_frequent():
        book.hide_frequent(body().get("key"))
        return jsonify(ok=True)

    @app.post("/api/frequent/restore")
    def restore_frequent():
        book.restore_frequent()
        return jsonify(ok=True)

    @app.post("/api/templates")
    def add_template():
        return jsonify(id=book.save_template(body())), 201

    @app.put("/api/templates/order")
    def order_templates():
        book.reorder_templates(body().get("ids"))
        return jsonify(ok=True)

    @app.put("/api/templates/<int:tid>")
    def put_template(tid):
        book.save_template(body(), tid)
        return jsonify(ok=True)

    @app.delete("/api/templates/<int:tid>")
    def del_template(tid):
        book.delete_template(tid)
        return jsonify(ok=True)

    # ------------------------------------------------------ category rules (1.62.0)
    @app.get("/api/cat-rules")
    def get_cat_rules():
        with book.session() as c:
            return jsonify(items=book.cat_rules(c))

    @app.put("/api/cat-rules")
    def put_cat_rules():
        return jsonify(items=book.save_cat_rules(body().get("items")))

    @app.post("/api/cat-rules/preview")
    def preview_cat_rules():
        return jsonify(book.preview_cat_rules())

    @app.post("/api/cat-rules/apply")
    def apply_cat_rules():
        return jsonify(ok=True, **book.apply_cat_rules_to_past())

    # ------------------------------------------------------ recurring entries (rent, subscriptions...)
    @app.get("/api/recurring")
    def get_recurring():
        book.maybe_run_recurring()
        with book.session() as c:
            return jsonify(items=book.recurring(c))

    @app.post("/api/recurring")
    def add_recurring():
        return jsonify(book.save_recurring(body())), 201

    @app.put("/api/recurring/<int:rid>")
    def put_recurring(rid):
        return jsonify(book.save_recurring(body(), rid))

    @app.post("/api/recurring/<int:rid>/active")
    def active_recurring(rid):
        return jsonify(book.set_recurring_active(rid, bool(body().get("on"))))

    @app.delete("/api/recurring/<int:rid>")
    def del_recurring(rid):
        book.delete_recurring(rid)
        return jsonify(ok=True)

    @app.post("/api/undo")
    def undo_delete():
        return jsonify(ok=True, restored=book.undo(body().get("token")))

    # ------------------------------------------------------ the phone's working copy (1.63.0, app/localcopy.py)
    @app.get("/api/local/snapshot")
    def local_snapshot():
        data, meta = localcopy.snapshot(book, applock.path)
        resp = Response(data, mimetype="application/zip")
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Snapshot-Rev"] = str(meta["rev"])
        resp.headers["X-Snapshot-MaxTx"] = str(meta.get("max_tx_id", 0))
        resp.headers["X-Snapshot-Version"] = meta["version"]
        return resp

    @app.get("/api/local/engine")
    def local_engine():
        resp = Response(localcopy.engine(), mimetype="application/zip")
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Snapshot-Version"] = config.VERSION
        return resp

    # ------------------------------------------------------ receipt photos
    @app.post("/api/transactions/<int:tid>/receipts")
    def add_receipt(tid):
        return jsonify(id=book.add_receipt(tid, request.get_data())), 201

    @app.get("/api/receipts/<int:rid>")
    def get_receipt(rid):
        mime, data = book.get_receipt(rid)
        resp = app.response_class(data, mimetype=mime)
        resp.headers["Cache-Control"] = "private, max-age=86400"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Content-Disposition"] = "inline"
        return resp

    @app.delete("/api/receipts/<int:rid>")
    def delete_receipt(rid):
        book.delete_receipt(rid)
        return jsonify(ok=True)

    # --------------------------------------------------------------- rates
    @app.put("/api/rates")
    def put_rates():
        book.set_rates(body().get("rates") or {})
        return jsonify(ok=True)

    @app.post("/api/rates/refresh")
    def refresh_rates():
        return jsonify(book.refresh_rates())

    # ------------------------------------------------- bank rates / exchange
    @app.get("/api/fx/board")
    def fx_board():
        with book.session() as c:
            return jsonify(book.bank_board(c, request.args.get("currency", "")))

    @app.put("/api/fx/rates")
    def fx_put_rates():
        d = body()
        saved = book.set_bank_rates(d.get("bank"), d.get("currency"), buy=d.get("buy"), sell=d.get("sell"), source=d.get("source") or "manual")
        return jsonify(ok=True, saved=saved)

    @app.post("/api/fx/fetch")
    def fx_fetch():
        d = body()
        return jsonify(book.fetch_web_rates(d.get("currency"), save=d.get("save", True) is not False,
                                            fetcher=app.config.get("fx_fetcher")))

    @app.get("/api/remote")
    def remote_info():
        return jsonify(remote.info())

    @app.put("/api/remote")
    def remote_set():
        d = body()
        if "url" in d:
            try:
                remote.set_url(d["url"])
            except ValueError as e:
                raise BookError(str(e)) from None
        if "enabled" in d:
            remote.set_enabled(bool(d["enabled"]))
        return jsonify(remote.info())

    @app.post("/api/remote/code")
    def remote_code():
        if not remote.enabled():
            raise BookError("請先開啟手機連線")
        return jsonify(remote.new_code())

    @app.put("/api/remote/devices/<int:did>")
    def remote_device_rename(did):
        remote.rename(did, body().get("name"))
        return jsonify(remote.info())

    @app.delete("/api/remote/devices/<int:did>")
    def remote_device_remove(did):
        remote.revoke(did)
        return jsonify(remote.info())

    @app.delete("/api/remote/devices")
    def remote_device_remove_all():
        remote.revoke()
        return jsonify(remote.info())

    @app.get("/api/fx/auto")
    def fx_auto_info():
        return jsonify(fxauto.info())

    @app.get("/api/invest/auto")
    def invest_auto_info():
        return jsonify(stockauto.info())

    @app.put("/api/invest/auto")
    def invest_auto_set():
        stockauto.set_enabled(bool(body().get("enabled")))
        return jsonify(stockauto.info())

    @app.put("/api/fx/auto")
    def fx_auto_set():
        fxauto.set_enabled(bool(body().get("enabled")))
        return jsonify(fxauto.info())

    @app.get("/api/fx/history")
    def fx_history():
        with book.session() as c:
            return jsonify(book.bank_history(c, request.args.get("bank", ""), request.args.get("currency", ""),
                                             request.args.get("side", "sell"), _int("days", 7, 1, 800)))

    @app.post("/api/exchange")
    def exchange():
        return jsonify(book.exchange(body())), 201

    # ---------------------------------------------------------- investments
    @app.get("/api/invest")
    def invest_board():
        with book.session() as c:
            return jsonify(book.invest_board(c))

    # ---------------------------------------------------------- the whole market
    @app.get("/api/market")
    def market_list():
        rows = [[r["c"], r["n"], r["m"], r["k"], r["p"], r["ch"], r["o"], r["h"], r["l"], r["v"]] for r in market.rows()]
        return jsonify(info=market.info(), rows=rows)

    @app.post("/api/market/refresh")
    def market_refresh():
        info = market.refresh()
        return jsonify(info=info, rows=[[r["c"], r["n"], r["m"], r["k"], r["p"], r["ch"], r["o"], r["h"], r["l"], r["v"]] for r in market.rows()])

    @app.get("/api/market/history")
    def market_history():
        try:
            return jsonify(market.history(request.args.get("symbol"), request.args.get("range") or "1y"))
        except MarketError as e:
            return jsonify(error=str(e)), 502

    @app.post("/api/invest/fetch")
    def invest_fetch():
        return jsonify(book.fetch_stock_prices(fetcher=app.config.get("price_fetcher"), force=bool(body().get("force"))))

    @app.put("/api/invest/price")
    def invest_price():
        d = body()
        book.set_price(d.get("symbol"), d.get("price"), d.get("source") or "manual")
        return jsonify(ok=True)

    @app.post("/api/invest/trades")
    def invest_trade():
        return jsonify(book.trade(body())), 201

    @app.put("/api/invest/trades/<int:tid>")
    def invest_update_trade(tid):
        return jsonify(book.update_trade(tid, body()))

    @app.post("/api/invest/trades/delete")
    def invest_delete_trades():
        return jsonify(book.delete_trades(body().get("ids")))

    @app.delete("/api/invest/trades/<int:tid>")
    def invest_delete_trade(tid):
        return jsonify(ok=True, undo=book.delete_trade(tid))

    @app.post("/api/invest/securities")
    def invest_add_security():
        d = body()
        aid = book.add_security(d.get("symbol"), d.get("name"), d.get("market"), account_id=d.get("account_id"),
                                account_name=d.get("account_name"), account_currency=d.get("account_currency"))
        return jsonify(id=aid), 201

    @app.put("/api/invest/securities/<int:aid>")
    def invest_update_security(aid):
        book.update_security(aid, body())
        return jsonify(ok=True)

    @app.delete("/api/invest/securities/<int:aid>")
    def invest_remove_security(aid):
        book.remove_security(aid)
        return jsonify(ok=True)

    @app.put("/api/invest/settings")
    def invest_settings():
        book.set_invest_settings(fee_discount=body().get("fee_discount"))
        return jsonify(ok=True)

    # ------------------------------------------------------------- reports
    def period():
        year = _int("year", datetime.now().year, 1970, 2200)
        month = _int("month", None, 1, 12)
        return year, month

    @app.get("/api/reports/breakdown")
    def r_breakdown():
        y, m = period()
        gb = request.args.get("group_by", "category")
        if gb not in ("category", "note", "tag"):
            raise BookError("group_by 必須是 category、note 或 tag")
        with book.session() as c:
            return jsonify(reports.breakdown(book, c, y, m, gb, _int("max", 8, 2, 30)))

    @app.get("/api/reports/tag")
    def r_tag():
        with book.session() as c:
            return jsonify(reports.tag_summary(book, c, request.args.get("tag", "")))

    @app.get("/api/reports/compare")
    def r_compare():
        y, m = period()
        with book.session() as c:
            return jsonify(reports.compare(book, c, y, m, request.args.get("kind", "expense"),
                                              months=request.args.get("months") or None, years=request.args.get("years") or None))

    @app.get("/api/reports/trend")
    def r_trend():
        y, m = period()
        with book.session() as c:
            return jsonify(reports.trend(book, c, y, m))

    @app.get("/api/reports/balances")
    def r_balances():
        y = _int("year", None, 1970, 2200)
        m = _int("month", None, 1, 12)
        n = _int("days", None, 1, 36500)                      # the last N days instead of a year / month (1.65.0)
        sel = [s for s in request.args.get("accounts", "total").split(",") if s]
        for s in sel:
            if s != "total" and not s.isdigit():
                raise BookError("accounts 參數不正確")
        with book.session() as c:
            return jsonify(reports.balance_series(book, c, sel, y, m, n, request.args.get("convert") == "1"))

    @app.get("/api/review")
    def r_review():
        """The month in a few lines. ?month=YYYY-MM (default: the month before this one)."""
        raw = request.args.get("month", "")
        today = datetime.now()
        if raw:
            if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", raw):
                raise BookError("月份格式要是 年-月，例如 2026-10")
            y, m = int(raw[:4]), int(raw[5:])
        else:
            y, m = (today.year, today.month - 1) if today.month > 1 else (today.year - 1, 12)
        with book.session() as c:
            return jsonify(reports.review(book, c, y, m))

    @app.get("/api/goals")
    def goals_list():
        with book.session() as c:
            return jsonify(book.goals(c))

    @app.post("/api/goals")
    def goals_add():
        return jsonify(book.add_goal(body())), 201

    @app.put("/api/goals/<int:gid>")
    def goals_update(gid):
        return jsonify(book.update_goal(gid, body()))

    @app.delete("/api/goals/<int:gid>")
    def goals_delete(gid):
        book.delete_goal(gid)
        return jsonify(ok=True)

    @app.post("/api/invest/dividends")
    def dividend_add():
        return jsonify(book.add_dividend(body())), 201

    @app.put("/api/invest/dividends/<int:did>")
    def dividend_update(did):
        return jsonify(book.update_dividend(did, body()))

    @app.delete("/api/invest/dividends/<int:did>")
    def dividend_delete(did):
        return jsonify(book.delete_dividend(did))

    @app.get("/api/networth")
    def r_networth():
        """Net worth day by day. ?days=N looks back N days (0 or missing = since the first transaction)."""
        d = _int("days", 0, 0, 36500)
        with book.session() as c:
            return jsonify(reports.networth_series(book, c, d))

    # -------------------------------------------------------------- import
    @app.post("/api/import/files")
    def import_files():
        files = request.files.getlist("files")
        if not files:
            raise BookError("請選擇要匯入的檔案（accounts.json、transactions.csv）")
        accounts_json, csvs = None, {}
        for f in files:
            name = (f.filename or "").lower()
            data = f.read()
            if name.endswith(".json"):
                accounts_json = data
            elif name.endswith(".csv"):
                csvs[name] = data
            else:
                raise BookError(f"不支援的檔案：{f.filename}（只接受 .json 與 .csv）")
        rows, final = [], {}
        if csvs:
            pick = "transactions.csv" if "transactions.csv" in csvs else sorted(csvs)[0]
            rows = importer.read_csv_rows(csvs[pick])
            final = importer.final_from_rows(rows)
        if accounts_json is not None:
            final = importer.read_accounts_json(accounts_json)
        if not rows and not final:
            raise BookError("檔案裡沒有可匯入的資料")
        return jsonify(importer.import_legacy(book, rows, final))

    def _import_inputs():
        files = [(f.filename or "", f.read()) for f in request.files.getlist("files")]
        try:
            opts = json.loads(request.form.get("options") or "{}")
        except ValueError:
            raise BookError("匯入設定不正確") from None
        if not isinstance(opts, dict):
            raise BookError("匯入設定不正確")
        return files, opts

    @app.post("/api/import/preview")
    def import_preview():
        files, opts = _import_inputs()
        return jsonify(importer.plan(book, files, opts))

    @app.post("/api/import/commit")
    def import_commit():
        files, opts = _import_inputs()
        return jsonify(importer.run(book, files, opts))

    @app.get("/api/import/last")
    def import_last():
        return jsonify(backup=book.last_import_backup())

    # ---------------------------------------------------------------- export
    def _csv_download(filename, headers, rows):
        """Phone: there is no folder to write into, so the CSV text goes back to the page, which hands it to the browser as a download."""
        import io
        buf = io.StringIO(newline="")
        w = csv.writer(buf)
        w.writerow(headers)
        w.writerows(rows)
        return dict(filename=filename, content="\ufeff" + buf.getvalue(), rows=len([r for r in rows if r and r[0] not in ("合計支出", "合計收入")]))

    @app.post("/api/export")
    def export_csv():
        with book.session() as c:
            headers, rows = book.balance_table(c)
        if config.PHONE:
            return jsonify(**_csv_download(f"transactions_balances_{datetime.now():%Y%m%d-%H%M%S}.csv", headers, rows))
        book.export_dir.mkdir(parents=True, exist_ok=True)
        path = book.export_dir / f"transactions_balances_{datetime.now():%Y%m%d-%H%M%S}.csv"
        with open(path, "w", newline="", encoding="utf-8-sig") as f:   # BOM so Excel shows 中文
            w = csv.writer(f)
            w.writerow(headers)
            w.writerows(rows)
        return jsonify(path=str(path), rows=len(rows))

    @app.get("/api/autostart")
    def autostart_status():
        try:
            return jsonify(autostart.status())
        except autostart.AutostartError as e:
            raise BookError(str(e)) from None

    @app.put("/api/autostart")
    def autostart_set():
        on = bool(body().get("enabled"))
        try:
            autostart.enable() if on else autostart.disable()
            return jsonify(autostart.status())
        except autostart.AutostartError as e:
            raise BookError(str(e)) from None

    @app.post("/api/export/tag")
    def export_tag():
        with book.session() as c:
            name, headers, rows = reports.tag_rows(book, c, body().get("tag", ""))
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in name)[:40] or "tag"
        if config.PHONE:
            return jsonify(**_csv_download(f"tag_{safe}_{datetime.now():%Y%m%d-%H%M%S}.csv", headers, rows))
        book.export_dir.mkdir(parents=True, exist_ok=True)
        path = book.export_dir / f"tag_{safe}_{datetime.now():%Y%m%d-%H%M%S}.csv"
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(headers)
            w.writerows(rows)
        return jsonify(path=str(path), rows=len([r for r in rows if r and r[0] not in ("合計支出", "合計收入")]))

    @app.post("/api/open-folder")
    def open_folder():
        which = body().get("which", "data")
        folder = {"data": book.data_dir, "exports": book.export_dir, "backups": book.backup_dir}.get(which)
        if folder is None:
            raise BookError("未知的資料夾")
        folder.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(folder))  # noqa
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        return jsonify(path=str(folder))

    # --------------------------------------------------------------- backups
    @app.get("/api/backups")
    def backups():
        return jsonify(items=book.list_backups())

    @app.post("/api/backups")
    def make_backup():
        return jsonify(name=book.backup("manual").name), 201

    @app.get("/api/autobackup")
    def get_autobackup():
        return jsonify(autobackup.info())

    @app.put("/api/autobackup")
    def put_autobackup():
        d = body()
        try:
            autobackup.configure(enabled=bool(d["enabled"]) if "enabled" in d else None, folder=d.get("folder"))
        except ValueError as e:
            raise BookError(str(e))
        return jsonify(autobackup.info())

    @app.post("/api/autobackup/run")
    def run_autobackup():
        ok = autobackup.run_once("manual")
        if not ok and autobackup.status["error"]:
            raise BookError(f"備份失敗：{autobackup.status['error']}", 500)
        return jsonify(autobackup.info())

    # ---- phone: the book lives inside the browser, so the person keeps a copy as an ordinary file
    @app.get("/api/phone/backup")
    def phone_backup():
        from flask import Response
        data = book.backup("phonefile").read_bytes()              # a consistent snapshot (SQLite online backup)
        name = f"pennyworth-{datetime.now():%Y%m%d-%H%M%S}.db"
        return Response(data, mimetype="application/octet-stream", headers={"Content-Disposition": f'attachment; filename="{name}"'})

    @app.post("/api/phone/restore")
    def phone_restore():
        f = request.files.get("file")
        if f is None:
            raise BookError("請選擇備份檔")
        data = f.read()
        if len(data) > 200 * 1024 * 1024 or not data.startswith(b"SQLite format 3\x00"):
            raise BookError("這不是 Tallomi 的備份檔")
        book.backup_dir.mkdir(parents=True, exist_ok=True)
        name = f"pennyworth-{datetime.now():%Y%m%d-%H%M%S}-uploaded.db"
        dest = book.backup_dir / name
        dest.write_bytes(data)
        try:
            book.restore_backup(name)                            # validates, backs the current book up first, then replaces it
        except BookError:
            dest.unlink(missing_ok=True)
            raise
        return jsonify(ok=True)

    @app.delete("/api/backups")
    def delete_backups():
        return jsonify(ok=True, deleted=book.delete_backups(body().get("names")))

    @app.post("/api/backups/restore")
    def restore_backup():
        book.restore_backup(body().get("name"))
        return jsonify(ok=True)

    @app.post("/api/clear-all")
    def clear_all():
        if body().get("confirm") != "清除全部":
            raise BookError("請輸入「清除全部」以確認")
        return jsonify(book.clear_everything())

    # ---------------------------------------------------------------- sheets
    @app.get("/api/sheets")
    def sheets_get():
        return jsonify(sheets_info())

    @app.put("/api/sheets/config")
    def sheets_config():
        d = body()
        sheets.save_config(key=d.get("key"), worksheet=d.get("worksheet"), auto=d.get("auto"))
        return jsonify(sheets_info())

    @app.post("/api/sheets/service-account")
    def sheets_upload_sa():
        f = request.files.get("file")
        if not f:
            raise BookError("請選擇 service_account.json")
        email = sheets.save_service_account(f.read())
        return jsonify(email=email)

    @app.post("/api/sheets/retry")
    def sheets_retry():
        sheets.retry_now()
        return jsonify(ok=True)

    @app.post("/api/sheets/test")
    def sheets_test():
        return jsonify(sheets.test())

    @app.post("/api/sheets/push")
    def sheets_push():
        return jsonify(sheets.push_all(force=bool(body().get("force"))))

    @app.post("/api/sheets/open")
    def sheets_open():
        url = sheets.sheet_url()
        try:
            webbrowser.open(url)
        except Exception:
            pass
        return jsonify(url=url)

    @app.post("/api/sheets/import")
    def sheets_import():
        title = (body().get("worksheet") or "").strip()
        if not title:
            raise BookError("請選擇要匯入的工作表")
        rows = sheets.read_rows(title)
        if not rows:
            raise BookError(f"工作表「{title}」沒有資料")
        if "time" not in rows[0]:
            raise BookError("這個工作表沒有 time 欄位，格式與舊版記帳表不同")
        return jsonify(importer.import_legacy(book, rows, importer.final_from_rows(rows)))

    return app
