"""Keep the small launcher that the desktop / taskbar shortcuts use up to date (1.71.0).

The shortcuts do not point into the program folder (it can be moved): they point at copies of tools/launch.* kept in
%LOCALAPPDATA%\\Pennyworth\\launcher. Those copies used to be refreshed only by running create_shortcut.bat again, so an improved launcher
never reached anyone by itself. Now every start (and so every update) puts the current files there, when that folder exists.
"""
import logging
import os
import shutil
from pathlib import Path

log = logging.getLogger("pennyworth")
FILES = ("launch.vbs", "launch.cmd", "launch.ps1")


def refresh(program_dir, local_appdata=None):
    """Copy the launcher files that differ; returns the names copied. Never raises: a locked or missing file just waits for the next start."""
    base = local_appdata or os.environ.get("LOCALAPPDATA")
    if not base:
        return []
    dest = Path(base) / "Pennyworth" / "launcher"
    if not dest.is_dir():                         # no shortcuts were ever made here: nothing to keep up to date
        return []
    done = []
    for name in FILES:
        src = Path(program_dir) / "tools" / name
        try:
            if src.is_file() and (not (dest / name).is_file() or (dest / name).read_bytes() != src.read_bytes()):
                shutil.copyfile(src, dest / name)
                done.append(name)
        except OSError:
            log.info("launcher file %s could not be updated now", name)
    if done:
        log.info("launcher refreshed: %s", ", ".join(done))
    return done
