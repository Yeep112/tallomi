"""Software updates for the copies given to other people.

How it works
  * The owner publishes a small list (manifest.json) and its signature (manifest.sig) next to the new program zip.
  * The program asks for the list now and then (only when it is online; offline it simply keeps working), checks the
    signature against the public key built into the program, then downloads the zip and checks its size and SHA-256.
  * The downloaded update waits. It is applied the next time the program starts (or when the user presses "立即更新"):
    first a backup of the book, then a snapshot of the current program, then the new files are copied in.
  * If the new version does not manage to start, the next start puts the snapshot back and never tries that version again.
Nothing here touches the books (they live in the user's data folder, not in the program folder).
"""
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath

from . import config, db, ed25519

log = logging.getLogger("pennyworth")

MAX_MANIFEST = 200_000
MAX_ZIP = 80 * 1024 * 1024
ZIP_RE = re.compile(r"^(Pennyworth|Tallomi)-\d+(\.\d+){1,3}\.zip$")
PROTECT_DIRS = {".venv", "__pycache__", ".pytest_cache"}      # never copied over, never removed
PROTECT_FILES = {".pennyworth-home"}
NEVER_FROM_PACKAGE = {"app/owner_profile.json"}
CLEAN_DIRS = ("app", "tools", "assets")                       # stale files in these are removed after a copy
CHECK_EVERY = 6 * 3600
RETRY_OFFLINE = 30 * 60


def vtuple(v):
    nums = [int(x) for x in re.findall(r"\d+", str(v))[:4]]
    return tuple(nums + [0] * (4 - len(nums)))


def _now():
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _http_get(url, limit):
    """Plain download with a size limit. Only https (or http to this very computer, for tests)."""
    low = url.lower()
    if not (low.startswith("https://") or low.startswith("http://127.0.0.1") or low.startswith("http://localhost")):
        raise ValueError("update address must be https")
    req = urllib.request.Request(url, headers={"User-Agent": f"Pennyworth/{config.VERSION}", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=20) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("download is larger than expected")
    return data


def _program_files(root):
    """Every file of a program folder as relative posix paths (without the private environment and caches)."""
    out = []
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in PROTECT_DIRS]
        for f in files:
            p = Path(dirpath) / f
            rel = p.relative_to(root).as_posix()
            if f.endswith(".pyc") or f.endswith(".log") or rel in NEVER_FROM_PACKAGE:
                continue
            out.append(rel)
    return sorted(out)


def _copy_files(src_root, dst_root, rels):
    for rel in rels:
        s, d = Path(src_root) / rel, Path(dst_root) / rel
        d.parent.mkdir(parents=True, exist_ok=True)
        tmp = d.with_name(d.name + ".pwnew")
        shutil.copy2(s, tmp)
        os.replace(tmp, d)


def _remove_stale(program, keep_rels):
    keep = set(keep_rels)
    for top in CLEAN_DIRS:
        root = Path(program) / top
        if not root.is_dir():
            continue
        for dirpath, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in PROTECT_DIRS]
            for f in files:
                rel = (Path(dirpath) / f).relative_to(program).as_posix()
                if rel not in keep and rel not in NEVER_FROM_PACKAGE and not f.endswith(".pyc"):
                    try:
                        (Path(dirpath) / f).unlink()
                    except OSError:
                        pass
    for f in Path(program).iterdir():
        if f.is_file() and f.name not in PROTECT_FILES and not f.name.startswith(".") and f.name not in keep and not f.name.endswith(".log"):
            try:
                f.unlink()
            except OSError:
                pass


def tops_one(tops):
    return next(iter(tops))


class UpdateError(Exception):
    pass


class Updater:
    def __init__(self, book_dir=None, updates_dir=None, program_dir=None, base_url=None, current=None, fetch=None, pubkey=None,
                 auto_get=None, preflight=True):
        self.book_dir = Path(book_dir) if book_dir else None
        self.dir = Path(updates_dir) if updates_dir else config.data_dir() / "updates"
        self.program = Path(program_dir) if program_dir else config.PROGRAM_DIR
        self.base = (base_url or config.UPDATE_URL).rstrip("/") + "/"
        self.current = current or config.VERSION
        self._fetch = fetch or _http_get
        self.pubkey = pubkey if pubkey is not None else config.update_pubkey()
        self.auto_get = auto_get or (lambda: True)
        self.preflight = preflight
        self._lock = threading.RLock()
        self.status = {"state": "idle", "latest": "", "notes": [], "error": "", "last_checked": "", "ready": "", "released": "", "manual": False}
        self.dir.mkdir(parents=True, exist_ok=True)
        pend = self._read("pending.json")
        if pend and vtuple(pend.get("version", "0")) > vtuple(self.current) and (self.dir / pend.get("zip", "?")).exists():
            self.status.update(state="ready", ready=pend["version"], latest=pend["version"], notes=pend.get("notes", []), released=pend.get("released", ""))
        elif pend:
            self._discard_pending()
        saved = self._read("status.json") or {}
        self.status["last_checked"] = saved.get("last_checked", "")
        self.last_check = saved.get("last_check") if isinstance(saved.get("last_check"), dict) else {}

    # ------------------------------------------------------------------ small files
    def _read(self, name):
        try:
            return json.loads((self.dir / name).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def _write(self, name, data):
        tmp = self.dir / (name + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.dir / name)

    def _remove(self, name):
        try:
            (self.dir / name).unlink()
        except OSError:
            pass

    def bad_versions(self):
        return set((self._read("bad_versions.json") or []))

    def _mark_bad(self, version):
        bad = self.bad_versions()
        bad.add(version)
        self._write("bad_versions.json", sorted(bad))

    def _discard_pending(self):
        pend = self._read("pending.json")
        if pend and pend.get("zip"):
            try:
                (self.dir / pend["zip"]).unlink()
            except OSError:
                pass
        self._remove("pending.json")

    # ------------------------------------------------------------------ checking
    def snapshot(self):
        with self._lock:
            return dict(self.status, current=self.current, enabled=True, source=self.base, last_check=dict(self.last_check),
                        failure=self._read("failure.json") or None)

    def ack_failure(self):
        """The person has seen why the last update did not stay: keep the record (Settings still shows it), stop the home-page notice."""
        with self._lock:
            f = self._read("failure.json")
            if f and not f.get("seen"):
                self._write("failure.json", dict(f, seen=True))
        return self.snapshot()

    def _record_failure(self, version, back_to, reason, kind):
        """kind: 'rollback' (the new version did not start, the old one was put back) or 'skipped' (it was refused before anything changed)."""
        try:
            self._write("failure.json", {"version": version, "back_to": back_to, "reason": str(reason)[:300], "kind": kind, "at": _now(), "seen": False})
        except OSError:
            log.exception("could not record the failed update")

    def read_manifest(self):
        """Fetch the list and its signature; return the list only if the signature is the owner's."""
        if not self.pubkey:
            raise UpdateError("這份程式沒有內建更新金鑰")
        raw = self._fetch(self.base + "manifest.json", MAX_MANIFEST)
        sig_text = self._fetch(self.base + "manifest.sig", 1000).decode("ascii", "replace").strip()
        try:
            sig = bytes.fromhex(sig_text)
        except ValueError:
            raise UpdateError("更新清單的簽章格式不對，已忽略")
        if not ed25519.verify(self.pubkey, raw, sig):
            raise UpdateError("更新清單的簽章不符，已忽略（不會下載）")
        m = json.loads(raw.decode("utf-8"))
        if m.get("app") != "pennyworth" or not re.fullmatch(r"\d+(\.\d+){1,3}", str(m.get("version", ""))):
            raise UpdateError("更新清單的內容不正確，已忽略")
        return m

    def check(self):
        """Ask for the newest version; download it when there is one. Safe to call any time; never raises."""
        with self._lock:
            if self.status["state"] in ("checking", "downloading"):
                return self.snapshot()
            prev_state = self.status["state"]
            self.status.update(state="checking", error="")
        try:
            m = self.read_manifest()
        except UpdateError as e:
            self._finish(state="error", error=str(e), checked=True)
            return self.snapshot()
        except Exception as e:      # no network, address not there yet, timeouts ...
            log.info("update check: no answer (%s)", e)
            self._finish(state="ready" if prev_state == "ready" else "offline", error="", checked=False)
            return self.snapshot()
        latest = m["version"]
        for v in m.get("bad_versions", []):
            if v != self.current:
                self._mark_bad(v)
        notes = [str(n)[:300] for n in m.get("notes", [])][:12]
        if vtuple(latest) <= vtuple(self.current):
            self._discard_pending()
            self._finish(state="uptodate", latest=latest, notes=[], ready="", checked=True)
        elif latest in self.bad_versions():
            self._finish(state="uptodate", latest=self.current, notes=[], checked=True)
        elif m.get("manual") or vtuple(self.current) < vtuple(m.get("min_version", "0")):
            self._finish(state="manual", latest=latest, notes=notes, manual=True, checked=True)
        elif (self._read("pending.json") or {}).get("version") == latest:
            self._finish(state="ready", latest=latest, notes=notes, ready=latest, checked=True)
        elif not self.auto_get():
            self._finish(state="available", latest=latest, notes=notes, released=str(m.get("released", "")), checked=True)
        else:
            self.download(m)
        return self.snapshot()

    def _finish(self, state, checked=False, **kw):
        with self._lock:
            self.status.update(state=state, **kw)
            now = _now()
            if checked:
                self.status["last_checked"] = now
            # Every try is written down, answered or not, so Settings can say when it last looked, where, and what came back.
            self.last_check = {"at": now, "source": self.base, "result": state, "latest": self.status.get("latest", ""),
                               "error": self.status.get("error", "") if state == "error" else ""}
            self._write("status.json", {"last_checked": self.status["last_checked"], "last_check": self.last_check})

    def download(self, m=None):
        """Download the version named in the (already verified) list, check it, and keep it for the next start."""
        try:
            if m is None:
                m = self.read_manifest()
            name = str(m.get("zip", ""))
            if not ZIP_RE.match(name):
                raise UpdateError("更新檔名稱不正確，已忽略")
            size, sha = int(m.get("size", 0)), str(m.get("sha256", "")).lower()
            if not (0 < size <= MAX_ZIP) or not re.fullmatch(r"[0-9a-f]{64}", sha):
                raise UpdateError("更新清單缺少檔案大小或雜湊，已忽略")
            with self._lock:
                self.status.update(state="downloading", latest=m["version"], notes=[str(n)[:300] for n in m.get("notes", [])][:12])
            data = self._fetch(self.base + name, size)
            if len(data) != size or hashlib.sha256(data).hexdigest() != sha:
                raise UpdateError("下載的更新檔與簽章清單不符，已丟棄")
            tmp = self.dir / (name + ".part")
            tmp.write_bytes(data)
            os.replace(tmp, self.dir / name)
            self._write("pending.json", {"version": m["version"], "zip": name, "sha256": sha, "size": size,
                                         "notes": self.status["notes"], "released": str(m.get("released", ""))})
            self._finish(state="ready", ready=m["version"], released=str(m.get("released", "")), checked=True)
        except UpdateError as e:
            self._finish(state="error", error=str(e), checked=True)
        except Exception as e:
            log.info("update download failed: %s", e)
            self._finish(state="offline", error="", checked=False)
        return self.snapshot()

    # ------------------------------------------------------------------ applying
    def _preflight(self, staged, version):
        """Compile the new program and try to import it in a separate process, before anything is replaced."""
        if not self.preflight or getattr(sys, "frozen", False):
            return
        import compileall
        if not compileall.compile_dir(str(staged / "app"), quiet=2, force=True, legacy=False, workers=1):
            raise UpdateError(f"新版 {version} 的程式檔有錯誤，沒有更新")
        code = "import sys; sys.path.insert(0, sys.argv[1]); import app.server, app.updater"
        env = dict(os.environ, PENNYWORTH_DATA_DIR=str(self.dir / "preflight"), PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
        env.pop("PENNYWORTH_UPDATES", None)
        r = subprocess.run([sys.executable, "-I", "-c", code, str(staged)], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90, env=env)
        shutil.rmtree(self.dir / "preflight", ignore_errors=True)
        if r.returncode != 0:
            log.error("update preflight failed: %s", r.stderr[-800:])
            raise UpdateError(f"新版 {version} 無法在這台電腦啟動，沒有更新")

    def apply_pending(self):
        """Put the downloaded version in place. Returns the new version, or None when there was nothing to do / it failed."""
        with self._lock:
            pend = self._read("pending.json")
            if not pend:
                return None
            zpath = self.dir / pend.get("zip", "?")
            version = pend.get("version", "")
            try:
                if vtuple(version) <= vtuple(self.current):
                    self._discard_pending()
                    return None
                if not zpath.exists() or _sha256(zpath) != pend.get("sha256"):
                    raise UpdateError("已下載的更新檔不完整，已丟棄；之後會重新下載")
                self.status.update(state="applying")
                if self.book_dir and (self.book_dir / "pennyworth.db").exists():
                    try:
                        db.make_backup(self.book_dir / "pennyworth.db", self.book_dir / "backups", "before-update")
                    except Exception as e:
                        raise UpdateError(f"更新前無法備份帳本（{e}），所以沒有更新")
                staging = self.dir / "staging"
                shutil.rmtree(staging, ignore_errors=True)
                staging.mkdir(parents=True)
                with zipfile.ZipFile(zpath) as z:
                    names = [n for n in z.namelist() if not n.endswith("/")]
                    tops = {n.split("/", 1)[0] for n in names}
                    if len(tops) != 1:
                        raise UpdateError("更新檔的結構不正確")
                    for n in names:
                        parts = PurePosixPath(n).parts
                        if n.startswith(("/", "\\")) or "\\" in n or ".." in parts or ":" in parts[0]:
                            raise UpdateError("更新檔含有不安全的路徑")
                        if (staging / tops_one(tops)).resolve() not in (staging / n).resolve().parents:
                            raise UpdateError("更新檔含有不安全的路徑")
                    z.extractall(staging)
                root = staging / tops.pop()
                cfg = (root / "app" / "config.py").read_text(encoding="utf-8")
                found = re.search(r'^VERSION\s*=\s*"([^"]+)"', cfg, re.M)
                if not (root / "run.py").exists() or not found or found.group(1) != version:
                    raise UpdateError("更新檔的內容與清單不符")
                if (root / "app" / "owner_profile.json").exists():
                    raise UpdateError("更新檔含有不該有的個人檔案")
                self._preflight(root, version)
                new_files = [r for r in _program_files(root) if r not in NEVER_FROM_PACKAGE]
                # snapshot of what is installed now, so a version that does not start can be undone
                prev = self.dir / "previous"
                shutil.rmtree(prev, ignore_errors=True)
                prev.mkdir(parents=True)
                old_files = _program_files(self.program)
                _copy_files(self.program, prev, old_files)
                (prev / "VERSION.txt").write_text(self.current, encoding="utf-8")
                self._write("applying.json", {"from": self.current, "to": version, "at": _now(), "phase": "applied"})
                try:
                    _copy_files(root, self.program, new_files)
                    _remove_stale(self.program, new_files)
                except Exception:
                    self._restore_previous()
                    self._remove("applying.json")
                    raise
                shutil.rmtree(staging, ignore_errors=True)
                self._discard_pending()
                self.status.update(state="applied", ready="", latest=version)
                log.info("program updated %s -> %s", self.current, version)
                return version
            except UpdateError as e:
                shutil.rmtree(self.dir / "staging", ignore_errors=True)
                self._mark_bad(version)
                self._discard_pending()
                self.status.update(state="error", error=str(e), ready="")
                self._record_failure(version, self.current, e, "skipped")
                log.error("update not applied: %s", e)
                return None
            except Exception as e:
                shutil.rmtree(self.dir / "staging", ignore_errors=True)
                log.exception("update failed")
                self._mark_bad(version)
                self._discard_pending()
                self.status.update(state="error", error=f"更新時出錯，已還原（{e}）", ready="")
                self._record_failure(version, self.current, f"更新時出錯，已還原（{e}）", "rollback")
                return None

    def _restore_previous(self):
        prev = self.dir / "previous"
        if not (prev / "VERSION.txt").exists():
            raise UpdateError("沒有可還原的上一版")
        files = [r for r in _program_files(prev) if r != "VERSION.txt"]
        _copy_files(prev, self.program, files)
        _remove_stale(self.program, files)
        return (prev / "VERSION.txt").read_text(encoding="utf-8").strip()

    def startup(self):
        """Run before the program starts serving. 'restart' = files on disk changed, start the program again."""
        mark = self._read("applying.json")
        if mark:
            if mark.get("phase") == "applied":                 # first start of the new version: now it has to prove itself
                self._write("applying.json", dict(mark, phase="started"))
                return None
            log.error("version %s did not start properly, going back to %s", mark.get("to"), mark.get("from"))
            try:
                self._restore_previous()
            except Exception:
                log.exception("could not put the previous version back")
            self._mark_bad(mark.get("to", ""))
            self._remove("applying.json")
            why = f"新版 {mark.get('to')} 沒能正常啟動，已自動回到 {mark.get('from')}"
            self.status.update(state="error", error=why)
            self._record_failure(mark.get("to", ""), mark.get("from", ""), why, "rollback")
            return "restart"
        if self._read("pending.json") and self.apply_pending():
            return "restart"
        return None

    def mark_healthy(self):
        """The new version is up and answering: the undo snapshot is no longer needed to start."""
        self._remove("applying.json")


class UpdateWorker:
    """Background thread: look for updates now and then, quietly, only while online."""

    def __init__(self, updater, enabled=lambda: True):
        self.u, self.enabled = updater, enabled
        self._stop = threading.Event()
        self._last = 0.0
        self._wait = CHECK_EVERY

    def start(self, delay=45):
        threading.Thread(target=self._run, args=(delay,), name="updates", daemon=True).start()

    def stop(self):
        self._stop.set()

    def _run(self, delay):
        if self._stop.wait(delay):
            return
        while not self._stop.is_set():
            if self.enabled() and time.time() - self._last >= self._wait:
                self._last = time.time()
                st = self.u.check()
                self._wait = RETRY_OFFLINE if st["state"] in ("offline", "error") else CHECK_EVERY
            self._stop.wait(300)
