"""「待確認」收件匣 (1.70.0).

Entries that arrive by themselves — an iPhone Shortcut that runs after an Apple Pay payment, a Back Tap, any link — are not recorded straight away.
They wait here with whatever the sender knew (amount, shop, card), and become a real entry only when the person opens one, picks the category and
presses 記下. Nothing in here is counted anywhere: not in balances, not in reports, not in budgets.

The sender is often sloppy (the iPhone sometimes hands over an amount of 0 or a blank shop name), so everything is optional and tidied, never refused.
"""
import re
import uuid
from datetime import datetime, timedelta

from .timeutil import now_iso

MAX_ITEMS = 200
SAME_WITHIN = timedelta(minutes=3)          # the same payment announced twice (the Shortcut ran twice, the link was opened twice) is one item
_NUM = re.compile(r"\d[\d,]*(?:\.\d+)?|\.\d+")


def _err(msg, status=400):
    from .book import BookError
    return BookError(msg, status)


def _clean(v, n):
    return re.sub(r"[\x00-\x1f\x7f]+", " ", str(v or "")).strip()[:n]


def tidy_amount(v) -> str:
    """'NT$1,280.50' -> '1280.5';  '0', '', 'abc' -> ''  (an amount is never refused: the person types it when it did not arrive)."""
    if isinstance(v, (int, float)):
        v = repr(v) if isinstance(v, float) else str(v)
    m = _NUM.search(str(v or ""))
    if not m:
        return ""
    s = m.group(0).replace(",", "")
    try:
        x = float(s)
    except ValueError:
        return ""
    if not (0 < x < 1e12):
        return ""
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    s = s.lstrip("0")
    if not s or s.startswith("."):
        s = "0" + s
    return s


class InboxMixin:
    def inbox(self, conn):
        """The waiting items, newest first."""
        return [dict(r) for r in conn.execute("SELECT id, cid, amount, merchant, card, note, source, created_at FROM inbox ORDER BY id DESC")]

    def add_inbox(self, p):
        p = p if isinstance(p, dict) else {}
        amount, merchant, card, note = tidy_amount(p.get("amount")), _clean(p.get("merchant"), 80), _clean(p.get("card"), 60), _clean(p.get("note"), 300)
        source = _clean(p.get("source"), 20) or "link"
        cid = re.sub(r"[^A-Za-z0-9_\-]", "", str(p.get("cid") or ""))[:64] or uuid.uuid4().hex
        with self.session(notify=True) as c:
            now = datetime.now().replace(microsecond=0)
            same = c.execute("SELECT id FROM inbox WHERE cid=?", (cid,)).fetchone()
            if same:                                                         # the very same item again (a phone replaying what it did while the computer was off)
                return {"id": same["id"], "cid": cid, "duplicate": True}
            for r in c.execute("SELECT id, created_at FROM inbox WHERE amount=? AND merchant=? AND card=? ORDER BY id DESC LIMIT 5", (amount, merchant, card)):
                try:
                    if now - datetime.fromisoformat(r["created_at"]) <= SAME_WITHIN:
                        return {"id": r["id"], "cid": cid, "duplicate": True}
                except ValueError:
                    continue
            if c.execute("SELECT COUNT(*) FROM inbox").fetchone()[0] >= MAX_ITEMS:
                c.execute("DELETE FROM inbox WHERE id IN (SELECT id FROM inbox ORDER BY id LIMIT 20)")      # the oldest ones make room; a full box never loses the newest payment
            iid = c.execute("INSERT INTO inbox(amount,merchant,card,note,source,cid,created_at) VALUES(?,?,?,?,?,?,?)", (amount, merchant, card, note, source, cid, now_iso())).lastrowid
            return {"id": iid, "cid": cid, "duplicate": False}

    def delete_inbox(self, iid):
        with self.session(notify=True) as c:
            if not c.execute("DELETE FROM inbox WHERE id=?", (iid,)).rowcount:
                raise _err("找不到這筆待確認", 404)

    def remove_inbox(self, cid):
        """Remove one item by the id its sender gave it. An item that is already gone is fine (it was confirmed on the other device first)."""
        with self.session(notify=True) as c:
            return {"removed": c.execute("DELETE FROM inbox WHERE cid=?", (str(cid or ""),)).rowcount}

    def clear_inbox(self):
        with self.session(notify=True) as c:
            return {"removed": c.execute("DELETE FROM inbox").rowcount}
