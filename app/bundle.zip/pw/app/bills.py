"""Split bills and "received by itself on the due day".

A split bill is a meal (or a trip, a gift...) that one person paid for several people.
- The payer's own share is an ordinary expense (category, items, budget and statistics all count).
- Each other person's share is an ordinary advance ("friend"): money out of the account now, a claim on that person, a due day, repayments
  recorded one by one into whichever account the money arrived in. Nothing new is needed for that: it is the same advance the program
  already had, so settling, writing off and the overdue warnings all work as before.
- `bill_id` ties the rows together so the 代墊 page can show one card per bill: who has paid, who has not, what is still open.
  The bill is finished when every share is paid (or given up).

"Received by itself": an advance may carry `auto_account_id`. On its due day (or later, if the program was not running) the remaining
amount is recorded as received into that account, which closes the advance. Used for "paid first, to be reimbursed on the 25th".
"""
from datetime import date, datetime

from . import money
from .timeutil import now_iso

MAX_SHARES = 40


def _err(msg, status=400):
    from .book import BookError
    return BookError(msg, status)


def _day(value, what):
    s = str(value or "").strip()
    if not s:
        return ""
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except ValueError:
        raise _err(f"{what}的格式不對，請選一個日期") from None


class BillsMixin:
    # ------------------------------------------------------------------ received by itself
    def _set_auto_settle(self, c, tx_id, p, existing=None):
        """Store / clear the "record it as received on the due day" account of an advance. `p["auto_settle"]` is an account id, or ''/None
        to switch it off; when the key is absent the old value stays (as long as it still makes sense)."""
        row = c.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
        keep = existing["auto_account_id"] if existing is not None and "auto_account_id" in existing.keys() else None
        want = p["auto_settle"] if "auto_settle" in p else keep
        if "auto_settle" not in p and not row["due_date"]:                 # the due day was removed: nothing to wait for any more
            want = None
        if want in ("", None, 0, "0", False) or not row["advance"] or row["settle_of"]:
            c.execute("UPDATE transactions SET auto_account_id=NULL WHERE id=?", (tx_id,))
            return
        try:
            aid = int(want)
        except (TypeError, ValueError):
            raise _err("請選擇到期後要入帳的帳戶") from None
        a = c.execute("SELECT * FROM accounts WHERE id=?", (aid,)).fetchone()
        orig = c.execute("SELECT currency FROM accounts WHERE id=?", (row["account_id"],)).fetchone()
        if not a:
            raise _err("請選擇到期後要入帳的帳戶")
        if a["currency"] != orig["currency"]:
            raise _err(f"自動入帳的帳戶要和墊付的帳戶同幣別（{orig['currency']}）")
        if a["archived"] and aid != keep:
            raise _err(f"「{a['name']}」已封存，請先取消封存")
        if not row["due_date"]:
            raise _err("要自動入帳，請先填「預計收回日」")
        c.execute("UPDATE transactions SET auto_account_id=? WHERE id=?", (aid, tx_id))

    def run_auto_settle(self, today=None):
        """Record as received every advance whose due day has come and which was set to be received by itself. -> how many were closed."""
        today = today or date.today().isoformat()
        with self.session() as c:
            due = [dict(r) for r in c.execute(
                "SELECT id, due_date, auto_account_id, counterparty, advance FROM transactions "
                "WHERE auto_account_id IS NOT NULL AND advance!='' AND settle_of IS NULL AND written_off=0 AND due_date!='' AND due_date<=?", (today,))]
        done = 0
        for r in due:
            when = f"{r['due_date']}T09:00:00"
            if when > now_iso():
                when = now_iso()
            try:
                self.settle_advance(r["id"], {"account_id": r["auto_account_id"], "time": when,
                                              "note": f"{r['counterparty']}{'還款' if r['advance'] == 'friend' else '報帳入帳'}（到期自動入帳）"})
                done += 1
            except Exception as e:                                      # the account was archived, it is already paid...: nothing to retry
                if "已經收齊" in str(e) or "不收了" in str(e) or "找不到" in str(e):
                    with self.session() as c:
                        c.execute("UPDATE transactions SET auto_account_id=NULL WHERE id=?", (r["id"],))
                continue
            with self.session() as c:
                c.execute("UPDATE transactions SET auto_account_id=NULL WHERE id=?", (r["id"],))
        return done

    # ------------------------------------------------------------------ split bills
    def create_bill(self, p):
        """p: title, time, account_id, tags, mine {amount, category, note}, shares [{name, amount, due, note}].
        -> {bill_id, ids, mine_id, primary_id}; the photo of the receipt goes on `primary_id`."""
        title = " ".join(str(p.get("title") or "").split())[:60]
        shares = p.get("shares") or []
        if not isinstance(shares, list) or not shares:
            raise _err("請至少加一位要向他收錢的人")
        if len(shares) > MAX_SHARES:
            raise _err(f"一張帳單最多 {MAX_SHARES} 個人")
        mine = p.get("mine") or {}
        has_mine = str(mine.get("amount") or "").strip() not in ("", "0")
        with self.session(notify=True) as c:
            bill = c.execute("INSERT INTO bills(title, created_at) VALUES(?,?)", (title, now_iso())).lastrowid
            base = {"account_id": p.get("account_id"), "time": p.get("time") or now_iso()}
            category = str(mine.get("category") or "").strip() if has_mine else ""
            share_cat = str(p.get("share_category") or "").strip() or category        # the friends' category starts the same as mine
            ids, mine_id = [], None
            if has_mine:
                mine_id = self._insert_tx(c, {**base, "type": "expense", "amount": mine.get("amount"), "category": category,
                                              "note": str(mine.get("note") or title or "").strip(), "tags": p.get("tags", "")})
                ids.append(mine_id)
            for i, sh in enumerate(shares, 1):
                who = " ".join(str(sh.get("name") or "").split())[:40]
                if not who:
                    raise _err(f"第 {i} 位朋友還沒填名字")
                try:
                    tid = self._insert_tx(c, {**base, "type": "expense", "amount": sh.get("amount"), "category": share_cat,
                                              "note": str(sh.get("note") or title or "").strip(), "advance": "friend", "counterparty": who,
                                              "due": _day(sh.get("due"), f"{who} 的預計還錢日"), "no_budget": False, "no_stats": False})      # a friend's share is plain spending, and what comes back plain income (1.68.0)
                except ValueError as e:
                    if "代墊" in str(e) or who in str(e):
                        raise
                    raise _err(f"{who}：{e}") from None
                ids.append(tid)
            c.execute(f"UPDATE transactions SET bill_id=? WHERE id IN ({','.join('?' * len(ids))})", (bill, *ids))
            return {"bill_id": bill, "ids": ids, "mine_id": mine_id, "primary_id": mine_id or ids[0]}

    def rename_bill(self, bill_id, p):
        title = " ".join(str(p.get("title") or "").split())[:60]
        with self.session(notify=True) as c:
            if not c.execute("SELECT 1 FROM bills WHERE id=?", (bill_id,)).fetchone():
                raise _err("找不到這張帳單", 404)
            c.execute("UPDATE bills SET title=? WHERE id=?", (title, bill_id))

    def delete_bill(self, bill_id):
        """Delete a whole bill (every row of it). Refused while any friend has already paid something: take those payments out first."""
        with self.session(notify=True) as c:
            ids = [r["id"] for r in c.execute("SELECT id FROM transactions WHERE bill_id=?", (bill_id,))]
            if not ids:
                raise _err("找不到這張帳單", 404)
            marks = ",".join("?" * len(ids))
            if c.execute(f"SELECT 1 FROM transactions WHERE settle_of IN ({marks})", ids).fetchone():
                raise _err("這張帳單已經有人還錢了，請先到「代墊」頁刪掉收款紀錄，再刪除整張帳單。")
            snaps = [self._snapshot(c, i) for i in ids]
            c.execute(f"DELETE FROM transactions WHERE id IN ({marks})", ids)
        return self._remember_undo(snaps)

    def delete_advances(self, ids):
        """The 代墊 page's one-click delete: the ticked advances AND the repayments recorded against them (the account balances follow).
        A ticked repayment is deleted on its own, which puts that advance back to "not paid yet". -> {deleted, advances, undo}."""
        try:
            ids = list(dict.fromkeys(int(i) for i in ids or []))
        except (TypeError, ValueError):
            raise _err("請先勾選要刪除的項目") from None
        if not ids or len(ids) > 500:
            raise _err("請先勾選要刪除的項目（一次最多 500 筆）")
        with self.session(notify=True) as c:
            doomed, advances = [], 0
            for i in ids:
                row = c.execute("SELECT id, advance, settle_of FROM transactions WHERE id=?", (i,)).fetchone()
                if not row or not row["advance"]:
                    continue
                if not row["settle_of"]:
                    advances += 1
                    doomed += [r["id"] for r in c.execute("SELECT id FROM transactions WHERE settle_of=?", (i,))]
                doomed.append(i)
            doomed = list(dict.fromkeys(doomed))
            if not doomed:
                raise _err("勾選的項目已經不存在了")
            snaps = [self._snapshot(c, i) for i in doomed]
            c.execute(f"DELETE FROM transactions WHERE id IN ({','.join('?' * len(doomed))})", doomed)
        return {"deleted": len(doomed), "advances": advances, "undo": self._remember_undo(snaps)}

    def bills_view(self, conn, rows, accts, fmt, receipts, state):
        """The split bills for the 代墊 page. `fmt(row)` formats one advance row. state: open | done | all."""
        groups, order = {}, []
        for r in rows:
            b = r.get("bill_id")
            if not b or r.get("settle_of"):
                continue
            g = groups.get(b)
            if g is None:
                g = groups[b] = {"id": b, "mine": None, "shares": [], "rows": []}
                order.append(b)
            g["rows"].append(r)
            if r.get("advance"):
                g["shares"].append(fmt(r))
            else:
                g["mine"] = r
        with_titles = self._bill_titles(conn, list(groups))
        out = []
        for b in order:
            g = groups[b]
            if not g["shares"]:
                continue
            first = g["rows"][0]
            a = accts[first["account_id"]]
            ccy = a["currency"]
            total = sum(r["amount_minor"] for r in g["rows"])
            open_shares = [s for s in g["shares"] if s["state"] in ("open", "partial")]
            left = sum(float(s["remaining"]) for s in open_shares)
            dues = sorted(s["due"] for s in open_shares if s["due"])
            rid = []
            for r in g["rows"]:
                rid += receipts.get(r["id"], [])
            mine = g["mine"]
            out.append({
                "id": b, "title": with_titles.get(b) or (mine["note"] if mine else "") or g["shares"][0]["note"] or "分帳",
                "time": first["time"], "account_id": a["id"], "account": a["name"], "currency": ccy,
                "total": money.from_minor(total, ccy),
                "mine": ({"id": mine["id"], "amount": money.from_minor(mine["amount_minor"], ccy), "category": mine["category"], "note": mine["note"]} if mine else None),
                "shares": sorted(g["shares"], key=lambda s: (s["state"] not in ("open", "partial"), s["due"] or "9999-99-99", s["counterparty"])),
                "paid_count": len(g["shares"]) - len(open_shares), "count": len(g["shares"]),
                "remaining": round(left, 2), "state": "open" if open_shares else "done",
                "next_due": dues[0] if dues else "", "receipts": rid,
                "primary_id": (mine or g["rows"][0])["id"],
            })
        out = [b for b in out if state == "all" or b["state"] == state]
        out.sort(key=lambda b: (b["next_due"] or "9999-99-99") if state == "open" else "", reverse=False)
        if state != "open":
            out.sort(key=lambda b: b["time"], reverse=True)
        return out

    @staticmethod
    def _bill_titles(conn, ids):
        if not ids:
            return {}
        return {r["id"]: r["title"] for r in conn.execute(f"SELECT id, title FROM bills WHERE id IN ({','.join('?' * len(ids))})", ids)}

    @staticmethod
    def friend_names(conn, limit=24):
        """The people this book has paid for before: {friends: most often first, last_bill: who was on the latest split bill}."""
        friends = [r["counterparty"] for r in conn.execute(
            "SELECT counterparty, COUNT(*) n, MAX(time) last FROM transactions WHERE advance='friend' AND counterparty!='' "
            "GROUP BY counterparty ORDER BY n DESC, last DESC LIMIT ?", (limit,))]
        row = conn.execute("SELECT bill_id FROM transactions WHERE bill_id IS NOT NULL AND advance='friend' ORDER BY time DESC, id DESC LIMIT 1").fetchone()
        last = []
        if row:
            last = [r["counterparty"] for r in conn.execute(
                "SELECT counterparty FROM transactions WHERE bill_id=? AND advance='friend' ORDER BY id", (row["bill_id"],))]
        return {"friends": friends, "last_bill": list(dict.fromkeys(last))}
