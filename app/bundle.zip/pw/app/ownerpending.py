"""1.72.2 — the owner's one-click publish: is there an update from Claude waiting on GitHub's `pending` branch?

Only the owner's own copy (with its private profile, in "my own book" mode, on the computer itself) ever asks. It reads two small
files: update.json on the pending branch and manifest.json on the live site. An update is "waiting" when it is newer than what the
site already has. Pressing the button opens receive_update.bat in its own window; that one tests, signs and publishes (the private
key never leaves this computer, and nothing here can publish by itself).
"""
import json
import os
import re
import subprocess
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

from . import config

ROOT = Path(__file__).resolve().parents[1]
STORE = ROOT.parent / "tallomi-update-backups"            # where receive_update keeps its backups, reports and last-result.json
CACHE_SECONDS = 600
_lock = threading.Lock()
_cache = {"at": 0.0, "value": None}
_launched = {"at": 0.0}


def vtuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:3]) or (0,)


def repo():
    """https://yeep112.github.io/tallomi/  ->  Yeep112/tallomi (GitHub does not mind the case)."""
    m = re.match(r"^https://([^./]+)\.github\.io/([^/]+)/?$", config.UPDATE_URL)
    return f"{m.group(1)}/{m.group(2)}" if m else ""


def owner_here():
    return bool(config.HAS_PROFILE and config.MODE == "owner" and not config.PHONE and not config.LOCAL_COPY)


def _get_json(url, timeout=8):
    req = urllib.request.Request(url, headers={"User-Agent": "tallomi-owner", "Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def fetch_pending():
    r = repo()
    return _get_json(f"https://raw.githubusercontent.com/{r}/pending/update.json?t={int(time.time())}") if r else None


def fetch_live():
    return _get_json(config.UPDATE_URL.rstrip("/") + f"/manifest.json?t={int(time.time())}")


def last_result():
    """What the last receive_update run ended with (written by it when it is done), or None."""
    try:
        r = json.loads((STORE / "last-result.json").read_text(encoding="utf-8"))
        return r if isinstance(r, dict) else None
    except (OSError, ValueError):
        return None


def status(fetch_pending=fetch_pending, fetch_live=fetch_live, now=time.time, force=False):
    """{'enabled', 'state': 'none' | 'waiting' | 'error', 'version', 'notes', 'tested', 'live', 'last_result', 'launched_at'}
    The GitHub part is kept for 10 minutes; the last result and the launch time are always read fresh."""
    if not owner_here():
        return {"enabled": False}
    return dict(_github(fetch_pending, fetch_live, now, force), last_result=last_result(), launched_at=_launched["at"])


def _github(fetch_pending, fetch_live, now, force):
    with _lock:
        if not force and _cache["value"] and now() - _cache["at"] < CACHE_SECONDS:
            return _cache["value"]
    try:
        info = fetch_pending()
        live = fetch_live() or {}
        lv = live.get("version", "")
        if not info or not info.get("version"):
            value = {"enabled": True, "state": "none", "live": lv}
        elif vtuple(info["version"]) > vtuple(lv or "0"):
            value = {"enabled": True, "state": "waiting", "version": info["version"], "live": lv,
                     "notes": [str(n) for n in info.get("notes", [])][:12], "tested": [str(t) for t in info.get("tested", [])][:12]}
        else:                                                  # already on the site (the branch was not cleared): nothing to do
            value = {"enabled": True, "state": "none", "live": lv}
    except (OSError, ValueError) as e:
        value = {"enabled": True, "state": "error", "error": str(e)[:200]}
    with _lock:
        _cache.update(at=now(), value=value)
    return value


def forget():
    with _lock:
        _cache.update(at=0.0, value=None)


def launch(popen=subprocess.Popen):
    """Open receive_update.bat in its own console window (Windows). It asks nothing more: the person just confirmed in the program."""
    bat = ROOT / "receive_update.bat"
    if os.name != "nt" or not bat.exists():
        raise RuntimeError("這台電腦找不到 receive_update.bat")
    popen(["cmd", "/c", str(bat), "--yes"], cwd=str(ROOT), creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    _launched["at"] = time.time()
    forget()


def open_report(path, starter=None):
    """Open a report receive_update wrote (only files inside its own folder)."""
    p = Path(path or "").resolve()
    store = STORE.resolve()
    if not path or store not in p.parents or not p.is_file():
        raise RuntimeError("找不到這份報告")
    if starter is None:
        if os.name != "nt":
            raise RuntimeError("只能在 Windows 上打開")
        starter = os.startfile  # noqa
    starter(str(p))
