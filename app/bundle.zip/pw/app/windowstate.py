"""Remember the size and place of the program window between starts (1.71.0).

The window used to open at 1280x840 wherever Windows put it. Now it opens where and how large it was when it was last closed — unless that
place is no longer on any screen (a monitor was unplugged), in which case only the size is used and Windows chooses the place.
Everything here is best effort: a damaged file or a webview without these features just means the default window.
"""
import json
import logging
from pathlib import Path

log = logging.getLogger("pennyworth")

DEFAULT_W, DEFAULT_H = 1280, 840
MIN_W, MIN_H = 600, 400
GRAB = 120                    # at least this much of the title bar must be on a screen, or the window could not be reached with the mouse


def _num(v):
    return int(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and abs(v) < 100000 else None


def _screens(screens):
    out = []
    for s in screens or []:
        try:
            out.append((int(s.x), int(s.y), int(s.width), int(s.height)))
        except (AttributeError, TypeError, ValueError):
            continue
    return out


def load(path, screens=None):
    """Keyword arguments for create_window: always width and height; x and y only when that place is still on a screen."""
    kw = {"width": DEFAULT_W, "height": DEFAULT_H}
    try:
        d = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return kw
    if not isinstance(d, dict):
        return kw
    w, h, x, y = _num(d.get("width")), _num(d.get("height")), _num(d.get("x")), _num(d.get("y"))
    scr = _screens(screens)
    if w and h and w >= MIN_W and h >= MIN_H:
        biggest = (max(s[2] for s in scr), max(s[3] for s in scr)) if scr else None
        if biggest is None or (w <= biggest[0] + 40 and h <= biggest[1] + 40):         # a size that does not fit any screen is not used
            kw["width"], kw["height"] = w, h
    if x is not None and y is not None and scr:
        for sx, sy, sw, sh in scr:
            if x + kw["width"] > sx + GRAB and x < sx + sw - GRAB and sy <= y < sy + sh - GRAB:
                kw["x"], kw["y"] = x, y
                break
    return kw


def save(path, x, y, width, height):
    vals = [_num(v) for v in (x, y, width, height)]
    if None in vals or vals[2] < MIN_W or vals[3] < MIN_H:
        return False
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(dict(zip(("x", "y", "width", "height"), vals))), encoding="utf-8")
        tmp.replace(p)
        return True
    except OSError:
        log.exception("could not remember the window place")
        return False


def create(webview, title, url, path, min_size=(980, 640)):
    """webview.create_window with the remembered size and place; the place is saved again when the window closes."""
    try:
        kw = load(path, getattr(webview, "screens", None))
    except Exception:
        log.exception("window place could not be read")
        kw = {"width": DEFAULT_W, "height": DEFAULT_H}
    window = webview.create_window(title, url, min_size=min_size, **kw)
    try:
        def closing(*_a):
            try:
                save(path, window.x, window.y, window.width, window.height)
            except Exception:
                log.exception("window place not saved")
        window.events.closing += closing
    except Exception:
        log.info("this window cannot report when it closes: its place is not remembered")
    return window
