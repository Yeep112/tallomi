"""Taskbar identity (Windows): makes Tallomi's window its own taskbar app instead of "a window of Edge".

When Tallomi opens as an Edge app window (the case whenever the window component pywebview is not installed), Windows files
that window under Edge: the taskbar shows Edge's icon, and "pin to taskbar" pins Edge. Windows groups windows by an
AppUserModelID (AUMID). So Tallomi
  1. gives its own process the AUMID `Tallomi.Bookkeeping`,
  2. stamps the same AUMID (plus the relaunch command / icon / name) on the Edge app window once it appears, and
  3. stamps it on the Tallomi shortcuts (desktop, Start menu, taskbar pin),
so the window and the shortcut become one taskbar button with Tallomi's own icon, and a pin starts Tallomi, not Edge.
Everything here is best-effort: any failure is logged and the program carries on exactly as before.
"""
import ctypes
import logging
import os
import struct
import threading
import time
import uuid

log = logging.getLogger("pennyworth")

APP_ID = "Tallomi.Bookkeeping"
APP_NAME = "Tallomi"
FMTID_APPUSERMODEL = "9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"
PID_RELAUNCH_COMMAND, PID_RELAUNCH_ICON, PID_RELAUNCH_NAME, PID_ID = 2, 3, 4, 5
IID_IPROPERTYSTORE = "886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"
VT_LPWSTR = 31
GPS_READWRITE = 2
BROWSER_CLASS = "Chrome_WidgetWin_1"                   # Edge and Chrome top-level windows
SHORTCUT_NAMES = ("tallomi", "pennyworth")


# ---------------------------------------------------------------------------------------------- pure logic
def is_app_window(cls, title):
    """An Edge/Chrome *app* window shows only the page title; a normal browser window adds the browser's name to it."""
    t = (title or "").strip()
    if cls != BROWSER_CLASS or not t.startswith(APP_NAME):
        return False
    return not any(w in t for w in ("Edge", "Chrome", "Chromium"))


def window_properties(launcher_dir=None):
    """The properties stamped on a window: the id, and (when the launcher exists) how to start Tallomi again from its taskbar button."""
    props = {PID_ID: APP_ID}
    if launcher_dir:
        vbs = os.path.join(launcher_dir, "launch.vbs")
        ico = os.path.join(launcher_dir, "pennyworth.ico")
        if os.path.isfile(vbs):
            wscript = os.path.join(os.environ.get("SystemRoot") or "C:\\Windows", "System32", "wscript.exe")
            props[PID_RELAUNCH_COMMAND] = f'"{wscript}" //B //Nologo "{vbs}"'
            props[PID_RELAUNCH_NAME] = APP_NAME
            if os.path.isfile(ico):
                props[PID_RELAUNCH_ICON] = f"{ico},0"
    return props


def launcher_dir():
    base = os.environ.get("LOCALAPPDATA")
    return os.path.join(base, "Pennyworth", "launcher") if base else None


def shortcut_paths(env=None):
    """Tallomi's shortcuts: desktop, Start menu and the taskbar pin (found by name; Edge/Chrome pins are not touched)."""
    env = env if env is not None else os.environ
    appdata, home = env.get("APPDATA", ""), env.get("USERPROFILE", "")
    folders = [os.path.join(home, "Desktop"), os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs"),
               os.path.join(appdata, "Microsoft", "Internet Explorer", "Quick Launch", "User Pinned", "TaskBar")]
    found = []
    for f in folders:
        try:
            for n in os.listdir(f):
                if n.lower().endswith(".lnk") and n.lower().startswith(SHORTCUT_NAMES):
                    found.append(os.path.join(f, n))
        except OSError:
            continue
    return found


class Tagger:
    """Watches for Tallomi's Edge app window and stamps the taskbar identity on it, once it exists (and once more shortly after,
    because the browser sets its own id when the window opens)."""

    def __init__(self, backend, props, icon=None, sleep=time.sleep, clock=time.monotonic):
        self.b, self.props, self.icon = backend, props, icon
        self.sleep, self.clock = sleep, clock
        self.done = {}                                   # hwnd -> number of times stamped
        self.first = {}                                  # hwnd -> when it was stamped the first time

    def step(self):
        n = 0
        for hwnd, cls, title in self.b.windows():
            if not is_app_window(cls, title) or self.done.get(hwnd, 0) >= 2:
                continue
            if self.done.get(hwnd) == 1 and self.clock() - self.first[hwnd] < 3:          # the second stamp comes a few seconds later
                continue
            try:
                self.b.stamp(hwnd, self.props)
                if self.icon and not self.done.get(hwnd):
                    self.b.set_icon(hwnd, self.icon)
                self.first.setdefault(hwnd, self.clock())
                self.done[hwnd] = self.done.get(hwnd, 0) + 1
                n += 1
                if self.done[hwnd] == 1:
                    log.info("taskbar identity set on window %s", hwnd)
            except Exception:
                log.exception("taskbar identity could not be set on window %s", hwnd)
                self.done[hwnd] = 2
        return n

    def run(self, seconds=45, interval=0.5):
        end = self.clock() + seconds
        while self.clock() < end:
            self.step()
            self.sleep(interval)
        return dict(self.done)


# ---------------------------------------------------------------------------------------------- Windows plumbing
class GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]


class PROPERTYKEY(ctypes.Structure):
    _fields_ = [("fmtid", GUID), ("pid", ctypes.c_uint32)]


class PROPVARIANT(ctypes.Structure):
    _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort), ("r2", ctypes.c_ushort), ("r3", ctypes.c_ushort),
                ("ptr", ctypes.c_void_p), ("pad", ctypes.c_void_p)]


def read_wstr(ptr):
    """A NUL-terminated UTF-16 string at an address (Windows wide strings are always 2-byte units)."""
    units = []
    while True:
        u = ctypes.c_uint16.from_address(ptr + 2 * len(units)).value
        if u == 0:
            break
        units.append(u)
    return struct.pack(f"<{len(units)}H", *units).decode("utf-16-le", "replace")


def guid(text):
    return GUID.from_buffer_copy(uuid.UUID(text).bytes_le)


def _key(pid):
    return PROPERTYKEY(guid(FMTID_APPUSERMODEL), pid)


_FUNC = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)      # stdcall on Windows (cdecl elsewhere, only so the tests can run)


def _vcall(ptr, index, argtypes, *args):
    """Call method number `index` of a COM object (a pointer to a pointer to a table of function pointers)."""
    table = ctypes.cast(ctypes.cast(ptr, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
    fn = _FUNC(ctypes.c_long, ctypes.c_void_p, *argtypes)(table[index])
    hr = fn(ptr, *args)
    if hr < 0:
        raise OSError(f"COM call {index} failed (0x{hr & 0xFFFFFFFF:08X})")
    return hr


class PropStore:
    """A wrapped IPropertyStore (method order: QueryInterface, AddRef, Release, GetCount, GetAt, GetValue, SetValue, Commit)."""

    def __init__(self, ptr, ole32=None):
        self.ptr = ptr
        self.ole32 = ole32 or ctypes.windll.ole32

    def set_string(self, pid, text):
        raw = text.encode("utf-16-le") + b"\0\0"
        self.ole32.CoTaskMemAlloc.restype = ctypes.c_void_p
        self.ole32.CoTaskMemAlloc.argtypes = [ctypes.c_size_t]
        mem = self.ole32.CoTaskMemAlloc(len(raw))
        if not mem:
            raise MemoryError("CoTaskMemAlloc")
        ctypes.memmove(mem, raw, len(raw))
        pv = PROPVARIANT(VT_LPWSTR, 0, 0, 0, mem, None)
        key = _key(pid)
        try:
            _vcall(self.ptr, 6, (ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT)), ctypes.byref(key), ctypes.byref(pv))
        finally:
            self.ole32.PropVariantClear(ctypes.byref(pv))

    def get_string(self, pid):
        pv = PROPVARIANT()
        key = _key(pid)
        _vcall(self.ptr, 5, (ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT)), ctypes.byref(key), ctypes.byref(pv))
        try:
            return read_wstr(pv.ptr) if pv.vt == VT_LPWSTR and pv.ptr else ""
        finally:
            self.ole32.PropVariantClear(ctypes.byref(pv))

    def commit(self):
        _vcall(self.ptr, 7, ())

    def release(self):
        try:
            table = ctypes.cast(ctypes.cast(self.ptr, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
            _FUNC(ctypes.c_ulong, ctypes.c_void_p)(table[2])(self.ptr)
        except Exception:
            pass


class WinBackend:
    """The real thing (Windows only)."""

    def __init__(self):
        from ctypes import wintypes
        self.w = wintypes
        self.u32, self.s32 = ctypes.windll.user32, ctypes.windll.shell32
        self.u32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.u32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.u32.IsWindowVisible.argtypes = [wintypes.HWND]
        self.u32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        self.u32.SendMessageW.restype = ctypes.c_ssize_t
        self.u32.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        self.u32.LoadImageW.restype = ctypes.c_void_p
        self.s32.SHGetPropertyStoreForWindow.argtypes = [wintypes.HWND, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
        self.s32.SHGetPropertyStoreFromParsingName.argtypes = [wintypes.LPCWSTR, ctypes.c_void_p, ctypes.c_int, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
        self._icons = {}

    def windows(self):
        out = []
        w = self.w
        cb_t = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)

        def cb(hwnd, _l):
            if self.u32.IsWindowVisible(hwnd):
                cls, title = ctypes.create_unicode_buffer(256), ctypes.create_unicode_buffer(512)
                self.u32.GetClassNameW(hwnd, cls, 256)
                self.u32.GetWindowTextW(hwnd, title, 512)
                out.append((hwnd, cls.value, title.value))
            return True
        self.u32.EnumWindows(cb_t(cb), 0)
        return out

    def stamp(self, hwnd, props):
        ppv = ctypes.c_void_p()
        iid = guid(IID_IPROPERTYSTORE)
        hr = self.s32.SHGetPropertyStoreForWindow(hwnd, ctypes.byref(iid), ctypes.byref(ppv))
        if hr != 0 or not ppv.value:
            raise OSError(f"SHGetPropertyStoreForWindow failed (0x{hr & 0xFFFFFFFF:08X})")
        store = PropStore(ppv.value)
        try:
            for pid, text in props.items():
                store.set_string(pid, text)
        finally:
            store.release()

    def set_icon(self, hwnd, path):
        """Title-bar / Alt-Tab icon (the taskbar button itself takes its icon from the shortcut)."""
        if not os.path.isfile(path):
            return
        for kind, metric in ((0, 49), (1, 11)):                      # ICON_SMALL / SM_CXSMICON, ICON_BIG / SM_CXICON
            size = self.u32.GetSystemMetrics(metric)
            icon = self.u32.LoadImageW(None, path, 1, size, size, 0x10)       # IMAGE_ICON, LR_LOADFROMFILE
            if icon:
                self.u32.SendMessageW(hwnd, 0x80, kind, icon)                # WM_SETICON

    def shortcut_store(self, path):
        ppv = ctypes.c_void_p()
        iid = guid(IID_IPROPERTYSTORE)
        hr = self.s32.SHGetPropertyStoreFromParsingName(path, None, GPS_READWRITE, ctypes.byref(iid), ctypes.byref(ppv))
        if hr != 0 or not ppv.value:
            raise OSError(f"SHGetPropertyStoreFromParsingName failed (0x{hr & 0xFFFFFFFF:08X})")
        return PropStore(ppv.value)


def stamp_shortcut(backend, path):
    """Give one shortcut the Tallomi id (only when it does not already have it). True = changed."""
    store = backend.shortcut_store(path)
    try:
        if store.get_string(PID_ID) == APP_ID:
            return False
        store.set_string(PID_ID, APP_ID)
        store.commit()
        return True
    finally:
        store.release()


def stamp_shortcuts(backend, paths):
    changed = 0
    for p in paths:
        try:
            if stamp_shortcut(backend, p):
                changed += 1
                log.info("taskbar identity set on shortcut %s", p)
        except Exception:
            log.exception("taskbar identity could not be set on shortcut %s", p)
    return changed


# ---------------------------------------------------------------------------------------------- entry points
def set_process_id():
    """Before any window opens: this process (and a pywebview window inside it) belongs to the Tallomi taskbar button."""
    if os.name != "nt":
        return False
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(ctypes.c_wchar_p(APP_ID))
        return True
    except Exception:
        log.exception("could not set the process taskbar id")
        return False


def _background(fn, name):
    threading.Thread(target=fn, name=name, daemon=True).start()


def tag_edge_window(icon=None):
    """Right after an Edge app window was started: find it and give it the Tallomi taskbar identity."""
    if os.name != "nt":
        return

    def work():
        try:
            Tagger(WinBackend(), window_properties(launcher_dir()), icon=icon).run()
        except Exception:
            log.exception("taskbar identity: giving up")
    _background(work, "taskbar-tag")


def fix_shortcuts():
    """At start: every Tallomi shortcut gets the id (so an old pinned icon joins the window's taskbar button)."""
    if os.name != "nt":
        return

    def work():
        try:
            stamp_shortcuts(WinBackend(), shortcut_paths())
        except Exception:
            log.exception("taskbar identity: shortcuts not updated")
    _background(work, "taskbar-links")
