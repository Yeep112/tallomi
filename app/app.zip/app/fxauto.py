"""Twice a day (morning and afternoon), while the computer is online, read the banks' board rates and record them (see bankfetch.py).

Runs inside the open program (checked every minute) and can also run on its own: `run.py --fetch-rates`
(used by the optional Windows scheduled task). Failures never interrupt bookkeeping; they only show in the exchange page.
"""
import logging
import threading
import time
from datetime import datetime, timedelta

from . import config

log = logging.getLogger(__name__)
RETRY_OFFLINE = 600          # seconds before trying again when the computer could not reach the banks at all
RETRY_OTHER = 1800           # ... when the banks answered but no rate could be read
MAX_TRIES_PER_SLOT = 3
SLOT_SPLIT_HOUR = 13         # "A" = before 13:00, "B" = from 13:00: each part of the day gets one successful update


def current_slot(now=None):
    now = now or datetime.now()
    return now.strftime("%Y-%m-%d") + (":A" if now.hour < SLOT_SPLIT_HOUR else ":B")


class FxAuto:
    def __init__(self, book, fetcher_getter=None):
        self.book = book
        self._fetcher_getter = fetcher_getter or (lambda: None)
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.status = {"state": "idle", "last_try": None, "last_ok": None, "results": {}, "tries": 0, "try_slot": None}

    # ------------------------------------------------------------ settings
    def enabled(self):
        with self.book.session() as c:
            return self.book.get_setting(c, "fx_auto", "1") != "0"

    def set_enabled(self, on):
        with self.book.session() as c:
            self.book.set_setting(c, "fx_auto", "1" if on else "0")

    def done_slots(self):
        """Today's finished updates, e.g. ["2026-11-12:A"]."""
        today = datetime.now().strftime("%Y-%m-%d")
        with self.book.session() as c:
            raw = self.book.get_setting(c, "fx_auto_done", "")
        return [s for s in raw.split(",") if s.startswith(today)]

    def done_today(self):
        return current_slot() in self.done_slots()

    def info(self):
        with self.book.session() as c:
            at = self.book.get_setting(c, "fx_auto_at", "")
        return {"enabled": self.enabled(), "done_today": self.done_today(), "done_count": len(self.done_slots()), "per_day": 2,
                "last_ok": at or None, "state": self.status["state"], "last_try": self.status["last_try"],
                "results": self.status["results"], "currencies": self.currencies()}

    def currencies(self):
        with self.book.session() as c:
            return self.book.fx_currencies(c)

    # ----------------------------------------------------------------- run
    def run_once(self):
        """Read every currency in use. -> True if at least one bank gave a rate."""
        if not self._lock.acquire(blocking=False):
            return False
        try:
            self.status["state"] = "running"
            self.status["last_try"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            slot = current_slot()
            if self.status["try_slot"] != slot:
                self.status["try_slot"], self.status["tries"] = slot, 0
            self.status["tries"] += 1
            ccys = self.currencies()
            results, any_ok, all_offline = {}, False, True
            for ccy in ccys:
                try:
                    r = self.book.fetch_web_rates(ccy, save=True, fetcher=self._fetcher_getter())
                except Exception as e:           # one currency failing must not stop the others
                    log.exception("rate fetch failed for %s", ccy)
                    results[ccy] = [{"bank": b, "ok": False, "error": str(e)} for b in config.BANKS]
                    all_offline = False
                    continue
                results[ccy] = [{k: x.get(k) for k in ("bank", "ok", "buy", "sell", "quoted_at", "error")} for x in r["results"]]
                for x in r["results"]:
                    if x.get("ok"):
                        any_ok = True
                    if not x.get("ok") and "連不上" not in (x.get("error") or ""):
                        all_offline = False
            self.status["results"] = results
            if any_ok:
                with self.book.session() as c:
                    done = self.done_slots() + [slot]
                    self.book.set_setting(c, "fx_auto_done", ",".join(dict.fromkeys(done)))
                    self.book.set_setting(c, "fx_auto_at", datetime.now().strftime("%Y-%m-%dT%H:%M:%S"))
                self.status["state"] = "ok"
            else:
                self.status["state"] = "offline" if (ccys and all_offline) else "error"
            log.info("daily rate update: %s for %s", self.status["state"], ccys)
            return any_ok
        finally:
            self._lock.release()

    def due(self):
        if not self.enabled() or self.done_today() or not self.currencies():
            return False
        tries = self.status["tries"] if self.status["try_slot"] == current_slot() else 0
        if tries >= MAX_TRIES_PER_SLOT:
            return False
        last = self.status["last_try"] if tries else None          # only a failed earlier try in this same half-day makes us wait
        if last:
            wait = RETRY_OFFLINE if self.status["state"] == "offline" else RETRY_OTHER
            if datetime.now() - datetime.strptime(last, "%Y-%m-%dT%H:%M:%S") < timedelta(seconds=wait):
                return False
        return True

    def run_if_due(self):
        return self.run_once() if self.due() else False

    # ------------------------------------------------------------ thread
    def start(self, first_delay=6):
        def loop():
            if self._stop.wait(first_delay):
                return
            while not self._stop.is_set():
                try:
                    self.run_if_due()
                except Exception:
                    log.exception("daily rate update crashed")
                if self._stop.wait(60):
                    return
        threading.Thread(target=loop, name="fx-auto", daemon=True).start()

    def stop(self):
        self._stop.set()
