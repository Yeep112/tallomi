"""Start Tallomi by itself, quietly in the background (no window, just the tray icon), each time you sign in to Windows.

It is one value in the per-user "Run" registry key (HKEY_CURRENT_USER, so no administrator rights are needed), the same
place the Task Manager's "Startup apps" list reads. Every normal start refreshes it, so it keeps working after an upgrade or
after the program folder was moved.
"""
import logging
import os
import shutil
import sys
import time
from pathlib import Path

from . import config

RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
APPROVED_KEY = r"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run"
VALUE = "Pennyworth"


class AutostartError(Exception):
    pass


def supported():
    return os.name == "nt"


def _winreg():
    import winreg
    return winreg


def launcher_dir():
    """The small launcher the desktop shortcut uses (kept outside the program folder, so it survives moving the folder)."""
    return Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local") / "Pennyworth" / "launcher"


def _launcher_vbs():
    if not supported():
        return None
    p = launcher_dir() / "launch.vbs"
    return str(p) if p.is_file() else None


def sync_launcher():
    """Make sure the launcher is there, current, and knows where this program folder is (the same one the desktop shortcut uses).
    Starting through it is the way known to work on this kind of PC, and it finds the folder again even if it was moved."""
    if not supported() or getattr(sys, "frozen", False):
        return False
    root = Path(__file__).resolve().parent.parent
    tools = root / "tools"
    if not (tools / "launch.vbs").is_file():
        return False
    try:
        dest = launcher_dir()
        dest.mkdir(parents=True, exist_ok=True)
        for name in ("launch.ps1", "launch.cmd", "launch.vbs"):
            shutil.copyfile(tools / name, dest / name)
        ico = root / "assets" / "pennyworth.ico"
        if ico.is_file() and not (dest / "pennyworth.ico").is_file():
            shutil.copyfile(ico, dest / "pennyworth.ico")
        data = config.data_dir()
        data.mkdir(parents=True, exist_ok=True)
        (data / "program_location.txt").write_text(str(root), encoding="utf-8")
        return True
    except OSError:
        logging.exception("could not refresh the launcher")
        return False


def startup_command(frozen=None, executable=None, script=None, launcher=None):
    """The command line stored in the registry."""
    frozen = getattr(sys, "frozen", False) if frozen is None else frozen
    exe = executable or sys.executable
    if frozen:                                                    # the built Pennyworth.exe
        return f'"{exe}" --background'
    vbs = _launcher_vbs() if launcher is None else (launcher or None)
    if vbs:                                                       # the launcher (what the honeycomb-T shortcut runs), told to stay in the background
        wscript = Path(os.environ.get("SystemRoot") or r"C:\Windows") / "System32" / "wscript.exe"
        return f'"{wscript}" //B //Nologo "{vbs}" -Background'
    pyw = Path(exe).with_name("pythonw.exe")                     # python without a console window
    run_py = script or str(Path(__file__).resolve().parent.parent / "run.py")
    return f'"{pyw if pyw.is_file() else exe}" "{run_py}" --background'


def _stamp_file():
    return config.data_dir() / "background_start.txt"


def note_background_start():
    """Remember when Tallomi last started quietly (so Settings can show whether start at sign-in really happened)."""
    try:
        _stamp_file().write_text(time.strftime("%Y-%m-%d %H:%M:%S") + "\n", encoding="utf-8")
    except OSError:
        pass


def last_background_start():
    try:
        return _stamp_file().read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def _read(name, key_path):
    w = _winreg()
    try:
        with w.OpenKey(w.HKEY_CURRENT_USER, key_path, 0, w.KEY_READ) as k:
            return w.QueryValueEx(k, name)[0]
    except FileNotFoundError:
        return None


def disabled_in_task_manager():
    """Windows lets the user switch a startup entry off in Task Manager; that choice wins over the Run value."""
    try:
        data = _read(VALUE, APPROVED_KEY)
    except OSError:
        return False
    return bool(data) and isinstance(data, (bytes, bytearray)) and bool(data[0] & 1)      # 02 / 06 = enabled, 03 = disabled


def status():
    if not supported():
        return {"supported": False, "enabled": False, "up_to_date": False, "disabled_by_windows": False, "command": "",
                "last_start": ""}
    try:
        cur = _read(VALUE, RUN_KEY)
    except OSError as e:
        raise AutostartError(f"讀不到 Windows 的啟動設定：{e}") from None
    want = startup_command()
    return {"supported": True, "enabled": cur is not None, "up_to_date": cur == want, "command": cur or "",
            "disabled_by_windows": cur is not None and disabled_in_task_manager(), "last_start": last_background_start()}


def enable():
    if not supported():
        raise AutostartError("只有 Windows 支援開機自動啟動")
    sync_launcher()
    w = _winreg()
    try:
        with w.CreateKeyEx(w.HKEY_CURRENT_USER, RUN_KEY, 0, w.KEY_SET_VALUE) as k:
            w.SetValueEx(k, VALUE, 0, w.REG_SZ, startup_command())
        try:                                                     # clear an old "disabled in Task Manager" choice
            with w.OpenKey(w.HKEY_CURRENT_USER, APPROVED_KEY, 0, w.KEY_SET_VALUE) as k:
                w.DeleteValue(k, VALUE)
        except OSError:
            pass
    except OSError as e:
        raise AutostartError(f"無法寫入 Windows 的啟動設定：{e}") from None


def disable():
    if not supported():
        return
    w = _winreg()
    try:
        with w.OpenKey(w.HKEY_CURRENT_USER, RUN_KEY, 0, w.KEY_SET_VALUE) as k:
            w.DeleteValue(k, VALUE)
    except FileNotFoundError:
        pass
    except OSError as e:
        raise AutostartError(f"無法移除 Windows 的啟動設定：{e}") from None


def refresh_if_enabled():
    """Called at every start: if auto-start is on but points somewhere else (upgrade, moved folder), point it here."""
    try:
        st = status()
        if st["supported"] and st["enabled"]:
            sync_launcher()                                       # keep the launcher current on every start
            st = status()
        if st["supported"] and st["enabled"] and not st["up_to_date"]:
            enable()
            logging.info("auto-start entry refreshed")
    except Exception:
        logging.exception("could not refresh the auto-start entry")
