"""Read today's foreign-exchange board rates from the banks' own web pages.

Nothing here is saved automatically by itself: the caller decides. Every result can be wrong (a bank may change its
page, block automated visits, or show a promotional rate), so the UI always lets the person correct the numbers.

How a page is read:
  1. a plain HTTP request (works when the rates are in the page itself);
  2. if no rate is found, Edge/Chrome is started invisibly ("headless"), lets the page's scripts run, and we read the
     finished page (needed when the page fills in the rates with JavaScript).
The text of the page is turned into a flat list of text pieces; the rate is the first sensible pair of numbers that
follows the currency's name. Buy is always the smaller number, sell the larger one (a bank buys low and sells high).
"""
import os
import re
import shutil
import subprocess
import tempfile
import sys
import urllib.request
from datetime import datetime
from html.parser import HTMLParser

from . import config, pool

# currency -> words that name it on Taiwanese bank pages
CCY_WORDS = {
    "USD": ["美元", "美金", "USD"], "JPY": ["日圓", "日幣", "JPY"], "EUR": ["歐元", "EUR"], "CNY": ["人民幣", "CNY", "RMB"],
    "HKD": ["港幣", "HKD"], "AUD": ["澳幣", "澳洲幣", "AUD"], "GBP": ["英鎊", "GBP"], "CAD": ["加拿大幣", "加幣", "CAD"],
    "SGD": ["新加坡幣", "新幣", "SGD"], "CHF": ["瑞士法郎", "CHF"], "KRW": ["韓元", "韓圜", "韓幣", "KRW"],
    "THB": ["泰銖", "泰幣", "THB"], "NZD": ["紐西蘭幣", "紐幣", "NZD"], "MYR": ["馬來幣", "馬幣", "令吉", "MYR"],
    "VND": ["越南盾", "VND"],
}
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/124.0 Safari/537.36 Tallomi")
_NUM = re.compile(r"^\d{1,6}(?:\.\d{1,6})?$")
_WHEN = re.compile(r"(\d{4})\s*[年/\-.]\s*(\d{1,2})\s*[月/\-.]\s*(\d{1,2})\s*日?\s*(\d{1,2}):(\d{2})(?::(\d{2}))?")


class FetchError(Exception):
    pass


class _Tokens(HTMLParser):
    """Visible text of a page as a list of short pieces (one per text node)."""
    SKIP = {"script", "style", "noscript", "template", "head"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tokens, self._skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self._skip += 1

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if self._skip:
            return
        s = re.sub(r"\s+", " ", data).strip()
        if s:
            self.tokens.append(s)


def tokens_of(html):
    p = _Tokens()
    try:
        p.feed(html)
        p.close()
    except Exception:
        pass
    return p.tokens


def _is_marker(token, words):
    for w in words:
        if w.isascii():
            if re.search(rf"(?<![A-Za-z]){w}(?![A-Za-z])", token):
                return True
        elif w in token:
            return True
    return False


def parse_rate(html, currency, reference=None):
    """-> {"buy","sell","quoted_at"} or raises FetchError. `reference` (base units per 1 currency) only helps to
    ignore numbers that cannot be this currency's rate."""
    words = CCY_WORDS.get(currency)
    if not words:
        raise FetchError(f"還不支援從網站讀取 {currency}，請手動輸入")
    toks = tokens_of(html)
    others = [w for c, ws in CCY_WORDS.items() if c != currency for w in ws]
    when = None
    m = _WHEN.search(" ".join(toks))
    if m:
        try:
            when = datetime(int(m[1]), int(m[2]), int(m[3]), int(m[4]), int(m[5]), int(m[6] or 0)).strftime("%Y-%m-%dT%H:%M:%S")
        except ValueError:
            when = None
    for i, tok in enumerate(toks):
        if not _is_marker(tok, words):
            continue
        nums = []
        for t in toks[i + 1:i + 14]:
            if _is_marker(t, others):
                break
            tt = t.replace(",", "")
            if _NUM.match(tt):
                nums.append(float(tt))
        for a, b in zip(nums, nums[1:]):
            if a <= 0 or b <= 0 or max(a, b) / min(a, b) > 1.15:
                continue
            if reference and not all(0.75 < v / reference < 1.33 for v in (a, b)):
                continue
            return {"buy": min(a, b), "sell": max(a, b), "quoted_at": when}
    raise FetchError(f"頁面裡找不到 {currency} 的匯率（網站可能改版、需要登入，或擋掉了自動讀取）")


def find_browser():
    roots = [os.environ.get(k) for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
    for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"):
        for root in roots:
            if root and os.path.isfile(os.path.join(root, rel)):
                return os.path.join(root, rel)
    for name in ("msedge", "google-chrome", "chromium", "chromium-browser"):
        p = shutil.which(name)
        if p:
            return p
    return None


def http_get(url, timeout=12):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Language": "zh-TW,zh;q=0.9"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read(4_000_000)
        enc = r.headers.get_content_charset() or "utf-8"
    try:
        return raw.decode(enc, "replace")
    except LookupError:
        return raw.decode("utf-8", "replace")


def browser_get(url, timeout=45):
    exe = find_browser()
    if not exe:
        raise FetchError("找不到 Edge 或 Chrome，無法讀取需要執行網頁程式的頁面")
    prof = tempfile.mkdtemp(prefix="pw-fetch-")
    try:
        cmd = [exe, "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-extensions",
               "--mute-audio", f"--user-data-dir={prof}", "--virtual-time-budget=15000", "--dump-dom", url]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            p = subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=flags)
        except subprocess.TimeoutExpired:
            raise FetchError("網站太久沒有回應") from None
        return p.stdout.decode("utf-8", "replace")
    finally:
        shutil.rmtree(prof, ignore_errors=True)


def fetch_bank(bank, currency, reference=None, getters=None):
    """One bank -> {"bank","ok","buy","sell","quoted_at","via","url","error"} (never raises)."""
    url = config.BANK_RATE_URLS.get(bank)
    out = {"bank": bank, "ok": False, "url": url, "buy": None, "sell": None, "quoted_at": None, "via": None, "error": None}
    if not url:
        out["error"] = "沒有設定這家銀行的網址"
        return out
    http, browser = getters or (http_get, browser_get)
    problems = []
    for via, getter in (("http", http), ("browser", browser)):
        if via == "browser" and sys.platform == "emscripten" and getters is None:
            continue                  # the phone version has no Edge / Chrome to drive
        try:
            r = parse_rate(getter(url), currency, reference)
            out.update(ok=True, via=via, error=None, **r)
            return out
        except FetchError as e:
            problems.append(str(e))
        except Exception as e:   # network down, TLS, blocked ...
            problems.append("連不上網站" if isinstance(e, OSError) else f"讀取失敗（{type(e).__name__}）")
    out["error"] = problems[-1] if problems else "讀不到匯率"
    if all("連不上" in x for x in problems):
        out["error"] = "連不上網站（請確認有網路）"
    if sys.platform == "emscripten":
        out["error"] += "；手機版只能讀到允許跨站讀取的網站，讀不到時請手動輸入牌告匯率"
    return out


def fetch_all(currency, reference=None, getters=None):
    banks = list(config.BANKS)
    return pool.pmap(lambda b: fetch_bank(b, currency, reference, getters), banks, len(banks))
