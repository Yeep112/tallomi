"""Run a function over several items at once. Where threads cannot be started (the phone version runs in a browser, platform
"emscripten") the items are simply done one after another."""
import sys
from concurrent.futures import ThreadPoolExecutor


def pmap(fn, items, workers):
    items = list(items)
    if len(items) <= 1 or sys.platform == "emscripten":
        return [fn(i) for i in items]
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(items)))) as ex:
        return list(ex.map(fn, items))
