"""Investments on top of the ledger.

How the money is counted
- Every stock has its own account (TSMC, 0050, ...). Buying moves money from a bank/cash account INTO the stock
  account as a normal transfer, so the stock account's balance is the cost you paid (price x shares + fee).
  That cost is what counts as real assets.
- The gain or loss on shares you still hold is only an ESTIMATE (market value - cost). It is shown on the investment
  page and never added to any account balance or total.
- Selling moves money OUT of the stock account (the cost of the shares sold, oldest shares first) and INTO the bank
  account you choose (what you actually receive after fee and tax). Only then is the profit or loss real: it shows up
  as the difference between the two amounts, and in "已實現損益".
- Every trade remembers the transfer it made. Those transfers are managed from the investment page only, and after
  any change the cost taken out by each sale is recomputed, so the stock account always matches the shares held.
"""
from contextlib import nullcontext
import json
import threading
import time as _time
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_FLOOR, ROUND_HALF_UP

from . import config, money, pricefetch
from .timeutil import normalize_time, now_iso

MANUAL_LOCK = timedelta(hours=2)
ZERO = Decimal(0)


def _dec(v, label, allow_zero=False):
    try:
        d = Decimal(str(v).replace(",", "").strip())
    except Exception:
        raise _err(f"{label}格式不正確") from None
    if not d.is_finite() or d < 0 or (d == 0 and not allow_zero) or d > Decimal("100000000000"):
        raise _err(f"{label}必須大於 0" if not allow_zero else f"{label}不可為負數")
    return d


def _err(msg, status=400):
    from .book import BookError
    return BookError(msg, status)


def xirr(flows):
    """The yearly rate that makes the money in and out worth the same (Excel's XIRR). flows: [(date, amount)], money put in is negative.
    None when it cannot be worked out: nothing came back yet, nothing was put in, or less than 30 days between the first and the last flow
    (a month's gain turned into a year says nothing)."""
    flows = [(d, float(a)) for d, a in flows if a]
    if len(flows) < 2 or not any(a < 0 for _, a in flows) or not any(a > 0 for _, a in flows):
        return None
    t0 = min(d for d, _ in flows)
    if (max(d for d, _ in flows) - t0).days < 30:
        return None
    days = [(d - t0).days / 365.0 for d, _ in flows]

    def f(r):
        return sum(a / (1.0 + r) ** t for (_, a), t in zip(flows, days))
    lo, hi = -0.99, 20.0
    flo, fhi = f(lo), f(hi)
    if flo * fhi > 0:
        return None
    for _ in range(200):
        mid = (lo + hi) / 2
        fm = f(mid)
        if flo * fm <= 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return (lo + hi) / 2


class InvestMixin:
    _price_lock = threading.Lock()
    _last_price_fetch = 0.0

    # ------------------------------------------------------------ securities
    @staticmethod
    def _valid_symbol(symbol, market):
        import re
        s = str(symbol or "").strip().upper()
        if market == "TW" and not re.fullmatch(r"[0-9]{4,6}[A-Z]?", s):
            raise _err("台股代號是 4～6 位數字（例如 2330、0050、00940），有些 ETF 結尾有英文字母")
        if market == "US" and not re.fullmatch(r"[A-Z][A-Z.\-]{0,5}", s):
            raise _err("美股代號是 1～6 個英文字母，例如 NVDA")
        return s

    @staticmethod
    def _market(market):
        m = str(market or "").strip().upper()
        if m not in config.MARKET_CURRENCY:
            raise _err("市場必須是 台股(TW) 或 美股(US)")
        return m

    def _link_presets(self, conn):
        """Accounts named like the usual stocks (TSMC, 0050, 0056, UMC, NVDA) become investment accounts, once.
        A stock the person removed on purpose is not linked again."""
        gone = set(json.loads(self.get_setting(conn, "sec_removed", "[]") or "[]"))
        have = {r["account_id"] for r in conn.execute("SELECT account_id FROM securities")}
        for a in conn.execute("SELECT id,name FROM accounts").fetchall():
            if a["id"] in have or a["id"] in gone:
                continue
            for key, (sym, name, market) in config.SECURITY_PRESETS.items():
                if a["name"].lower() == key.lower():
                    conn.execute("INSERT INTO securities(account_id,symbol,name,market,currency) VALUES(?,?,?,?,?)",
                                 (a["id"], sym, name, market, config.MARKET_CURRENCY[market]))

    def _seed_holdings(self, conn):
        """Once: record the shares held today (config.INITIAL_HOLDINGS) as buys that move no money."""
        key = "holdings_seeded_20261112"
        if self.get_setting(conn, key) == "1" or not config.INITIAL_HOLDINGS:
            return []
        done = []
        for name, spec in config.INITIAL_HOLDINGS.items():
            a = conn.execute("SELECT * FROM accounts WHERE name=? COLLATE NOCASE", (name,)).fetchone()
            preset = next((v for k, v in config.SECURITY_PRESETS.items() if k.lower() == name.lower()), None)
            if not preset:
                continue
            sym, sname, market = preset
            if a is None:
                nxt = conn.execute("SELECT COALESCE(MAX(sort_order),-1)+1 FROM accounts").fetchone()[0]
                aid = conn.execute("INSERT INTO accounts(name,currency,opening_minor,sort_order,created_at) VALUES(?,?,?,?,?)",
                                   (name, config.MARKET_CURRENCY[market], 0, nxt, now_iso())).lastrowid
                ccy = config.MARKET_CURRENCY[market]
            else:
                aid, ccy = a["id"], a["currency"]
            if ccy != config.MARKET_CURRENCY[market] or conn.execute("SELECT 1 FROM stock_trades WHERE account_id=?", (aid,)).fetchone():
                continue
            if not conn.execute("SELECT 1 FROM securities WHERE account_id=?", (aid,)).fetchone():
                conn.execute("INSERT INTO securities(account_id,symbol,name,market,currency) VALUES(?,?,?,?,?)", (aid, sym, sname, market, config.MARKET_CURRENCY[market]))
            for day, shares, price, cost in spec["lots"]:
                p = Decimal(str(price)) if price else (Decimal(cost) / Decimal(shares)).quantize(Decimal("0.0001"))
                conn.execute("INSERT INTO stock_trades(account_id,tx_id,side,time,shares,price,fee,tax,cost_minor,pay_account_id,pay_minor,note,created_at)"
                             " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                             (aid, None, "buy", f"{day}T09:00:00", str(shares), format(p.normalize(), "f"), "0", "0",
                              self._minor_of(Decimal(cost), ccy), None, None, "現有持股（依券商畫面登錄）" + ("，其餘批次合計" if price is None else ""), now_iso()))
            if not self.latest_price(conn, sym):
                self._store_price(conn, sym, spec["price"], None, config.HOLDINGS_AS_OF, "broker")
            done.append(name)
        self.set_setting(conn, key, "1")
        return done

    def add_security(self, symbol, name, market, account_id=None, account_name=None, account_currency=None):
        market = self._market(market)
        sym = self._valid_symbol(symbol, market)
        name = str(name or "").strip()[:60]
        with self.session(notify=True) as c:
            if account_id in (None, ""):
                acct_name = self._clean_name(account_name or sym)
                ccy = money.normalize_currency(account_currency or config.MARKET_CURRENCY[market])
                nxt = c.execute("SELECT COALESCE(MAX(sort_order),-1)+1 FROM accounts").fetchone()[0]
                try:
                    aid = c.execute("INSERT INTO accounts(name,currency,opening_minor,sort_order,created_at) VALUES(?,?,?,?,?)",
                                    (acct_name, ccy, 0, nxt, now_iso())).lastrowid
                except Exception as e:
                    if "UNIQUE" in str(e):
                        raise _err(f"已經有名為「{acct_name}」的帳戶，請改選「使用現有帳戶」") from None
                    raise
            else:
                aid = self._get_account(c, int(account_id))["id"]
                if c.execute("SELECT 1 FROM securities WHERE account_id=?", (aid,)).fetchone():
                    raise _err("這個帳戶已經是投資標的了")
            c.execute("INSERT INTO securities(account_id,symbol,name,market,currency) VALUES(?,?,?,?,?)",
                      (aid, sym, name, market, config.MARKET_CURRENCY[market]))
            gone = [x for x in json.loads(self.get_setting(c, "sec_removed", "[]") or "[]") if x != aid]
            self.set_setting(c, "sec_removed", json.dumps(gone))
            return aid

    def update_security(self, account_id, data):
        with self.session(notify=True) as c:
            s = c.execute("SELECT * FROM securities WHERE account_id=?", (account_id,)).fetchone()
            if not s:
                raise _err("找不到這個投資標的", 404)
            used = c.execute("SELECT COUNT(*) FROM stock_trades WHERE account_id=?", (account_id,)).fetchone()[0]
            market = s["market"]
            if "market" in data and self._market(data["market"]) != market:
                if used:
                    raise _err("已經有買賣紀錄，不能更改市場")
                market = self._market(data["market"])
            sym = self._valid_symbol(data.get("symbol", s["symbol"]), market)
            name = str(data.get("name", s["name"]) or "").strip()[:60]
            c.execute("UPDATE securities SET symbol=?, name=?, market=?, currency=? WHERE account_id=?",
                      (sym, name, market, config.MARKET_CURRENCY[market], account_id))

    def remove_security(self, account_id):
        """Stop treating an account as an investment (the account itself is kept)."""
        with self.session(notify=True) as c:
            if c.execute("SELECT COUNT(*) FROM stock_trades WHERE account_id=?", (account_id,)).fetchone()[0]:
                raise _err("這檔股票已經有買賣紀錄，不能移除。請先刪除它的買賣紀錄。")
            if not c.execute("DELETE FROM securities WHERE account_id=?", (account_id,)).rowcount:
                raise _err("找不到這個投資標的", 404)
            gone = json.loads(self.get_setting(c, "sec_removed", "[]") or "[]")
            if account_id not in gone:
                gone.append(account_id)
            self.set_setting(c, "sec_removed", json.dumps(gone))

    def set_invest_settings(self, fee_discount=None):
        with self.session() as c:
            if fee_discount is not None:
                d = _dec(fee_discount, "手續費折扣")
                if d > 1:
                    raise _err("手續費折扣要在 0～1 之間（6 折請輸入 0.6）")
                self.set_setting(c, "tw_fee_discount", format(d.normalize(), "f"))

    # ------------------------------------------------------------ fees
    def _fee_rules(self, conn, sec):
        """How the broker's fee and the exchange tax are usually worked out for this stock (all editable per trade)."""
        if sec["market"] != "TW":
            return {"fee_rate": 0.0, "tax_rate": 0.0, "min_fee_lot": 0, "min_fee_odd": 0}
        disc = Decimal(self.get_setting(conn, "tw_fee_discount", "1") or "1")
        etf = sec["symbol"].startswith("00")
        return {"fee_rate": float(Decimal(config.TW_FEE_RATE) * disc),
                "tax_rate": float(Decimal(config.TW_TAX_ETF if etf else config.TW_TAX_STOCK)),
                "min_fee_lot": 20, "min_fee_odd": 1}

    @staticmethod
    def _est_fee_tax(rules, side, shares, price):
        gross = shares * price
        fee = (gross * Decimal(str(rules["fee_rate"]))).to_integral_value(ROUND_FLOOR) if rules["fee_rate"] else ZERO
        if rules["fee_rate"]:
            fee = max(fee, Decimal(rules["min_fee_odd"] if shares < 1000 else rules["min_fee_lot"]))
        tax = (gross * Decimal(str(rules["tax_rate"]))).to_integral_value(ROUND_FLOOR) if side == "sell" else ZERO
        return fee, tax

    # ------------------------------------------------------------ prices
    def latest_price(self, conn, symbol):
        r = conn.execute("SELECT * FROM stock_prices WHERE symbol=? ORDER BY at DESC, id DESC LIMIT 1", (symbol,)).fetchone()
        return dict(r) if r else None

    def _store_price(self, c, symbol, price, prev_close, at, source):
        text = format(Decimal(str(price)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP).normalize(), "f")
        prev = None
        if prev_close:
            prev = format(Decimal(str(prev_close)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP).normalize(), "f")
        at = at or now_iso()
        last = self.latest_price(c, symbol)
        if prev is None and last:
            prev = last["prev_close"]
        if last and Decimal(last["price"]) == Decimal(text) and last["source"] == source and last["at"][:10] == at[:10]:
            c.execute("UPDATE stock_prices SET at=?, prev_close=COALESCE(?,prev_close) WHERE id=?", (max(at, last["at"]), prev, last["id"]))
        else:
            c.execute("INSERT INTO stock_prices(symbol,price,prev_close,at,source) VALUES(?,?,?,?,?)", (symbol, text, prev, at, source))
        # keep every record of today and the last one of each earlier day
        c.execute("DELETE FROM stock_prices WHERE symbol=? AND substr(at,1,10)<? AND id NOT IN "
                  "(SELECT MAX(id) FROM stock_prices WHERE symbol=? GROUP BY substr(at,1,10))",
                  (symbol, now_iso()[:10], symbol))

    def set_price(self, symbol, price, source="manual"):
        sym = str(symbol or "").strip().upper()
        d = _dec(price, "股價")
        source = source if source in ("manual", "web") else "manual"
        with self.session() as c:
            if not c.execute("SELECT 1 FROM securities WHERE symbol=?", (sym,)).fetchone():
                raise _err("沒有這檔股票", 404)
            self._store_price(c, sym, d, None, None, source)

    def fetch_stock_prices(self, fetcher=None, force=False):
        """Read the current price of every stock on the page. A price typed by hand within the last 2 hours is not
        replaced; the web price is returned as `pending` so the person can choose to take it."""
        with self._price_lock:
            now = _time.monotonic()
            with self.session() as c:
                self._link_presets(c)
                secs = [dict(r) for r in c.execute("SELECT DISTINCT symbol, market FROM securities ORDER BY symbol")]
                refs = {}
                for s in secs:
                    lp = self.latest_price(c, s["symbol"])
                    refs[s["symbol"]] = float(Decimal(lp["price"])) if lp else None
            if not force and fetcher is None and now - InvestMixin._last_price_fetch < 15:
                return {"results": [], "applied": [], "pending": [], "failed": [], "throttled": True}
            InvestMixin._last_price_fetch = now
            results = (fetcher or pricefetch.fetch_prices)(secs, refs)
            applied, pending, failed = [], [], []
            with self.session(notify=True) as c:
                for s in secs:
                    r = results.get(s["symbol"]) or {"ok": False, "error": "沒有結果"}
                    sym = s["symbol"]
                    if not r.get("ok"):
                        failed.append({"symbol": sym, "error": r.get("error") or "讀不到價格"})
                        continue
                    last = self.latest_price(c, sym)
                    if last and last["source"] == "manual" and Decimal(str(r["price"])) != Decimal(last["price"]):
                        try:
                            age = datetime.now() - datetime.fromisoformat(last["at"])
                        except ValueError:
                            age = MANUAL_LOCK
                        if age < MANUAL_LOCK:
                            pending.append({"symbol": sym, "price": r["price"], "source": r.get("source"), "at": r.get("at"),
                                            "manual": float(Decimal(last["price"]))})
                            continue
                    self._store_price(c, sym, r["price"], r.get("prev_close"), r.get("at"), str(r.get("source") or "web")[:20])
                    applied.append({"symbol": sym, "price": r["price"], "source": r.get("source"), "note": r.get("note") or ""})
            return {"results": [{k: r.get(k) for k in ("symbol", "ok", "price", "source", "at", "error", "note")}
                                for r in (results.get(s["symbol"]) or {} for s in secs) if r],
                    "applied": applied, "pending": pending, "failed": failed, "throttled": False}

    # ------------------------------------------------------------ fx helper
    def _fx(self, conn, src, dst, rates=None):
        if src == dst:
            return Decimal(1)
        rates = rates or self.get_rates(conn)
        if src not in rates or dst not in rates:
            return None
        return rates[src] / rates[dst]

    @staticmethod
    def _minor_of(amount, ccy):
        q = Decimal(1).scaleb(-money.exponent(ccy))
        return int(amount.quantize(q, rounding=ROUND_HALF_UP).scaleb(money.exponent(ccy)))

    # ------------------------------------------------------------ replay
    def _replay(self, conn, account_id=None, strict=False):
        """Walk the trades oldest first. Shares are sold first-in-first-out.
        -> {account_id: {"lots":[...], "realized": minor, "removed": {trade_id: cost taken out}}}"""
        out = {}
        sql = "SELECT t.*, s.symbol FROM stock_trades t JOIN securities s ON s.account_id=t.account_id"
        args = ()
        if account_id is not None:
            sql += " WHERE t.account_id=?"
            args = (account_id,)
        for t in conn.execute(sql + " ORDER BY t.time, t.id", args):
            st = out.setdefault(t["account_id"], {"lots": [], "realized": 0, "removed": {}})
            shares = Decimal(t["shares"])
            if t["side"] == "buy":
                st["lots"].append({"trade_id": t["id"], "time": t["time"], "shares": shares, "price": Decimal(t["price"]),
                                   "cost": t["cost_minor"]})
                continue
            need, removed = shares, 0
            for lot in st["lots"]:
                if need <= 0:
                    break
                take = min(lot["shares"], need)
                if take == lot["shares"]:
                    part = lot["cost"]
                else:
                    part = int((Decimal(lot["cost"]) * take / lot["shares"]).quantize(Decimal(1), rounding=ROUND_HALF_UP))
                lot["shares"] -= take
                lot["cost"] -= part
                removed += part
                need -= take
            st["lots"] = [l for l in st["lots"] if l["shares"] > 0]
            if need > 0 and strict:
                raise _err(f"{t['symbol']} 在 {t['time'][:16].replace('T', ' ')} 賣出 {shares.normalize():f} 股，"
                           f"但當時只持有 {(shares - need).normalize():f} 股。請先補上買進紀錄，或刪除這筆賣出。")
            st["realized"] += t["cost_minor"] - removed
            st["removed"][t["id"]] = removed
        return out

    def _resync(self, conn, account_id):
        """Make the transfer of every sale carry exactly the cost of the shares it sold."""
        st = self._replay(conn, account_id, strict=True).get(account_id)
        if not st:
            return
        for tid, removed in st["removed"].items():
            conn.execute("UPDATE transactions SET amount_minor=?, updated_at=? WHERE id=(SELECT tx_id FROM stock_trades WHERE id=?)",
                         (max(1, removed), now_iso(), tid))

    # ------------------------------------------------------------ trades
    def trade(self, p, _conn=None):
        """Buy or sell. p: account_id (the stock's account), side, shares, price, fee, tax, time, pay_account_id
        (buy: where the money comes from, empty = shares you already held, no money moves; sell: where it goes),
        pay_amount (what really left / arrived, when the currency differs), acct_amount (cost / proceeds in the
        stock account's currency, when the quote currency differs), note."""
        side = str(p.get("side") or "").lower()
        if side not in ("buy", "sell"):
            raise _err("請選擇買進或賣出")
        with (self.session(notify=True) if _conn is None else nullcontext(_conn)) as c:      # _conn: part of a bigger change (editing a trade)
            try:
                aid = int(p.get("account_id"))
            except (TypeError, ValueError):
                raise _err("請選擇股票") from None
            sec = c.execute("SELECT s.*, a.currency AS acct_ccy, a.name AS acct_name FROM securities s "
                            "JOIN accounts a ON a.id=s.account_id WHERE s.account_id=?", (aid,)).fetchone()
            if not sec:
                raise _err("這個帳戶還不是投資標的", 404)
            try:
                when = normalize_time(p.get("time") or now_iso())
            except ValueError as e:
                raise _err(str(e)) from None
            shares = _dec(p.get("shares"), "股數")
            if sec["market"] == "TW" and shares != shares.to_integral_value():
                raise _err("台股股數要是整數（1 張 = 1000 股，零股直接輸入股數）")
            if shares > Decimal("1000000000"):
                raise _err("股數過大")
            price = _dec(p.get("price"), "成交價")
            fee = _dec(p.get("fee") or 0, "手續費", allow_zero=True)
            tax = _dec(p.get("tax") or 0, "證交稅", allow_zero=True) if side == "sell" else ZERO
            qccy, accy = sec["currency"], sec["acct_ccy"]
            gross = shares * price
            q_total = gross + fee if side == "buy" else gross - fee - tax
            if q_total <= 0:
                raise _err("扣掉手續費與稅之後，賣出金額必須大於 0")
            raw = p.get("acct_amount")
            if raw not in (None, ""):
                try:
                    a_total = money.parse_amount(raw)
                except ValueError as e:
                    raise _err(str(e)) from None
                if a_total <= 0:
                    raise _err("金額必須大於 0")
            else:
                fx = self._fx(c, qccy, accy)
                if fx is None:
                    raise _err(f"{qccy} 換成 {accy} 需要匯率：請輸入實際金額，或先到設定頁填匯率")
                a_total = q_total * fx
            cost_minor = self._minor_of(a_total, accy)
            if cost_minor <= 0:
                raise _err("金額太小，四捨五入後為 0")

            pay = None
            pay_id = p.get("pay_account_id")
            if pay_id not in (None, ""):
                try:
                    pay = c.execute("SELECT * FROM accounts WHERE id=?", (int(pay_id),)).fetchone()
                except (TypeError, ValueError):
                    pay = None
                if not pay:
                    raise _err("找不到所選的帳戶")
                if pay["id"] == aid:
                    raise _err("買賣的對象帳戶不能是股票自己的帳戶")
                if pay["archived"]:
                    raise _err(f"「{pay['name']}」已封存，請先取消封存")
            elif side == "sell":
                raise _err("請選擇賣出後入帳的帳戶")

            pay_minor = None
            if pay:
                raw = p.get("pay_amount")
                if raw not in (None, ""):
                    try:
                        pay_minor = money.to_minor(raw, pay["currency"])
                    except ValueError as e:
                        raise _err(str(e)) from None
                else:
                    fx = self._fx(c, accy, pay["currency"])
                    if fx is None:
                        raise _err(f"{accy} 與 {pay['currency']} 之間需要匯率：請輸入實際金額，或先到設定頁填匯率")
                    pay_minor = cost_minor if pay["currency"] == accy else self._minor_of(money.to_major(cost_minor, accy) * fx, pay["currency"])
                if pay_minor <= 0:
                    raise _err("金額必須大於 0")

            note_extra = str(p.get("note") or "").strip()[:200]
            word = "買進" if side == "buy" else "賣出"
            note = f"{word} {sec['symbol']} {shares.normalize():f}股 @{price.normalize():f}" + (f" {note_extra}" if note_extra else "")
            now = now_iso()
            tx_id = None
            if pay:
                src, dst = (pay["id"], aid) if side == "buy" else (aid, pay["id"])
                a_amt, b_amt = (pay_minor, cost_minor) if side == "buy" else (1, pay_minor)   # a sale's cost is set by _resync
                tx_id = c.execute(
                    "INSERT INTO transactions(time,type,category,note,amount_minor,account_id,to_account_id,to_amount_minor,"
                    "created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (when, "transfer", "", note, a_amt, src, dst, b_amt, now, now)).lastrowid
            tid = c.execute(
                "INSERT INTO stock_trades(account_id,tx_id,side,time,shares,price,fee,tax,cost_minor,pay_account_id,pay_minor,note,created_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (aid, tx_id, side, when, format(shares.normalize(), "f"), format(price.normalize(), "f"),
                 format(fee.normalize(), "f"), format(tax.normalize(), "f"), cost_minor, pay["id"] if pay else None,
                 pay_minor, note_extra, now)).lastrowid
            self._resync(c, aid)          # raises if this would sell more than is held
            realized = None
            if side == "sell":
                realized = money.from_minor(cost_minor - self._replay(c, aid)[aid]["removed"][tid], accy)
            return {"id": tid, "tx_id": tx_id, "realized": realized}

    def update_trade(self, trade_id, p):
        """Edit a buy / sell: the old record (and the transfer it made) is replaced by the new one in ONE step, so a refused edit
        (for example one that would sell shares that are not there) leaves everything exactly as it was."""
        with self.session(notify=True) as c:
            t = c.execute("SELECT * FROM stock_trades WHERE id=?", (trade_id,)).fetchone()
            if not t:
                raise _err("找不到這筆買賣紀錄（可能已被刪除）", 404)
            c.execute("DELETE FROM stock_trades WHERE id=?", (trade_id,))
            if t["tx_id"]:
                c.execute("DELETE FROM transactions WHERE id=?", (t["tx_id"],))
            old_account = t["account_id"]
            out = self.trade(p, _conn=c)
            if old_account != int(p.get("account_id")):
                self._resync(c, old_account)                  # the old stock lost a trade: later sales there must still have shares
            return out

    def delete_trades(self, ids):
        """The investment page's one-click delete: every ticked buy / sell goes, with the money moves they made. All or nothing."""
        try:
            ids = list(dict.fromkeys(int(i) for i in ids or []))
        except (TypeError, ValueError):
            raise _err("請先勾選要刪除的買賣紀錄") from None
        if not ids or len(ids) > 500:
            raise _err("請先勾選要刪除的買賣紀錄（一次最多 500 筆）")
        snaps = []
        with self.session(notify=True) as c:
            accounts, n = set(), 0
            for i in ids:
                t = c.execute("SELECT * FROM stock_trades WHERE id=?", (i,)).fetchone()
                if not t:
                    continue
                snaps.append(self._trade_snapshot(c, t))
                c.execute("DELETE FROM stock_trades WHERE id=?", (i,))
                if t["tx_id"]:
                    c.execute("DELETE FROM transactions WHERE id=?", (t["tx_id"],))
                accounts.add(t["account_id"])
                n += 1
            if not n:
                raise _err("勾選的買賣紀錄已經不存在了", 404)
            for aid in accounts:
                self._resync(c, aid)                          # raises (and undoes everything) if a remaining sale would have no shares
        return {"deleted": n, "undo": self._remember_undo(snaps)}

    def delete_trade(self, trade_id):
        with self.session(notify=True) as c:
            t = c.execute("SELECT * FROM stock_trades WHERE id=?", (trade_id,)).fetchone()
            if not t:
                raise _err("找不到這筆買賣紀錄（可能已被刪除）", 404)
            snap = self._trade_snapshot(c, t)
            c.execute("DELETE FROM stock_trades WHERE id=?", (trade_id,))
            if t["tx_id"]:
                c.execute("DELETE FROM transactions WHERE id=?", (t["tx_id"],))
            self._resync(c, t["account_id"])      # a later sale may no longer have shares to sell
        return self._remember_undo([snap])

    _TRADE_COLS = ("id", "account_id", "tx_id", "side", "time", "shares", "price", "fee", "tax", "cost_minor",
                   "pay_account_id", "pay_minor", "note", "created_at")

    def _trade_snapshot(self, c, t):
        """What "復原" needs to put a deleted buy / sell back: the trade row and the transfer it made (with its tags and photos)."""
        snap = {"trade": {k: t[k] for k in self._TRADE_COLS}}
        if t["tx_id"]:
            snap["txsnap"] = self._snapshot(c, t["tx_id"])
        return snap

    # ------------------------------------------------------------ dividends (1.67.0)
    def _dividend_fields(self, c, p, existing=None):
        try:
            aid = int(p.get("account_id", existing["account_id"] if existing else None))
        except (TypeError, ValueError):
            raise _err("請選擇股票") from None
        sec = c.execute("SELECT * FROM securities WHERE account_id=?", (aid,)).fetchone()
        if not sec:
            raise _err("這個帳戶還不是投資標的", 404)
        try:
            pay_id = int(p.get("pay_account_id", existing["pay_id"] if existing else None))
        except (TypeError, ValueError):
            raise _err("請選擇股利入帳的帳戶") from None
        pay = c.execute("SELECT * FROM accounts WHERE id=?", (pay_id,)).fetchone()
        if not pay:
            raise _err("找不到入帳的帳戶", 404)
        if c.execute("SELECT 1 FROM securities WHERE account_id=?", (pay_id,)).fetchone():
            raise _err("股利要入到銀行或現金帳戶，不能入到股票帳戶")
        if pay["archived"] and not (existing and existing["pay_id"] == pay_id):
            raise _err(f"「{pay['name']}」已封存")
        try:
            when = normalize_time(p.get("time") or (existing["time"] if existing else now_iso()))
        except ValueError as e:
            raise _err(str(e)) from None
        try:
            amount = money.to_minor(p.get("amount", money.from_minor(existing["amount_minor"], pay["currency"]) if existing and existing["pay_id"] == pay_id else None), pay["currency"])
        except ValueError as e:
            raise _err(str(e)) from None
        if amount <= 0:
            raise _err("股利金額必須大於 0")
        per = str(p.get("per_share", existing["per_share"] if existing else "") or "").strip()
        if per:
            per = format(_dec(per, "每股股利").normalize(), "f")
        note = str(p.get("note", existing["note"] if existing else "") or "").strip()[:200]
        held = ZERO
        for t in c.execute("SELECT side, shares FROM stock_trades WHERE account_id=? AND time<=?", (aid, when)):
            held += Decimal(t["shares"]) if t["side"] == "buy" else -Decimal(t["shares"])
        return sec, aid, pay, when, amount, per, note, max(held, ZERO)

    def add_dividend(self, p):
        """p: account_id (the stock), time, amount (what really arrived), pay_account_id, per_share (optional), note."""
        with self.session(notify=True) as c:
            sec, aid, pay, when, amount, per, note, held = self._dividend_fields(c, p)
            now = now_iso()
            text = f"{sec['symbol']} 股利" + (f" {note}" if note else "")
            tx_id = c.execute("INSERT INTO transactions(time,type,category,note,amount_minor,account_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                              (when, "income", "股利", text, amount, pay["id"], now, now)).lastrowid
            did = c.execute("INSERT INTO stock_dividends(account_id,tx_id,time,shares,per_share,note,created_at) VALUES(?,?,?,?,?,?,?)",
                            (aid, tx_id, when, format(held.normalize(), "f"), per, note, now)).lastrowid
            return {"id": did, "tx_id": tx_id}

    def _dividend_row(self, c, did):
        row = c.execute("SELECT d.*, t.account_id AS pay_id, t.amount_minor FROM stock_dividends d JOIN transactions t ON t.id=d.tx_id WHERE d.id=?", (did,)).fetchone()
        if not row:
            raise _err("找不到這筆股利", 404)
        return row

    def update_dividend(self, did, p):
        with self.session(notify=True) as c:
            old = self._dividend_row(c, did)
            if "account_id" in p and int(p["account_id"]) != old["account_id"]:
                raise _err("股利所屬的股票不能改，請刪除後重新記一筆")
            sec, aid, pay, when, amount, per, note, held = self._dividend_fields(c, p, old)
            now = now_iso()
            text = f"{sec['symbol']} 股利" + (f" {note}" if note else "")
            c.execute("UPDATE transactions SET time=?, note=?, amount_minor=?, account_id=?, updated_at=? WHERE id=?", (when, text, amount, pay["id"], now, old["tx_id"]))
            c.execute("UPDATE stock_dividends SET time=?, shares=?, per_share=?, note=? WHERE id=?", (when, format(held.normalize(), "f"), per, note, did))
            return {"id": did}

    def delete_dividend(self, did):
        with self.session(notify=True) as c:
            old = self._dividend_row(c, did)
            c.execute("DELETE FROM transactions WHERE id=?", (old["tx_id"],))              # the dividend row goes with it
            return {"deleted": 1}

    # ------------------------------------------------------------ the page
    def invest_board(self, conn):
        self._link_presets(conn)
        rows, bal, accts = self.ledger(conn)
        rates = self.get_rates(conn)
        base = self.base_currency(conn)
        disc = self.get_setting(conn, "tw_fee_discount", "1") or "1"
        replay = self._replay(conn)
        positions, totals = [], {"value": ZERO, "cost": ZERO, "realized": ZERO, "missing": 0, "no_rate": 0,
                                 "day": ZERO, "day_from": ZERO, "day_n": 0, "sold": ZERO, "div": ZERO, "div_ttm": ZERO, "gross": ZERO}
        today = date.today()
        ttm_from = (today - timedelta(days=365)).isoformat()
        divs, trade_flows = {}, {}
        for d in conn.execute("SELECT d.*, t.account_id AS pay_id, t.amount_minor, p.currency AS pay_ccy, p.name AS pay_name FROM stock_dividends d "
                              "JOIN transactions t ON t.id=d.tx_id JOIN accounts p ON p.id=t.account_id ORDER BY d.time DESC, d.id DESC"):
            divs.setdefault(d["account_id"], []).append(d)
        for t in conn.execute("SELECT account_id, side, time, cost_minor FROM stock_trades ORDER BY time, id"):
            trade_flows.setdefault(t["account_id"], []).append((date.fromisoformat(t["time"][:10]), -t["cost_minor"] if t["side"] == "buy" else t["cost_minor"]))
        pf_flows, pf_ok = [], True                                   # every stock's money in and out, in the base currency, for the whole portfolio's yearly return
        to_base = lambda minor, ccy: (money.to_major(minor, ccy) * rates[ccy]) if ccy in rates else None
        secs = conn.execute("SELECT s.*, a.name AS acct_name, a.currency AS acct_ccy, a.archived FROM securities s "
                            "JOIN accounts a ON a.id=s.account_id ORDER BY a.sort_order, a.id").fetchall()
        sec_ids = {s["account_id"] for s in secs}
        for s in secs:
            aid, accy, qccy = s["account_id"], s["acct_ccy"], s["currency"]
            st = replay.get(aid) or {"lots": [], "realized": 0, "removed": {}}
            lots = st["lots"]
            shares = sum((l["shares"] for l in lots), ZERO)
            cost = sum(l["cost"] for l in lots)
            lp = self.latest_price(conn, s["symbol"])
            price = Decimal(lp["price"]) if lp else None
            prev = Decimal(lp["prev_close"]) if lp and lp["prev_close"] else None
            fx = self._fx(conn, qccy, accy, rates)
            rules = self._fee_rules(conn, s)
            # dividends, in the stock account's currency (what arrived is converted at today's rate when it came in another currency)
            dv_total = dv_ttm = 0
            dv_flows, dv_missing = [], False
            for d in divs.get(aid, []):
                f = self._fx(conn, d["pay_ccy"], accy, rates)
                if f is None:
                    dv_missing = True
                    continue
                m = d["amount_minor"] if d["pay_ccy"] == accy else self._minor_of(money.to_major(d["amount_minor"], d["pay_ccy"]) * f, accy)
                dv_total += m
                if d["time"][:10] >= ttm_from:
                    dv_ttm += m
                dv_flows.append((date.fromisoformat(d["time"][:10]), m))

            def val(sh, gross=False):
                """Market value of `sh` shares. Like the broker's app it is what a sale would bring in: the estimated
                sell fee and exchange tax are taken off (each batch of shares on its own, rounded down)."""
                if price is None or fx is None:
                    return None
                g = sh * price
                if not gross and rules["fee_rate"]:
                    fee, tax = self._est_fee_tax(rules, "sell", sh, price)
                    g = (g - fee - tax).to_integral_value(ROUND_FLOOR)
                return self._minor_of(g * fx, accy)

            lot_vals = [val(l["shares"]) for l in lots]
            value = (0 if not lots else (None if any(v is None for v in lot_vals) else sum(lot_vals)))
            gross_value = val(shares, gross=True) if shares > 0 else 0
            pnl = (value - cost) if value is not None else None
            ret = (pnl / cost) if (pnl is not None and cost) else None
            lot_out = []
            for l, lv in zip(lots, lot_vals):
                lot_out.append({"trade_id": l["trade_id"], "time": l["time"], "shares": float(l["shares"]), "price": float(l["price"]),
                                "cost": money.from_minor(l["cost"], accy), "value": money.from_minor(lv, accy) if lv is not None else None,
                                "pnl": money.from_minor(lv - l["cost"], accy) if lv is not None else None,
                                "ret": ((lv - l["cost"]) / l["cost"]) if lv is not None and l["cost"] else None})
            held = shares > 0
            # today's move: the quote against the previous close, on the shares held now (no fees: it is the market's move, not a sale)
            day_change = day_from = None
            if held and price is not None and prev is not None and fx is not None:
                day_change = self._minor_of((price - prev) * shares * fx, accy)
                day_from = self._minor_of(prev * shares * fx, accy)
            # everything the stock has made so far: what the shares held now would bring (pnl) plus what earlier sales already made (realized),
            # against everything that was ever put in (the cost of the shares held now + the cost of the shares that were sold)
            sold_cost = sum(st["removed"].values())
            total_pnl = (pnl + st["realized"]) if pnl is not None else None
            total_in = cost + sold_cost
            total_ret = (total_pnl / total_in) if (total_pnl is not None and total_in) else None
            flows = list(trade_flows.get(aid, [])) + dv_flows
            if held and value is not None:
                flows.append((today, value))
            pos_xirr = xirr(flows) if (value is not None and not dv_missing) else None
            if accy in rates:
                pf_flows += [(d, float(to_base(m, accy))) for d, m in flows]
                totals["div"] += to_base(dv_total, accy)
            if held and value is None:
                pf_ok = False
            div_yield = (dv_ttm / gross_value) if (held and gross_value) else None
            cost_yield = (dv_ttm / cost) if (held and cost) else None
            if held:
                if gross_value and accy in rates:
                    totals["gross"] += to_base(gross_value, accy)
                    totals["div_ttm"] += to_base(dv_ttm, accy)
            if held:
                if value is None:
                    totals["missing"] += 1
                elif accy not in rates:
                    totals["no_rate"] += 1
                else:
                    totals["value"] += to_base(value, accy)
                    totals["cost"] += to_base(cost, accy)
                    if day_change is not None:
                        totals["day"] += to_base(day_change, accy)
                        totals["day_from"] += to_base(day_from, accy)
                        totals["day_n"] += 1
            if accy in rates:
                totals["realized"] += to_base(st["realized"], accy)
                totals["sold"] += to_base(sold_cost, accy)
            positions.append({
                "account_id": aid, "account": s["acct_name"], "currency": accy, "quote_currency": qccy, "archived": bool(s["archived"]),
                "symbol": s["symbol"], "name": s["name"], "market": s["market"], "shares": float(shares),
                "cost": money.from_minor(cost, accy), "avg_cost": float(money.to_major(cost, accy) / shares) if shares > 0 else None,
                "price": float(price) if price is not None else None,
                "price_at": lp["at"] if lp else None, "price_source": lp["source"] if lp else None,
                "prev_close": float(prev) if prev else None,
                "day_pct": float((price - prev) / prev) if price is not None and prev else None,
                "day_change": money.from_minor(day_change, accy) if day_change is not None else None,
                "total_pnl": money.from_minor(total_pnl, accy) if total_pnl is not None else None,
                "total_ret": float(total_ret) if total_ret is not None else None,
                "value": money.from_minor(value, accy) if value is not None else None,
                "pnl": money.from_minor(pnl, accy) if pnl is not None else None, "ret": float(ret) if ret is not None else None,
                "gross_value": money.from_minor(gross_value, accy) if gross_value is not None else None,
                "realized": money.from_minor(st["realized"], accy),
                "dividends": money.from_minor(dv_total, accy), "dividends_ttm": money.from_minor(dv_ttm, accy),
                "yield": div_yield, "yield_cost": cost_yield, "xirr": pos_xirr, "dividend_missing_rate": dv_missing,
                "balance": money.from_minor(bal[aid], accy),
                "balance_gap": money.from_minor(bal[aid] - cost, accy),
                "needs_rate": bool(price is not None and fx is None),
                "rules": rules, "lots": lot_out,
            })
        trades = []
        for t in conn.execute("SELECT t.*, s.symbol, s.name AS sname, a.currency AS acct_ccy, a.name AS acct_name, p.name AS pay_name, "
                              "p.currency AS pay_ccy FROM stock_trades t JOIN securities s ON s.account_id=t.account_id "
                              "JOIN accounts a ON a.id=t.account_id LEFT JOIN accounts p ON p.id=t.pay_account_id "
                              "ORDER BY t.time DESC, t.id DESC LIMIT 200"):
            removed = (replay.get(t["account_id"]) or {}).get("removed", {}).get(t["id"])
            trades.append({"id": t["id"], "time": t["time"], "side": t["side"], "account_id": t["account_id"], "account": t["acct_name"],
                           "symbol": t["symbol"], "name": t["sname"], "shares": float(Decimal(t["shares"])), "price": float(Decimal(t["price"])),
                           "fee": float(Decimal(t["fee"])), "tax": float(Decimal(t["tax"])), "currency": t["acct_ccy"],
                           "amount": money.from_minor(t["cost_minor"], t["acct_ccy"]),
                           "pay_account": t["pay_name"], "pay_currency": t["pay_ccy"],
                           "pay_amount": money.from_minor(t["pay_minor"], t["pay_ccy"]) if t["pay_minor"] is not None and t["pay_ccy"] else None,
                           "realized": money.from_minor(t["cost_minor"] - removed, t["acct_ccy"]) if removed is not None else None,
                           "note": t["note"], "moved_money": t["tx_id"] is not None, "pay_account_id": t["pay_account_id"]})
        pickable = [{"id": a["id"], "name": a["name"], "currency": a["currency"], "balance": money.from_minor(bal[a["id"]], a["currency"])}
                    for a in sorted(accts.values(), key=lambda a: (a["sort_order"], a["id"]))
                    if not a["archived"] and a["id"] not in sec_ids]
        value, cost = totals["value"], totals["cost"]
        dec = money.exponent(base)
        r = lambda d: float(d.quantize(Decimal(1).scaleb(-dec), rounding=ROUND_HALF_UP))
        dividend_list = []
        for aid_, lst in divs.items():
            sec_ = next((x for x in secs if x["account_id"] == aid_), None)
            for d in lst:
                dividend_list.append({"id": d["id"], "time": d["time"], "account_id": aid_, "symbol": sec_["symbol"] if sec_ else "", "name": (sec_["name"] if sec_ else ""),
                                      "amount": money.from_minor(d["amount_minor"], d["pay_ccy"]), "currency": d["pay_ccy"], "pay_account_id": d["pay_id"], "pay_account": d["pay_name"],
                                      "shares": float(Decimal(d["shares"])), "per_share": float(Decimal(d["per_share"])) if d["per_share"] else None, "note": d["note"], "tx_id": d["tx_id"]})
        dividend_list.sort(key=lambda d: (d["time"], d["id"]), reverse=True)
        # where the money is: every stock held (what it would bring in), and the cash and deposits by currency (debts are left out and shown as a number)
        slices, debt = [], ZERO
        for pos in positions:
            if pos["shares"] > 0 and pos["value"] is not None and pos["currency"] in rates:
                slices.append({"key": f"s{pos['account_id']}", "label": pos["name"] or pos["symbol"], "symbol": pos["symbol"], "kind": "stock", "currency": pos["currency"],
                               "market": pos["market"], "value": r(Decimal(str(pos["value"])) * rates[pos["currency"]])})
        cash = {}
        for a in accts.values():
            if a["archived"] or a["id"] in sec_ids or a["currency"] not in rates:
                continue
            v = money.to_major(bal[a["id"]], a["currency"]) * rates[a["currency"]]
            if v > 0:
                cash[a["currency"]] = cash.get(a["currency"], ZERO) + v
            else:
                debt += -v
        for ccy, v in sorted(cash.items(), key=lambda kv: -kv[1]):
            slices.append({"key": f"c{ccy}", "label": "現金與存款" + ("" if ccy == base else f"（{ccy}）"), "symbol": "", "kind": "cash", "currency": ccy, "market": "", "value": r(v)})
        pf_x = xirr(pf_flows) if (pf_ok and not totals["missing"] and not totals["no_rate"]) else None
        return {
            "base": base, "positions": positions, "trades": trades, "accounts": pickable, "fee_discount": float(Decimal(disc)),
            "totals": {"value": r(value), "cost": r(cost), "pnl": r(value - cost), "ret": float((value - cost) / cost) if cost else None,
                       "realized": r(totals["realized"]),
                       "day_pnl": r(totals["day"]), "day_ret": float(totals["day"] / totals["day_from"]) if totals["day_from"] else None,
                       "day_count": totals["day_n"],
                       "total_pnl": r(value - cost + totals["realized"]),
                       "total_ret": float((value - cost + totals["realized"]) / (cost + totals["sold"])) if (cost + totals["sold"]) else None,
                       "missing_prices": totals["missing"], "missing_rates": totals["no_rate"],
                       "dividends": r(totals["div"]), "dividends_ttm": r(totals["div_ttm"]),
                       "yield": float(totals["div_ttm"] / totals["gross"]) if totals["gross"] else None,
                       "total_pnl_div": r(value - cost + totals["realized"] + totals["div"]),
                       "total_ret_div": float((value - cost + totals["realized"] + totals["div"]) / (cost + totals["sold"])) if (cost + totals["sold"]) else None,
                       "xirr": pf_x},
            "dividends": dividend_list[:200],
            "allocation": {"base": base, "slices": slices, "debt": r(debt)},
            "markets": config.MARKET_CURRENCY,
        }
