"""Every Taiwan listed (上市) and OTC (上櫃) stock and ETF, plus the price history behind the charts.

Nothing here touches the book: the list lives in its own small file (market_list.json next to the book) because it is
public market data that can always be fetched again, and it would only bloat backups and the phone sync.

Sources (all public, no sign-in):
  list     TWSE open data   openapi.twse.com.tw  /exchangeReport/STOCK_DAY_ALL   (every listed stock and ETF, last trading day)
           TPEx open data   www.tpex.org.tw      /openapi/v1/tpex_mainboard_daily_close_quotes   (every OTC stock and ETF)
  history  Yahoo Finance chart data (SYMBOL.TW / SYMBOL.TWO): today, 5 days, 1 / 3 / 6 months, 1 / 5 years
           fallback for listed stocks: TWSE monthly daily-price report (for the 1 month ... 1 year ranges)
The parsers are pure functions (unit-tested with sample data); a source that changes its layout makes a clear error
instead of wrong numbers, and the last good list is kept.
"""
import json
import logging
import os
import re
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import pool, pricefetch

log = logging.getLogger(__name__)

TWSE_ALL = "https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL"
TPEX_ALL = "https://www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes"
TPEX_ALL_ALT = "https://www.tpex.org.tw/openapi/v1/tpex_mainboard_quotes"          # same data under its other name
YAHOO_CHART = "https://query1.finance.yahoo.com/v8/finance/chart/{sym}?range={rng}&interval={iv}"
TWSE_MONTH = "https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=json&date={ym}01&stockNo={sym}"

TAIPEI = timezone(timedelta(hours=8))
CODE_RE = re.compile(r"^[0-9]{4,6}[A-Z]?$")
# range -> (Yahoo range, Yahoo interval, seconds a downloaded history is reused)
RANGES = {"1d": ("1d", "5m", 90), "5d": ("5d", "15m", 180), "1mo": ("1mo", "1d", 1800), "3mo": ("3mo", "1d", 1800),
          "6mo": ("6mo", "1d", 3600), "1y": ("1y", "1d", 3600), "5y": ("5y", "1wk", 6 * 3600)}
FALLBACK_MONTHS = {"1mo": (2, 31), "3mo": (4, 92), "6mo": (7, 183), "1y": (13, 366)}      # months to read, days to keep
REFRESH_AFTER = (14, 30)          # the exchanges have published the day's prices by now
RETRY_SECONDS = 1800
MAX_SAVED_HISTORY = 150            # curves kept for offline use (the least recently fetched are dropped)


class MarketError(Exception):
    pass


def _num(v):
    """'1,234.50' -> 1234.5 ; '', '--', '---', 'X0.00', None -> None. A sign is kept."""
    if v is None:
        return None
    t = str(v).replace(",", "").strip()
    if not t or not re.fullmatch(r"[+-]?\d+(\.\d+)?", t):
        return None
    return float(t)


def _price(v):
    x = _num(v)
    return x if x and x > 0 else None


def roc_to_iso(s):
    """'1141112' / '114/11/12' (Republic of China years) or '20251112' -> '2025-11-12'; None if unreadable."""
    t = str(s or "").strip()
    try:
        if "/" in t:
            y, m, d = [int(x) for x in t.split("/")]
        elif len(t) == 7 and t.isdigit():
            y, m, d = int(t[:3]), int(t[3:5]), int(t[5:7])
        elif len(t) == 8 and t.isdigit():
            return datetime.strptime(t, "%Y%m%d").strftime("%Y-%m-%d")
        else:
            return None
        return datetime(y + 1911 if y < 1911 else y, m, d).strftime("%Y-%m-%d")
    except ValueError:
        return None


def kind_of(code):
    """Taiwan ETF codes start with 00 (0050, 00878, 00679B ...); everything else is an ordinary stock."""
    return "etf" if code.startswith("00") else "stock"


def _row(code, name, market, close, change, open_, high, low, volume):
    prev = round(close - change, 4) if close is not None and change is not None else None
    return {"c": code, "n": str(name or "").strip(), "m": market, "k": kind_of(code), "p": close,
            "ch": change if close is not None else None, "pc": prev, "o": open_, "h": high, "l": low, "v": int(volume) if volume else 0}


def _json_list(text, who):
    text = (text or "").lstrip("\ufeff \t\r\n")                  # some servers start the file with a byte-order mark
    try:
        data = json.loads(text)
    except ValueError:
        snippet = re.sub(r"\s+", " ", text[:70])
        raise MarketError(f"{who}回傳的不是資料（開頭是：{snippet or '空白'}）") from None
    if not isinstance(data, list):
        raise MarketError(f"{who}回傳的資料格式不同了")
    return data


def _norm(k):
    return re.sub(r"[^0-9a-z\u4e00-\u9fff]", "", str(k).lower())


class _Fields:
    """Reads one record of an exchange's list without depending on one exact spelling of the field names.
    Each field has the names seen so far (exact match, ignoring case and punctuation), then a few keywords as a fallback,
    so a renamed column (Close -> ClosingPrice, Code -> SecuritiesCompanyCode ...) keeps working."""
    FIELDS = {
        "code": (("code", "securitiescompanycode", "stockcode", "股票代號", "證券代號", "代號"), ("代號", "code")),
        "name": (("name", "companyname", "securitiesname", "股票名稱", "證券名稱", "名稱", "公司名稱"), ("name", "名稱")),
        "date": (("date", "日期", "tradedate", "資料日期"), ("date", "日期")),
        "close": (("close", "closingprice", "closeprice", "收盤價", "收盤"), ("close", "收盤")),
        "change": (("change", "pricechange", "漲跌", "漲跌價差"), ("change", "漲跌")),
        "open": (("open", "openingprice", "openprice", "開盤價", "開盤"), ("open", "開盤")),
        "high": (("high", "highestprice", "highprice", "最高價", "最高"), ("high", "最高")),
        "low": (("low", "lowestprice", "lowprice", "最低價", "最低"), ("low", "最低")),
        "volume": (("tradingshares", "tradevolume", "tradingvolume", "volume", "成交股數", "成交量", "成交數量"), ("volume", "shares", "成交股", "成交量")),
    }

    def __init__(self, item):
        self.item = item
        self.keys = {_norm(k): k for k in item}

    def get(self, field):
        names, words = self.FIELDS[field]
        for n in names:
            k = self.keys.get(_norm(n))
            if k is not None:
                return self.item[k]
        for nk, k in self.keys.items():
            if any(w in nk for w in words) and not (field == "change" and "percent" in nk) and not (field == "close" and "change" in nk):
                return self.item[k]
        return None


def _no_rows(who, items):
    """Nothing could be read: say which field names the exchange sent, so a format change can be spotted at once."""
    first = next((i for i in items if isinstance(i, dict)), None)
    seen = "、".join(list(first)[:8]) if first else "（沒有任何一筆）"
    return MarketError(f"{who}的資料裡讀不到股票代號（可能改版了）。收到的欄位：{seen}")


def _parse_all(text, who, market):
    items = _json_list(text, who)
    out, date = [], None
    for it in items:
        if not isinstance(it, dict):
            continue
        f = _Fields(it)
        code = str(f.get("code") or "").strip().upper()
        if not CODE_RE.match(code):
            continue
        date = date or roc_to_iso(f.get("date"))
        close = _price(f.get("close"))
        out.append(_row(code, f.get("name"), market, close, _num(f.get("change")) if close else None,
                        _price(f.get("open")), _price(f.get("high")), _price(f.get("low")), _num(f.get("volume"))))
    if not out:
        raise _no_rows(who, items)
    return date, out


def parse_twse_all(text):
    """STOCK_DAY_ALL -> (trade_date, [row]). Usual keys: Date, Code, Name, TradeVolume, OpeningPrice, HighestPrice, LowestPrice, ClosingPrice, Change."""
    return _parse_all(text, "證交所", "TWSE")


def parse_tpex_all(text):
    """tpex_mainboard_daily_close_quotes -> (trade_date, [row]). Usual keys: Date, SecuritiesCompanyCode, CompanyName, Close, Change, Open, High, Low, TradingShares."""
    return _parse_all(text, "櫃買中心", "TPEx")


def parse_yahoo_history(text, rng):
    """Yahoo chart JSON -> {"points": [[epoch_seconds, close]], "price", "prev_close", "day_high", "day_low", "name"}."""
    try:
        res = json.loads(text)["chart"]["result"][0]
        ts = res.get("timestamp") or []
        closes = res["indicators"]["quote"][0].get("close") or []
        meta = res.get("meta") or {}
    except (ValueError, KeyError, IndexError, TypeError):
        raise MarketError("Yahoo 沒有這檔股票的走勢資料") from None
    pts = [[int(t), round(float(c), 4)] for t, c in zip(ts, closes) if c is not None and c > 0]
    if len(pts) < 2:
        raise MarketError("Yahoo 的走勢資料太少")
    return {"points": pts, "price": _price(meta.get("regularMarketPrice")),
            "prev_close": _price(meta.get("chartPreviousClose")) if rng == "1d" else None,
            "day_high": _price(meta.get("regularMarketDayHigh")), "day_low": _price(meta.get("regularMarketDayLow")),
            "name": meta.get("longName") or meta.get("shortName") or ""}


def parse_twse_month(text):
    """TWSE STOCK_DAY (one month of one stock) -> [[epoch_seconds, close]]. Rows: [date, volume, value, open, high, low, close, change, trades]."""
    try:
        data = json.loads(text)
    except ValueError:
        raise MarketError("證交所回傳的不是資料") from None
    if str(data.get("stat", "")).upper() != "OK":
        return []
    pts = []
    for row in data.get("data") or []:
        try:
            day = roc_to_iso(row[0])
            close = _price(row[6])
            if day and close:
                y, m, d = [int(x) for x in day.split("-")]
                pts.append([int(datetime(y, m, d, 13, 30, tzinfo=TAIPEI).timestamp()), close])
        except (IndexError, TypeError):
            continue
    return pts


def summarize(points):
    """First / last / high / low and the change over the whole range."""
    first, last = points[0][1], points[-1][1]
    return {"first": first, "last": last, "high": max(p[1] for p in points), "low": min(p[1] for p in points),
            "change": round(last - first, 4), "pct": (last - first) / first if first else None}


class MarketData:
    def __init__(self, path, getter_fn=None):
        self.path = Path(path)
        self._getter_fn = getter_fn or (lambda: None)
        self._lock = threading.Lock()
        self._data = None
        self._hist = None                                  # {"CODE|range": (epoch, result)}; also kept in market_history.json
        self.hist_path = self.path.with_name("market_history.json")
        self._stop = threading.Event()
        self.status = {"state": "idle", "last_try": None, "error": None}

    # ------------------------------------------------------------ plumbing
    def _get(self, url):
        g = self._getter_fn()
        return g(url) if g else pricefetch._get(url, timeout=25, headers={"Accept": "application/json, text/plain, */*"})

    def _load(self):
        if self._data is None:
            try:
                d = json.loads(self.path.read_text(encoding="utf-8"))
                self._data = d if isinstance(d, dict) and isinstance(d.get("rows"), list) else {"rows": []}
            except (OSError, ValueError):
                self._data = {"rows": []}
        return self._data

    def _save(self, data, path=None):
        path = Path(path or self.path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, path)
        except OSError:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    # ---------------------------------------------------------------- list
    def rows(self):
        return self._load()["rows"]

    def lookup(self, code):
        return next((r for r in self.rows() if r["c"] == code), None)

    def info(self):
        d = self._load()
        return {"updated_at": d.get("updated_at"), "trade_date": d.get("trade_date"), "count": len(d["rows"]),
                "stocks": sum(1 for r in d["rows"] if r["k"] == "stock"), "etfs": sum(1 for r in d["rows"] if r["k"] == "etf"),
                "state": self.status["state"], "error": self.status["error"], "warn": d.get("warn") or "", "last_try": self.status["last_try"]}

    def refresh(self):
        """Download both lists. The old list stays when a download fails; one failed half keeps that half's old rows."""
        if not self._lock.acquire(blocking=False):
            return self.info()
        try:
            self.status.update(state="running", last_try=datetime.now().strftime("%Y-%m-%dT%H:%M:%S"), error=None)
            old = self._load()
            parts, problems, dates, offline = {}, [], [], []
            for market, url, parser in (("TWSE", TWSE_ALL, parse_twse_all), ("TPEx", TPEX_ALL, parse_tpex_all)):
                label = "上市" if market == "TWSE" else "上櫃"
                try:
                    try:
                        date, rows = parser(self._get(url))
                    except MarketError:
                        if market != "TPEx":
                            raise
                        date, rows = parser(self._get(TPEX_ALL_ALT))          # the other name of the same OTC data
                    parts[market] = rows
                    if date:
                        dates.append(date)
                except MarketError as e:
                    problems.append(f"{label}：{e}"); offline.append(False)
                except OSError as e:
                    msg, off = pricefetch.describe_net_error(e)
                    problems.append(f"{label}：{msg}"); offline.append(off)
                except Exception as e:
                    problems.append(f"{label}：讀取失敗（{type(e).__name__}）"); offline.append(False)
            if not parts:
                self.status.update(state="offline" if all(offline) else "error", error="；".join(problems))
                return self.info()
            for market in ("TWSE", "TPEx"):
                if market not in parts:
                    parts[market] = [r for r in old["rows"] if r["m"] == market]      # keep what we had for that half
            merged = {}
            for rows in (parts["TPEx"], parts["TWSE"]):
                for r in rows:
                    merged[r["c"]] = r
            data = {"updated_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"), "trade_date": max(dates) if dates else old.get("trade_date"),
                    "warn": "；".join(problems), "rows": sorted(merged.values(), key=lambda r: r["c"])}
            self._save(data)
            self._data = data
            self.status.update(state="ok", error=None)
            log.info("market list updated: %s rows (%s)", len(data["rows"]), data["trade_date"])
            return self.info()
        finally:
            self._lock.release()

    def due(self, now=None):
        """Needs a download: never done, or the exchanges published a newer day since the last one, or it is a day old."""
        now = now or datetime.now()
        if self.status["last_try"] and self.status["state"] in ("offline", "error"):
            if now - datetime.strptime(self.status["last_try"], "%Y-%m-%dT%H:%M:%S") < timedelta(seconds=RETRY_SECONDS):
                return False
        at = self._load().get("updated_at")
        if not at:
            return True
        at = datetime.strptime(at, "%Y-%m-%dT%H:%M:%S")
        if now - at > timedelta(hours=24):
            return True
        cutoff = now.replace(hour=REFRESH_AFTER[0], minute=REFRESH_AFTER[1], second=0, microsecond=0)
        return now.weekday() < 5 and now >= cutoff and at < cutoff

    def start(self, first_delay=15):
        def loop():
            if self._stop.wait(first_delay):
                return
            while not self._stop.is_set():
                try:
                    if self.due():
                        self.refresh()
                except Exception:
                    log.exception("market list update crashed")
                if self._stop.wait(120):
                    return
        threading.Thread(target=loop, name="market-list", daemon=True).start()

    def stop(self):
        self._stop.set()

    # ------------------------------------------------------------- history
    def _suffixes(self, code):
        r = self.lookup(code)
        return [".TWO"] if r and r["m"] == "TPEx" else [".TW"] if r else [".TW", ".TWO"]

    def _twse_fallback(self, code, rng):
        months, days = FALLBACK_MONTHS[rng]
        now = datetime.now()
        yms = []
        y, m = now.year, now.month
        for _ in range(months):
            yms.append(f"{y:04d}{m:02d}")
            m -= 1
            if m == 0:
                y, m = y - 1, 12
        parts = pool.pmap(lambda ym: parse_twse_month(self._get(TWSE_MONTH.format(ym=ym, sym=code))), yms, 4)
        cutoff = time.time() - days * 86400
        pts = sorted((p for part in parts for p in part if p[0] >= cutoff), key=lambda p: p[0])
        if len(pts) < 2:
            raise MarketError("證交所沒有這檔股票的歷史價格")
        return {"points": pts, "price": None, "prev_close": None, "day_high": None, "day_low": None, "name": ""}

    def _hist_store(self):
        if self._hist is None:
            try:
                raw = json.loads(self.hist_path.read_text(encoding="utf-8"))
                self._hist = {k: (v["t"], v["d"]) for k, v in raw.items() if isinstance(v, dict) and "t" in v and "d" in v}
            except (OSError, ValueError, TypeError):
                self._hist = {}
        return self._hist

    def _hist_put(self, key, res):
        store = self._hist_store()
        store[key] = (time.time(), res)
        while len(store) > MAX_SAVED_HISTORY:
            store.pop(min(store, key=lambda k: store[k][0]))
        try:
            self._save({k: {"t": t, "d": d} for k, (t, d) in store.items()}, self.hist_path)
        except OSError:
            log.exception("could not save the price history")

    def history(self, code, rng):
        """Price curve of one stock. Fresh copies are reused for a while; every good download is also kept on disk, so when the
        sites cannot be reached the last one is shown again (flagged "stale" with the time it was fetched)."""
        code = str(code or "").strip().upper()
        if not CODE_RE.match(code):
            raise MarketError("股票代號不正確")
        if rng not in RANGES:
            raise MarketError("不支援的時間範圍")
        key = f"{code}|{rng}"
        hit = self._hist_store().get(key)
        if hit and time.time() - hit[0] < RANGES[rng][2]:
            return hit[1]
        yrng, iv, _ = RANGES[rng]
        problems, res = [], None
        for suf in self._suffixes(code):
            try:
                res = parse_yahoo_history(self._get(YAHOO_CHART.format(sym=code + suf, rng=yrng, iv=iv)), rng)
                res["source"] = "yahoo"
                break
            except MarketError as e:
                problems.append(str(e))
            except OSError as e:
                problems.append("Yahoo：" + pricefetch.describe_net_error(e)[0])
        if res is None and rng in FALLBACK_MONTHS and (self.lookup(code) or {}).get("m", "TWSE") == "TWSE":
            try:
                res = self._twse_fallback(code, rng)
                res["source"] = "twse"
            except MarketError as e:
                problems.append(str(e))
            except OSError as e:
                problems.append("證交所：" + pricefetch.describe_net_error(e)[0])
        if res is None:
            if hit:                                                   # offline / blocked: show what we fetched last time
                return {**hit[1], "stale": True, "stale_reason": problems[-1] if problems else ""}
            raise MarketError((problems[-1] if problems else "讀不到走勢資料") + "（這個時間範圍還沒有存過資料；連上網路看過一次，之後離線也看得到）")
        res.update(symbol=code, range=rng, fetched_at=datetime.now().strftime("%Y-%m-%dT%H:%M:%S"), **summarize(res["points"]))
        self._hist_put(key, res)
        return res
