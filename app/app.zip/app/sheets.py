"""Google Sheets two-way sync.

Write: the whole ledger is mirrored into ONE dedicated worksheet (default
"Tallomi") after every change. A mirror (not append-only) is the only way
edits and deletions can show up correctly. Other worksheets are never touched.

Read: any worksheet in the old notebook format can be imported.
"""
import json
import re
import threading
import time
from datetime import datetime

from .book import BookError
from . import config as _config
from .timeutil import now_iso

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
DEFAULT_WORKSHEET = "Pennyworth"
CHUNK = 2000
RETRY_MIN, RETRY_MAX = 15.0, 120.0      # seconds between automatic retries while offline

_NET_WORDS = ("max retries exceeded", "name or service not known", "getaddrinfo", "connection aborted",
              "connection reset", "connection refused", "timed out", "temporary failure in name resolution",
              "nameresolution", "network is unreachable", "failed to resolve", "unable to find the server",
              "remote end closed", "ssl", "eof occurred")
_NET_NAMES = {"ConnectionError", "ConnectTimeout", "ReadTimeout", "Timeout", "TransportError", "ProtocolError",
              "ChunkedEncodingError", "NewConnectionError", "MaxRetryError", "SSLError", "ConnectionResetError",
              "TimeoutError", "gaierror", "RemoteDisconnected"}


def is_offline_error(e):
    """True when the failure is 'no network / Google unreachable' rather than a setup problem."""
    seen = set()
    while e is not None and id(e) not in seen:
        seen.add(id(e))
        if isinstance(e, (ConnectionError, TimeoutError)) or type(e).__name__ in _NET_NAMES:
            return True
        low = str(e).lower()
        if any(w in low for w in _NET_WORDS):
            return True
        e = e.__cause__ or e.__context__
    return False


def is_transient_error(e):
    """Server-side hiccups worth retrying: 429 and 5xx from Google."""
    resp = getattr(e, "response", None)
    code = getattr(resp, "status_code", None)
    return isinstance(code, int) and (code == 429 or code >= 500)


def extract_sheet_key(text: str) -> str:
    text = (text or "").strip()
    m = re.search(r"/spreadsheets/d/([A-Za-z0-9_\-]+)", text)
    if m:
        return m.group(1)
    if re.fullmatch(r"[A-Za-z0-9_\-]{20,}", text):
        return text
    if not text:
        return ""
    raise BookError("試算表 ID 格式不正確。可以直接貼上試算表網址。")


class SheetsSync:
    def __init__(self, book, client_factory=None, debounce=2.0):
        self.book = book
        self._client_factory = client_factory or self._default_client
        self.debounce = debounce
        self.status = {"state": "idle", "last_ok": None, "error": None, "rows": 0, "pending": False, "will_retry": False}
        self.retry_min, self.retry_max = RETRY_MIN, RETRY_MAX
        self._wake = threading.Event()
        self._dirty = threading.Event()
        self._stop = threading.Event()
        self._thread = None
        self._push_lock = threading.Lock()
        # 1.0.0-1.0.1 defaulted auto-sync to OFF and saved that choice whenever the settings were saved.
        # Turn it on once so upgraded installs behave like new ones; the user can still switch it off.
        with book.session() as c:
            if book.get_setting(c, "sheets_auto_default_on") != "1":
                book.set_setting(c, "sheets_auto", "1")
                book.set_setting(c, "sheets_auto_default_on", "1")
        book.on_change(self.request_sync)

    # ------------------------------------------------------------- config
    @property
    def sa_file(self):
        return self.book.data_dir / "service_account.json"

    def config(self):
        with self.book.session() as c:
            g = lambda k, d="": self.book.get_setting(c, k, d)
            cfg = {"key": g("sheets_key", _config.DEFAULT_SHEET_KEY), "worksheet": g("sheets_worksheet", DEFAULT_WORKSHEET) or DEFAULT_WORKSHEET,
                   "auto": g("sheets_auto", "1") == "1"}
        cfg["has_credentials"] = self.sa_file.exists()
        cfg["email"] = ""
        if cfg["has_credentials"]:
            try:
                cfg["email"] = json.loads(self.sa_file.read_text(encoding="utf-8")).get("client_email", "")
            except (OSError, ValueError):
                pass
        cfg["configured"] = bool(cfg["key"] and cfg["has_credentials"])
        return cfg

    def save_config(self, key=None, worksheet=None, auto=None):
        with self.book.session() as c:
            if key is not None:
                self.book.set_setting(c, "sheets_key", extract_sheet_key(key))
            if worksheet is not None:
                ws = str(worksheet).strip() or DEFAULT_WORKSHEET
                if len(ws) > 100 or re.search(r"[\[\]\*\?/\\:]", ws):
                    raise BookError("工作表名稱不能包含 [ ] * ? / \\ : 且需在 100 字以內")
                self.book.set_setting(c, "sheets_worksheet", ws)
            if auto is not None:
                self.book.set_setting(c, "sheets_auto", "1" if auto else "0")
        if auto:
            self.request_sync()

    def save_service_account(self, data: bytes):
        try:
            obj = json.loads(data.decode("utf-8-sig"))
        except (ValueError, UnicodeDecodeError):
            raise BookError("這不是有效的 JSON 檔") from None
        if not (isinstance(obj, dict) and obj.get("type") == "service_account"
                and obj.get("client_email") and obj.get("private_key")):
            raise BookError("這不是 Google 服務帳戶金鑰（需要 type=service_account、client_email、private_key）")
        self.sa_file.write_text(json.dumps(obj), encoding="utf-8")
        try:
            self.sa_file.chmod(0o600)
        except OSError:
            pass
        return obj["client_email"]

    # ------------------------------------------------------------- client
    def _default_client(self):
        try:
            import gspread
            from google.oauth2.service_account import Credentials
        except ImportError:
            raise BookError("缺少 gspread / google-auth 套件，無法使用 Google 試算表同步") from None
        creds = Credentials.from_service_account_file(str(self.sa_file), scopes=SCOPES)
        return gspread.authorize(creds)

    def _friendly(self, e):
        name = type(e).__name__
        text = str(e)
        email = self.config().get("email") or "服務帳戶的 email"
        if isinstance(e, BookError):
            return str(e)
        if is_offline_error(e):
            return "目前連不上網路。記帳資料都已安全存在這台電腦，連線後會自動同步到 Google 試算表。"
        if name == "SpreadsheetNotFound" or "404" in text:
            return f"找不到這份試算表。請確認 ID 正確，並把試算表「共用」給 {email}（編輯者）。"
        if "403" in text or "PERMISSION" in text.upper():
            return f"沒有權限。請把試算表「共用」給 {email}，權限設為編輯者；並確認 Google Sheets API 已啟用。"
        if "429" in text:
            return "Google 回報請求過於頻繁，稍後會自動重試。"
        return f"{name}: {text}"[:300]

    def _open(self):
        cfg = self.config()
        if not cfg["has_credentials"]:
            raise BookError("尚未上傳 Google 服務帳戶金鑰（service_account.json）")
        if not cfg["key"]:
            raise BookError("尚未設定試算表 ID")
        client = self._client_factory()
        return client.open_by_key(cfg["key"]), cfg

    # --------------------------------------------------------------- actions
    def test(self):
        """Connection check that also answers "will a sync land where I expect?": does the chosen worksheet exist, was it written by Tallomi,
        and does it hold as many entries as this book (so a stale or renamed tab shows up before anything is overwritten)."""
        try:
            sh, cfg = self._open()
            tabs = [w.title for w in sh.worksheets()]
            out = {"title": sh.title, "worksheets": tabs, "email": cfg["email"], "worksheet": cfg["worksheet"], "exists": cfg["worksheet"] in tabs}
            try:
                with self.book.session() as c:
                    out["local_rows"] = len(self.book.balance_table(c)[1])
                heads = {}
                for t in ([cfg["worksheet"]] if out["exists"] else []) + [x for x in tabs if x != cfg["worksheet"]][:8]:
                    ws = sh.worksheet(t)
                    heads[t] = [str(x).strip() for x in ws.row_values(1)]
                    if t == cfg["worksheet"]:
                        col = ws.col_values(1)
                        out["sheet_rows"] = max(0, len([x for x in col if str(x).strip()]) - 1) if any(heads[t]) else 0
                if out["exists"]:
                    h = heads[cfg["worksheet"]]
                    out["format"] = "tallomi" if "to_amount" in h else ("other" if any(h) else "empty")
                else:                                                     # the tab was probably renamed: point at the one Tallomi wrote
                    out["suggest"] = [t for t, h in heads.items() if "to_amount" in h]
            except Exception:                                             # the details are a bonus; the connection itself worked
                pass
            return out
        except Exception as e:
            raise BookError(self._friendly(e), 502) from None

    def list_worksheets(self):
        return self.test()["worksheets"]

    def sheet_url(self, find_tab=True):
        """Link to the spreadsheet, opened on the worksheet Tallomi writes to when we can find it."""
        cfg = self.config()
        if not cfg["key"]:
            raise BookError("尚未設定試算表")
        url = f"https://docs.google.com/spreadsheets/d/{cfg['key']}/edit"
        if find_tab and cfg["has_credentials"]:
            try:
                sh, _ = self._open()
                url += f"#gid={sh.worksheet(cfg['worksheet']).id}"
            except Exception:
                pass
        return url

    def push_all(self, force=False, background=False):
        with self._push_lock:
            self.status.update(state="syncing", error=None, will_retry=False)
            try:
                sh, cfg = self._open()
                with self.book.session() as c:
                    headers, rows = self.book.balance_table(c)
                values = [headers] + [[self._cell(v) for v in r] for r in rows]
                try:
                    ws = sh.worksheet(cfg["worksheet"])
                except Exception as e:
                    if type(e).__name__ != "WorksheetNotFound":
                        raise
                    ws = sh.add_worksheet(title=cfg["worksheet"], rows=max(len(values) + 100, 1000),
                                          cols=max(len(headers), 26))
                else:
                    # Never silently overwrite someone else's data (e.g. the old notebook's sheet):
                    # a worksheet Tallomi wrote always has a to_amount column.
                    head = [str(x).strip() for x in ws.row_values(1)]
                    if any(head) and "to_amount" not in head and not force:
                        raise BookError(
                            f"工作表「{cfg['worksheet']}」裡已經有不是 Tallomi 寫入的資料（可能是舊版記帳表），"
                            "為了安全沒有覆蓋。請先用「從試算表匯入」把舊資料帶進來，再改用別的工作表名稱，"
                            "或確認要覆蓋時按「立即同步全部」。", 409)
                ws.clear()
                if ws.row_count < len(values) + 50 or ws.col_count < len(headers):
                    ws.resize(rows=max(len(values) + 100, 1000), cols=max(len(headers), 26))
                for i in range(0, len(values), CHUNK):
                    ws.update(values=values[i:i + CHUNK], range_name=f"A{i + 1}", value_input_option="RAW")
                self._set_pending(False)
                self.status.update(state="ok", last_ok=now_iso(), rows=len(rows), error=None, pending=False, will_retry=False)
                return {"rows": len(rows), "worksheet": cfg["worksheet"]}
            except Exception as e:
                msg = self._friendly(e)
                offline = not isinstance(e, BookError) and is_offline_error(e)
                retry = offline or (not isinstance(e, BookError) and is_transient_error(e))
                if retry:
                    self._set_pending(True)
                self.status.update(state="offline" if offline else "error", error=msg,
                                   pending=self.status.get("pending") or retry, will_retry=retry)
                if retry and not background:
                    self.request_sync()           # a manual push that could not reach Google: keep trying in the background
                if isinstance(e, BookError):      # keep our own status (e.g. 409 = needs confirmation)
                    raise
                raise BookError(msg, 502) from None

    @staticmethod
    def _cell(v):
        if v is None:
            return ""
        return v

    def read_rows(self, title):
        """Returns (rows[list of dict]) from a worksheet with a header row."""
        try:
            sh, _ = self._open()
            ws = sh.worksheet(title)
            values = ws.get_all_values()
        except Exception as e:
            raise BookError(self._friendly(e), 502) from None
        if not values:
            return []
        header = [h.strip() for h in values[0]]
        out = []
        for row in values[1:]:
            d = {h: (row[i] if i < len(row) else "") for i, h in enumerate(header) if h}
            if any(str(v).strip() for v in d.values()):
                out.append(d)
        return out

    # ---------------------------------------------------------- background
    def _set_pending(self, on):
        """Remember (across restarts) that the sheet is behind the local book."""
        try:
            with self.book.session() as c:
                self.book.set_setting(c, "sheets_pending", "1" if on else "0")
        except Exception:
            pass

    def resume_pending(self):
        """Called at start-up: changes made offline (or just before the app was closed) still need uploading."""
        with self.book.session() as c:
            pending = self.book.get_setting(c, "sheets_pending") == "1"
        if pending:
            self.status["pending"] = True
            self.request_sync()

    def retry_now(self):
        """Network came back (the browser told us): do not wait out the back-off."""
        self._wake.set()

    def request_sync(self):
        try:
            cfg = self.config()
        except Exception:
            return
        if not (cfg["auto"] and cfg["configured"]):
            return
        self._set_pending(True)
        self.status["pending"] = True
        if self._thread is None or not self._thread.is_alive():
            self._thread = threading.Thread(target=self._run, name="sheets-sync", daemon=True)
            self._thread.start()
        self._dirty.set()

    def _run(self):
        delay = self.retry_min
        while not self._stop.is_set():
            self._dirty.wait()
            if self._stop.is_set():
                break
            time.sleep(self.debounce)       # let a burst of edits settle
            self._dirty.clear()
            try:
                self.push_all(background=True)
                delay = self.retry_min
            except Exception:
                if self.status.get("will_retry"):      # offline / Google hiccup: keep the change and try again
                    self._wake.wait(delay)
                    self._wake.clear()
                    delay = min(delay * 2, self.retry_max)
                    self._dirty.set()
                # other errors need the user (permissions, wrong sheet): status already records them

    def stop(self):
        self._stop.set()
        self._wake.set()
        self._dirty.set()
