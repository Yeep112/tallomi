"""Time parsing that tolerates what Google Sheets / Excel / the old notebook produce."""
import re
from datetime import datetime

_LOOSE = re.compile(
    r"^\s*(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})"
    r"(?:[ T]+(上午|下午|AM|PM|am|pm)?\s*(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?\s*(AM|PM|am|pm|上午|下午)?)?\s*$"
)


def now_iso() -> str:
    return datetime.now().replace(microsecond=0).isoformat()


def parse_time(value) -> datetime:
    """Return a naive local datetime or raise ValueError."""
    if isinstance(value, datetime):
        return value.replace(microsecond=0, tzinfo=None)
    s = str(value or "").strip()
    if not s:
        raise ValueError("請輸入時間")
    try:
        dt = datetime.fromisoformat(s)
        return dt.replace(microsecond=0, tzinfo=None)
    except ValueError:
        pass
    m = _LOOSE.match(s)
    if not m:
        raise ValueError(f"無法辨識的時間格式：{s}")
    y, mo, d, ap1, hh, mm, ss, ap2 = m.groups()
    hour = int(hh) if hh else 0
    ap = (ap1 or ap2 or "").lower()
    if ap in ("下午", "pm") and hour < 12:
        hour += 12
    if ap in ("上午", "am") and hour == 12:
        hour = 0
    try:
        return datetime(int(y), int(mo), int(d), hour, int(mm or 0), int(ss or 0))
    except ValueError:
        raise ValueError(f"無法辨識的時間格式：{s}") from None


def normalize_time(value) -> str:
    return parse_time(value).isoformat()
