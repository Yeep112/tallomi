"""Savings goals (1.67.0).

A goal is a target amount, optionally by a date, and optionally followed in one account: what has been saved is that account's balance (or, for a goal
made "from now on", what it gained since), so there is nothing extra to type in while the money is simply kept there. A goal with no account
keeps a number the person updates by hand.

For every goal the page shows: saved, how much is left, the share done, and — when there is a date — how much has to be put aside every month to
get there, how fast the account has really been growing (the last 90 days) and whether that is enough.
"""
from datetime import date, datetime, timedelta
from decimal import Decimal
from math import ceil

from . import money
from .timeutil import now_iso

MONTH = 30.4375
PACE_DAYS = 90                     # the speed of saving is read from the last 90 days
MIN_PACE_DAYS = 14                 # ... but not before the goal is two weeks old: a few days say nothing


def _err(msg, status=400):
    from .book import BookError
    return BookError(msg, status)


def _day(value, label="日期"):
    s = str(value or "").strip()
    if not s:
        return ""
    try:
        return date.fromisoformat(s[:10]).isoformat()
    except ValueError:
        raise _err(f"{label}格式不正確，請用 年-月-日") from None


class GoalsMixin:
    # ------------------------------------------------------------ reading
    @staticmethod
    def _balance_on(rows, accts, aid, day_iso):
        """The balance of one account at the end of `day_iso`, from the ledger rows (oldest first)."""
        bal = accts[aid]["opening_minor"]
        for r in rows:
            if r["time"][:10] > day_iso:
                break
            t = r["type"]
            if t == "transfer":
                if r["account_id"] == aid:
                    bal -= r["amount_minor"]
                if r["to_account_id"] == aid:
                    bal += r["to_amount_minor"]
            elif r["account_id"] == aid:
                bal += -r["amount_minor"] if t == "expense" else r["amount_minor"]
        return bal

    def goals(self, conn, today=None):
        """Every goal with its progress worked out. -> {"goals": [...], "accounts": [pickable accounts], "base": ccy}"""
        today = today or date.today()
        rows, bal, accts = self.ledger(conn, shared=True)
        base = self.base_currency(conn)
        out = []
        for g in conn.execute("SELECT * FROM goals ORDER BY (deadline=''), deadline, id"):
            aid = g["account_id"] if g["account_id"] in accts else None
            ccy = accts[aid]["currency"] if aid else g["currency"]
            target = g["target_minor"]
            if aid:
                saved = bal[aid] - g["baseline_minor"]
            else:
                saved = g["manual_minor"]
            saved_shown = max(saved, 0)
            left = max(target - saved, 0)
            done = saved >= target
            item = {"id": g["id"], "name": g["name"], "note": g["note"], "currency": ccy, "account_id": aid,
                    "account": accts[aid]["name"] if aid else "", "from_now": bool(aid and g["baseline_minor"]),
                    "target": money.from_minor(target, ccy), "saved": money.from_minor(saved_shown, ccy), "left": money.from_minor(left, ccy),
                    "pct": min(saved_shown / target, 1.0) if target else 0.0, "done": done, "deadline": g["deadline"],
                    "days_left": None, "months_left": None, "need_month": None, "pace_month": None, "forecast": "", "status": "done" if done else "open"}
            created = (g["created_at"] or "")[:10] or today.isoformat()
            if g["deadline"]:
                days = (date.fromisoformat(g["deadline"]) - today).days
                item["days_left"] = days
                if not done:
                    if days <= 0:
                        item["status"] = "overdue"
                    else:
                        months = max(1, ceil(days / MONTH))
                        item["months_left"] = months
                        item["need_month"] = money.from_minor(-(-left // months), ccy)       # rounded up: put aside this much and it is enough
            if aid and not done:
                since = max(today - timedelta(days=PACE_DAYS), date.fromisoformat(created))
                span = (today - since).days
                if span >= MIN_PACE_DAYS:
                    then = self._balance_on(rows, accts, aid, since.isoformat()) - g["baseline_minor"]       # what was saved at the start of the window
                    pace = (saved - then) / span * MONTH                                          # minor units per month
                    item["pace_month"] = money.from_minor(int(round(pace)), ccy)
                    if pace > 0:
                        item["forecast"] = (today + timedelta(days=ceil(left / pace * MONTH))).isoformat()
                    if g["deadline"] and item["status"] == "open":
                        need = -(-left // item["months_left"])
                        item["status"] = "on_track" if pace >= need * 0.95 else "behind"
            out.append(item)
        pick = [{"id": a["id"], "name": a["name"], "currency": a["currency"], "balance": money.from_minor(bal[a["id"]], a["currency"])}
                for a in sorted(accts.values(), key=lambda a: (a["sort_order"], a["id"])) if not a["archived"]]
        return {"base": base, "goals": out, "accounts": pick}

    # ------------------------------------------------------------ writing
    def _goal_fields(self, c, p, existing=None):
        name = str(p.get("name", existing["name"] if existing else "")).strip()
        if not name:
            raise _err("請輸入目標名稱")
        if len(name) > 40:
            raise _err("目標名稱太長（最多 40 字）")
        raw_acct = p.get("account_id", existing["account_id"] if existing else None)
        aid = None
        if raw_acct not in (None, "", 0, "0"):
            try:
                aid = int(raw_acct)
            except (TypeError, ValueError):
                raise _err("帳戶不正確") from None
            a = c.execute("SELECT * FROM accounts WHERE id=?", (aid,)).fetchone()
            if not a:
                raise _err("找不到這個帳戶", 404)
            if a["archived"] and not (existing and existing["account_id"] == aid):
                raise _err(f"「{a['name']}」已封存")
            ccy = a["currency"]
        else:
            ccy = money.normalize_currency(p.get("currency") or (existing["currency"] if existing else self.base_currency(c)))
        try:
            target = money.to_minor(p.get("target", money.from_minor(existing["target_minor"], existing["currency"]) if existing else None), ccy)
        except ValueError as e:
            raise _err(str(e)) from None
        if target <= 0:
            raise _err("目標金額必須大於 0")
        deadline = _day(p.get("deadline", existing["deadline"] if existing else ""), "期限")
        if deadline and not existing and deadline < date.today().isoformat():
            raise _err("期限已經過了，請選今天或之後的日期")
        manual = existing["manual_minor"] if existing else 0
        if not aid and "saved" in p:
            try:
                manual = money.to_minor(p.get("saved") or 0, ccy)
            except ValueError as e:
                raise _err(str(e)) from None
            if manual < 0:
                raise _err("已存金額不可為負數")
        baseline = existing["baseline_minor"] if existing else 0
        if aid and (("from_now" in p) or not existing or (existing and existing["account_id"] != aid)):
            if p.get("from_now"):
                _, bal, _ = self.ledger(c)
                baseline = bal[aid]
            else:
                baseline = 0
        if not aid:
            baseline = 0
        note = str(p.get("note", existing["note"] if existing else "") or "").strip()[:200]
        return name, target, ccy, deadline, aid, baseline, manual, note

    def add_goal(self, p):
        with self.session(notify=True) as c:
            if c.execute("SELECT COUNT(*) FROM goals").fetchone()[0] >= 50:
                raise _err("目標最多 50 個")
            name, target, ccy, deadline, aid, baseline, manual, note = self._goal_fields(c, p)
            gid = c.execute("INSERT INTO goals(name,target_minor,currency,deadline,account_id,baseline_minor,manual_minor,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                            (name, target, ccy, deadline, aid, baseline, manual, note, now_iso())).lastrowid
            return {"id": gid}

    def update_goal(self, gid, p):
        with self.session(notify=True) as c:
            g = c.execute("SELECT * FROM goals WHERE id=?", (gid,)).fetchone()
            if not g:
                raise _err("找不到這個目標", 404)
            name, target, ccy, deadline, aid, baseline, manual, note = self._goal_fields(c, p, g)
            c.execute("UPDATE goals SET name=?,target_minor=?,currency=?,deadline=?,account_id=?,baseline_minor=?,manual_minor=?,note=? WHERE id=?",
                      (name, target, ccy, deadline, aid, baseline, manual, note, gid))
            return {"id": gid}

    def delete_goal(self, gid):
        with self.session(notify=True) as c:
            if not c.execute("DELETE FROM goals WHERE id=?", (gid,)).rowcount:
                raise _err("找不到這個目標", 404)
