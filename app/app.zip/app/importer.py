"""Import data produced by the old notebook (accounts.json, transactions.csv,
transactions_balances.csv or its Google Sheet copy)."""
import csv
import io
import json
from decimal import Decimal

from . import money
from .book import BookError, ADJUST_CATEGORY
from .catrules import first_rule
from .timeutil import normalize_time, now_iso

META_COLS = {"time", "type", "category", "amount", "note", "account", "prev_balance",
             "new_balance", "total_amount", "currency", "to_amount"}


def decode_text(data) -> str:
    if isinstance(data, str):
        return data
    for enc in ("utf-8-sig", "utf-8", "big5", "cp950"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    raise BookError("無法讀取檔案編碼，請存成 UTF-8 的 CSV")


def read_csv_rows(data) -> list:
    text = decode_text(data)
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames or "time" not in reader.fieldnames:
        raise BookError("CSV 需要有 time、type、amount、account 等欄位（與舊版 transactions.csv 相同）")
    return [{(k or "").strip(): (v if v is not None else "") for k, v in row.items() if k} for row in reader]


def read_accounts_json(data) -> dict:
    try:
        obj = json.loads(decode_text(data))
    except ValueError:
        raise BookError("accounts.json 不是有效的 JSON") from None
    if not isinstance(obj, dict):
        raise BookError("accounts.json 應該是 {\"帳戶名\": 餘額} 的格式")
    out = {}
    for k, v in obj.items():
        try:
            out[str(k).strip()] = float(str(v).replace(",", ""))
        except ValueError:
            raise BookError(f"accounts.json 裡「{k}」的餘額不是數字") from None
    return out


def final_from_rows(rows) -> dict:
    """Latest value of each account column (scan from the bottom)."""
    if not rows:
        return {}
    cols = [c for c in rows[0].keys() if c and c not in META_COLS]
    final = {}
    for col in cols:
        for r in reversed(rows):
            v = str(r.get(col, "")).replace(",", "").strip()
            if v == "":
                continue
            try:
                final[col] = float(v)
                break
            except ValueError:
                continue
    return final


class _DryRun(Exception):
    """Raised at the end of a preview so the session rolls everything back."""


def import_legacy(book, rows, final_balances=None, default_currency=None, dry_run=False) -> dict:
    final_balances = final_balances or {}
    try:
        return _import_legacy(book, rows, final_balances, default_currency, dry_run)
    except _DryRun as d:
        return d.args[0]


def _import_legacy(book, rows, final_balances, default_currency, dry_run) -> dict:
    report = {"accounts_created": [], "imported": 0, "duplicates": 0, "invalid": [], "warnings": []}
    with book.session(notify=True) as c:
        default_currency = default_currency or book.base_currency(c)
        existing = {r["name"].lower(): r for r in c.execute("SELECT * FROM accounts")}

        # ---- 1. parse rows
        parsed = []
        for n, row in enumerate(rows, start=2):
            if not any(str(v).strip() for v in row.values()):
                continue
            try:
                typ = str(row.get("type", "")).strip().lower()
                if typ not in ("income", "expense", "transfer", "adjust"):
                    raise ValueError(f"不認識的類型「{row.get('type', '')}」")
                when = normalize_time(row.get("time"))
                amount = money.parse_amount(row.get("amount"))
                if typ != "adjust" and amount <= 0:
                    raise ValueError("金額必須大於 0")
                acct = str(row.get("account", "")).strip()
                to_acct = None
                if typ == "transfer":
                    if "->" not in acct:
                        raise ValueError("轉帳的 account 需為「來源->目的」")
                    acct, to_acct = [s.strip() for s in acct.split("->", 1)]
                    if not acct or not to_acct or acct.lower() == to_acct.lower():
                        raise ValueError("轉帳的來源與目的帳戶不正確")
                if not acct:
                    raise ValueError("缺少帳戶")
                cat = str(row.get("category", "")).strip()
                if typ == "transfer" or cat.lower() == "none":
                    cat = "" if typ == "transfer" else "未分類"
                if typ in ("income", "expense") and not cat:
                    cat = "未分類"
                if typ == "adjust" and not cat:
                    cat = ADJUST_CATEGORY
                parsed.append(dict(time=when, type=typ, category=cat, note=str(row.get("note", "")).strip()[:500],
                                   amount=amount, account=acct, to_account=to_acct,
                                   currency=str(row.get("currency", "")).strip().upper(),
                                   to_amount=row.get("to_amount", ""), tags=Book.clean_tags(str(row.get("tags", "") or ""))))
            except ValueError as e:
                report["invalid"].append(f"第 {n} 列：{e}")

        # ---- 1b. category rules fill in the entries that came without a category (1.62.0)
        rules = book.cat_rules(c)
        if rules:
            ruled = 0
            for p in parsed:
                if p["type"] in ("income", "expense") and p["category"] in ("", "未分類"):
                    r = first_rule(rules, p["type"], p["note"])
                    if r and (r.get("category") or r.get("tags")):
                        if r.get("category"):
                            p["category"] = r["category"]
                        for t in r.get("tags") or []:
                            if t not in p["tags"] and len(p["tags"]) < Book.MAX_TAGS:
                                p["tags"].append(t)
                        ruled += 1
            if ruled:
                report["ruled"] = ruled

        # ---- 2. make sure every account exists
        order = []
        for p in parsed:
            for nm in (p["account"], p["to_account"]):
                if nm and nm not in order:
                    order.append(nm)
        for nm in final_balances:
            if nm not in order:
                order.append(nm)
        new_ccy = {}
        for p in parsed:
            if p["currency"] and p["account"] not in new_ccy:
                new_ccy[p["account"]] = p["currency"]
        created = {}
        nxt = c.execute("SELECT COALESCE(MAX(sort_order),-1)+1 FROM accounts").fetchone()[0]
        for nm in order:
            if nm.lower() in existing:
                continue
            ccy = default_currency
            if new_ccy.get(nm):
                try:
                    ccy = money.normalize_currency(new_ccy[nm])
                except ValueError:
                    report["warnings"].append(f"帳戶「{nm}」的幣別「{new_ccy[nm]}」不正確，已改用 {default_currency}")
            cur = c.execute("INSERT INTO accounts(name,currency,opening_minor,sort_order,created_at) VALUES(?,?,?,?,?)",
                            (nm[:40], ccy, 0, nxt, now_iso()))
            nxt += 1
            row = c.execute("SELECT * FROM accounts WHERE id=?", (cur.lastrowid,)).fetchone()
            existing[nm.lower()] = row
            created[nm.lower()] = row
            report["accounts_created"].append(nm)

        untouched = {}
        for key, row in existing.items():
            if key in created or row["opening_minor"]:
                continue
            used = c.execute("SELECT 1 FROM transactions WHERE account_id=? OR to_account_id=? LIMIT 1", (row["id"], row["id"])).fetchone()
            if not used:
                untouched[key] = row

        # ---- 3. insert transactions (skip ones already in the book)
        known = {(r["time"], r["type"], r["amount_minor"], r["account_id"], r["to_account_id"], r["note"])
                 for r in c.execute("SELECT time,type,amount_minor,account_id,to_account_id,note FROM transactions")}
        net = {}
        now = now_iso()
        for p in parsed:
            a = existing[p["account"].lower()]
            amt = money.to_minor(p["amount"], a["currency"])
            if amt == 0:
                report["invalid"].append(f"{p['time']} {p['account']}：金額四捨五入後為 0")
                continue
            t = to_amt = None
            if p["type"] == "transfer":
                t = existing[p["to_account"].lower()]
                raw = str(p["to_amount"]).strip()
                try:
                    to_amt = money.to_minor(raw, t["currency"]) if raw else None
                except ValueError:
                    to_amt = None
                if to_amt is None:
                    if t["currency"] != a["currency"]:
                        report["warnings"].append(
                            f"{p['time']} 轉帳 {a['name']}→{t['name']} 幣別不同但沒有轉入金額，已用原金額")
                    to_amt = money.to_minor(p["amount"], t["currency"])
            key = (p["time"], p["type"], amt, a["id"], t["id"] if t else None, p["note"])
            if key in known:
                report["duplicates"] += 1
                continue
            c.execute(
                "INSERT INTO transactions(time,type,category,note,amount_minor,account_id,to_account_id,"
                "to_amount_minor,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (p["time"], p["type"], p["category"], p["note"], amt, a["id"], t["id"] if t else None,
                 to_amt, now, now))
            report["imported"] += 1
            if p["tags"]:
                tid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
                c.executemany("INSERT OR IGNORE INTO tx_tags(tx_id,tag) VALUES(?,?)", [(tid, t) for t in p["tags"]])
            if p["type"] == "transfer":
                net[a["id"]] = net.get(a["id"], 0) - amt
                net[t["id"]] = net.get(t["id"], 0) + to_amt
            elif p["type"] == "expense":
                net[a["id"]] = net.get(a["id"], 0) - amt
            else:
                net[a["id"]] = net.get(a["id"], 0) + amt

        # ---- 4. opening balance of *new* accounts = final balance - effect of imported rows
        for key, a in {**untouched, **created}.items():
            nm = a["name"]
            target = next((v for k, v in final_balances.items() if k.lower() == key), None)
            if target is None:
                continue
            opening = money.to_minor(Decimal(str(target)), a["currency"]) - net.get(a["id"], 0)
            c.execute("UPDATE accounts SET opening_minor=? WHERE id=?", (opening, a["id"]))
        skipped = [k for k in final_balances if k.lower() in existing and k.lower() not in created and k.lower() not in untouched]
        if skipped:
            report["warnings"].append("已存在的帳戶不會更動期初餘額：" + "、".join(skipped))
        if dry_run:
            raise _DryRun(report)
    return report


# =====================================================================================================
# Import from other bookkeeping apps (any CSV): columns are recognised by name, not by position.
# =====================================================================================================
import re
from .book import Book

FIELDS = ("date", "clock", "type", "amount", "account", "to_account", "category", "note", "currency", "tags")
FIELD_LABEL = {"date": "日期", "clock": "時間（選填）", "type": "收入／支出", "amount": "金額", "account": "帳戶",
               "to_account": "轉入帳戶（選填）", "category": "分類", "note": "備註", "currency": "幣別（選填）", "tags": "標籤（選填）"}
REQUIRED = ("date", "amount", "account")
ALIASES = {
    "date": ["date", "日期", "交易日期", "記帳日期", "time", "時間", "datetime", "日期時間", "transaction date", "day"],
    "clock": ["last updated", "updated", "updated at", "created", "created at", "更新時間", "建立時間", "最後更新", "記錄時間"],
    "type": ["income/expenses", "income/expense", "income expense", "type", "收支", "收入/支出", "收入／支出", "類型", "收支類型", "交易類型", "kind", "in/out"],
    "amount": ["amount", "金額", "價格", "price", "money", "sum", "total"],
    "account": ["account", "帳戶", "帳號", "錢包", "wallet", "from account", "來源帳戶", "付款帳戶", "資產", "from"],
    "to_account": ["to account", "轉入帳戶", "轉入", "目的帳戶", "to", "destination account"],
    "category": ["category", "分類", "類別", "項目", "category name", "主分類"],
    "note": ["memo", "note", "notes", "備註", "說明", "描述", "description", "備忘", "remark", "remarks"],
    "currency": ["currency", "幣別", "幣種", "貨幣"],
    "tags": ["tags", "tag", "標籤", "標記"],
}
_INCOME = {"in", "income", "incomes", "收入", "收", "入", "+", "inflow", "credit", "revenue"}
_EXPENSE = {"out", "expense", "expenses", "支出", "支", "出", "-", "outflow", "debit", "spending"}
_TRANSFER = {"transfer", "轉帳", "轉賬", "轉移", "轉出", "transfers"}
_ADJUST = {"adjust", "adjustment", "調整", "餘額調整"}
ADJUST_NAMES = {"difference", "differences", "差額", "差異", "餘額調整", "balance adjustment", "adjustment", "調整"}


def _norm_header(s) -> str:
    return " ".join(str(s or "").replace("﻿", "").strip().casefold().split())


def detect_columns(headers) -> dict:
    """{field: header} for every field we can recognise (each header is used once, first alias wins)."""
    by_norm = {}
    for h_ in headers:
        by_norm.setdefault(_norm_header(h_), h_)
    out, used = {}, set()
    for f in FIELDS:
        for al in ALIASES[f]:
            h_ = by_norm.get(_norm_header(al))
            if h_ is not None and h_ not in used:
                out[f] = h_
                used.add(h_)
                break
    return out


def _kind(value):
    v = str(value or "").strip().casefold()
    if v in _INCOME:
        return "income"
    if v in _EXPENSE:
        return "expense"
    if v in _TRANSFER:
        return "transfer"
    if v in _ADJUST:
        return "adjust"
    return None


def _date_text(value) -> str:
    """'20261112' / '2026/11/12 13:05' / '2026-11-12' -> something normalize_time understands."""
    s = str(value or "").strip()
    m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})(?:[ T]?(\d{2}):?(\d{2})(?::?(\d{2}))?)?", s)
    if m:
        y, mo, d, hh, mm, ss = m.groups()
        return f"{y}-{mo}-{d}" + (f" {hh}:{mm}:{ss or '00'}" if hh else "")
    return s.replace("/", "-").replace(".", "-") if re.match(r"\d{4}[/.]\d{1,2}[/.]\d{1,2}", s) else s


def _when(row, cols):
    """The entry time. A date-only value borrows the time of day from the 'last updated' column when that
    is the same day (it only keeps entries of one day in the order they were made)."""
    txt = _date_text(row.get(cols["date"]))
    dt = parse_time_text(txt)
    if len(txt) <= 10 and "clock" in cols:
        try:
            other = parse_time_text(_date_text(row.get(cols["clock"])))
            if other.date() == dt.date():
                return other.isoformat()
        except ValueError:
            pass
    return dt.isoformat()


def parse_time_text(txt):
    from .timeutil import parse_time
    return parse_time(txt)


def sniff_format(rows) -> str:
    """'legacy' = the old notebook's transactions.csv (time/type/amount/account, type in income/expense/transfer/adjust)."""
    if not rows:
        return "generic"
    keys = {_norm_header(k) for k in rows[0].keys()}
    if {"time", "type", "amount", "account"} <= keys:
        tcol = next(k for k in rows[0].keys() if _norm_header(k) == "type")
        vals = {str(r.get(tcol, "")).strip().lower() for r in rows if str(r.get(tcol, "")).strip()}
        if vals and vals <= {"income", "expense", "transfer", "adjust"}:
            return "legacy"
    return "generic"


def read_table(data):
    text = decode_text(data)
    if text.lstrip().startswith(("{", "[")):
        raise BookError("這看起來不是 CSV。請從舊的記帳軟體匯出 CSV 檔再匯入")
    sample = text[:4096]
    delim = ","
    try:
        delim = csv.Sniffer().sniff(sample, delimiters=",;\t").delimiter
    except csv.Error:
        pass
    reader = csv.DictReader(io.StringIO(text), delimiter=delim)
    if not reader.fieldnames:
        raise BookError("檔案是空的")
    headers = [(h_ or "").replace("﻿", "").strip() for h_ in reader.fieldnames]
    rows = []
    for raw in reader:
        row = {}
        for k, v in raw.items():
            if k is None:
                continue
            row[k.replace("﻿", "").strip()] = v.strip() if isinstance(v, str) else ""
        rows.append(row)
    return headers, rows


def to_legacy_rows(rows, cols, opts, existing_cats=(), existing_accts=None):
    """Turn rows of any layout into rows of the old notebook layout, which `import_legacy` already knows how to store.
    -> (legacy_rows, issues, stats)"""
    opts = opts or {}
    cat_map = {str(k): str(v) for k, v in (opts.get("category_map") or {}).items() if str(v).strip()}
    acct_map = {str(k): str(v).strip() for k, v in (opts.get("account_map") or {}).items() if str(v).strip()}
    diff_adjust = opts.get("diff_adjust", True)
    existing_accts = existing_accts or {}
    existing_cat = {c.casefold(): c for c in existing_cats}
    seen_cat = {}
    out, issues, warns = [], [], []
    stats = {"accounts": {}, "categories": {}, "adjust": 0, "dates": []}

    def canon_cat(name):
        if name in cat_map:
            return cat_map[name]
        key = name.casefold()
        if key in existing_cat:
            return existing_cat[key]
        name = seen_cat.setdefault(key, name)
        return name + "（匯入）" if name in Book.RESERVED_CATEGORIES else name

    def acct(name):
        name = acct_map.get(name, name)
        return name[:40]

    for n, row in enumerate(rows, start=2):
        if not any(str(v).strip() for v in row.values()):
            continue
        try:
            when = _when(row, cols)
            raw_amt = row.get(cols["amount"], "")
            amount = money.parse_amount(raw_amt)
            src_acct = str(row.get(cols["account"], "")).strip()
            if not src_acct:
                raise ValueError("缺少帳戶")
            kind = _kind(row.get(cols["type"])) if "type" in cols else None
            if "type" in cols and kind is None and str(row.get(cols["type"], "")).strip():
                raise ValueError(f"看不懂的收支類型「{row.get(cols['type'])}」")
            if kind is None:                                       # no type column: the sign says it
                kind = "expense" if amount < 0 else "income"
            amount_abs = abs(amount)
            cat_src = str(row.get(cols["category"], "")).strip() if "category" in cols else ""
            note = str(row.get(cols["note"], "")).strip() if "note" in cols else ""
            currency = str(row.get(cols["currency"], "")).strip().upper() if "currency" in cols else ""
            tags = str(row.get(cols["tags"], "")).strip() if "tags" in cols else ""
            lrow = dict(time=when, type=kind, amount="", account=acct(src_acct), currency=currency, note=note,
                        category="", to_amount="", tags=tags, _src_account=src_acct)
            if kind == "transfer":
                to = str(row.get(cols["to_account"], "")).strip() if "to_account" in cols else ""
                if not to:
                    raise ValueError("轉帳缺少轉入帳戶（請在欄位對應裡指定）")
                lrow["account"] = acct(src_acct) + "->" + acct(to)
                lrow["amount"] = str(amount_abs)
                lrow["_src_to"] = to
            elif kind == "adjust" or (diff_adjust and cat_src.casefold() in ADJUST_NAMES and kind in ("income", "expense")):
                signed = amount_abs if kind in ("income", "adjust") and amount >= 0 else -amount_abs
                if kind == "expense":
                    signed = -amount_abs
                lrow.update(type="adjust", amount=str(signed), category="")
                if not note and cat_src:
                    lrow["note"] = cat_src
                stats["adjust"] += 1
            else:
                if amount_abs == 0:
                    raise ValueError("金額是 0")
                lrow["amount"] = str(amount_abs)
                lrow["category"] = canon_cat(cat_src) if cat_src else "未分類"
            if currency and existing_accts.get(lrow["account"].casefold()) not in (None, currency) and kind != "transfer":
                warns.append(f"帳戶「{lrow['account']}」是 {existing_accts[lrow['account'].casefold()]}，但檔案寫 {currency}（已照帳戶的幣別處理，沒有換算）")
            out.append(lrow)
            stats["dates"].append(when[:10])
            a = stats["accounts"].setdefault(src_acct, {"name": acct(src_acct), "count": 0, "net": Decimal(0), "currency": currency})
            a["count"] += 1
            if lrow["type"] == "expense":
                a["net"] -= amount_abs
            elif lrow["type"] in ("income",):
                a["net"] += amount_abs
            elif lrow["type"] == "adjust":
                a["net"] += Decimal(lrow["amount"])
            elif lrow["type"] == "transfer":
                a["net"] -= amount_abs
            if lrow["category"]:
                cc = stats["categories"].setdefault(cat_src or "未分類", {"count": 0, "to": lrow["category"], "kinds": set()})
                cc["count"] += 1
                cc["kinds"].add(lrow["type"])
        except ValueError as e:
            issues.append(f"第 {n} 列：{e}")
    return out, issues, warns, stats


def prepare(book, files, opts):
    """files: [(name, bytes)] -> dict(kind, rows (legacy layout), final, issues, warnings, info). Nothing is written."""
    opts = opts or {}
    csvs = [(n, d) for n, d in files if n.lower().endswith((".csv", ".txt", ".tsv"))]
    jsons = [(n, d) for n, d in files if n.lower().endswith(".json")]
    other = [n for n, _ in files if not n.lower().endswith((".csv", ".txt", ".tsv", ".json"))]
    if other:
        raise BookError(f"不支援的檔案：{other[0]}（請用 .csv；Excel 檔請先「另存為 CSV」）")
    if not csvs and not jsons:
        raise BookError("請選擇要匯入的檔案")
    final = read_accounts_json(jsons[0][1]) if jsons else {}
    info = {"kind": "legacy", "headers": [], "columns": {}, "total": 0}
    if not csvs:
        return dict(rows=[], final=final, issues=[], warnings=[], stats={"accounts": {}, "categories": {}, "adjust": 0, "dates": []}, info=info)
    name, data = csvs[0]
    headers, raw = read_table(data)
    info.update(headers=headers, total=len(raw))
    if sniff_format(raw) == "legacy" and not opts.get("columns"):
        rows = [{(k or "").strip(): (v if v is not None else "") for k, v in r.items() if k} for r in raw]
        if not jsons:
            final = final_from_rows(rows)
        stats = {"accounts": {}, "categories": {}, "adjust": 0, "dates": []}
        return dict(rows=rows, final=final, issues=[], warnings=[], stats=stats, info=info)
    cols = detect_columns(headers)
    for f, h_ in (opts.get("columns") or {}).items():
        if f in FIELDS:
            if h_ in headers:
                cols[f] = h_
            else:
                cols.pop(f, None)
    info.update(kind="generic", columns=cols)
    missing = [FIELD_LABEL[f] for f in REQUIRED if f not in cols]
    if missing:
        info["missing"] = missing
        return dict(rows=[], final=final, issues=[], warnings=[], stats={"accounts": {}, "categories": {}, "adjust": 0, "dates": []}, info=info)
    with book.session(quiet=True) as c:
        ci = book.category_info(c)
        cats = set(ci["usage"]) | set(ci["defined"])
        accts = {r["name"].casefold(): r["currency"] for r in c.execute("SELECT name,currency FROM accounts")}
    rows, issues, warns, stats = to_legacy_rows(raw, cols, opts, cats, accts)
    return dict(rows=rows, final=final, issues=issues, warnings=warns, stats=stats, info=info)


def _existing(book):
    with book.session(quiet=True) as c:
        ci = book.category_info(c)
        accts = [{"name": r["name"], "currency": r["currency"]} for r in c.execute("SELECT name,currency FROM accounts WHERE archived=0 ORDER BY sort_order,id")] \
            if _has_col(c, "accounts", "archived") else \
            [{"name": r["name"], "currency": r["currency"]} for r in c.execute("SELECT name,currency FROM accounts ORDER BY sort_order,id")]
        cats = sorted(set(ci["usage"]) | set(ci["defined"]), key=str.casefold)
        untouched = {r["name"].casefold() for r in c.execute(
            "SELECT name FROM accounts a WHERE opening_minor=0 AND NOT EXISTS (SELECT 1 FROM transactions t WHERE t.account_id=a.id OR t.to_account_id=a.id)")}
    return accts, cats, untouched


def _has_col(c, table, col):
    return any(r[1] == col for r in c.execute(f"PRAGMA table_info({table})"))


def _balances_for_new(book, opts, final):
    """Optional 'balance right now' typed by the user, only for accounts that do not exist yet."""
    typed = opts.get("balances") or {}
    with book.session(quiet=True) as c:
        have = {r["name"].casefold() for r in c.execute("SELECT name FROM accounts")}
    _, _, untouched = _existing(book)
    have -= untouched
    out = dict(final)
    for name, v in typed.items():
        if str(v).strip() == "" or str(name).casefold() in have:
            continue
        try:
            out[str(name)] = float(str(v).replace(",", ""))
        except ValueError:
            raise BookError(f"帳戶「{name}」的目前餘額不是數字") from None
    return out


def plan(book, files, opts):
    """What an import would do, without doing it (everything is rolled back)."""
    prep = prepare(book, files, opts)
    info, stats = prep["info"], prep["stats"]
    accts, cats, untouched = _existing(book)
    out = {"kind": info["kind"], "headers": info["headers"], "columns": info["columns"], "total": info["total"],
           "fields": [{"key": f, "label": FIELD_LABEL[f], "required": f in REQUIRED} for f in FIELDS],
           "existing_accounts": accts, "existing_categories": cats}
    if info.get("missing"):
        out.update(missing=info["missing"], will_import=0, duplicates=0, invalid=[], warnings=[], accounts=[], categories=[], sample=[])
        return out
    rep = import_legacy(book, prep["rows"], _balances_for_new(book, opts, prep["final"]), dry_run=True)
    have = {a["name"].casefold(): a["currency"] for a in accts}
    out.update(
        will_import=rep["imported"], duplicates=rep["duplicates"], adjust=stats["adjust"],
        invalid=(prep["issues"] + rep["invalid"]), warnings=list(dict.fromkeys(prep["warnings"] + rep["warnings"])),
        date_from=min(stats["dates"]) if stats["dates"] else None, date_to=max(stats["dates"]) if stats["dates"] else None,
        accounts=[{"source": src, "name": a["name"], "count": a["count"], "net": float(a["net"]), "currency": a["currency"],
                   "exists": a["name"].casefold() in have, "existing_currency": have.get(a["name"].casefold()),
                   "settable": a["name"].casefold() not in have or a["name"].casefold() in untouched}
                  for src, a in stats["accounts"].items()],
        categories=sorted(({"source": src, "name": c["to"], "count": c["count"], "kinds": sorted(c["kinds"])}
                           for src, c in stats["categories"].items()), key=lambda x: -x["count"]),
        sample=[{k: r.get(k, "") for k in ("time", "type", "category", "amount", "account", "note")} for r in prep["rows"][:5]],
        accounts_created=rep["accounts_created"])
    return out


def run(book, files, opts):
    prep = prepare(book, files, opts)
    if prep["info"].get("missing"):
        raise BookError("還有必要的欄位沒有對應：" + "、".join(prep["info"]["missing"]))
    rows, final = prep["rows"], _balances_for_new(book, opts, prep["final"])
    if not rows and not final:
        raise BookError("檔案裡沒有可匯入的資料")
    backup = book.backup("beforeimport").name           # one-click way back if the file turns out to be wrong
    rep = import_legacy(book, rows, final)
    rep["backup"] = backup
    rep["invalid"] = prep["issues"] + rep["invalid"]
    rep["warnings"] = list(dict.fromkeys(prep["warnings"] + rep["warnings"]))
    return rep
