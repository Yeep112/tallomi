"""Optional live exchange-rate lookup. Manual rates always work without this."""
import json
import urllib.error
import urllib.request

from .book import BookError

RATE_URL = "https://open.er-api.com/v6/latest/{base}"


def fetch_rates(base: str, timeout: float = 10.0) -> dict:
    """Returns {code: units of code per 1 `base`}."""
    req = urllib.request.Request(RATE_URL.format(base=base), headers={"User-Agent": "Pennyworth/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        raise BookError("目前連不上網路，無法取得線上匯率。可以等有網路再試，或先手動輸入匯率；記帳本身不受影響。", 502) from None
    if data.get("result") != "success" or not isinstance(data.get("rates"), dict):
        raise BookError("匯率服務回傳了無法解讀的資料，請改為手動輸入匯率。", 502)
    return data["rates"]
