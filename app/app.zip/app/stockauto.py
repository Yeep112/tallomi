"""Twice a day, while the computer is online, read every stock's price from the official sources (see pricefetch.py)
and put it in the 庫存 table. Same idea as fxauto.py for exchange rates.

Two updates a day: the morning one (06:00 - 13:44) picks up the US close and the Taiwan pre-open reference price,
the afternoon one (from 13:45, after the Taiwan market closed) picks up the Taiwan closing price. 00:00 - 05:59 still
belongs to the previous day's afternoon update. A price typed by hand is never replaced silently (see invest.py).

Runs inside the open program (checked every minute) and on its own through `run.py --fetch-rates`.
"""
import logging
import threading
from datetime import datetime, timedelta

log = logging.getLogger(__name__)
RETRY_OFFLINE = 600
RETRY_OTHER = 1800
MAX_TRIES_PER_SLOT = 3
MORNING_FROM = (6, 0)
AFTERNOON_FROM = (13, 45)


def current_slot(now=None):
    now = now or datetime.now()
    hm = (now.hour, now.minute)
    if hm < MORNING_FROM:                       # after midnight: still the previous day's afternoon update
        return (now - timedelta(days=1)).strftime("%Y-%m-%d") + ":B"
    return now.strftime("%Y-%m-%d") + (":B" if hm >= AFTERNOON_FROM else ":A")


class StockAuto:
    def __init__(self, book, fetcher_getter=None):
        self.book = book
        self._fetcher_getter = fetcher_getter or (lambda: None)
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.status = {"state": "idle", "last_try": None, "last_ok": None, "results": [], "tries": 0, "try_slot": None}

    # ------------------------------------------------------------ settings
    def enabled(self):
        with self.book.session() as c:
            return self.book.get_setting(c, "stock_auto", "1") != "0"

    def set_enabled(self, on):
        with self.book.session() as c:
            self.book.set_setting(c, "stock_auto", "1" if on else "0")

    def done_slots(self):
        """Finished updates of the current update day, e.g. ["2026-11-12:A"]."""
        day = current_slot().split(":")[0]
        with self.book.session() as c:
            raw = self.book.get_setting(c, "stock_auto_done", "")
        return [s for s in raw.split(",") if s.startswith(day)]

    def done_today(self):
        return current_slot() in self.done_slots()

    def symbols(self):
        with self.book.session() as c:
            return [r["symbol"] for r in c.execute("SELECT DISTINCT symbol FROM securities ORDER BY symbol")]

    def info(self):
        with self.book.session() as c:
            at = self.book.get_setting(c, "stock_auto_at", "")
        return {"enabled": self.enabled(), "done_today": self.done_today(), "done_count": len(self.done_slots()), "per_day": 2,
                "last_ok": at or None, "state": self.status["state"], "last_try": self.status["last_try"],
                "results": self.status["results"], "symbols": self.symbols()}

    # ----------------------------------------------------------------- run
    def run_once(self):
        """Read every stock on the page. -> True if at least one price was read."""
        if not self._lock.acquire(blocking=False):
            return False
        try:
            self.status["state"] = "running"
            self.status["last_try"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
            slot = current_slot()
            if self.status["try_slot"] != slot:
                self.status["try_slot"], self.status["tries"] = slot, 0
            self.status["tries"] += 1
            syms = self.symbols()
            any_ok, all_offline, rows = False, True, []
            try:
                r = self.book.fetch_stock_prices(fetcher=self._fetcher_getter(), force=True)
            except Exception as e:                       # a crash inside a fetch must not stop bookkeeping
                log.exception("stock price update failed")
                r = {"results": [], "applied": [], "pending": [], "failed": [{"symbol": s, "error": str(e)} for s in syms]}
                all_offline = False
            any_ok = bool(r.get("applied") or r.get("pending"))
            for f in r.get("failed", []):
                if "連不上" not in (f.get("error") or ""):
                    all_offline = False
            rows = [{"symbol": x["symbol"], "ok": True, "price": x["price"], "source": x.get("source"), "kept_manual": False}
                    for x in r.get("applied", [])]
            rows += [{"symbol": x["symbol"], "ok": True, "price": x["price"], "source": x.get("source"), "kept_manual": True}
                     for x in r.get("pending", [])]
            rows += [{"symbol": x["symbol"], "ok": False, "error": x.get("error")} for x in r.get("failed", [])]
            self.status["results"] = rows
            if any_ok:
                stamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
                with self.book.session() as c:
                    done = self.done_slots() + [slot]
                    self.book.set_setting(c, "stock_auto_done", ",".join(dict.fromkeys(done)))
                    self.book.set_setting(c, "stock_auto_at", stamp)
                self.status["state"], self.status["last_ok"] = "ok", stamp
            else:
                self.status["state"] = "offline" if (syms and all_offline) else "error"
            log.info("daily stock price update: %s for %s", self.status["state"], syms)
            return any_ok
        finally:
            self._lock.release()

    def due(self):
        if not self.enabled() or self.done_today() or not self.symbols():
            return False
        tries = self.status["tries"] if self.status["try_slot"] == current_slot() else 0
        if tries >= MAX_TRIES_PER_SLOT:
            return False
        last = self.status["last_try"] if tries else None
        if last:
            wait = RETRY_OFFLINE if self.status["state"] == "offline" else RETRY_OTHER
            if datetime.now() - datetime.strptime(last, "%Y-%m-%dT%H:%M:%S") < timedelta(seconds=wait):
                return False
        return True

    def run_if_due(self):
        return self.run_once() if self.due() else False

    # ------------------------------------------------------------ thread
    def start(self, first_delay=9):
        def loop():
            if self._stop.wait(first_delay):
                return
            while not self._stop.is_set():
                try:
                    self.run_if_due()
                except Exception:
                    log.exception("daily stock price update crashed")
                if self._stop.wait(60):
                    return
        threading.Thread(target=loop, name="stock-auto", daemon=True).start()

    def stop(self):
        self._stop.set()
