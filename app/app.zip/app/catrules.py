"""Category rules (分類規則): "a note that contains <word> gets <category / tags / account>".

How it works
- The rules are one ordered list kept with the book (settings key `cat_rules`). The first rule, from the top, that fits an entry wins.
- A rule only FILLS WHAT IS BLANK: it never overwrites a category, tags or account the person chose themselves.
- It is applied when an entry is added (the add form, the quick-add address, the phone's queued entries, recurring entries) and when a
  file is imported. Old entries are only touched when the person asks for it: preview first, then apply, and the change can be undone.
- Old entries that are looked at are the ones still in 「未分類」; their category / tags are filled in, nothing else changes.
"""
import json
import re

MAX_CAT_RULES = 100
KINDS = ("any", "expense", "income")
_SPLIT = re.compile(r"[,，、|｜\n]+")


def _err(msg, status=400):
    from .book import BookError
    return BookError(msg, status)


def keywords(text):
    return [k.strip() for k in _SPLIT.split(str(text or "")) if k.strip()]


def rule_hits(rule, typ, note):
    """Does this rule fit an entry of this type with this note?"""
    if not rule.get("on", True) or typ not in ("income", "expense"):
        return False
    if rule.get("kind", "any") not in ("any", typ):
        return False
    low = str(note or "").casefold()
    return bool(low) and any(k.casefold() in low for k in keywords(rule.get("text")))


def first_rule(rules, typ, note):
    for r in rules:
        if rule_hits(r, typ, note):
            return r
    return None


class CatRulesMixin:
    def cat_rules(self, conn):
        raw = self.get_setting(conn, "cat_rules", "")
        try:
            items = json.loads(raw) if raw else []
        except ValueError:
            items = []
        return [r for r in items if isinstance(r, dict) and keywords(r.get("text"))]

    def _clean_cat_rules(self, c, items):
        if not isinstance(items, list):
            raise _err("規則格式不正確")
        if len(items) > MAX_CAT_RULES:
            raise _err(f"規則最多 {MAX_CAT_RULES} 條，請先刪掉不用的")
        out = []
        for n, p in enumerate(items, start=1):
            if not isinstance(p, dict):
                raise _err("規則格式不正確")
            kws = keywords(p.get("text"))
            if not kws:
                raise _err(f"第 {n} 條規則還沒有填「備註包含」的字")
            text = "、".join(k[:40] for k in kws[:10])
            kind = p.get("kind") if p.get("kind") in KINDS else "any"
            cat = str(p.get("category") or "").strip()[:60]
            if cat in self.RESERVED_CATEGORIES:
                raise _err(f"「{cat}」是系統保留的名稱，請換一個類別")
            tags = self.clean_tags(p.get("tags") or "")
            aid = None
            if str(p.get("account_id") or "").isdigit():
                aid = int(p["account_id"])
                if not c.execute("SELECT 1 FROM accounts WHERE id=?", (aid,)).fetchone():
                    aid = None
            if not (cat or tags or aid):
                raise _err(f"第 {n} 條規則（{text}）還沒有要設定的類別、標籤或帳戶")
            out.append({"text": text, "kind": kind, "category": cat, "tags": tags, "account_id": aid, "on": p.get("on", True) is not False})
        return out

    def save_cat_rules(self, items):
        with self.session(notify=True) as c:
            clean = self._clean_cat_rules(c, items)
            self.set_setting(c, "cat_rules", json.dumps(clean, ensure_ascii=False))
            return clean

    def fill_from_rules(self, c, p, rules=None):
        """A copy of an entry's input with its blanks filled in by the first rule that fits (the entry itself is never overwritten)."""
        typ = p.get("type")
        if typ not in ("income", "expense") or not str(p.get("note") or "").strip():
            return p
        rules = self.cat_rules(c) if rules is None else rules
        if not rules:
            return p
        r = first_rule(rules, typ, p.get("note"))
        if not r:
            return p
        q = dict(p)
        if r.get("category") and str(q.get("category") or "").strip() in ("", "未分類"):
            q["category"] = r["category"]
        if r.get("tags") and not self.clean_tags(q.get("tags") or ""):
            q["tags"] = list(r["tags"])
        if r.get("account_id") and not str(q.get("account_id") or "").strip():
            a = c.execute("SELECT archived FROM accounts WHERE id=?", (r["account_id"],)).fetchone()
            if a and not a["archived"]:
                q["account_id"] = r["account_id"]
        return q

    def _past_matches(self, c, rules):
        """Old entries still in 「未分類」 that a rule would sort: [(row, rule, new_tags)]."""
        out = []
        rows = c.execute("SELECT id,type,category,note FROM transactions WHERE type IN ('income','expense') AND (category='' OR category='未分類') "
                         "AND note<>'' AND settle_of IS NULL AND id NOT IN (SELECT tx_id FROM stock_trades WHERE tx_id IS NOT NULL) ORDER BY time DESC, id DESC").fetchall()
        for row in rows:
            r = first_rule(rules, row["type"], row["note"])
            if not r or not r.get("category"):
                continue
            out.append((row, r))
        return out

    def preview_cat_rules(self):
        with self.session() as c:
            rules = self.cat_rules(c)
            hits = self._past_matches(c, rules)
        by = {}
        for row, r in hits:
            e = by.setdefault(r["text"], {"text": r["text"], "category": r["category"], "count": 0})
            e["count"] += 1
        return {"count": len(hits), "by_rule": list(by.values()),
                "sample": [{"note": row["note"], "type": row["type"], "to": r["category"]} for row, r in hits[:8]]}

    def apply_cat_rules_to_past(self):
        with self.session(notify=True) as c:
            rules = self.cat_rules(c)
            snaps, done = [], 0
            for row, r in self._past_matches(c, rules):
                full = c.execute("SELECT * FROM transactions WHERE id=?", (row["id"],)).fetchone()
                snaps.append(self._edit_snap(c, full))
                c.execute("UPDATE transactions SET category=?, updated_at=? WHERE id=?", (r["category"], self._now(), row["id"]))
                if r.get("tags"):
                    have = [x["tag"] for x in c.execute("SELECT tag FROM tx_tags WHERE tx_id=?", (row["id"],))]
                    merged = have + [t for t in r["tags"] if t.casefold() not in {h.casefold() for h in have}]
                    if len(merged) <= self.MAX_TAGS:
                        self._set_tags(c, row["id"], merged)
                done += 1
        out = {"changed": done}
        if snaps:
            out["undo"] = self._remember_undo(snaps)
        return out

    @staticmethod
    def _now():
        from .timeutil import now_iso
        return now_iso()
