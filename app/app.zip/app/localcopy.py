"""The phone's working copy of the book (1.63.0).

The owner's phone normally talks to the computer. So that it also opens and works while the computer is off, it keeps a copy of the book and
this same program (run by Pyodide inside the phone, like the public phone version). This file builds the two things the phone downloads:

  snapshot()  the book as one zip: a consistent copy of the database WITHOUT what must never leave the computer (the Google Sheets key, the phone
              pairing list, receipt photos, folders of the computer), the PIN record (so the same PIN opens the copy), and a small meta.json
  engine()    this program's own Python files as a zip (always the same version as the book, so the copy never meets a newer or older program)

While the phone uses the copy, everything it changes is logged on the phone and sent to the computer one by one when it is back (app-local.js).
"""
import io
import json
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from . import config

# settings that stay on the computer
SECRET_SETTINGS = ("sheets_key", "sheets_pending", "sheets_auto", "sheets_worksheet", "remote_url", "remote_enabled", "ab_dir", "ab_last", "ab_last_second", "ab_on")
SKIP_PY = {"tray.py"}


def snapshot(book, applock_path):
    """-> (zip bytes, meta). Safe to call while the program is running: the copy is made with SQLite's online backup."""
    with tempfile.TemporaryDirectory() as td:
        dst_path = Path(td) / "pennyworth.db"
        rev = book.rev                                              # read first: the copy holds at least everything up to this revision
        src = sqlite3.connect(str(book.db_path))
        dst = sqlite3.connect(str(dst_path))
        try:
            src.backup(dst)
        finally:
            src.close()
        try:
            dst.execute("DELETE FROM devices")
            dst.execute("DELETE FROM receipts")
            dst.execute("DELETE FROM settings WHERE key IN (%s)" % ",".join("?" * len(SECRET_SETTINGS)), SECRET_SETTINGS)
            max_tx = dst.execute("SELECT COALESCE(MAX(id),0) FROM transactions").fetchone()[0]
            dst.commit()
            dst.execute("VACUUM")
        finally:
            dst.close()
        meta = {"rev": rev, "version": config.VERSION, "taken_at": datetime.now().replace(microsecond=0).isoformat(), "max_tx_id": max_tx}
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            z.write(dst_path, "pennyworth.db")
            ap = Path(applock_path)
            if ap.is_file():
                z.write(ap, "applock.json")
            z.writestr("meta.json", json.dumps(meta))
        return buf.getvalue(), meta


def engine():
    """-> zip bytes holding this program's Python files as app/*.py (what the phone version's own package holds)."""
    app = Path(__file__).resolve().parent
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(app.glob("*.py")):
            if f.name not in SKIP_PY:
                z.write(f, f"app/{f.name}")
        pk = app / "update_pubkey.txt"
        if pk.is_file():
            z.write(pk, "app/update_pubkey.txt")
    return buf.getvalue()
