"""Two small locks.

OwnerLock  account + password that guard "switch back to my own book" in the owner's copy (so somebody who is shown the
           preview cannot walk into the owner's real book). Stored next to the program settings, only as a salted hash.
AppLock    an optional PIN (4-8 digits) for a book: when it is on, nothing of the book is served until the PIN is typed;
           it can lock itself after some idle minutes, and it can be turned off again with the PIN.
Both slow down guessing. Neither is encryption of the book file; they keep the screen and the program's pages closed.
"""
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
from pathlib import Path

_NATIVE_PBKDF2 = hasattr(hashlib, "pbkdf2_hmac")
# Some Python builds (the phone version's Pyodide) have no fast PBKDF2: there the pure-Python one below is used, with fewer rounds.
# The round count is stored with every record, so a record always verifies with the count it was made with.
ITER = 200_000 if _NATIVE_PBKDF2 else 20_000
IDLE_CHOICES = (0, 1, 5, 15, 60)           # minutes; 0 = lock only when the program starts
PIN_RE = re.compile(r"^\d{4,8}$")


class LockError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def _pbkdf2_sha256(password, salt, iters):
    """PBKDF2-HMAC-SHA256, one 32-byte block (RFC 8018), for Pythons without hashlib.pbkdf2_hmac."""
    key = hashlib.sha256(password).digest() if len(password) > 64 else password
    key = key.ljust(64, b"\0")
    inner = hashlib.sha256(bytes(b ^ 0x36 for b in key))
    outer = hashlib.sha256(bytes(b ^ 0x5C for b in key))

    def prf(data):
        i = inner.copy()
        i.update(data)
        o = outer.copy()
        o.update(i.digest())
        return o.digest()

    u = prf(salt + b"\x00\x00\x00\x01")
    t = int.from_bytes(u, "big")
    for _ in range(iters - 1):
        u = prf(u)
        t ^= int.from_bytes(u, "big")
    return t.to_bytes(32, "big")


def _hash(secret, salt, iters=None):
    iters = iters or ITER
    raw = secret.encode("utf-8")
    if _NATIVE_PBKDF2:
        return hashlib.pbkdf2_hmac("sha256", raw, salt, iters).hex()
    return _pbkdf2_sha256(raw, salt, iters).hex()


def _read(path):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(path, data):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    os.replace(tmp, path)


class Throttle:
    """After 5 wrong tries in a row: wait 30 s, then doubling up to 15 minutes. A right answer starts over."""

    def __init__(self, clock=time.time):
        self.clock = clock
        self.fails = 0
        self.until = 0.0
        self._lock = threading.Lock()

    def check(self):
        with self._lock:
            wait = int(self.until - self.clock())
        if wait > 0:
            raise LockError(f"輸入錯太多次了，請 {wait} 秒後再試", 429)

    def fail(self):
        with self._lock:
            self.fails += 1
            if self.fails >= 5:
                self.until = self.clock() + min(900, 30 * 2 ** (self.fails - 5))

    def ok(self):
        with self._lock:
            self.fails, self.until = 0, 0.0


class OwnerLock:
    def __init__(self, path, clock=time.time):
        self.path = Path(path)
        self.throttle = Throttle(clock)

    def is_set(self):
        d = _read(self.path)
        return bool(d.get("hash") and d.get("account"))

    def account(self):
        return _read(self.path).get("account", "")

    def verify(self, account, password):
        """Raises LockError unless the account and password are the right ones."""
        d = _read(self.path)
        if not d.get("hash"):
            return
        self.throttle.check()
        good = hmac.compare_digest(str(account or "").strip().lower(), d["account"].lower())
        calc = _hash(str(password or ""), bytes.fromhex(d["salt"]), d.get("iter", ITER))
        good = hmac.compare_digest(calc, d["hash"]) and good
        if not good:
            self.throttle.fail()
            raise LockError("帳號或密碼不對", 403)
        self.throttle.ok()

    def set(self, account, password, current=None):
        account = str(account or "").strip()
        if not 1 <= len(account) <= 40:
            raise LockError("帳號請填 1～40 個字")
        if len(str(password or "")) < 6:
            raise LockError("密碼至少 6 個字")
        if self.is_set():
            self.verify(self.account(), current)
        salt = secrets.token_bytes(16)
        _write(self.path, {"account": account, "salt": salt.hex(), "iter": ITER, "hash": _hash(password, salt)})

    def clear(self, current):
        if self.is_set():
            self.verify(self.account(), current)
        try:
            self.path.unlink()
        except OSError:
            pass


class AppLock:
    def __init__(self, path, clock=time.time):
        self.path = Path(path)
        self.clock = clock
        self.throttle = Throttle(clock)
        self._sessions = {}                       # unlock token -> time of last use
        self._lock = threading.Lock()

    # ---- settings
    def enabled(self):
        return bool(_read(self.path).get("hash"))

    def idle_min(self):
        return int(_read(self.path).get("idle_min", 0) or 0)

    def set_pin(self, pin, current=None):
        if not PIN_RE.match(str(pin or "")):
            raise LockError("PIN 請輸入 4～8 個數字")
        d = _read(self.path)
        if d.get("hash"):
            self._verify(current, d)
        salt = secrets.token_bytes(16)
        _write(self.path, {"salt": salt.hex(), "iter": ITER, "hash": _hash(pin, salt), "idle_min": d.get("idle_min", 0), "bio": bool(d.get("bio"))})

    def disable(self, current):
        d = _read(self.path)
        if d.get("hash"):
            self._verify(current, d)
        try:
            self.path.unlink()
        except OSError:
            pass
        with self._lock:
            self._sessions.clear()

    def biometric(self):
        d = _read(self.path)
        return bool(d.get("hash")) and bool(d.get("bio"))

    def set_biometric(self, on):
        """Phone only: remember that this phone also unlocks with Face ID / fingerprint (the phone itself checks it)."""
        d = _read(self.path)
        if not d.get("hash"):
            raise LockError("請先設定 PIN")
        d["bio"] = bool(on)
        _write(self.path, d)

    def unlock_trusted(self):
        """An unlock that the phone's own biometric check already vouched for (see /api/lock/unlock-biometric)."""
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._sessions[token] = self.clock()
        return token

    def set_idle(self, minutes):
        if minutes not in IDLE_CHOICES:
            raise LockError("不支援這個時間")
        d = _read(self.path)
        if not d.get("hash"):
            raise LockError("還沒有設定 PIN")
        d["idle_min"] = minutes
        _write(self.path, d)

    # ---- unlocking
    def _verify(self, pin, d):
        self.throttle.check()
        calc = _hash(str(pin or ""), bytes.fromhex(d["salt"]), d.get("iter", ITER))
        if not hmac.compare_digest(calc, d["hash"]):
            self.throttle.fail()
            raise LockError("PIN 不對", 403)
        self.throttle.ok()

    def unlock(self, pin):
        d = _read(self.path)
        if not d.get("hash"):
            return ""
        self._verify(pin, d)
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._sessions[token] = self.clock()
        return token

    def valid(self, token):
        """Is this browser unlocked right now? Using the program keeps it unlocked; sitting idle past the limit locks it."""
        if not self.enabled():
            return True
        idle = self.idle_min() * 60
        with self._lock:
            last = self._sessions.get(token or "")
            if last is None:
                return False
            now = self.clock()
            if idle and now - last > idle:
                del self._sessions[token]
                return False
            self._sessions[token] = now
            return True

    def lock(self, token):
        with self._lock:
            self._sessions.pop(token or "", None)
