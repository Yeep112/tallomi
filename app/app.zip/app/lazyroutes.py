"""Starting faster (1.67.0): Werkzeug writes and compiles a small Python function for every route (to build addresses back from a route) the moment the
route is added. The program has some 150 routes and never builds an address from one, so on the phone that was most of the time spent in create_app
(about 0.4 s of it at a quarter of the usual speed). Here the function is made the first time somebody asks for it.

Only touches a private method of Werkzeug 3.x; with any other layout nothing is changed."""


def install():
    try:
        from werkzeug.routing import rules
        orig = rules.Rule._compile_builder
        if getattr(orig, "_lazy", False):
            return False
    except (ImportError, AttributeError):
        return False

    def _compile_builder(self, append_unknown=True):
        made = []

        def build(rule, *args, **kwargs):
            if not made:
                made.append(orig(rule, append_unknown))
            return made[0](rule, *args, **kwargs)
        return build

    _compile_builder._lazy = True
    rules.Rule._compile_builder = _compile_builder
    return True
