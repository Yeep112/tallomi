"""Daily automatic backup, with a second copy in another folder.

* Once a day (while the program runs) and once when 「結束 Tallomi」 is pressed (if anything changed since the last
  automatic backup) a snapshot of the book is saved in the backups folder.
* Only the newest KEEP_AUTO automatic backups are kept there; the same number is kept in the second folder.
  Backups made by hand ("立即備份", or before a reset / restore) are not touched by this.
* The second folder (on Windows by default D:\\pennyworth\\備份, change it in Settings) receives a copy of every
  automatic backup. If it cannot be written (drive missing, no permission ...) the reason shows in Settings and the
  next day's backup tries again; the main backup is never affected.
"""
import logging
import os
import re
import shutil
import threading
from datetime import datetime
from pathlib import Path

from . import db

log = logging.getLogger(__name__)
KEEP_AUTO = 5
RETRY_AFTER = 1800                     # seconds before trying again after a failure
AUTO_RE = re.compile(r"^pennyworth-\d{8}-\d{6}-auto(_\d+)?\.db$")
DEFAULT_SECOND_DIR = r"D:\pennyworth\備份"


def _age(p):
    """Oldest first. The modification time decides (two backups can share one second in their names)."""
    return (p.stat().st_mtime_ns, p.name)


def default_second_dir():
    return DEFAULT_SECOND_DIR if os.name == "nt" else ""


class AutoBackup:
    def __init__(self, book):
        self.book = book
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self.rev_at_backup = book.rev
        self.status = {"state": "idle", "error": None, "second_error": None, "last_try": None}

    # ------------------------------------------------------------ settings
    def enabled(self):
        with self.book.session() as c:
            return self.book.get_setting(c, "ab_on", "1") != "0"

    def folder(self):
        with self.book.session() as c:
            return self.book.get_setting(c, "ab_dir", default_second_dir())

    def configure(self, enabled=None, folder=None):
        if folder is not None:
            folder = str(folder).strip().strip('"')
            if folder:
                p = Path(folder)
                if not p.is_absolute():
                    raise ValueError("請填完整路徑，例如 D:\\pennyworth\\備份")
                if p.resolve() in (self.book.backup_dir.resolve(), self.book.data_dir.resolve()):
                    raise ValueError("第二份存放處要和原本的備份資料夾不同，才有分散風險的效果")
                try:
                    p.mkdir(parents=True, exist_ok=True)
                    probe = p / ".pennyworth-write-test"
                    probe.write_text("ok")
                    probe.unlink()
                except OSError as e:
                    raise ValueError(f"這個資料夾無法建立或寫入：{e.strerror or e}")
        with self.book.session() as c:
            if enabled is not None:
                self.book.set_setting(c, "ab_on", "1" if enabled else "0")
            if folder is not None:
                self.book.set_setting(c, "ab_dir", folder)

    # ---------------------------------------------------------------- info
    def _last(self, key):
        with self.book.session() as c:
            return self.book.get_setting(c, key, "") or None

    def auto_files(self):
        d = self.book.backup_dir
        return sorted((p for p in d.iterdir() if AUTO_RE.match(p.name)), key=_age) if d.exists() else []

    def info(self):
        folder = self.folder()
        return {"enabled": self.enabled(), "folder": folder, "default_folder": default_second_dir(), "keep": KEEP_AUTO,
                "last_ok": self._last("ab_last"), "last_second_ok": self._last("ab_last_second"),
                "state": self.status["state"], "error": self.status["error"], "second_error": self.status["second_error"],
                "count": len(self.auto_files())}

    def due(self, now=None):
        """True when no automatic backup was made today (and the last try, if it failed, is old enough)."""
        if not self.enabled():
            return False
        now = now or datetime.now()
        last = self._last("ab_last")
        if last and last[:10] == now.strftime("%Y-%m-%d"):
            return False
        t = self.status["last_try"]
        return not (t and (now - t).total_seconds() < RETRY_AFTER and self.status["state"] == "error")

    # ----------------------------------------------------------------- run
    def run_once(self, reason="daily"):
        """Make the automatic backup now. -> True if the main backup was written."""
        if not self._lock.acquire(blocking=False):
            return False
        try:
            self.status.update(state="running", last_try=datetime.now(), error=None, second_error=None)
            try:
                path = self.book.backup("auto")
            except Exception as e:
                log.exception("automatic backup failed")
                self.status.update(state="error", error=str(e))
                return False
            for old in self.auto_files()[:-KEEP_AUTO]:
                try:
                    old.unlink()
                except OSError:
                    pass
            stamp = datetime.now().replace(microsecond=0).isoformat()
            with self.book.session() as c:
                self.book.set_setting(c, "ab_last", stamp)
            self._copy_second(path, stamp)
            self.rev_at_backup = self.book.rev                  # (after our own bookkeeping above, which also counts as a change)
            self.status["state"] = "ok"
            log.info("automatic backup (%s): %s", reason, path.name)
            return True
        finally:
            self._lock.release()

    def _copy_second(self, path, stamp):
        folder = self.folder()
        if not folder:
            return
        try:
            dest_dir = Path(folder)
            dest_dir.mkdir(parents=True, exist_ok=True)
            tmp = dest_dir / (path.name + ".part")
            shutil.copy2(path, tmp)
            tmp.replace(dest_dir / path.name)
            for old in sorted((p for p in dest_dir.iterdir() if db.BACKUP_RE.match(p.name)), key=_age)[:-KEEP_AUTO]:
                try:
                    old.unlink()
                except OSError:
                    pass
            with self.book.session() as c:
                self.book.set_setting(c, "ab_last_second", stamp)
        except OSError as e:
            log.warning("second backup folder failed: %s", e)
            self.status["second_error"] = f"{e.strerror or e}（{folder}）"

    def on_quit(self):
        """Called when the program is asked to quit: back up if anything was saved since the last automatic backup."""
        try:
            if self.enabled() and self.book.rev != self.rev_at_backup:
                self.run_once("quit")
        except Exception:
            log.exception("backup at quit failed")

    # -------------------------------------------------------------- thread
    def start(self):
        threading.Thread(target=self._loop, name="autobackup", daemon=True).start()

    def stop(self):
        self._stop.set()

    def _loop(self):
        if self._stop.wait(20):
            return
        while True:
            try:
                if self.due():
                    self.run_once("daily")
            except Exception:
                log.exception("autobackup loop")
            if self._stop.wait(300):
                return
