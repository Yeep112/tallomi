"""Money helpers.

All amounts are stored as integers in the currency's minor unit
(TWD cents, JPY yen, ...) so sums are exact. The API talks in normal decimals.
"""
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
import re

ZERO_DECIMAL = {"JPY", "KRW", "VND", "CLP", "ISK", "UGX", "PYG", "XAF", "XOF", "XPF",
                "RWF", "VUV", "KMF", "GNF", "DJF", "BIF"}
THREE_DECIMAL = {"KWD", "BHD", "OMR", "JOD", "TND", "LYD", "IQD"}
MAX_MAJOR = Decimal("1000000000000")  # 1e12, sanity limit

_CCY_RE = re.compile(r"^[A-Z]{3}$")


def normalize_currency(code) -> str:
    c = str(code or "").strip().upper()
    if not _CCY_RE.match(c):
        raise ValueError("幣別代碼必須是 3 個英文字母，例如 TWD、USD、JPY")
    return c


def exponent(ccy: str) -> int:
    if ccy in ZERO_DECIMAL:
        return 0
    if ccy in THREE_DECIMAL:
        return 3
    return 2


def parse_amount(value) -> Decimal:
    """'1,234.5' / 1234.5 / '  12 ' -> Decimal. Raises ValueError on garbage."""
    if value is None or (isinstance(value, str) and not value.strip()):
        raise ValueError("請輸入金額")
    if isinstance(value, bool):
        raise ValueError("金額格式不正確")
    try:
        d = Decimal(str(value).replace(",", "").strip())
    except InvalidOperation:
        raise ValueError(f"金額格式不正確：{value}") from None
    if not d.is_finite():
        raise ValueError("金額格式不正確")
    if abs(d) > MAX_MAJOR:
        raise ValueError("金額過大")
    return d


def to_minor(value, ccy: str) -> int:
    d = parse_amount(value)
    q = Decimal(1).scaleb(-exponent(ccy))
    return int((d.quantize(q, rounding=ROUND_HALF_UP)).scaleb(exponent(ccy)))


def to_major(minor: int, ccy: str) -> Decimal:
    return Decimal(int(minor)).scaleb(-exponent(ccy))


def from_minor(minor, ccy: str) -> float:
    """For JSON output / display."""
    if minor is None:
        return None
    return float(to_major(minor, ccy))


def convert_minor(minor: int, from_ccy: str, to_ccy: str, rate_from, rate_to) -> int:
    """Convert via the base currency. rate_x = how many base units 1 x is worth."""
    if from_ccy == to_ccy:
        return int(minor)
    major = to_major(minor, from_ccy) * Decimal(str(rate_from)) / Decimal(str(rate_to))
    q = Decimal(1).scaleb(-exponent(to_ccy))
    return int(major.quantize(q, rounding=ROUND_HALF_UP).scaleb(exponent(to_ccy)))
