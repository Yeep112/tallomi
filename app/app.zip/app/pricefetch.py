"""Read current share prices from public sources.

Nothing here decides what to store: the caller does. Any price may be late, missing or wrong (a source may change,
block automated visits, or be closed), so the investment page always lets the person type the price themselves.

Sources, tried in this order for each stock until one answers:
  Taiwan  1. TWSE market-information service (mis.twse.com.tw), the exchange's own quotes
          2. Yahoo Finance chart data  (SYMBOL.TW, then SYMBOL.TWO for OTC stocks)
          3. SinoTrade's stock list page (read like the bank pages: plain HTTP, then an invisible Edge/Chrome)
  US      1. Yahoo Finance chart data
          2. Stooq daily quote file
Each result: {"symbol","ok","price","prev_close","at","source","name","note","error"}.
"""
import csv
import http.cookiejar
import io
import json
import re
import socket
import ssl
import urllib.error
import urllib.request
from urllib.parse import urlparse
from datetime import datetime

from . import bankfetch, pool

UA = bankfetch.USER_AGENT
SINOTRADE_URL = "https://aiinvest.sinotrade.com.tw/Stock/List/TW"


class PriceError(Exception):
    pass


def _num(v):
    """'1050.0000' -> 1050.0 ; '-', '', None, 0 -> None"""
    try:
        x = float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None
    return x if x > 0 else None


# ---------------------------------------------------------------- parsers (pure, unit-tested)
def parse_twse(text):
    """getStockInfo.jsp JSON -> {symbol: result}. Uses the last trade `z`; before the first trade of the day the
    mid-point of best bid/ask; if there is none either, yesterday's close (flagged in `note`)."""
    try:
        data = json.loads(text)
    except ValueError:
        raise PriceError("證交所回傳的不是資料") from None
    out = {}
    for it in data.get("msgArray") or []:
        sym = str(it.get("c") or "").strip()
        if not sym:
            continue
        prev = _num(it.get("y"))
        price, note = _num(it.get("z")), ""
        if price is None:
            bid = _num(str(it.get("b") or "").split("_")[0])
            ask = _num(str(it.get("a") or "").split("_")[0])
            if bid and ask:
                price, note = round((bid + ask) / 2, 4), "尚未成交，取買賣價中間值"
            elif bid or ask:
                price, note = bid or ask, "尚未成交，取買賣價"
            elif prev:
                price, note = prev, "尚未成交，暫用昨收"
        if price is None:
            continue
        at = None
        try:
            if it.get("tlong"):
                at = datetime.fromtimestamp(int(it["tlong"]) / 1000).strftime("%Y-%m-%dT%H:%M:%S")
            elif it.get("d") and it.get("t"):
                at = datetime.strptime(it["d"] + it["t"], "%Y%m%d%H:%M:%S").strftime("%Y-%m-%dT%H:%M:%S")
        except (ValueError, OSError, OverflowError):
            at = None
        out[sym] = {"symbol": sym, "ok": True, "price": price, "prev_close": prev, "at": at, "source": "twse",
                    "name": it.get("n") or "", "note": note, "error": None}
    return out


def parse_yahoo(text):
    try:
        meta = json.loads(text)["chart"]["result"][0]["meta"]
    except (ValueError, KeyError, IndexError, TypeError):
        raise PriceError("Yahoo 沒有這檔股票的資料") from None
    price = _num(meta.get("regularMarketPrice"))
    if price is None:
        raise PriceError("Yahoo 沒有提供價格")
    at = None
    if meta.get("regularMarketTime"):
        try:
            at = datetime.fromtimestamp(int(meta["regularMarketTime"])).strftime("%Y-%m-%dT%H:%M:%S")
        except (ValueError, OSError, OverflowError):
            at = None
    return {"ok": True, "price": price, "prev_close": _num(meta.get("chartPreviousClose") or meta.get("previousClose")),
            "at": at, "source": "yahoo", "name": meta.get("longName") or meta.get("shortName") or "", "note": "", "error": None}


def parse_stooq(text):
    rows = list(csv.DictReader(io.StringIO(text.strip())))
    if not rows:
        raise PriceError("Stooq 沒有資料")
    r = rows[0]
    price = _num(r.get("Close"))
    if price is None:
        raise PriceError("Stooq 沒有這檔股票的資料")
    at = None
    try:
        d, t = r.get("Date") or "", r.get("Time") or "00:00:00"
        at = datetime.strptime(f"{d} {t}", "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%dT%H:%M:%S")
    except ValueError:
        pass
    return {"ok": True, "price": price, "prev_close": None, "at": at, "source": "stooq", "name": "", "note": "", "error": None}


def parse_sinotrade(html, symbol, reference):
    """The first number that follows the stock code on the page and lies within 20% of `reference`.
    Without a reference price a number cannot be told apart from a volume or a change, so nothing is guessed."""
    if not reference:
        raise PriceError("永豐頁面無法判斷價格（還沒有任何參考價）")
    toks = bankfetch.tokens_of(html)
    for i, tok in enumerate(toks):
        if (tok.split() or [""])[0] != symbol:
            continue
        for t in toks[i + 1:i + 12]:
            v = _num(t)
            if v and re.match(r"^[\d,]+(\.\d+)?$", t) and 0.8 < v / reference < 1.2:
                return {"ok": True, "price": v, "prev_close": None, "at": None, "source": "sinotrade", "name": "",
                        "note": "", "error": None}
    raise PriceError("永豐頁面裡找不到這檔股票的價格（可能需要登入，或網站改版）")


# ---------------------------------------------------------------- network
_RELAXED_HOSTS = ("twse.com.tw", "tpex.org.tw")      # the exchanges' certificates lack a "Subject Key Identifier"


def tls_context(url=""):
    """Normal certificate and host-name checking. For the two Taiwanese exchanges only, Python 3.13+'s extra-strict X.509 rule is
    switched off: their certificates miss a field that rule insists on, so every connection fails with "Missing Subject Key Identifier"."""
    ctx = ssl.create_default_context()
    host = (urlparse(url).hostname or "").lower()
    if any(host == h or host.endswith("." + h) for h in _RELAXED_HOSTS) and hasattr(ssl, "VERIFY_X509_STRICT"):
        ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
    return ctx


def describe_net_error(e):
    """(message for the person, is_offline) for an exception raised while downloading."""
    if isinstance(e, urllib.error.HTTPError):
        return f"網站拒絕了這次讀取（HTTP {e.code}）", False
    reason = getattr(e, "reason", e)
    if isinstance(reason, ssl.SSLError):
        return f"憑證驗證失敗（{reason}）", False
    if isinstance(reason, (socket.gaierror, ConnectionError)) or isinstance(e, ConnectionError):
        return "連不上網路", True
    if isinstance(reason, (TimeoutError, socket.timeout)) or isinstance(e, (TimeoutError, socket.timeout)):
        return "連線逾時（網站沒有回應）", True
    return f"連不上網站（{type(reason).__name__}: {reason}）", False


def _opener():
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()),
                                       urllib.request.HTTPSHandler(context=tls_context("https://mis.twse.com.tw/")))


def _get(url, opener=None, timeout=10, headers=None):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "zh-TW,zh;q=0.9", **(headers or {})})
    with (opener.open(req, timeout=timeout) if opener else urllib.request.urlopen(req, timeout=timeout, context=tls_context(url))) as r:
        return r.read(2_000_000).decode("utf-8", "replace")


def fetch_twse(symbols):
    """-> {symbol: result} for the symbols the exchange answered (listed `tse_` and OTC `otc_` both asked)."""
    op = _opener()
    try:
        _get("https://mis.twse.com.tw/stock/index.jsp", op)          # the service wants the cookie of its own page
    except OSError:
        pass
    chans = "|".join(f"{ex}_{s}.tw" for s in symbols for ex in ("tse", "otc"))
    ts = int(datetime.now().timestamp() * 1000)
    text = _get(f"https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch={chans}&json=1&delay=0&_={ts}", op,
                headers={"Referer": "https://mis.twse.com.tw/stock/index.jsp"})
    return parse_twse(text)


def fetch_yahoo(symbol, market):
    names = [symbol] if market == "US" else [f"{symbol}.TW", f"{symbol}.TWO"]
    err = None
    for n in names:
        try:
            return parse_yahoo(_get(f"https://query1.finance.yahoo.com/v8/finance/chart/{n}?interval=1d&range=5d"))
        except PriceError as e:
            err = e
        except OSError:
            continue
    raise err or PriceError("連不上 Yahoo")


def fetch_stooq(symbol):
    return parse_stooq(_get(f"https://stooq.com/q/l/?s={symbol.lower()}.us&f=sd2t2ohlcv&h&e=csv"))


def fetch_sinotrade(symbol, reference):
    problems = []
    for getter in (bankfetch.http_get, bankfetch.browser_get):
        try:
            return parse_sinotrade(getter(SINOTRADE_URL), symbol, reference)
        except (PriceError, bankfetch.FetchError) as e:
            problems.append(str(e))
        except Exception as e:
            problems.append("連不上網站" if isinstance(e, OSError) else f"讀取失敗（{type(e).__name__}）")
    raise PriceError(problems[-1] if problems else "讀不到價格")


def _fail(sym, msg):
    return {"symbol": sym, "ok": False, "price": None, "prev_close": None, "at": None, "source": None,
            "name": "", "note": "", "error": msg}


def _explain(e):
    if isinstance(e, PriceError):
        return str(e)
    if isinstance(e, OSError):
        msg, offline = describe_net_error(e)
        return "連不上網站（請確認有網路）" if offline else msg
    return f"讀取失敗（{type(e).__name__}）"


def fetch_prices(items, references=None):
    """items: [{"symbol","market"}], references: {symbol: last known price}. Never raises; one entry per symbol."""
    references = references or {}
    items = [i for i in items if i.get("symbol")]
    out, tw = {}, [i["symbol"] for i in items if i["market"] == "TW"]
    twse, twse_err = {}, None
    if tw:
        try:
            twse = fetch_twse(tw)
        except Exception as e:
            twse_err = _explain(e)

    def one(it):
        sym, market = it["symbol"], it["market"]
        problems = []
        if market == "TW":
            if sym in twse:
                return twse[sym]
            problems.append(twse_err or "證交所沒有這檔的報價")
            steps = [lambda: fetch_yahoo(sym, "TW"), lambda: fetch_sinotrade(sym, references.get(sym))]
        else:
            steps = [lambda: fetch_yahoo(sym, "US"), lambda: fetch_stooq(sym)]
        for step in steps:
            try:
                r = step()
                r["symbol"] = sym
                return r
            except Exception as e:
                problems.append(_explain(e))
        return _fail(sym, problems[-1] if problems else "讀不到價格")

    if items:
        for it, r in zip(items, pool.pmap(one, items, 8)):
            out[it["symbol"]] = r
    return out
