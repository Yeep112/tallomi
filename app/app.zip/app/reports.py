"""Report data for the charts (port of the notebook's pie / bar / line / balance charts).

Everything is converted to the base currency with the *current* rate table.
Balance adjustments are never counted as income or expense; transfers only when the "count transfers" setting is on.
"""
import calendar
from bisect import bisect_right
from datetime import date, datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

from . import money

NO_NOTE = "(無備註)"
NO_CATEGORY = "未分類"
NO_TAG = "(沒有標籤)"
OTHER = "其他"


def _period_filter(year, month):
    if month:
        prefix = f"{year:04d}-{month:02d}"
    else:
        prefix = f"{year:04d}"
    return lambda t: t.startswith(prefix)


def _round_base(v: Decimal, base: str) -> float:
    return float(v.quantize(Decimal(1).scaleb(-money.exponent(base)), rounding=ROUND_HALF_UP))


def _uniq(seq, limit):
    out = list(dict.fromkeys(s for s in seq if s))
    return out[:limit] + (["…"] if len(out) > limit else [])


def breakdown(book, conn, year, month=None, group_by="category", max_slices=8):
    base = book.base_currency(conn)
    rates = book.get_rates(conn)
    rows, _, accts = book.ledger(conn)
    inside = _period_filter(year, month)
    with_tr = book.count_transfers(conn)
    missing = set()
    groups = {"income": {}, "expense": {}}
    real = {"income": Decimal(0), "expense": Decimal(0)}           # true totals: an entry with two tags is in two groups but counted once here
    budget_spent = {}                                              # category -> what counts against its budget (no transfers, no "not in budget" entries)
    for r in book.flows(rows, accts, with_tr, book.tags_map(conn) if group_by == "tag" else None):
        if not inside(r["time"]):
            continue
        ccy = r["ccy"]
        if ccy not in rates:
            missing.add(ccy)
            continue
        if group_by == "note":
            labels = [r["note"] or NO_NOTE]
        elif group_by == "tag":
            labels = r["tags"] or [NO_TAG]
        else:
            labels = [r["category"] or NO_CATEGORY]
        v = money.to_major(r["minor"], ccy) * rates[ccy]
        real[r["type"]] += v
        if group_by == "category" and r["type"] == "expense" and not r.get("transfer") and not r.get("no_budget"):
            budget_spent[labels[0]] = budget_spent.get(labels[0], Decimal(0)) + v
        for label in labels:
            g = groups[r["type"]].setdefault(label, {"label": label, "total": Decimal(0), "count": 0,
                                                     "accounts": [], "notes": []})
            g["total"] += v
            g["count"] += 1
            g["accounts"].append(r["account"])
            g["notes"].append(r["note"])

    def finish(d, kind):
        items = sorted(d.values(), key=lambda g: g["total"], reverse=True)
        if len(items) > max_slices:
            head, tail = items[:max_slices - 1], items[max_slices - 1:]
            other = {"label": OTHER, "total": sum((g["total"] for g in tail), Decimal(0)),
                     "count": sum(g["count"] for g in tail),
                     "accounts": [a for g in tail for a in g["accounts"]],
                     "notes": [n for g in tail for n in g["notes"]]}
            items = head + [other]
        total = real[kind] if group_by == "tag" else sum((g["total"] for g in items), Decimal(0))
        return {"total": _round_base(total, base),
                "groups": [{"label": g["label"], "total": _round_base(g["total"], base), "count": g["count"],
                            "accounts": _uniq(g["accounts"], 6), "notes": _uniq(g["notes"], 6)} for g in items]}

    return {"base": base, "year": year, "month": month, "group_by": group_by, "with_transfers": with_tr,
            "income": finish(groups["income"], "income"), "expense": finish(groups["expense"], "expense"),
            "budget_spent": {k: _round_base(v, base) for k, v in budget_spent.items()},
            "missing_rates": sorted(missing)}


def trend(book, conn, year, month=None):
    base = book.base_currency(conn)
    rates = book.get_rates(conn)
    rows, _, accts = book.ledger(conn)
    inside = _period_filter(year, month)
    if month:
        n = calendar.monthrange(year, month)[1]
        labels = [f"{year:04d}-{month:02d}-{d:02d}" for d in range(1, n + 1)]
        key = lambda t: t[:10]
    else:
        labels = [f"{year:04d}-{m:02d}" for m in range(1, 13)]
        key = lambda t: t[:7]
    inc = {l: Decimal(0) for l in labels}
    exp = {l: Decimal(0) for l in labels}
    missing = set()
    with_tr = book.count_transfers(conn)
    for r in book.flows(rows, accts, with_tr):
        if not inside(r["time"]):
            continue
        ccy = r["ccy"]
        if ccy not in rates:
            missing.add(ccy)
            continue
        v = money.to_major(r["minor"], ccy) * rates[ccy]
        (inc if r["type"] == "income" else exp)[key(r["time"])] += v
    return {"base": base, "labels": labels, "with_transfers": with_tr,
            "income": [_round_base(inc[l], base) for l in labels],
            "expense": [_round_base(exp[l], base) for l in labels],
            "missing_rates": sorted(missing)}


def balance_series(book, conn, accounts, year=None, month=None):
    """Daily end-of-day balances. accounts: list of account ids and/or 'total'."""
    base = book.base_currency(conn)
    rates = book.get_rates(conn)
    rows, _, accts = book.ledger(conn, snapshots=True)
    if not rows:
        return {"base": base, "labels": [], "series": [], "missing_rates": []}
    last_snap_by_day = {}
    for r in rows:
        last_snap_by_day[r["time"][:10]] = r["snap"]
    first = date.fromisoformat(rows[0]["time"][:10])
    last = max(date.fromisoformat(rows[-1]["time"][:10]), date.today())
    days, d = [], first
    while d <= last:
        days.append(d)
        d += timedelta(days=1)
    # forward-fill
    opening = {i: a["opening_minor"] for i, a in accts.items()}
    snaps, cur = [], opening
    for day in days:
        cur = last_snap_by_day.get(day.isoformat(), cur)
        snaps.append(cur)
    keep = [i for i, day in enumerate(days)
            if (year is None or day.year == year) and (not month or day.month == month)]
    labels = [days[i].isoformat() for i in keep]
    missing = set()
    series = []
    for sel in accounts:
        if sel == "total":
            data = []
            for i in keep:
                tot = Decimal(0)
                for aid, a in accts.items():
                    if a["currency"] not in rates:
                        missing.add(a["currency"])
                        continue
                    tot += money.to_major(snaps[i][aid], a["currency"]) * rates[a["currency"]]
                data.append(_round_base(tot, base))
            series.append({"key": "total", "label": "總資產", "currency": base, "data": data})
        else:
            aid = int(sel)
            a = accts.get(aid)
            if not a:
                continue
            series.append({"key": aid, "label": a["name"], "currency": a["currency"],
                           "data": [money.from_minor(snaps[i][aid], a["currency"]) for i in keep]})
    return {"base": base, "labels": labels, "series": series, "missing_rates": sorted(missing)}


NETWORTH_POINTS = 120          # the chart never needs more than this many dots; a longer range is sampled every few days


def networth_series(book, conn, days=None):
    """Net worth day by day, rebuilt from the ledger (the line behind the overview's 淨資產 card).

    The parts follow the card exactly: a stock account counts at what was paid for it (that is the balance the book keeps),
    every other account is cash, and an account that is below zero is a debt. The last point is today's card.
    Only the exchange rates are not historical: the book keeps the *current* table, so any day that holds a foreign-currency
    account is valued with today's rate. `approx` says when that applies, so the screen can say so instead of pretending.

    days: how far back from today (or from the last transaction, if that is later); None / 0 = from the first transaction."""
    base = book.base_currency(conn)
    rates = book.get_rates(conn)
    q = Decimal(1).scaleb(-money.exponent(base))
    rows, _, accts = book.ledger(conn)
    stock = {r[0] for r in conn.execute("SELECT account_id FROM securities")}
    missing = sorted({a["currency"] for a in accts.values() if a["currency"] not in rates})

    holding = {}                                   # account id -> (part, value in base)
    tot = {"stocks": Decimal(0), "cash": Decimal(0), "debts": Decimal(0)}
    foreign = set()

    def put(aid, minor):
        old = holding.pop(aid, None)
        if old:
            tot[old[0]] -= old[1]
        ccy = accts[aid]["currency"]
        rate = rates.get(ccy)
        if rate is None:
            return                                  # no rate: left out, like the card, and listed in missing_rates
        if ccy != base and minor:
            foreign.add(ccy)
        v = (money.to_major(minor, ccy) * rate).quantize(q, rounding=ROUND_HALF_UP)
        if v < 0:
            part, v = "debts", -v
        else:
            part = "stocks" if aid in stock else "cash"
        holding[aid] = (part, v)
        tot[part] += v

    def now():
        return (tot["stocks"], tot["cash"], tot["debts"])

    for aid, a in accts.items():
        put(aid, a["opening_minor"])
    opening = now()
    ev_days, ev_vals = [], []                       # end-of-day totals, one entry per day that has a transaction
    cur = None
    for r in rows:
        day = r["time"][:10]
        if cur is not None and day != cur:
            ev_days.append(cur)
            ev_vals.append(now())
        cur = day
        put(r["account_id"], r["new_minor"])
        if r["type"] == "transfer":
            put(r["to_account_id"], r["to_new_minor"])
    if cur is not None:
        ev_days.append(cur)
        ev_vals.append(now())

    today = date.today()
    first = date.fromisoformat(ev_days[0]) if ev_days else today
    last = max(date.fromisoformat(ev_days[-1]), today) if ev_days else today
    start = first
    if days and days > 0:
        start = max(first, last - timedelta(days=int(days) - 1))
    n = (last - start).days + 1
    step = max(1, -(-n // NETWORTH_POINTS))
    picked = sorted(set(range(n - 1, -1, -step)))   # counted back from the last day, so the last dot is always today's card
    labels, net, gross, debts, stocks, cash = [], [], [], [], [], []
    for i in picked:
        day = (start + timedelta(days=i)).isoformat()
        k = bisect_right(ev_days, day)
        s, c, d = ev_vals[k - 1] if k else opening
        labels.append(day)
        stocks.append(_round_base(s, base))
        cash.append(_round_base(c, base))
        debts.append(_round_base(d, base))
        gross.append(_round_base(s + c, base))
        net.append(_round_base(s + c - d, base))
    return {"base": base, "labels": labels, "net": net, "gross": gross, "debts": debts, "stocks": stocks, "cash": cash,
            "approx": bool(foreign), "foreign": sorted(foreign), "missing_rates": missing,
            "first_day": first.isoformat(), "days": int(days or 0), "step": step}


# ------------------------------------------------------------------ one tag as a project (a trip, a renovation ...)
def _tag_name(book, conn, tag):
    """The tag as it is stored (case-insensitive match), or an error."""
    want = (tag or "").strip().lstrip("#").casefold()
    for t in book.tag_list(conn):
        if t["tag"].casefold() == want:
            return t["tag"]
    from .book import BookError
    raise BookError("找不到這個標籤", 404)


def tag_summary(book, conn, tag, max_days=400):
    name = _tag_name(book, conn, tag)
    key = name.casefold()
    base = book.base_currency(conn)
    rates = book.get_rates(conn)
    rows, _, accts = book.ledger(conn)
    tags = book.tags_map(conn)
    mine = [r for r in rows if key in {t.casefold() for t in tags.get(r["id"], [])}]
    kinds = {"income": 0, "expense": 0, "transfer": 0, "adjust": 0}
    for r in mine:
        kinds[r["type"]] += 1
    times = [r["time"] for r in mine]
    first, last = (min(times)[:10], max(times)[:10]) if times else (None, None)
    days = (date.fromisoformat(last) - date.fromisoformat(first)).days + 1 if first else 0
    bucket = (lambda t: t[:7]) if days > max_days else (lambda t: t[:10])
    labels = []
    if first:
        if days > max_days:
            y, m = int(first[:4]), int(first[5:7])
            while f"{y:04d}-{m:02d}" <= last[:7]:
                labels.append(f"{y:04d}-{m:02d}")
                y, m = (y + 1, 1) if m == 12 else (y, m + 1)
        else:
            d0 = date.fromisoformat(first)
            labels = [(d0 + timedelta(days=i)).isoformat() for i in range(days)]
    inc = {l: Decimal(0) for l in labels}
    exp = {l: Decimal(0) for l in labels}
    cats = {"income": {}, "expense": {}}
    total = {"income": Decimal(0), "expense": Decimal(0)}
    missing = set()
    for r in book.flows(rows, accts, book.count_transfers(conn), tags):
        if key not in {t.casefold() for t in r["tags"]}:
            continue
        ccy = r["ccy"]
        if ccy not in rates:
            missing.add(ccy)
            continue
        v = money.to_major(r["minor"], ccy) * rates[ccy]
        total[r["type"]] += v
        (inc if r["type"] == "income" else exp)[bucket(r["time"])] += v
        g = cats[r["type"]].setdefault(r["category"] or NO_CATEGORY, {"total": Decimal(0), "count": 0})
        g["total"] += v
        g["count"] += 1

    def groups(kind):
        items = sorted(cats[kind].items(), key=lambda kv: kv[1]["total"], reverse=True)
        return [{"label": k, "total": _round_base(g["total"], base), "count": g["count"]} for k, g in items]

    exp_vals = [_round_base(exp[l], base) for l in labels]
    run, cum = 0.0, []
    for v in exp_vals:
        run += v
        cum.append(round(run, 6))
    spent_days = len([v for v in exp_vals if v > 0])
    return {"base": base, "tag": name, "entries": len(mine), "kinds": kinds, "first": first, "last": last, "days": days,
            "bucket": "month" if days > max_days else "day", "with_transfers": book.count_transfers(conn),
            "income": _round_base(total["income"], base), "expense": _round_base(total["expense"], base),
            "net": _round_base(total["income"] - total["expense"], base),
            "avg_per_day": _round_base(total["expense"] / days, base) if days and not days > max_days else None,
            "spent_days": spent_days,
            "labels": labels, "daily_income": [_round_base(inc[l], base) for l in labels], "daily_expense": exp_vals, "cumulative_expense": cum,
            "expense_by_category": groups("expense"), "income_by_category": groups("income"),
            "missing_rates": sorted(missing)}


def tag_rows(book, conn, tag):
    """Every entry with this tag, oldest first, as CSV rows for reimbursement. Last two rows: totals in the base currency."""
    name = _tag_name(book, conn, tag)
    key = name.casefold()
    base = book.base_currency(conn)
    rates = book.get_rates(conn)
    rows, _, accts = book.ledger(conn)
    tags = book.tags_map(conn)
    receipts = book.receipts_map(conn)
    labels = {"income": "收入", "expense": "支出", "transfer": "轉帳", "adjust": "調整"}
    headers = ["日期時間", "類型", "類別", "備註", "帳戶", "轉入帳戶", "金額", "幣別", f"約合 {base}", "標籤", "收據照片數"]
    out, tot = [], {"income": Decimal(0), "expense": Decimal(0)}
    for r in rows:
        if key not in {t.casefold() for t in tags.get(r["id"], [])}:
            continue
        a = accts[r["account_id"]]
        ccy = a["currency"]
        major = money.to_major(r["amount_minor"], ccy)
        approx = ""
        if r["type"] in ("income", "expense") and ccy in rates:
            v = major * rates[ccy]
            tot[r["type"]] += v
            approx = _round_base(v, base)
        out.append([r["time"].replace("T", " ")[:19], labels[r["type"]], r["category"] if r["type"] in ("income", "expense") else "",
                    r["note"], a["name"], accts[r["to_account_id"]]["name"] if r["to_account_id"] else "",
                    float(major), ccy, approx, "、".join(tags.get(r["id"], [])), len(receipts.get(r["id"], []))])
    out.append([])
    out.append(["合計支出", "", "", "", "", "", "", "", _round_base(tot["expense"], base)])
    out.append(["合計收入", "", "", "", "", "", "", "", _round_base(tot["income"], base)])
    return name, headers, out


# ------------------------------------------------------------------ this month against last month and last year
def parse_months(raw):
    """'2026-09,2026-11' (or a list) -> sorted unique [(2026, 9), (2026, 11)]; 2 to 8 months."""
    import re
    from .book import BookError
    items = raw if isinstance(raw, (list, tuple)) else str(raw or "").split(",")
    out = set()
    for it in items:
        it = str(it).strip()
        if not it:
            continue
        m = re.fullmatch(r"(\d{4})-(\d{1,2})", it)
        if not m or not 1 <= int(m.group(2)) <= 12 or not 1970 <= int(m.group(1)) <= 2200:
            raise BookError(f"月份格式不正確：{it}（要像 2026-09）")
        out.add((int(m.group(1)), int(m.group(2))))
    if not 2 <= len(out) <= 8:
        raise BookError("請選 2 到 8 個月份來比較")
    return sorted(out)


def parse_years(raw):
    """'2024,2026' (or a list) -> sorted unique [2024, 2026]; 2 to 8 years."""
    import re
    from .book import BookError
    items = raw if isinstance(raw, (list, tuple)) else str(raw or "").split(",")
    out = set()
    for it in items:
        it = str(it).strip()
        if not it:
            continue
        if not re.fullmatch(r"\d{4}", it) or not 1970 <= int(it) <= 2200:
            raise BookError(f"年份格式不正確：{it}（要像 2026）")
        out.add(int(it))
    if not 2 <= len(out) <= 8:
        raise BookError("請選 2 到 8 個年份來比較")
    return sorted(out)


def compare(book, conn, year, month=None, kind="expense", months=None, years=None):
    """Per category: this period, the one before it (previous month, or previous year when `month` is empty) and,
    for a month, the same month a year ago. With `months` (a hand-picked list) every chosen month gets its own column,
    and with `years` every chosen year does."""
    if kind not in ("expense", "income"):
        kind = "expense"
    base = book.base_currency(conn)
    rates = book.get_rates(conn)
    rows, _, accts = book.ledger(conn)
    if years:
        periods = [(f"y{i}", y, None) for i, y in enumerate(parse_years(years))]
        label = lambda y, m: f"{y:04d}"
    elif months:
        picked = parse_months(months)
        periods = [(f"m{i}", y, m) for i, (y, m) in enumerate(picked)]
        label = lambda y, m: f"{y:04d}-{m:02d}"
    elif month:
        py, pm = (year - 1, 12) if month == 1 else (year, month - 1)
        periods = [("cur", year, month), ("prev", py, pm), ("yoy", year - 1, month)]
        label = lambda y, m: f"{y:04d}-{m:02d}"
    else:
        periods = [("cur", year, None), ("prev", year - 1, None)]
        label = lambda y, m: f"{y:04d}"
    checks = {k: (_period_filter(y, m), label(y, m)) for k, y, m in periods}
    cats, total, missing = {}, {k: Decimal(0) for k in checks}, set()
    for r in book.flows(rows, accts, book.count_transfers(conn)):
        if r["type"] != kind:
            continue
        hit = [k for k, (f, _) in checks.items() if f(r["time"])]
        if not hit:
            continue
        ccy = r["ccy"]
        if ccy not in rates:
            missing.add(ccy)
            continue
        v = money.to_major(r["minor"], ccy) * rates[ccy]
        g = cats.setdefault(r["category"] or NO_CATEGORY, {k: Decimal(0) for k in checks})
        for k in hit:
            g[k] += v
            total[k] += v
    if months or years:
        items = sorted(cats.items(), key=lambda kv: (sum(kv[1].values()), kv[0]), reverse=True)
    else:
        items = sorted(cats.items(), key=lambda kv: (kv[1]["cur"], kv[1]["prev"]), reverse=True)
    return {"base": base, "kind": kind, "year": year, "month": month or 0, "custom": bool(months or years),
            "periods": [{"key": k, "label": checks[k][1]} for k, _, _ in periods],
            "totals": {k: _round_base(v, base) for k, v in total.items()},
            "rows": [{"category": c, **{k: _round_base(v, base) for k, v in g.items()}} for c, g in items],
            "missing_rates": sorted(missing)}
