"""Using Tallomi from a phone: the computer stays the only place the data lives.

The phone reaches the program through the owner's private Tailscale network (`tailscale serve` hands the requests to the
program on this computer, over HTTPS). Nothing is opened to the public internet. On top of that every phone has to be
paired once:

  1. On the computer (Settings -> 手機連線) press "產生配對碼": an 8-digit code, valid 5 minutes, usable once.
  2. On the phone open the address and type the code. The phone gets a long random cookie; only its hash is stored here.
  3. A paired phone can be removed again in Settings at any time.

Requests that come straight from this computer (the desktop window) never need any of this.
"""
import hashlib
import ipaddress
import secrets
import threading
import time
from datetime import datetime

COOKIE = "pw_dev"
CODE_TTL = 300             # seconds a pairing code stays valid
MAX_WRONG = 5              # wrong codes allowed before the code is thrown away
COOKIE_DAYS = 180


def _hash(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _now():
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


class PairError(Exception):
    pass


class Remote:
    def __init__(self, book):
        self.book = book
        self._lock = threading.Lock()
        self._code = None            # {"code","expires","wrong"}
        self._last_try = 0.0
        self._seen = {}              # device id -> monotonic time of the last last_seen update

    # ------------------------------------------------------------ settings
    def enabled(self):
        with self.book.session() as c:
            return self.book.get_setting(c, "remote_enabled", "0") == "1"

    def set_enabled(self, on):
        with self.book.session() as c:
            self.book.set_setting(c, "remote_enabled", "1" if on else "0")
        if not on:
            self._code = None

    def url(self):
        with self.book.session() as c:
            return self.book.get_setting(c, "remote_url", "")

    def set_url(self, url):
        url = (url or "").strip()
        if url and not url.lower().startswith(("https://", "http://")):
            url = "https://" + url
        if len(url) > 300:
            raise ValueError("網址太長")
        with self.book.session() as c:
            self.book.set_setting(c, "remote_url", url.rstrip("/"))

    def allowed_host(self, host):
        """Which Host headers a paired phone may use: a Tailscale name / address, or the address typed in Settings."""
        host = (host or "").strip("[]").lower()
        if not host:
            return False
        if host.endswith(".ts.net"):
            return True
        try:
            ip = ipaddress.ip_address(host)
            return ip in ipaddress.ip_network("100.64.0.0/10") or ip in ipaddress.ip_network("fd7a:115c:a1e0::/48")
        except ValueError:
            pass
        url = self.url()
        return bool(url) and host == (url.split("://", 1)[-1].split("/")[0].rsplit(":", 1)[0]).strip("[]").lower()

    # ------------------------------------------------------------ pairing
    def new_code(self):
        with self._lock:
            code = f"{secrets.randbelow(10 ** 8):08d}"
            self._code = {"code": code, "expires": time.time() + CODE_TTL, "wrong": 0}
            return {"code": code, "expires_in": CODE_TTL}

    def code_state(self):
        c = self._code
        if not c or c["expires"] < time.time():
            return None
        return {"expires_in": int(c["expires"] - time.time())}

    def pair(self, code, name, agent):
        """-> the cookie value for the new phone. Raises PairError with a message for the person."""
        with self._lock:
            now = time.time()
            if now - self._last_try < 1:
                raise PairError("太快了，請稍等一秒再試")
            self._last_try = now
            c = self._code
            if not c or c["expires"] < now:
                self._code = None
                raise PairError("沒有有效的配對碼。請在電腦上開啟「設定 → 手機連線」按「產生配對碼」。")
            digits = "".join(ch for ch in str(code or "") if ch.isdigit())
            if not secrets.compare_digest(digits, c["code"]):
                c["wrong"] += 1
                if c["wrong"] >= MAX_WRONG:
                    self._code = None
                    raise PairError("輸錯太多次，這組配對碼已作廢。請在電腦上重新產生。")
                raise PairError(f"配對碼不對（還能試 {MAX_WRONG - c['wrong']} 次）")
            self._code = None                                  # one use only
        token = secrets.token_urlsafe(32)
        name = (name or "").strip()[:40] or "手機"
        with self.book.session() as c2:
            c2.execute("INSERT INTO devices(name,token_hash,created_at,last_seen,agent) VALUES(?,?,?,?,?)",
                       (name, _hash(token), _now(), _now(), (agent or "")[:200]))
        return token

    # ------------------------------------------------------------ devices
    def check(self, token):
        """-> device id when the cookie belongs to a paired phone."""
        if not token or len(token) > 200:
            return None
        with self.book.session() as c:
            r = c.execute("SELECT id FROM devices WHERE token_hash=?", (_hash(token),)).fetchone()
        if not r:
            return None
        did, now = r["id"], time.monotonic()
        if now - self._seen.get(did, -1e9) > 120:              # keep "last used" fresh without writing on every request
            self._seen[did] = now
            with self.book.session(quiet=True) as c:              # (not a change the other windows need to hear about)
                c.execute("UPDATE devices SET last_seen=? WHERE id=?", (_now(), did))
        return did

    def devices(self):
        with self.book.session() as c:
            return [dict(r) for r in c.execute("SELECT id,name,created_at,last_seen,agent FROM devices ORDER BY id")]

    def rename(self, did, name):
        with self.book.session() as c:
            c.execute("UPDATE devices SET name=? WHERE id=?", ((name or "").strip()[:40] or "手機", did))

    def revoke(self, did=None):
        with self.book.session() as c:
            if did is None:
                c.execute("DELETE FROM devices")
            else:
                c.execute("DELETE FROM devices WHERE id=?", (did,))

    def info(self):
        return {"enabled": self.enabled(), "url": self.url(), "code": self.code_state(), "devices": self.devices()}
