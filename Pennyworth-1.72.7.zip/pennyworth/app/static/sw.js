'use strict';
/* Tallomi service worker. Keeps the program's own files (not your data) so the app opens instantly on the phone,
   and shows a clear message when the computer cannot be reached. Data is never cached: it only lives on the computer. */
const CACHE = 'pennyworth-shell-__VERSION__';       // the server fills in the program version, so an upgrade starts with a clean copy
const ENGINE_CACHE = 'tallomi-engine';            // 1.63.0: the runtime for the phone's own copy of the program (downloaded once from the public phone site; see app-local.js)
const SHELL_CACHE = 'tallomi-offline';             // the page itself, kept only while offline mode is on (see app-offline.js); data stays in IndexedDB
const SHELL = ['/static/style.css', '/static/theme.js', '/static/app-diag.js', '/static/app-prefetch.js', '/static/app.js', '/static/app-categories.js', '/static/app-extras.js', '/static/app-tags.js', '/static/app-compare.js', '/static/app-periods.js', '/static/app-list.js', '/static/app-advance.js', '/static/app-tiles.js', '/static/app-calendar.js', '/static/app-exchange.js', '/static/app-emoji.js', '/static/app-icons.js', '/static/app-market.js', '/static/app-invest.js', '/static/app-dividend.js', '/static/app-goals.js', '/static/app-phone.js', '/static/app-onphone.js', '/static/app-import.js', '/static/app-onboard.js', '/static/app-lock.js', '/static/app-mode.js', '/static/app-update.js', '/static/app-offline.js', '/static/app-local.js', '/static/local-worker.js', '/static/app-recurring.js', '/static/app-rules.js', '/static/app-palette.js', '/static/app-listkeys.js', '/static/app-balance.js', '/static/app-bills.js', '/static/app-networth.js', '/static/app-home.js', '/static/app-quick.js', '/static/vendor/qrcode.js', '/static/pair.js',
  '/static/vendor/chart.umd.js', '/static/icon-192.png', '/static/icon-512.png', '/static/apple-touch-icon.png', '/static/manifest.webmanifest', ...__EMOJI__];      // __EMOJI__: every bundled icon picture, so icons also show when the computer cannot be reached

// Keep every file of the program (and every icon picture) on the phone. Only the ones still missing are fetched, a few at a time: asking for 300 files at once
// over the Tailscale link used to leave some out, and a missing icon picture shows as a "?" when the computer is off. (c.add refuses a 502 from Tailscale too.)
async function warmShell() {
  const c = await caches.open(CACHE), todo = [];
  for (const u of SHELL) if (!(await c.match(u, { ignoreSearch: true }))) todo.push(u);
  for (let i = 0; i < todo.length; i += 8) await Promise.allSettled(todo.slice(i, i + 8).map((u) => c.add(u)));
}
self.addEventListener('install', (e) => { self.skipWaiting(); e.waitUntil(warmShell()); });
self.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'warm') e.waitUntil(warmShell());
  if (e.data && e.data.type === 'remote-page') e.waitUntil(remotePage(!!e.data.on));
  if (e.data && e.data.type === 'forget-page') { pageGen += 1; e.waitUntil(caches.open(CACHE).then((c) => c.delete(PAGE))); }      // a newer build on the computer (reloadForUpdate)
});

// 1.72.7 — the page itself kept on a phone connected to the computer (Tailscale), so opening Tallomi does not wait for the computer to send it (~1.4 s).
// The kept page is opened at once and a fresh one is fetched in the background for next time. It is kept in the cache of this program version only, so
// an update of the program (a new sw.js) starts again from the computer's page; a page that finds the computer runs a newer build reloads (revWatch) and
// forgets the kept page first (reloadForUpdate). The page itself turns this on once it knows it is a phone on the computer (never the computer's own window).
// The page holds no data, only the program; the data still comes from the computer (or, for the first moment, from last time's answers, app-prefetch.js).
const PAGE = '/__page', REMOTE = '/__remote';
let pageGen = 0;                                       // a copy asked for before the page was told to forget it is not kept (it may be the old build)
async function keepPage(r, gen = pageGen) {
  const c = await caches.open(CACHE);
  if (gen !== pageGen || !(await c.match(REMOTE)) || !r || !r.ok || r.redirected || !/text\/html/.test(r.headers.get('Content-Type') || '')) return;
  const text = (await r.text()).replace('<head>', `<head><meta name="pw-kept" content="${Date.now()}">`);      // so the page knows it came from the phone (診斷紀錄)
  if (gen === pageGen) await c.put(PAGE, new Response(text, { status: 200, headers: r.headers }));
}
async function keptPage() {
  const c = await caches.open(CACHE);
  return (await c.match(REMOTE)) ? c.match(PAGE) : null;
}
// A fresh copy for next time. Sent to pairing (/pair) or refused: the kept page is forgotten. The computer away (Tailscale answers 502): the kept page stays.
async function freshPage() {
  const gen = pageGen;
  try {
    const r = await fetch('/', { cache: 'no-store', credentials: 'same-origin' });
    if (r.redirected || r.status === 401 || r.status === 403) { await (await caches.open(CACHE)).delete(PAGE); return; }
    await keepPage(r, gen);
  } catch { /* computer away: keep what we have */ }
}
async function remotePage(on) {
  const c = await caches.open(CACHE);
  if (!on) { await c.delete(REMOTE); await c.delete(PAGE); return; }
  if (!(await c.match(REMOTE))) await c.put(REMOTE, new Response('1'));
  if (!(await c.match(PAGE))) await freshPage();
}
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE && k !== SHELL_CACHE && k !== ENGINE_CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

const OFFLINE = `<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Tallomi</title><body style="font:16px system-ui,sans-serif;margin:0;padding:48px 28px;background:#16233A;color:#fff;line-height:1.7">
<h1 style="font-size:22px;margin:0 0 12px">連不上你的電腦</h1>
<p>Tallomi 的資料放在你家的電腦裡。請確認：</p>
<ul><li>電腦已開機，<b>Tallomi 正在執行</b>（在電腦上開啟 Tallomi 即可）</li><li>電腦與手機都開著 Tailscale 並已登入</li><li>手機有網路</li></ul>
<p id="s" style="opacity:.8">電腦回來後會自動連線，不用重新開啟。</p>
<p><button onclick="location.reload()" style="font:inherit;padding:10px 20px;border-radius:8px;border:0">重試</button></p>
<script>var t0=Date.now();
setInterval(function(){var s=Math.floor((Date.now()-t0)/1000);document.getElementById('s').textContent='電腦回來後會自動連線，不用重新開啟（已等待 '+Math.floor(s/60)+' 分 '+(s%60)+' 秒）';},1000);
setInterval(function(){fetch('/api/ping',{cache:'no-store'}).then(function(r){if(r.status<500)location.reload();}).catch(function(){});},4000);
</script></body></html>`;

// A page or file from the computer, but a computer that does not answer must not keep the phone waiting: with a kept copy at hand, give up after `ms`.
const raceKept = (req, ms, kept) => new Promise((resolve, reject) => {
  let done = false;
  const t = setTimeout(() => { if (!done) { done = true; kept().then((k) => (k ? resolve(k) : fetch(req).then(resolve, reject)), () => fetch(req).then(resolve, reject)); } }, ms);
  fetch(req).then((r) => { if (!done) { done = true; clearTimeout(t); resolve(r); } }, (e) => { if (!done) { done = true; clearTimeout(t); reject(e); } });
});
const keptShell = () => caches.open(SHELL_CACHE).then((c) => c.match('/__shell')).catch(() => null);
// The page leaves a note when the computer was away a moment ago (app-local.js): a start-up then waits only briefly for it before opening the kept page.
const awayFresh = () => caches.open(SHELL_CACHE).then((c) => c.match('/__away')).then((r) => (r ? r.text() : '')).then((t) => { const n = Number(t); return !!n && Date.now() - n < 10 * 60 * 1000; }).catch(() => false);

self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method === 'GET' && url.origin !== location.origin && /\/app\/(pyodide|wheels)\//.test(url.pathname)) {       // the runtime of the phone's own copy: the saved one first
    e.respondWith(caches.open(ENGINE_CACHE).then(async (c) => {
      const hit = await c.match(url.href, { ignoreVary: true });
      if (hit) return hit;
      const r = await fetch(req);
      if (r.ok) c.put(url.href, r.clone());
      return r;
    }));
    return;
  }
  if (req.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;     // data always goes to the computer
  if (req.mode === 'navigate') {
    const offline = async () => {
      if (url.pathname === '/' || url.pathname === '/index.html') {      // offline mode on: open the kept copy of the app, it shows the data kept on the phone
        const kept = await keptShell();
        if (kept) return kept;
      }
      return new Response(OFFLINE, { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    };
    // "Bad gateway / unavailable" comes from Tailscale itself when Tallomi is not running on the computer: show the same message instead of a blank page
    const home = url.pathname === '/' || url.pathname === '/index.html';
    const get = () => (home ? awayFresh().then((away) => raceKept(req, away ? 700 : 3000, keptShell)) : fetch(req));        // with a kept copy, a computer that is silent for 3 s counts as away (1.63.0); 0.7 s right after it was found away
    if (home && !url.search) {                         // 1.72.7: a phone on the computer opens its kept page at once
      e.respondWith((async () => {
        try {                                          // (the page turns this off itself in offline mode and with 電腦沒開也能用: those open their own copy, below.
          const kept = await keptPage();               //  The "tallomi-offline" cache cannot tell: opening it, as awayFresh/keptShell do, creates it.)
          if (kept) { e.waitUntil(freshPage()); return kept; }
        } catch { /* no cache: from the computer as before */ }
        return homeFromComputer();
      })());
      return;
    }
    function homeFromComputer() {
      const gen0 = pageGen;
      return get().then(async (r) => {
        if (r.status === 502 || r.status === 503 || r.status === 504) return offline();
        if (r.ok && !r.redirected && home && await caches.has(SHELL_CACHE)) {
          const copy = r.clone(); caches.open(SHELL_CACHE).then((c) => c.put('/__shell', copy));       // keep the kept copy as new as the program
        }
        if (home && r.ok && !r.redirected && !url.search) { const copy = r.clone(); keepPage(copy, gen0).catch(() => {}); }       // 1.72.7: and the phone's kept page (when turned on)
        return r;
      }).catch(offline);
    }
    e.respondWith(homeFromComputer());
    return;
  }
  if (url.pathname.startsWith('/static/')) {          // the program's files: always the newest from the computer; the saved copy is only for when it cannot be reached
    // (the page asks for them as "...js?v=<build>": the browser keeps those for good, so this fetch is usually answered on the phone itself;
    // the copies saved above are looked up without the "?v=" part too, because the first copy was saved under the plain name)
    const saved = () => caches.match(req).then((r) => r || caches.match(req, { ignoreSearch: true }));
    // "...?v=<build>" names exactly one version of the file: a copy kept under this very address IS the file, so it is used at once, without asking the computer
    // (which, over Tailscale, costs a round trip per file at every start, and a long wait for each of them when the computer does not answer).
    e.respondWith((async () => {
      if (url.search.startsWith('?v=')) { const hit = await caches.match(req); if (hit) return hit; }
      else if (/\.(png|svg|webp|jpe?g|ico|woff2?)$/.test(url.pathname)) { const hit = await saved(); if (hit) return hit; }       // pictures and fonts do not change within a version
      return raceKept(req, 4000, saved).then(async (r) => {
        if (r.status === 502 || r.status === 503 || r.status === 504) return (await saved()) || r;       // Tailscale answers "bad gateway" itself when Tallomi is not running: that is not the file
        if (r.ok && r.type !== 'cors') { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return r;
      }).catch(() => saved());
    })());
  }
});
