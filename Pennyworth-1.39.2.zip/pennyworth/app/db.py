"""SQLite schema, connection and backups."""
import re
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

SCHEMA_VERSION = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS client_ops (
    cid   TEXT PRIMARY KEY,
    tx_id INTEGER NOT NULL,
    at    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS accounts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL UNIQUE COLLATE NOCASE,
    currency      TEXT NOT NULL,
    opening_minor INTEGER NOT NULL DEFAULT 0,
    sort_order    INTEGER NOT NULL DEFAULT 0,
    archived      INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL,
    icon          TEXT NOT NULL DEFAULT '',            -- '' = picked automatically from the name
    color         TEXT NOT NULL DEFAULT ''             -- '' = automatic, else '#RRGGBB'
);
CREATE TABLE IF NOT EXISTS category_icons (
    category TEXT PRIMARY KEY,
    icon     TEXT NOT NULL DEFAULT '',                  -- emoji picked by the user; '' = automatic
    color    TEXT NOT NULL DEFAULT ''                   -- '#RRGGBB'; '' = automatic
);
CREATE TABLE IF NOT EXISTS categories (                 -- categories the user added by hand (so they exist before any entry uses them)
    name TEXT PRIMARY KEY,
    kind TEXT NOT NULL DEFAULT 'both'                   -- 'income' | 'expense' | 'both'
);
CREATE TABLE IF NOT EXISTS tx_tags (                    -- labels on entries, e.g. 日本旅行 (an entry can have several)
    tx_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    tag   TEXT NOT NULL,
    PRIMARY KEY (tx_id, tag)
);
CREATE INDEX IF NOT EXISTS idx_tag ON tx_tags(tag);
CREATE TABLE IF NOT EXISTS receipts (                   -- small photos (already shrunk by the screen) attached to an entry
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tx_id      INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    mime       TEXT NOT NULL,
    data       BLOB NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_receipt_tx ON receipts(tx_id);
CREATE TABLE IF NOT EXISTS budgets (                    -- monthly spending limit per category, in the base currency
    category TEXT PRIMARY KEY,
    amount TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS icon_library (               -- pictures the user uploaded, kept so they can be picked again
    icon     TEXT PRIMARY KEY,                          -- a small PNG as a data: URL
    added_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    time            TEXT NOT NULL,
    type            TEXT NOT NULL CHECK (type IN ('income','expense','transfer','adjust')),
    category        TEXT NOT NULL DEFAULT '',
    note            TEXT NOT NULL DEFAULT '',
    amount_minor    INTEGER NOT NULL,
    account_id      INTEGER NOT NULL REFERENCES accounts(id),
    to_account_id   INTEGER REFERENCES accounts(id),
    to_amount_minor INTEGER,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL,
    advance         TEXT NOT NULL DEFAULT '',          -- '' | 'friend' (paid for a friend) | 'claim' (paid first, to be reimbursed)
    counterparty    TEXT NOT NULL DEFAULT '',          -- the friend / the company or person who will pay it back
    no_budget       INTEGER NOT NULL DEFAULT 0,        -- 1 = not counted against the category budget
    no_stats        INTEGER NOT NULL DEFAULT 0,        -- 1 = not counted in the income / expense totals and reports
    settle_of       INTEGER,                           -- a repayment: the id of the advance it pays back
    written_off     INTEGER NOT NULL DEFAULT 0,        -- 1 = given up collecting (it then counts as a real expense)
    due_date        TEXT NOT NULL DEFAULT ''           -- advances: the day the money should be back (YYYY-MM-DD), or ''
);
CREATE INDEX IF NOT EXISTS idx_tx_time ON transactions(time, id);
CREATE INDEX IF NOT EXISTS idx_tx_account ON transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_tx_to_account ON transactions(to_account_id);
CREATE TABLE IF NOT EXISTS templates (                  -- quick templates: a favourite entry that fills the form with one tap
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    type         TEXT NOT NULL,
    category     TEXT NOT NULL DEFAULT '',
    note         TEXT NOT NULL DEFAULT '',
    amount       TEXT NOT NULL DEFAULT '',               -- decimal string, '' = ask every time
    account_id   INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
    to_account_id INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
    tags         TEXT NOT NULL DEFAULT '',
    advance      TEXT NOT NULL DEFAULT '',
    counterparty TEXT NOT NULL DEFAULT '',
    no_budget    INTEGER NOT NULL DEFAULT 0,
    no_stats     INTEGER NOT NULL DEFAULT 0,
    sort_order   INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS rates (
    currency   TEXT PRIMARY KEY,
    rate       TEXT NOT NULL,          -- 1 unit of currency = rate base units (decimal string)
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bank_rates (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    bank     TEXT NOT NULL,
    currency TEXT NOT NULL,
    side     TEXT NOT NULL CHECK (side IN ('buy','sell')),   -- buy: bank buys foreign cash from you; sell: bank sells it to you
    rate     TEXT NOT NULL,                                  -- base currency per 1 unit of `currency` (decimal string)
    at       TEXT NOT NULL,
    source   TEXT NOT NULL DEFAULT 'manual'
);
CREATE INDEX IF NOT EXISTS idx_bank_rates ON bank_rates(bank, currency, side, at);
CREATE TABLE IF NOT EXISTS securities (
    account_id INTEGER PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
    symbol     TEXT NOT NULL,
    name       TEXT NOT NULL DEFAULT '',
    market     TEXT NOT NULL CHECK (market IN ('TW','US')),
    currency   TEXT NOT NULL                                   -- currency the market quotes the price in
);
CREATE TABLE IF NOT EXISTS stock_trades (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id  INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,   -- the stock's own account
    tx_id       INTEGER REFERENCES transactions(id) ON DELETE CASCADE,        -- the transfer that moved the money (NULL = holding recorded without moving money)
    side        TEXT NOT NULL CHECK (side IN ('buy','sell')),
    time        TEXT NOT NULL,
    shares      TEXT NOT NULL,                                 -- decimal string, in shares (1 lot = 1000 shares)
    price       TEXT NOT NULL,                                 -- per share, in the quote currency
    fee         TEXT NOT NULL DEFAULT '0',                     -- quote currency
    tax         TEXT NOT NULL DEFAULT '0',                     -- quote currency (sell only)
    cost_minor  INTEGER NOT NULL,                              -- buy: cost put into the stock account; sell: net proceeds, both in the stock account's currency
    pay_account_id INTEGER REFERENCES accounts(id) ON DELETE SET NULL,        -- buy: paid from; sell: paid into
    pay_minor   INTEGER,                                       -- amount that left / entered that account, in its own currency
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_trades ON stock_trades(account_id, time, id);
CREATE TABLE IF NOT EXISTS stock_prices (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol     TEXT NOT NULL,
    price      TEXT NOT NULL,
    prev_close TEXT,
    at         TEXT NOT NULL,
    source     TEXT NOT NULL DEFAULT 'manual'
);
CREATE INDEX IF NOT EXISTS idx_stock_prices ON stock_prices(symbol, at);
CREATE TABLE IF NOT EXISTS devices (                            -- phones / tablets paired to use Tallomi from outside the computer
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,                           -- sha256 of the cookie value; the cookie itself is never stored
    created_at TEXT NOT NULL,
    last_seen  TEXT NOT NULL,
    agent      TEXT NOT NULL DEFAULT ''
);
"""


def connect(path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


REQUIRED_COLUMNS = {
    "settings": {"key", "value"},
    "accounts": {"id", "name", "currency", "opening_minor", "sort_order", "archived", "created_at"},
    "transactions": {"id", "time", "type", "category", "note", "amount_minor", "account_id",
                     "to_account_id", "to_amount_minor", "created_at", "updated_at"},
    "rates": {"currency", "rate", "updated_at"},
}


def set_aside_if_foreign(path: Path):
    """If `path` is not a Tallomi database (another program's file, an older layout,
    or a damaged file), rename it out of the way and return the new path. Never deletes."""
    path = Path(path)
    if not path.exists() or path.stat().st_size == 0:
        return None
    problem = None
    try:
        c = sqlite3.connect(str(path))
        try:
            tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            for table, cols in REQUIRED_COLUMNS.items():
                if table in tables:
                    have = {r[1] for r in c.execute(f'PRAGMA table_info("{table}")')}
                    if not cols <= have:
                        problem = f"table {table} has columns {sorted(have)}"
                        break
        finally:
            c.close()
    except sqlite3.DatabaseError as e:
        problem = f"unreadable: {e}"
    if problem is None:
        return None
    dest = path.with_name(f"pennyworth.incompatible-{datetime.now():%Y%m%d-%H%M%S}.db")
    path.replace(dest)
    return dest, problem


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    have = {r[1] for r in conn.execute('PRAGMA table_info("accounts")')}      # databases made before icons existed
    for col in ("icon", "color"):
        if col not in have:
            conn.execute(f"ALTER TABLE accounts ADD COLUMN {col} TEXT NOT NULL DEFAULT ''")
    have_tx = {r[1] for r in conn.execute('PRAGMA table_info("transactions")')}                 # books made before advances existed
    for col, ddl in (("advance", "TEXT NOT NULL DEFAULT ''"), ("counterparty", "TEXT NOT NULL DEFAULT ''"), ("no_budget", "INTEGER NOT NULL DEFAULT 0"),
                     ("no_stats", "INTEGER NOT NULL DEFAULT 0"), ("settle_of", "INTEGER"), ("written_off", "INTEGER NOT NULL DEFAULT 0"), ("due_date", "TEXT NOT NULL DEFAULT ''")):
        if col not in have_tx:
            conn.execute(f"ALTER TABLE transactions ADD COLUMN {col} {ddl}")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tx_settle ON transactions(settle_of)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tx_advance ON transactions(advance)")
    for tbl in ("accounts", "category_icons"):             # pictures already in use (uploaded before the library existed) belong in it
        conn.execute(f"INSERT OR IGNORE INTO icon_library(icon, added_at) SELECT DISTINCT icon, '2000-01-01T00:00:00' FROM {tbl} WHERE icon LIKE 'data:image/%'")
    conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")


BACKUP_RE = re.compile(r"^pennyworth-\d{8}-\d{6}[A-Za-z0-9_\-]*\.db$")
KEEP_BACKUPS = 30


def make_backup(db_path: Path, backup_dir: Path, reason: str = "") -> Path:
    """Consistent snapshot via SQLite's online backup API."""
    backup_dir.mkdir(parents=True, exist_ok=True)
    tag = re.sub(r"[^A-Za-z0-9_\-]", "", reason)[:30]
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = backup_dir / (f"pennyworth-{stamp}" + (f"-{tag}" if tag else "") + ".db")
    n = 1
    while dest.exists():  # two backups within the same second
        dest = backup_dir / (f"pennyworth-{stamp}" + (f"-{tag}" if tag else "") + f"_{n}.db")
        n += 1
    src = sqlite3.connect(str(db_path))
    dst = sqlite3.connect(str(dest))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    files = sorted(p for p in backup_dir.iterdir() if BACKUP_RE.match(p.name))
    for old in files[:-KEEP_BACKUPS]:
        try:
            old.unlink()
        except OSError:
            pass
    return dest


def is_valid_book(path: Path) -> bool:
    try:
        c = sqlite3.connect(str(path))
        try:
            ok = c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            names = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            return ok and {"accounts", "transactions", "settings", "rates"} <= names
        finally:
            c.close()
    except sqlite3.Error:
        return False


def replace_file(src: Path, dst: Path) -> None:
    tmp = dst.with_suffix(".restore.tmp")
    shutil.copyfile(src, tmp)
    tmp.replace(dst)
