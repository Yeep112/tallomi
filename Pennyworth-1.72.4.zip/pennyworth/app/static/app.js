'use strict';
/* Tallomi UI. No framework; every user-supplied string goes through textContent. */

// ------------------------------------------------------------------ helpers
const $ = (s, el = document) => el.querySelector(s);
const TYPE_LABEL = { income: '收入', expense: '支出', transfer: '轉帳', adjust: '調整' };
const PALETTE = ['#2E6F95', '#B08D3C', '#3E8E7E', '#8E5572', '#C0623F', '#5B7DB1', '#7A8B3C', '#A4506A', '#4C5C68', '#9C7A97'];
const OTHER_COLOR = '#9AA5B1';

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  let value;
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value') value = v;
    else if (k === 'checked' || k === 'selected' || k === 'disabled') el[k] = !!v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  const add = (k) => {
    if (k == null || k === false) return;
    if (Array.isArray(k)) k.forEach(add);
    else el.appendChild(k instanceof Node ? k : document.createTextNode(String(k)));
  };
  kids.forEach(add);
  if (value !== undefined) el.value = value;
  return el;
}

const digitsCache = {};
function digits(ccy) {
  if (!(ccy in digitsCache)) {
    try { digitsCache[ccy] = new Intl.NumberFormat('en', { style: 'currency', currency: ccy }).resolvedOptions().maximumFractionDigits; }
    catch { digitsCache[ccy] = 2; }
  }
  return digitsCache[ccy];
}
const NO_CENTS = new Set(['TWD']);   // TWD has a minor unit on paper, but nobody uses it: show cents only when present
const HIDDEN = '***';
function num(v, ccy, sign, force) {
  if (v == null) return '—';
  if (isHidden() && !force) return HIDDEN;
  const d = digits(ccy || 'TWD');
  const min = NO_CENTS.has(ccy) && Number.isInteger(v) ? 0 : d;
  return numFmt(min, d, sign).format(v).replace('-', '−');
}
// Building an Intl.NumberFormat is slow (tens of microseconds, several times that on a phone) and a page shows hundreds of amounts: one formatter per (digits, sign) is kept.
const numFmts = new Map();
function numFmt(min, max, sign, locale = 'zh-TW') {
  const k = `${locale}|${min}|${max}|${sign ? 1 : 0}`;
  let f = numFmts.get(k);
  if (!f) { f = new Intl.NumberFormat(locale, { minimumFractionDigits: min, maximumFractionDigits: max, ...(sign ? { signDisplay: 'exceptZero' } : {}) }); numFmts.set(k, f); }
  return f;
}
function money(v, ccy, { sign = false, tone = false, tag = true } = {}) {
  const cls = 'num' + (tone ? (v > 0 ? ' pos' : v < 0 ? ' neg' : '') : '');
  return h('span', { class: cls }, num(v, ccy, sign), tag ? h('span', { class: 'ccy' }, ccy) : null);
}
const pad = (n) => String(n).padStart(2, '0');
function nowLocal() { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; }
const shortTime = (t) => t.replace('T', ' ').slice(0, 16);
// A phone: a narrow screen, or an iPhone held sideways (short, wide, touch). Everything that is "phone layout" in style.css uses the same test.
const PHONE_Q = '(max-width: 720px), (max-height: 500px) and (orientation: landscape) and (pointer: coarse)';
const TX_PAGE = window.matchMedia(PHONE_Q).matches ? 40 : 100;      // a phone draws fewer rows at a time ("載入更多" adds the rest)
const onTouch = () => window.matchMedia('(pointer: coarse)').matches;      // finger instead of a mouse
const lsGet = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } };
const SVG_NS = 'http://www.w3.org/2000/svg';
function svg(...shapes) {
  const el = document.createElementNS(SVG_NS, 'svg');
  el.setAttribute('viewBox', '0 0 24 24'); el.setAttribute('aria-hidden', 'true');
  for (const [tag, attrs] of shapes) {
    const n = document.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    el.appendChild(n);
  }
  return el;
}
// A colour of the current theme (charts ask for several on every draw). The answer is kept until the theme's own inline style
// (see theme.js) or the page's classes change, so drawing a chart no longer forces a style lookup per colour.
const cssMemo = { key: null, vals: new Map() };
const css = (name) => {
  const el = document.documentElement, key = (el.getAttribute('style') || '') + '|' + el.className;
  if (cssMemo.key !== key) { cssMemo.key = key; cssMemo.vals.clear(); }
  let v = cssMemo.vals.get(name);
  if (v === undefined) { v = getComputedStyle(el).getPropertyValue(name).trim(); if (v) cssMemo.vals.set(name, v); }
  return v;
};

// With offline mode on (paired phone only) reads fall back to the copy kept on the phone and new entries wait in a queue; see app-offline.js.
async function api(method, path, body, isForm) {
  if (method === 'POST' && path === '/api/transactions' && !isForm && body && typeof body === 'object' && typeof outboxKeep === 'function' && !(typeof offlineOn === 'function' && offlineOn())) {
    const entry = outboxKeep({ ...body });                                // written down first (app-extras.js): an entry that was tapped survives the page being closed before the answer comes (a copy: the caller's own object stays as it was, so a second entry made from it is a new one)
    try { const r = await apiRoute(method, path, entry.body, isForm); outboxDone(entry); return r; }
    catch (e) { outboxDone(entry); throw e; }
  }
  return apiRoute(method, path, body, isForm);
}
async function apiRoute(method, path, body, isForm) {
  if (typeof offlineOn === 'function' && offlineOn()) return offlineApi(method, path, body, isForm);
  return typeof locGuard === 'function' ? locGuard(method, path, body, isForm) : apiNet(method, path, body, isForm);     // 1.63.0: with 電腦沒開也能用 on, a computer that does not answer is replaced by the phone's own copy (app-local.js)
}
// 1.62.0 — the same question asked twice at the same moment (the Settings page's status panel and its backup list both ask for the backups)
// is sent once; the second asker gets its own copy of the answer. Any change that starts clears the list, so nothing read before a change is reused after it.
const inflightGets = new Map();
async function apiNet(method, path, body, isForm) {
  if (method !== 'GET') { inflightGets.clear(); return apiNetGo(method, path, body, isForm); }
  const f = inflightGets.get(path);
  if (f) { pfNote(path); return f.then((d) => (d && typeof d === 'object' ? JSON.parse(JSON.stringify(d)) : d)); }
  const p = apiNetGo(method, path, body, isForm); inflightGets.set(path, p);
  const done = () => { if (inflightGets.get(path) === p) inflightGets.delete(path); };
  p.then(done, done);
  return p;
}
async function apiNetGo(method, path, body, isForm) {
  if (method === 'GET') {                              // an answer asked ahead (app-prefetch.js) is used if it is still good; the question is also noted so the page's next visit can ask ahead
    pfNote(path);
    const ahead = await pfTake(path);
    if (ahead) return ahead.data;
  } else if (pfAsked.size) pfAsked.clear();            // a change is on its way: nothing asked before it may be used
  const opt = { method, headers: { 'X-Pennyworth': '1' } };
  if (body !== undefined && !isForm) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  if (isForm) opt.body = body;
  let r;
  const remote = (S.st && S.st.remote) || (typeof offlineOn === 'function' && offlineOn());
  const gone = () => { const err = new Error(remote || S.awayHost ? '連不上你的電腦：請確認電腦開機、Tallomi 正在執行、手機的 Tailscale 已開啟。' : '無法連線到 Tallomi 本機服務，程式可能已關閉。'); err.network = true; return err; };
  let guard = null;
  if (typeof locOn === 'function' && locOn() && LOC.mode === 'pc' && !LOC.bypass) {      // the computer may not answer at all: give up after a while and let the phone's copy take over
    const ac = new AbortController(); opt.signal = ac.signal;
    guard = setTimeout(() => ac.abort(), method === 'GET' ? locSlow() : 15000);
  }
  try { r = await fetch(path, opt); } catch { throw gone(); } finally { if (guard) clearTimeout(guard); }
  let data = null;
  try { data = await r.json(); } catch { /* not json */ }
  // Tailscale (or any gateway in front of the computer) answers 502 / 503 / 504 with a page of its own when Tallomi is not running. Tallomi's own answers always carry a JSON "error".
  // The page does not know yet that it is on a phone while it starts up (the state has not arrived), so a host that is not this computer counts too.
  const away = remote || !/^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname);
  if (away && (r.status === 502 || r.status === 503 || r.status === 504) && !(data && data.error)) { remote || (S.awayHost = true); throw gone(); }
  const rev = Number(r.headers.get('X-Rev'));
  if (rev > (S.rev || 0)) S.rev = rev;                 // our own change: do not treat it as news from another window
  if (r.status === 401 && data && data.locked) { await showLock(); return apiNetGo(method, path, body, isForm); }      // PIN lock: ask, then try again
  if (r.status === 401 && data && data.pair) { location.replace('/pair' + (typeof isQuickHash === 'function' && isQuickHash(location.hash) ? location.hash : '')); throw new Error('這支手機需要重新配對'); }      // a quick-entry link survives the pairing page
  if ((r.status === 404 || r.status === 405) && path.startsWith('/api/') && (!data || data.error === '找不到' || !data.error))
    { const err = new Error('目前執行的 Tallomi 程式是舊版，缺少這個功能。請把 Tallomi 完全結束（設定 → 結束 Tallomi），再重新開啟。'); err.status = r.status; throw err; }
  if (!r.ok) { const err = new Error((data && data.error) || `請求失敗（${r.status}）`); err.status = r.status; throw err; }
  return data;
}

function toast(msg, err, action) {
  const t = h('div', { class: 'toast' + (err ? ' err' : '') + (action ? ' has-act' : '') }, h('span', { class: 'toast-msg' }, msg));
  if (action) t.appendChild(h('button', { class: 'toast-act', type: 'button', onclick: async () => {
    t.remove();
    try { await action.run(); } catch (e) { fail(e); }
  } }, action.label));
  const box = $('#toasts');
  box.querySelectorAll('.toast').forEach((o) => { if (err || !o.classList.contains('err')) o.remove(); });     // one message at a time: a newer one replaces the older (a failure is not wiped by a success)
  box.appendChild(t);
  setTimeout(() => t.remove(), err ? 7000 : action ? 10000 : 3500);
}
const fail = (e) => toast(e.message || String(e), true);

// ------------------------------------------------------------------- dialogs
// While a dialog is open the page behind it must not scroll. On a phone the body is pinned in place (iOS ignores overflow:hidden),
// on a computer the page just stops scrolling and keeps its width. The place in the page is put back when the last dialog closes.
let scrollLocks = 0, lockedY = 0;
function lockScroll() {
  if (scrollLocks++) return;
  const root = document.documentElement;
  lockedY = window.scrollY;
  if (window.matchMedia(PHONE_Q).matches) { root.classList.add('modal-open', 'modal-pinned'); document.body.style.top = `-${lockedY}px`; }
  else { const gap = window.innerWidth - root.clientWidth; root.classList.add('modal-open'); if (gap > 0) document.body.style.paddingRight = `${gap}px`; }
}
function unlockScroll() {
  if (!scrollLocks || --scrollLocks) return;
  const root = document.documentElement, pinned = root.classList.contains('modal-pinned');
  root.classList.remove('modal-open', 'modal-pinned'); document.body.style.top = ''; document.body.style.paddingRight = '';
  if (pinned) window.scrollTo(0, lockedY);
}
// 1.53.0 — on a phone a sheet can be pulled down with a finger to leave it: start on the title strip, or on the content while it is scrolled to the top.
// Past SWIPE_DOWN px (or a quick flick) it closes like the cancel button; otherwise it springs back. Boxes, menus and scrolled content are left alone.
const SWIPE_DOWN = 110;
function swipeDownClose(dlg, canClose) {
  let y0 = 0, x0 = 0, t0 = 0, dy = 0, mode = '';           // mode: '' idle, 'track' finger down, 'drag' pulling, 'no' not ours
  const sheetNow = () => window.matchMedia(PHONE_Q).matches;
  dlg.addEventListener('touchstart', (e) => {
    mode = '';
    if (!sheetNow() || e.touches.length !== 1 || !canClose()) { mode = 'no'; return; }
    const t = e.target;
    if (t.closest && t.closest('input,select,textarea,button,a,[contenteditable],.no-sheet-swipe')) { mode = 'no'; return; }
    const body = t.closest && t.closest('.dlg-body');
    if (body) {
      // anything inside that scrolls (the content itself, or a wide table) must be at its top-left edge, else the finger is scrolling
      for (let n = t; n && n !== dlg; n = n.parentElement) if (n.scrollTop > 0 || n.scrollLeft > 0) { mode = 'no'; return; }
    }
    y0 = e.touches[0].clientY; x0 = e.touches[0].clientX; t0 = Date.now(); dy = 0; mode = 'track';
  }, { passive: true });
  dlg.addEventListener('touchmove', (e) => {
    if (mode === 'no' || mode === '') return;
    const dyNow = e.touches[0].clientY - y0, dx = e.touches[0].clientX - x0;
    if (mode === 'track') {
      if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dyNow)) { mode = 'no'; return; }        // sideways: a scrolling table or a swipe row, not ours
      if (dyNow < -6) { mode = 'no'; return; }                                                // upwards: normal scrolling
      if (dyNow < 8) return;
      mode = 'drag'; dlg.style.transition = 'none';
    }
    dy = Math.max(0, dyNow);
    e.preventDefault();                                                                       // we own this gesture now: no scroll, no pull-to-refresh
    dlg.style.transform = `translateY(${dy}px)`;
  }, { passive: false });
  const end = () => {
    if (mode !== 'drag') { mode = ''; return; }
    mode = '';
    const fast = dy > 40 && (Date.now() - t0) < 260;
    dlg.style.transition = 'transform .18s ease-out';
    if ((dy > SWIPE_DOWN || fast) && canClose()) {
      dlg.style.transform = 'translateY(100%)';
      setTimeout(() => dlg.close(), 150);
    } else {
      dlg.style.transform = '';
      setTimeout(() => { dlg.style.transition = ''; }, 200);
    }
  };
  dlg.addEventListener('touchend', end);
  dlg.addEventListener('touchcancel', end);
}

function openDialog({ title, body, primary, wide, extraFoot, cancelLabel = '取消' }) {
  const dlg = h('dialog', { class: wide ? 'wide' : '', 'aria-label': title });
  const errBox = h('div', { class: 'neg', role: 'alert' });
  const submit = h('button', { class: 'btn primary' + (primary && primary.danger ? ' danger solid' : ''), type: 'submit' }, primary ? primary.label : '好');
  const form = h('form', { method: 'dialog' },
    h('div', { class: 'dlg-head' }, h('h3', null, title)),
    h('div', { class: 'dlg-body' }, body, errBox),
    h('div', { class: 'dlg-foot' }, extraFoot || null,
      h('button', { class: 'btn', type: 'button', autofocus: onTouch() ? '' : null, onclick: () => dlg.close() }, primary ? cancelLabel : '關閉'),     // on a phone the browser's own first-focus lands on this button, not on a text box (no keyboard without a tap)
      primary ? submit : null));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!primary) return dlg.close();
    submit.disabled = true; errBox.textContent = '';
    try { const keep = await primary.run(dlg); if (keep !== false) dlg.close(); }
    catch (err) { errBox.textContent = err.message || String(err); }
    finally { submit.disabled = false; }
  });
  dlg.appendChild(form);
  dlg.addEventListener('close', () => { dlg.remove(); unlockScroll(); });
  // A tap or click on the dimmed area outside the box is the same as pressing the cancel button. It must start AND end outside, so selecting
  // text inside a field and letting go over the backdrop does not close it, and nothing happens while the form is being saved.
  const outside = (e) => { const r = dlg.getBoundingClientRect(); return e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom; };
  let downOutside = false;
  dlg.addEventListener('pointerdown', (e) => { downOutside = e.target === dlg && outside(e); });
  dlg.addEventListener('click', (e) => { if (e.target === dlg && downOutside && outside(e) && !submit.disabled) dlg.close(); downOutside = false; });
  swipeDownClose(dlg, () => !submit.disabled);
  document.body.appendChild(dlg);
  lockScroll();
  dlg.showModal();
  const first = dlg.querySelector('input:not([type=hidden]):not([disabled]), select:not([disabled])');
  if (first && !onTouch()) first.focus();       // on a phone a focus the finger did not make leaves iOS with a focused box and no keyboard
  return dlg;
}

function confirmBox({ title, message, confirmLabel = '確定', danger = false, typed = null }) {
  return new Promise((resolve) => {
    let ok = false;
    const input = typed ? h('input', { type: 'text', autocomplete: 'off', 'aria-label': `輸入 ${typed} 確認` }) : null;
    const body = h('div', { class: 'rows', style: 'padding:0;max-width:none' }, message,
      typed ? h('label', { class: 'field' }, h('span', null, `請輸入「${typed}」以確認`), input) : null);
    const dlg = openDialog({
      title, body, primary: {
        label: confirmLabel, danger,
        run: async () => {
          if (typed && input.value.trim() !== typed) throw new Error(`輸入的內容不是「${typed}」`);
          ok = true;
        }
      }
    });
    dlg.addEventListener('close', () => resolve(ok));
  });
}

// --------------------------------------------------------------------- state
const S = {
  st: null,
  entry: { type: 'expense', account_id: null, to_account_id: null, amount: '', to_amount: '', category: '', note: '', tags: lsGet('pw_pin_tags') || '', time: '', advance: '', counterparty: '', due: '', no_budget: false, no_stats: false },
  txf: { q: '', type: '', account_id: '', from: '', to: '', tag: '', limit: TX_PAGE, transfers: true, group: 'day', back: null, folded: new Set() },
  rp: { year: new Date().getFullYear(), month: new Date().getMonth() + 1, group: 'category', cmpKind: 'expense', cmpMode: 'auto', months: [], years: [], kind: 'pie', accounts: ['total'], range: 'ym', bview: 'lines', shareKind: 'pie', shareBy: 'value' },
  charts: [],
  selMode: true, sel: new Set(),                       // transactions page: multi-select
  hideAll: lsGet('pw_hide') === '1',                 // Settings: hide every page
  hidePages: (() => { try { return JSON.parse(lsGet('pw_hide_pages') || '{}') || {}; } catch { return {}; } })(),   // the eye on each page
  route: 'overview',
  prefsApplied: false,
  lastRefresh: 0,
};
// opened from the tray icon's 記一筆: land on the transactions page with the cursor in the amount box
if (new URLSearchParams(location.search).get('add')) { S.focusAdd = true; history.replaceState(null, '', location.pathname + '#/transactions'); }

const PAGE_NAMES = { overview: '總覽', transactions: '交易', exchange: '換匯', invest: '投資', accounts: '帳戶', reports: '報表' };
const isHidden = () => !!(S.hideAll || S.hidePages[S.route]);
document.documentElement.classList.toggle('amounts-hidden', isHidden());
// 1.72.1: safe before the book has loaded (a tap during a slow start, a Shortcut link while the computer is off): no accounts yet, never a script error
const acct = (id) => ((S.st && S.st.accounts) || []).find((a) => a.id == id);
const activeAccounts = () => ((S.st && S.st.accounts) || []).filter((a) => !a.archived);
const stWaiters = [];
const whenState = () => (S.st ? Promise.resolve(S.st) : new Promise((res) => stWaiters.push(res)));   // something that needs the book waits for it instead of failing

// Look-and-feel choices live in the book (so they survive a changed port or a restored backup);
// localStorage is only a cache so the right colour is on screen before the first request returns.
function applyPrefs(p) {
  lsSet('pw_color', p.color); lsSet('pw_hide', p.hide ? '1' : '0'); lsSet('pw_hide_pages', JSON.stringify(p.pages || {}));
  Theme.apply(p.color); S.hideAll = !!p.hide; S.hidePages = { ...(p.pages || {}) }; markHidden();
}
// While amounts are hidden, green / red would still reveal income vs expense: show them in plain ink.
function markHidden() { document.documentElement.classList.toggle('amounts-hidden', isHidden()); }
// Every page has its own eye. The master switch in Settings hides all of them at once and leaves the per-page choices alone.
function setHidePage(page, v) {
  S.hidePages[page] = v; lsSet('pw_hide_pages', JSON.stringify(S.hidePages)); markHidden();
  if (S.st) S.st.prefs.pages[page] = v;
  api('PUT', '/api/settings', { ui_hide_pages: { [page]: v } }).catch(() => {});
  renderRoute();
}
function setHideAll(v) {
  S.hideAll = v; lsSet('pw_hide', v ? '1' : '0'); markHidden();
  if (S.st) S.st.prefs.hide = v;
  api('PUT', '/api/settings', { ui_hide: v }).catch(() => {});
  renderRoute();
}
function eyeButton(page) {
  const locked = S.hideAll;
  const hidden = isHidden();
  const label = locked ? '已在「設定」隱藏所有金額' : hidden ? '顯示這一頁的金額' : '隱藏這一頁的金額';
  const btn = h('button', { class: 'eye' + (locked ? ' locked' : ''), type: 'button', 'aria-pressed': String(hidden), 'aria-label': label, title: label,
    onclick: () => { if (locked) toast('已在「設定」打開「隱藏所有金額」。要單獨顯示這一頁，請先到設定頁關閉它。'); else setHidePage(page, !S.hidePages[page]); } });
  btn.replaceChildren(hidden
    ? svg(['path', { d: 'M3 10c2.2 3.2 5.4 5 9 5s6.8-1.8 9-5' }], ['path', { d: 'M12 15v3' }], ['path', { d: 'M7 13.6l-1.4 2.4' }], ['path', { d: 'M17 13.6l1.4 2.4' }])
    : svg(['path', { d: 'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z' }], ['circle', { cx: '12', cy: '12', r: '3' }]));
  return btn;
}

// The short explanation under a page title. On the phone it waits behind a small "ⓘ" next to the title (the paragraph pushed the page down by 100-150px); on a computer it stays visible.
function pageIntro(text) {
  if (!isPhone()) return { btn: null, p: h('p', { class: 'sub' }, text) };
  const p = h('p', { class: 'sub intro-note', hidden: true }, text);
  const btn = h('button', { class: 'info-btn', type: 'button', 'aria-label': '這一頁的說明', 'aria-expanded': 'false', title: '說明', onclick: () => {
    const open = p.hidden; p.hidden = !open; btn.setAttribute('aria-expanded', String(open)); btn.classList.toggle('on', open);
  } }, 'ⓘ');
  return { btn, p };
}

async function refresh() {
  pfRoute(currentRoute());                             // the page's own questions leave now, together with the one for the state (not one after the other)
  S.st = (await pfState()) || await api('GET', '/api/state');
  S.lastRefresh = Date.now(); S.day = nowLocal().slice(0, 10);
  if (S.st) while (stWaiters.length) stWaiters.shift()(S.st);
  if (typeof offlineSync === 'function') await offlineSync();
  if (typeof locAfterRefresh === 'function') locAfterRefresh().catch(() => {});
  if (!S.prefsApplied && S.st.prefs) { S.prefsApplied = true; applyPrefs(S.st.prefs); }
  $('#ver').textContent = `版本 ${S.st.version}`;
  updateAdvBadge();
  updateModeTag();
  updateUpdateBar();
  updateSyncLine(S.st.sheets);
  const first = activeAccounts()[0];
  if (!acct(S.entry.account_id) || acct(S.entry.account_id).archived) S.entry.account_id = first ? first.id : null;
  if (S.entry.to_account_id && !acct(S.entry.to_account_id)) S.entry.to_account_id = null;
  await renderRoute();
}
async function afterChange(msg, action) { if (msg) toast(msg, false, action); watchSync(); try { await refresh(); } catch (e) { fail(e); } }

function updateSyncLine(sh) {
  const line = $('#sync-line');
  const dot = h('span', { class: 'dot' });
  let text = 'Google 試算表：未設定';
  if (sh && !sh.has_credentials) text = 'Google 試算表：未上傳金鑰';
  else if (sh && !sh.key) text = 'Google 試算表：未設定試算表';
  if (sh && sh.configured) {
    const s = sh.status || {};
    if (!navigator.onLine) { dot.classList.add('off'); text = '離線中，連線後自動同步'; line.title = '記帳資料都存在這台電腦裡，網路恢復後會自動上傳到 Google 試算表。'; return line.replaceChildren(dot, h('span', null, text)); }
    if (s.state === 'syncing') { dot.classList.add('busy'); text = '同步中…'; }
    else if (s.state === 'offline') { dot.classList.add('off'); text = '離線中，連線後自動同步'; line.title = s.error || ''; }
    else if (s.state === 'error') { dot.classList.add('err'); text = '同步失敗'; line.title = s.error || ''; }
    else if (s.state === 'ok') { dot.classList.add('ok'); text = `已同步 ${String(s.last_ok || '').slice(11, 16)}`; }
    else text = sh.auto ? 'Google 試算表：自動同步已開啟' : 'Google 試算表：自動同步已關閉';
  }
  if (!(sh && sh.status && ['error', 'offline'].includes(sh.status.state))) line.title = '';
  line.replaceChildren(dot, h('span', null, text));
}

// After a change, tell the user whether the Google Sheet caught up (the push runs ~2s later in the background).
let syncWatch = 0;
async function watchSync() {
  const sh = S.st && S.st.sheets;
  if (!sh || !sh.configured || !sh.auto) return;
  const me = ++syncWatch, t0 = Date.now(), prevOk = sh.status.last_ok;
  await new Promise((r) => setTimeout(r, 2600));
  while (me === syncWatch && Date.now() - t0 < 25000) {
    let cur;
    try { cur = await api('GET', '/api/sheets'); } catch { return; }
    updateSyncLine(cur);
    if (cur.status.state === 'offline') { toast('目前離線：已先存在這台電腦，連線後會自動同步'); return; }
    if (cur.status.state === 'error') { toast(`Google 試算表同步失敗：${cur.status.error}`, true); return; }
    if (cur.status.state === 'ok' && cur.status.last_ok !== prevOk) { toast('已同步到 Google 試算表'); return; }
    await new Promise((r) => setTimeout(r, 1000));
  }
}

// -------------------------------------------------------------------- router
// Phone tab bar: shows 6 tabs, the rest by swiping. Keep the current tab in view and show a soft edge where more tabs are hidden.
function navEdges() {
  const nav = document.querySelector('.nav'), side = document.querySelector('.side');
  if (!nav || !side) return;
  const more = nav.scrollWidth - nav.clientWidth > 2;
  side.toggleAttribute('data-more-left', more && nav.scrollLeft > 2);
  side.toggleAttribute('data-more-right', more && nav.scrollLeft + nav.clientWidth < nav.scrollWidth - 2);
}
function navReveal() {
  const nav = document.querySelector('.nav'), cur = nav && nav.querySelector('a[aria-current]');
  if (cur && nav.scrollWidth > nav.clientWidth + 2) {
    const l = cur.offsetLeft, r = l + cur.offsetWidth;
    if (l < nav.scrollLeft || r > nav.scrollLeft + nav.clientWidth) nav.scrollTo({ left: Math.max(0, l - (nav.clientWidth - cur.offsetWidth) / 2) });
  }
  navEdges();
}
{ const n = document.querySelector('.nav'); if (n) n.addEventListener('scroll', navEdges, { passive: true }); }
window.addEventListener('resize', navEdges);

// The round "記一筆" button steps out of the way while the page scrolls down (it sat on top of the 編輯 button at the end of a row) and comes back as soon as the page scrolls up or reaches the top.
{
  let lastY = window.scrollY, run = 0;
  window.addEventListener('scroll', () => {
    const y = window.scrollY, d = y - lastY; lastY = y;
    if (y < 80) { run = 0; document.documentElement.classList.remove('fab-away'); return; }
    run = (run > 0) === (d > 0) ? run + d : d;
    if (run > 14) document.documentElement.classList.add('fab-away');
    else if (run < -10) document.documentElement.classList.remove('fab-away');
  }, { passive: true });
}
const ROUTES = { overview: viewOverview, calendar: viewCalendar, advances: viewAdvances, transactions: viewTransactions, exchange: viewExchange, invest: viewInvest, accounts: viewAccounts, reports: viewReports, categories: viewCategories, tags: viewTags, settings: viewSettings };
function currentRoute() { const r = (location.hash || '').replace('#/', ''); return ROUTES[r] ? r : 'overview'; }
// 1.71.0: opening the program with no page named in the address returns to the page that was open last time (this device only; Settings → 外觀 can switch it off).
const LAST_ROUTE = 'pw_last_route', RESTORE_LAST = 'pw_restore_last';
const restoreLastOn = () => lsGet(RESTORE_LAST) !== '0';
(function restoreLastPage() {
  if (!restoreLastOn() || (location.hash && location.hash !== '#' && location.hash !== '#/')) return;      // a link or the tray's 記一筆 already says where to go
  const last = lsGet(LAST_ROUTE);
  if (last && last !== 'overview' && last !== 'settings' && ROUTES[last]) history.replaceState(null, '', location.pathname + location.search + '#/' + last);
})();
// Leaving a page keeps its finished picture for a few minutes; coming back shows it at once while the fresh data loads behind it
// (the same swap used for a live change), so switching pages never starts from a blank screen.
const routeSnaps = {};
const SNAP_MAX_AGE = 10 * 60 * 1000;
// 1.53.0 — on a phone, slide a finger left/right over the page to go to the next/previous page of the main menu (總覽 ⇄ 月曆 ⇄ 交易 …).
// Not started on things that already use a sideways move: swipeable rows, the calendar grid, anything that scrolls sideways, charts, fields, sheets.
const PAGE_SWIPE_AT = 70;
const CAL_EDGE = 64;                                                   // on the calendar grid only a slide that starts this close to a side of the screen changes page; elsewhere on it, it changes month
const calEdge = (x) => x < CAL_EDGE || x > document.documentElement.clientWidth - CAL_EDGE;
function pageSwipeSkip(t, x) {
  if (!t || !t.closest) return true;
  if (t.closest('.cal') && !calEdge(x)) return true;
  if (t.closest('.swipeable') && !calEdge(x)) return true;           // 1.60.1: a row with swipe actions keeps its own slide, except near the two sides of the screen, where a slide changes page
  if (t.closest('dialog, input, select, textarea, canvas, .nav, .no-page-swipe, [draggable=true], .tile.lifted, .tpl-row, .kb, summary')) return true;
  for (let n = t; n && n !== document.body; n = n.parentElement) {
    if (n.scrollWidth > n.clientWidth + 2) { const ox = getComputedStyle(n).overflowX; if (ox === 'auto' || ox === 'scroll') return true; }
  }
  return false;
}
// The main menu's visible pages in order, with their names. Read once per gesture (it cannot change while a finger is down):
// looking it up on every finger move forced the page to be laid out again each frame.
function pageSwipeNav() {
  const order = [], name = {};
  for (const a of document.querySelectorAll('.nav a[data-route]')) {
    if (a.hidden || (a.offsetParent === null && !a.getClientRects().length)) continue;
    order.push(a.dataset.route); name[a.dataset.route] = a.textContent.trim();
  }
  return { order, name };
}
function pageSwipeTarget(dir, nav) {
  const order = (nav || pageSwipeNav()).order, i = order.indexOf(S.route);
  return i < 0 ? null : order[i + dir] || null;
}
{
  let st = null;
  const view = () => $('#view');
  const spring = (v) => { v.style.transition = 'transform .22s cubic-bezier(.2,.8,.3,1)'; v.style.transform = ''; setTimeout(() => { v.style.transition = ''; }, 200); };
  document.addEventListener('pointerdown', (e) => {
    st = null;
    if (e.pointerType !== 'touch' || !e.isPrimary || !isPhone() || document.querySelector('dialog[open]')) return;
    const W = document.documentElement.clientWidth;
    if (e.clientX < 22 || e.clientX > W - 22 || pageSwipeSkip(e.target, e.clientX)) return;      // the screen's edges belong to the system's own swipe-back
    st = { x: e.clientX, y: e.clientY, on: false, dx: 0, t: performance.now(), nav: null };
  });
  // the page follows the finger while it is down; a hint at the top names the page it will open and says when letting go will do it.
  // Letting go past a third of the width (or after a quick flick) slides the page away and opens the neighbour, otherwise it springs back.
  const atAt = () => Math.min(130, Math.max(PAGE_SWIPE_AT, document.documentElement.clientWidth * 0.28));
  let raf = 0, hint = null, peek = null;
  // the neighbouring page's place-holder, parked beside the page and carried along with it, so the next page really comes in from the side
  const peekFor = (dx, to, label) => {
    const W = document.documentElement.clientWidth;
    if (!to) { if (peek) { peek.remove(); peek = null; } return; }
    if (!peek) { document.querySelectorAll('.page-peek').forEach((n) => n.remove()); peek = h('div', { class: 'page-peek', 'aria-hidden': 'true' }); document.body.appendChild(peek); }
    if (peek.dataset.r !== to) {                                   // the same grey outline the page shows while it loads, with its name where the title will be
      peek.dataset.r = to; const sk = skeletonFor(to); sk.querySelector('.sk-title').replaceWith(h('h2', { class: 'pk-name' }, label)); peek.replaceChildren(sk);
    }
    peek.style.transform = `translate3d(${dx + (dx < 0 ? W : -W)}px,0,0)`;
  };
  const hintFor = (dx, to, armed, label) => {
    if (!to) { if (hint) { hint.remove(); hint = null; } return; }
    if (!hint) { document.querySelectorAll('.page-pill').forEach((n) => n.remove()); hint = h('div', { class: 'page-pill hint', role: 'status' }); document.body.appendChild(hint); }
    if (hint.classList.contains('armed') !== armed) hint.classList.toggle('armed', armed);
    const text = (dx < 0 ? '' : '‹ ') + label + (dx < 0 ? ' ›' : '');
    if (hint.textContent !== text) hint.textContent = text;          // only when it changes: rewriting the same words every frame made the page lay out again
  };
  document.addEventListener('pointermove', (e) => {
    if (!st) return;
    const dx = e.clientX - st.x, dy = e.clientY - st.y;
    if (!st.on) {
      if (Math.abs(dy) > 12 && Math.abs(dy) >= Math.abs(dx) / 1.5) { st = null; return; }    // scrolling, not swiping
      if (Math.abs(dx) < 10 || Math.abs(dx) < Math.abs(dy) * 2) return;
      st.on = true; st.nav = pageSwipeNav(); view().style.transition = 'none'; view().style.willChange = 'transform';
    }
    const to = pageSwipeTarget(dx < 0 ? 1 : -1, st.nav);
    if (to && Math.abs(dx) > 24 && st.pf !== to) { st.pf = to; pfHeadStart(to); }                    // 1.62.0: the neighbour's questions leave while the finger is still moving
    st.real = !!to; st.dx = to ? dx : dx * 0.25;                                                         // nothing on that side: only a little rubber band
    const armed = !!to && Math.abs(dx) >= atAt();
    if (armed !== st.armed) { st.armed = armed; if (armed && navigator.vibrate) { try { navigator.vibrate(8); } catch { /* not supported */ } } }
    if (!raf) raf = requestAnimationFrame(() => { raf = 0; if (st && st.on) { view().style.transform = `translate3d(${st.dx}px,0,0)`; const t2 = pageSwipeTarget(st.dx < 0 ? 1 : -1, st.nav), label = t2 && st.nav.name[t2]; hintFor(st.dx, t2, !!st.armed, label); peekFor(st.dx, st.real ? t2 : null, label); } });
  });
  document.addEventListener('pointerup', (e) => {
    if (!st) return; const { on, t, nav } = st; const dx = e.clientX - st.x, dy = e.clientY - st.y; st = null;
    if (!on) return;
    S.pageSwiped = Date.now();
    const vw = view(); vw.style.willChange = '';
    if (hint) { hint.remove(); hint = null; }
    const dir = dx < 0 ? 1 : -1;
    const flick = Math.abs(dx) > 40 && Math.abs(dx) / Math.max(1, performance.now() - t) > 0.3;      // a quick short flick also counts (over 0.3 px per ms on the whole way)
    const to = (Math.abs(dx) >= atAt() || flick) && Math.abs(dx) >= Math.abs(dy) * 1.5 ? pageSwipeTarget(dir, nav) : null;
    if (!to) { peekFor(0, null); spring(vw); return; }
    const W = document.documentElement.clientWidth;
    const out = dx < 0 ? -W : W, left = Math.max(0.12, Math.min(0.26, (W - Math.abs(dx)) / W * 0.3));     // finish the slide from where the finger let go
    vw.style.transition = `transform ${left}s cubic-bezier(.3,.7,.3,1)`; vw.style.transform = `translate3d(${out}px,0,0)`;
    if (peek) { peek.style.transition = `transform ${left}s cubic-bezier(.3,.7,.3,1)`; peek.style.transform = 'translate3d(0,0,0)'; }
    setTimeout(() => {
      vw.style.transition = 'none'; vw.style.transform = '';
      location.hash = '#/' + to;
      pageNameToast(to);
      const pk = peek; peek = null;
      if (pk) setTimeout(() => { pk.style.transition = 'opacity .16s'; pk.style.opacity = '0'; setTimeout(() => pk.remove(), 200); }, 150);   // the real page has been built by now: let the place-holder fade off
      vw.style.transition = '';
    }, left * 1000 + 10);
  });
  document.addEventListener('pointercancel', () => { if (st && st.on) { const v = view(); v.style.opacity = ''; v.style.willChange = ''; if (hint) { hint.remove(); hint = null; } peekFor(0, null); spring(v); } st = null; });
  document.addEventListener('click', (e) => { if (Date.now() - (S.pageSwiped || 0) < 400) { e.stopPropagation(); e.preventDefault(); } }, true);
}
// 1.60.1 — tapping the menu icon of the page you are already on (a second tap on the same icon) takes it back to the top.
let iconTopUntil = 0;
document.addEventListener('click', (e) => {
  const a = e.target && e.target.closest ? e.target.closest('.nav a[data-route], .side a[data-route]') : null;
  if (!a || a.dataset.route !== S.route || document.querySelector('dialog[open]')) return;
  e.preventDefault();
  if (window.scrollY < 2) return;
  iconTopUntil = Date.now() + 900;
  const calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  window.scrollTo({ top: 0, behavior: calm ? 'auto' : 'smooth' });
});
// The new page's name, shown at the top for a moment, so a quick run of swipes never loses the way.
function pageNameToast(route) {
  const a = document.querySelector(`.nav a[data-route="${route}"]`); if (!a) return;
  document.querySelectorAll('.page-pill').forEach((n) => n.remove());
  const pill = h('div', { class: 'page-pill', role: 'status' }, a.textContent.trim());
  document.body.appendChild(pill);
  setTimeout(() => pill.classList.add('out'), 900);
  setTimeout(() => pill.remove(), 1250);
}
async function renderRoute() {
  if (!S.st) return;
  const my = (S.renderSeq = (S.renderSeq || 0) + 1);
  S.afterShow = S.goAfter || null; S.goAfter = null;          // goThen(): something a shortcut asked for once the next page is on screen
  const route = currentRoute();
  const view = $('#view');
  const prev = S.route;
  let same = S.route === route && view.childNodes.length > 0;
  S.route = route; markHidden();
  if (location.hash === '#/' + route && route !== 'settings') lsSet(LAST_ROUTE, route);          // only real pages count as "last page"
  document.querySelectorAll('.nav a').forEach((a) => {
    if (a.dataset.route === route) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  navReveal();
  if (!same) {                                         // another page
    if (prev && prev !== route && view.childNodes.length && !S.charts.length && !view.querySelector('canvas, :scope > .empty, :scope > .skeleton')) routeSnaps[prev] = { nodes: [...view.childNodes], at: Date.now(), y: window.scrollY };
    S.charts.forEach((c) => c.destroy()); S.charts = [];
    for (const k of Object.keys(routeSnaps)) if (Date.now() - routeSnaps[k].at >= SNAP_MAX_AGE) delete routeSnaps[k];     // old pages are not kept around
    const snap = routeSnaps[route]; delete routeSnaps[route];
    if (snap && Date.now() - snap.at < SNAP_MAX_AGE) { view.replaceChildren(...snap.nodes); window.scrollTo(0, snap.y); same = true; virtualRefresh(); }
    else {                                             // never seen (or too old): grey placeholder blocks shaped like the page + a thin progress line while it is built out of sight
      view.replaceChildren(skeletonFor(route)); view.classList.add('loading'); window.scrollTo(0, 0);
      const fresh = await buildStage(route, my, true);
      if (my === S.renderSeq) view.classList.remove('loading');
      if (fresh) { view.replaceChildren(...fresh.childNodes); fresh.remove(); window.scrollTo(0, 0); afterShown(); }
      return;
    }
  }
  // The same page again (a change came in, e.g. the automatic price update): build the new page out of sight and swap it in
  // in one step, so the visible page never goes blank or jumps.
  const oldCharts = S.charts; S.charts = [];
  const stage = await buildStage(route, my, false);
  if (!stage) return;                                          // the person moved on to another page meanwhile
  const y = Date.now() < iconTopUntil ? 0 : window.scrollY;   // a tap on the page's own icon is taking it to the top: a refresh landing meanwhile must not undo that
  oldCharts.forEach((c) => c.destroy());
  if (stage.failed) view.replaceChildren(h('div', { class: 'empty' }, h('b', null, '畫面載入失敗'), stage.failed.message));
  else view.replaceChildren(...stage.childNodes);
  stage.remove();
  window.scrollTo(0, y);
  afterShown();
}
// Build a page in a hidden box next to the real one (same width, so charts and rows measure right). Returns the box, or null when the
// person has already gone elsewhere. A page that fails to build shows its error in the box instead.
async function buildStage(route, my, first) {
  const view = $('#view');
  const stage = h('div', { class: view.className.replace('loading', '').trim(), 'aria-hidden': 'true' });
  stage.style.cssText = `position:absolute;left:0;top:0;width:${view.clientWidth}px;visibility:hidden;pointer-events:none`;
  view.parentNode.appendChild(stage);
  let failed = null;
  const learning = pfBegin();                          // which questions this page asks the computer (app-prefetch.js asks them ahead next time)
  try { await ROUTES[route](stage); } catch (e) { failed = e; }
  pfEnd(route, learning, !failed && my === S.renderSeq);
  if (my !== S.renderSeq) { stage.remove(); return null; }
  if (failed) { stage.failed = failed; if (first) { stage.replaceChildren(h('div', { class: 'empty' }, h('b', null, '畫面載入失敗'), failed.message)); } }
  return stage;
}
// What a page asked to do once it is really on screen (the stage cannot take focus): e.g. open the record dialog after the 記一筆 shortcut.
function afterShown() {
  virtualRefresh();
  if (S.afterShow) { const f = S.afterShow; S.afterShow = null; setTimeout(f, 30); }
}
window.addEventListener('hashchange', () => { pfRoute(currentRoute()); renderRoute(); });     // moving to another page: its questions leave before the skeleton is even drawn
// Moving between pages does not pile up "previous pages": the overview stays as the one page Back returns to, and going from one page to
// another replaces the current history entry instead of adding one. (Ctrl/⌘-click, middle click and links that open elsewhere behave as usual.)
let homeBelow = false;                                   // the overview is the entry just below this one
function goRoute(hash) {
  const to = hash.replace('#/', ''), from = currentRoute();
  if (to === from && location.hash === hash) return;
  if (from === 'overview') { homeBelow = true; location.hash = hash; return; }
  if (to === 'overview' && homeBelow) {
    homeBelow = false; history.back();
    setTimeout(() => { if (currentRoute() !== 'overview') location.replace('#/overview'); }, 250);
    return;
  }
  location.replace(hash);
}
document.addEventListener('click', (e) => {
  if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  const a = e.target.closest && e.target.closest('a[href^="#/"]');
  if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download')) return;
  const hash = a.getAttribute('href');
  if (!ROUTES[hash.slice(2).split('?')[0]]) return;      // not a page of ours: leave it alone
  e.preventDefault(); goRoute(hash);
});

// ----------------------------------------------------- transaction form pieces
// Shared by the quick-entry bar and the edit dialog.
function txFields(m, redraw, { editing = false } = {}) {
  const A = (id) => acct(id);
  const pick = activeAccounts().filter((a) => true);
  const keep = (id) => (id && A(id) && A(id).archived ? [A(id)] : []);
  const repay = editing && !!m.settle_of;                       // a friend's repayment: where it landed may be changed (same currency), nothing else about its kind
  const choices = (selectedId) => [...(repay ? pick.filter((a) => !A(selectedId) || a.currency === A(selectedId).currency) : pick), ...keep(selectedId)];
  const from = A(m.account_id), to = A(m.to_account_id);
  const isT = m.type === 'transfer';
  const cross = isT && from && to && from.currency !== to.currency;
  let hintEl = null, hintFn = null;
  const sel = (id, cur, onchange, label) => h('label', { class: 'field half' }, h('span', null, label),
    h('select', { onchange }, choices(cur).map((a) => h('option', { value: a.id, selected: a.id == cur }, `${a.name}（${a.currency}）`))));
  const out = [];
  if (repay) {
    out.push(h('p', { class: 'hint field grow', style: 'margin:0' }, `${m.counterparty ? m.counterparty + '　' : ''}${m.settle_from ? m.settle_from + ' → ' : ''}還到哪個帳戶：這筆收款跟著原來的代墊算（${m.no_stats ? '不算收入' : '算成收入'}）。要改入帳帳戶，從下面選。`));
  } else if (!editing || m.type !== 'adjust') {
    out.push(h('div', { class: 'seg', role: 'group', 'aria-label': '交易類型' },
      ['expense', 'income', 'transfer'].map((t) => h('button', {
        type: 'button', 'aria-pressed': String(m.type === t),
        onclick: () => { m.type = t; if (t === 'transfer' && (!m.to_account_id || m.to_account_id == m.account_id)) { const o = activeAccounts().find((a) => a.id != m.account_id); m.to_account_id = o ? o.id : null; } redraw(); },
      }, TYPE_LABEL[t]))));
  }
  out.push(h('label', { class: 'field' }, h('span', null, m.type === 'adjust' ? '金額（正數為增加、負數為減少）' : '金額'),
    h('input', { class: 'amt', name: 'amount', inputmode: 'decimal', autocomplete: 'off', placeholder: '0', value: m.amount, 'aria-label': '金額', oninput: (e) => { m.amount = e.target.value; if (hintFn) hintFn(); } })));
  if (from) out.push(h('span', { class: 'ccy-tag' }, from.currency));
  out.push(sel(m.account_id, m.account_id, (e) => { m.account_id = +e.target.value; redraw(); }, repay ? '還到哪個帳戶' : isT ? '轉出帳戶' : '帳戶'));
  if (isT) {
    out.push(sel(m.to_account_id, m.to_account_id, (e) => { m.to_account_id = +e.target.value; redraw(); }, '轉入帳戶'));
    if (cross) {
      const rates = rateTable();
      const hintText = () => {
        if (!(rates[from.currency] && rates[to.currency])) return '尚未設定匯率，請直接輸入實際轉入金額';
        const amt = Number(String(m.amount).replace(/,/g, ''));
        if (amt > 0) return `依目前匯率約 ${num(amt * rates[from.currency] / rates[to.currency], to.currency)} ${to.currency}，可依實際成交修改`;
        return '留空會依匯率換算';
      };
      hintEl = h('span', { class: 'hint' }, hintText());
      hintFn = () => { hintEl.textContent = hintText(); };
      out.push(h('label', { class: 'field' }, h('span', null, `轉入金額（${to.currency}）`),
        h('input', { name: 'to_amount', inputmode: 'decimal', autocomplete: 'off', value: m.to_amount, 'aria-label': '轉入金額', oninput: (e) => { m.to_amount = e.target.value; } }),
        hintEl));
    }
  } else if (!repay) {
    out.push(catField(m));
  }
  out.push(h('label', { class: 'field grow' }, h('span', null, '備註'),
    h('input', { name: 'note', autocomplete: 'off', value: m.note, maxlength: 500, oninput: (e) => { m.note = e.target.value; } })));
  const adv = editing && m.settle_of ? null : advanceField(m, redraw);
  if (adv) out.push(adv);
  // Rarely changed fields (tags, receipt photos, time) sit under one fold so the form is short on a phone. It starts open when any of them
  // already holds something (an edit, a tag, a photo, a chosen date), and stays as the person left it while the form redraws.
  const more = [];
  if (m.type !== 'adjust') { more.push(tagField(m, editing ? null : redraw)); more.push(photoField(m)); }
  more.push(h('label', { class: 'field' }, h('span', null, '時間'),
    h('input', { type: 'datetime-local', step: editing ? '1' : '60', value: (m.time || nowLocal()).slice(0, editing ? 19 : 16), 'aria-label': '時間', oninput: (e) => { m.time = e.target.value; } })));
  if (m.moreOpen == null) m.moreOpen = !!(editing || m.time || String(m.tags || '').trim() || (m.photos && m.photos.length) || (m.receipts && m.receipts.length));
  const fold = h('details', { class: 'more-fields', ontoggle: () => { m.moreOpen = fold.open; } },
    h('summary', null, m.type === 'adjust' ? '更多選項（時間）' : '更多選項（標籤、收據照片、時間）'), h('div', { class: 'more-body' }, more));
  fold.open = !!m.moreOpen;
  out.push(fold);
  return out;
}
// Category field: type it with the keyboard, or open the A-Z list of every category used before (the ▾ button, or just start
// typing and the matching ones appear). A name that is not in the list simply becomes a new category.
const catCmp = (a, b) => { const x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : x > y ? 1 : a < b ? -1 : a > b ? 1 : 0; };
function catOptions(current, type, all) {
  const info = S.st.cat_info;
  const kind = type === 'income' || type === 'expense';
  const src = !all && kind && info ? info[type] : (S.st.categories || []);
  const list = src.filter((c) => c && c !== '未分類');
  if (current && current !== '未分類' && !list.includes(current)) list.push(current);   // keep an old transaction's own category in the list
  return list.sort(catCmp);
}
function catField(m) {
  const initial = m.category;                                   // an old transaction's own category stays in the list
  let open = false, hi = -1, shown = [];
  const input = h('input', { name: 'category', role: 'combobox', 'aria-autocomplete': 'list', 'aria-expanded': 'false', autocomplete: 'off', autocapitalize: 'off',
    enterkeyhint: 'done', maxlength: 60, value: m.category, placeholder: '未分類', 'aria-label': '類別' });
  const menu = h('ul', { class: 'cat-menu', role: 'listbox', hidden: true });
  const toggle = h('button', { class: 'cat-btn', type: 'button', tabindex: '-1', 'aria-label': '顯示所有類別', title: '顯示所有類別' }, '▾');
  const paint = (all) => {
    const q = input.value.trim().toLowerCase();
    shown = catOptions(initial, m.type, S.catAll).filter((c) => all || !q || c.toLowerCase().includes(q));
    const info = S.st.cat_info, kind = m.type === 'income' || m.type === 'expense';
    const more = kind && info && info[m.type].length < (S.st.categories || []).length;       // the kind's list is shorter than the unified one
    const foot = (more || S.catAll) && kind ? [h('li', { class: 'cat-more', role: 'button', 'data-more': '1' },
      S.catAll ? `只顯示${TYPE_LABEL[m.type]}類別` : `顯示全部類別（${(S.st.categories || []).length}）`)] : [];
    menu.replaceChildren(...shown.map((c, i) => h('li', { role: 'option', class: i === hi ? 'on' : '', 'aria-selected': String(i === hi), 'data-v': c }, catChip(c, 'sm'), h('span', null, c))), ...foot);
    open = shown.length > 0 || foot.length > 0;
    menu.hidden = !open; input.setAttribute('aria-expanded', String(open));
  };
  const close = () => { open = false; hi = -1; menu.hidden = true; input.setAttribute('aria-expanded', 'false'); };
  const pick = (v) => { input.value = v; m.category = v; close(); };
  input.addEventListener('input', () => { m.category = input.value; hi = -1; if (input.value.trim()) paint(false); else close(); });
  input.addEventListener('blur', () => setTimeout(close, 120));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault(); if (!open) paint(true);
      if (shown.length) { hi = (hi + (e.key === 'ArrowDown' ? 1 : -1) + shown.length) % shown.length; paint(menu.dataset.all === '1'); }
    } else if (e.key === 'Escape' && open) { e.preventDefault(); e.stopPropagation(); close(); }
    else if (e.key === 'Enter' && open && hi >= 0) { e.preventDefault(); pick(shown[hi]); }
  });
  // mousedown is stopped so the field keeps its focus (and the phone keeps its keyboard) while a choice is made
  const keep = (e) => e.preventDefault();
  menu.addEventListener('mousedown', keep); toggle.addEventListener('mousedown', keep);
  menu.addEventListener('click', (e) => {
    const li = e.target.closest('li'); if (!li) return;
    if (li.dataset.more) { S.catAll = !S.catAll; paint(menu.dataset.all === '1'); return; }       // unified list <-> this kind's list
    pick(li.dataset.v);
  });
  toggle.addEventListener('click', () => { if (open) close(); else { hi = -1; menu.dataset.all = '1'; paint(true); } });
  input.addEventListener('input', () => { menu.dataset.all = ''; });
  return h('label', { class: 'field grow half cat-field' }, h('span', null, '類別'), h('div', { class: 'cat-row' }, input, toggle, menu));
}
function rateTable() {
  const r = { [S.st.base]: 1 };
  S.st.rates.rates.forEach((x) => { if (x.rate) r[x.currency] = x.rate; });
  return r;
}
function payload(m) {
  return { type: m.type, time: m.time || undefined, account_id: m.account_id, to_account_id: m.type === 'transfer' ? m.to_account_id : undefined,
    amount: m.amount, to_amount: m.type === 'transfer' ? m.to_amount : undefined, category: m.type === 'transfer' ? '' : m.category, note: m.note,
    tags: m.type === 'adjust' ? undefined : (m.tags || ''),
    advance: m.type === 'expense' ? (m.advance || '') : '', counterparty: m.type === 'expense' && m.advance ? (m.counterparty || '') : '', due: m.type === 'expense' && m.advance ? (m.due || '') : '',
    no_budget: m.type === 'expense' ? !!m.no_budget : false, no_stats: m.type === 'expense' ? !!m.no_stats : false,
    auto_settle: m.type === 'expense' && m.advance && m.due && m.auto_settle ? m.auto_settle : (m.type === 'expense' && m.advance ? '' : undefined) };
}

function entryBar() {
  const wrap = h('form', { class: 'entry', 'aria-label': '記一筆' });
  const m = S.entry;
  const redraw = () => { const n = entryBar(); wrap.replaceWith(n); const a = $('input[name=amount]', n); if (a && m.amount === '' && !onTouch()) a.focus(); };
  const pin = pinBar();
  if (pin) wrap.appendChild(pin);
  wrap.appendChild(templateBar(m, redraw));
  txFields(m, redraw).forEach((f) => wrap.appendChild(f));
  wrap.appendChild(h('button', { class: 'btn primary', type: 'submit' }, '記下'));
  wrap.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await recordEntry(m);
      await refresh();
      const f = $('input[name=amount]'); if (f && !onTouch()) f.focus();
    } catch (err) { fail(err); }
  });
  return wrap;
}
// Save the entry in `m` as a new transaction (shared by the quick-entry bar and the "add" dialogs), then clear what should not carry over.
async function recordEntry(m) {
  const a = acct(m.account_id);
  const made = await api('POST', '/api/transactions', payload(m));
  let lost = 0;
  if (made.queued) { toast('電腦連不上：這筆已先存在手機，電腦回來後自動補送'); if (m.photos && m.photos.length) toast('照片離線時存不了；補送後到編輯再加', true); }
  else if (m.photos && m.photos.length) lost = await uploadPhotos(made.id, m);
  let tplMsg = '';
  if (m.save_tpl) { try { tplMsg = `，已${await saveEntryAsTemplate(m)}範本`; } catch (e) { toast(`交易已記下，但範本沒存成功：${e.message || e}`, true); } }
  let repMsg = '';
  if (m.repeat && !made.queued) { try { repMsg = `，之後每月 ${Number(((m.time ? String(m.time) : nowLocal()).slice(8, 10)))} 日自動記（下一次 ${await createRepeatRule(m)}）`; } catch (e) { toast(`交易已記下，但定期交易沒建成功：${e.message || e}`, true); } }
  else if (m.repeat) toast('離線時沒辦法設定定期交易；電腦連上後再到「設定 → 定期交易」新增', true);
  if (!made.queued) toast(`已記下${m.advance ? ADV_LABEL[m.advance] + '的' : ''}${TYPE_LABEL[m.type]}　${num(Number(String(m.amount).replace(/,/g, '')), a ? a.currency : 'TWD')} ${a ? a.currency : ''}　${a ? a.name : ''}${tplMsg}${repMsg}`);
  if (lost) toast(`有 ${lost} 張照片沒存成功，交易本身已記下；可以到編輯再加一次`, true);
  Object.assign(m, { amount: '', to_amount: '', note: '', category: '', tags: pinnedTags(), time: '', advance: '', counterparty: '', due: '', auto_settle: '', no_budget: false, no_stats: false, save_tpl: false, tpl_ask: false, repeat: false });
  watchSync();
  return made;
}

function openTxDialog(tx) {
  const m = { type: tx.type, account_id: tx.account_id, to_account_id: tx.to_account_id, amount: String(tx.amount), to_amount: tx.to_amount == null ? '' : String(tx.to_amount), category: tx.category, note: tx.note, tags: (tx.tags || []).join(' '), advance: tx.advance || '', counterparty: tx.counterparty || '', due: tx.due || '', auto_settle: tx.auto_account_id || '', no_budget: !!tx.no_budget, no_stats: !!tx.no_stats, settle_of: tx.settle_of || null, settle_from: tx.settle_from || '', receipts: [...(tx.receipts || [])], photos: [], dropped: [], time: tx.time };
  const holder = h('div', { class: 'rows', style: 'padding:0;max-width:none' });
  const draw = () => { holder.replaceChildren(...[h('div', { class: 'grid2' }, txFields(m, draw, { editing: true }).map((f) => (f.classList && f.classList.contains('ccy-tag')) ? null : f))].filter(Boolean)); };
  draw();
  const editDlg = openDialog({
    title: '編輯交易', body: holder,
    extraFoot: h('button', { class: 'btn danger', type: 'button', style: 'margin-right:auto', onclick: async (e) => {
      const ok = await confirmBox({ title: '刪除這筆交易？', message: h('p', null, `${shortTime(tx.time)}　${TYPE_LABEL[tx.type]}　${num(tx.amount, tx.currency)} ${tx.currency}　${tx.account}。帳戶餘額會立刻重新計算。`), confirmLabel: '刪除', danger: true });
      if (!ok) return;
      try { const r = await api('DELETE', `/api/transactions/${tx.id}`); e.target.closest('dialog').close(); await afterChange('已刪除', undoAction(r.undo)); } catch (err) { fail(err); }
    } }, '刪除'),
    primary: { label: '儲存修改', run: async () => {
      await api('PUT', `/api/transactions/${tx.id}`, payload(m));
      await dropReceipts(m);
      const lost = await uploadPhotos(tx.id, m);
      await afterChange(lost ? `已儲存，但有 ${lost} 張照片沒存成功` : '已儲存修改');
    } },
  });
  editDlg.addEventListener('close', () => forgetPhotos(m));
}

// ------------------------------------------------------------------ overview
// One setting for the monthly totals on the overview and for the reports: do transfers count as income / expense?
function transfersSwitch(note) {
  return h('div', { class: 'tr-switch' },
    h('label', { class: 'tally-toggle' }, h('input', { type: 'checkbox', checked: !!S.st.prefs.count_transfers, onchange: async (e) => {
      try { await api('PUT', '/api/settings', { count_transfers: e.target.checked }); await afterChange(); } catch (err) { e.target.checked = !e.target.checked; fail(err); }
    } }), h('span', null, '轉帳也算收支')),
    note ? h('span', { class: 'hint' }, note) : null);
}
// Monthly budgets: one bar per category with a limit, most-used first. Green until 80 %, amber up to the limit, red beyond it.
function budgetCard() {
  const list = S.st.summary.budgets || [], base = S.st.base;
  if (!list.length) return null;
  const tone = (r) => (r > 1 ? 'over' : r >= 0.8 ? 'warn' : 'ok');
  const row = (b) => h('div', { class: `bud-row ${tone(b.ratio)}` },
    h('div', { class: 'bud-top' }, catChip(b.category, 'sm'), h('b', null, b.category),
      h('span', { class: 'bud-nums' }, `${num(b.spent, base)} / ${num(b.limit, base)}`)),
    h('div', { class: 'bud-bar', role: 'progressbar', 'aria-label': `${b.category} 預算`, 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(Math.round(b.ratio * 100)) },
      h('i', { style: `width:${Math.min(100, b.ratio * 100).toFixed(1)}%` })),
    h('div', { class: 'bud-note' }, b.ratio > 1 ? `超出 ${num(b.spent - b.limit, base)}（${Math.round(b.ratio * 100)}%）` : `還可以花 ${num(b.limit - b.spent, base)}（已用 ${Math.round(b.ratio * 100)}%）`));
  const shown = S.budAll ? list : list.slice(0, 5);
  return h('section', { class: 'section bud-card' },
    h('div', { class: 'section-head' }, h('h2', null, `${S.st.summary.month.label} 預算`), h('a', { class: 'btn sm ghost', href: '#/categories' }, '調整預算')),
    h('div', { class: 'rows' }, shown.map(row),
      list.length > 5 ? h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { S.budAll = !S.budAll; renderRoute(); } }, S.budAll ? '只顯示最接近上限的 5 個' : `顯示全部 ${list.length} 個`) : null));
}
// The top of the overview: total assets, this month's balance and how it compares with last month's first days.
// How the total is made up. 資產 = the stock accounts (valued at what was paid for them); 現金流 = cash, bank and post-office accounts;
// 總資產 = both together; 總負債 = every account that is below zero; 淨資產 = 總資產 − 總負債 (this is what the book's "total" has always been).
function wealthParts() {
  let stocks = 0, cash = 0, debts = 0;
  for (const a of S.st.accounts) {
    if (a.archived && !a.balance) continue;
    const v = a.base_value; if (v == null) continue;
    if (v < 0) debts += -v; else if (a.stock) stocks += v; else cash += v;
  }
  const gross = stocks + cash;
  return { stocks, cash, debts, gross, net: gross - debts };
}
function wealthRow(w, base, cls) {
  const cell = (label, val, tone, tip) => h('div', { class: 'wp-cell', title: tip || null }, h('span', { class: 'label muted' }, label), h('b', { class: 'num ' + (tone || '') }, num(val, base)));
  return h('div', { class: 'wealth-parts ' + (cls || ''), role: 'group', 'aria-label': '總資產的組成' },
    cell('資產（股票）', w.stocks, '', '所有股票帳戶，依付出成本計算'),
    cell('現金流（現金與銀行）', w.cash, '', '現金、銀行、郵局等非股票帳戶的餘額'),
    cell('總負債', -w.debts, w.debts ? 'neg' : '', '餘額低於 0 的帳戶（例如信用卡）'),
    cell('淨資產', w.net, w.net < 0 ? 'neg' : 'pos', '淨資產 ＝ 總資產 － 總負債'));
}
function overviewTop(s, base) {
  const net = s.month.income - s.month.expense, p = s.prev_month;
  const hasPrev = p && (p.income_so_far || p.expense_so_far || p.income || p.expense);
  let delta = null;
  if (hasPrev) {
    const d = Math.round((net - (p.income_so_far - p.expense_so_far)) * 100) / 100;
    delta = d === 0 ? h('span', { class: 'w-delta' }, '和上月同期一樣')
      : h('span', { class: 'w-delta ' + (d > 0 ? 'pos' : 'neg'), title: `上月 1–${p.day} 日的結餘和這個月到今天相比` }, `比上月同期${d > 0 ? '多' : '少'} `, h('b', { class: 'num' }, num(Math.abs(d), base)));
  }
  const parts = wealthRow(wealthParts(), base);
  // phone: the four parts are one line you can slide sideways; tapping the total opens them as a grid
  const toggleParts = () => { const on = parts.classList.toggle('open'); const t = parts.parentNode && parts.parentNode.querySelector('.w-total'); if (t) t.setAttribute('aria-expanded', String(on)); };
  return h('div', { class: 'worth top' },
    h('div', { class: 'w-total', role: 'button', tabindex: '0', 'aria-expanded': 'false', title: '點一下展開／收合組成', onclick: toggleParts, onkeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleParts(); } } },
      h('div', { class: 'label' }, `總資產（${base}）`, h('span', { class: 'w-chev', 'aria-hidden': 'true' }, '▾')), h('div', { class: 'big' }, num(wealthParts().gross, base), h('small', null, base))),
    parts,
    h('div', { class: 'w-month' }, h('span', { class: 'label muted' }, `${Number(s.month.label.slice(5))} 月結餘`), h('b', { class: 'w-net ' + (net >= 0 ? 'pos' : 'neg') }, num(net, base, true)), delta),
    h('div', { class: 'month' },
      h('div', null, h('span', { class: 'label muted' }, '收入'), h('b', { class: 'pos' }, num(s.month.income, base))),
      h('div', null, h('span', { class: 'label muted' }, '支出'), h('b', { class: 'neg' }, num(s.month.expense, base)))));
}
// The overview is put together from blocks (see app-home.js): the person chooses which ones show and in what order ("自訂首頁").
// Blocks that are hidden are not even asked for their data. Warnings about the numbers themselves stay on top whatever the layout is.
async function viewOverview(view) {
  const s = S.st.summary, base = S.st.base;
  const lay = homeLayout(), shown = lay.order.filter((id) => !lay.hidden.has(id));
  const ov = S.ov || (S.ov = { y: new Date().getFullYear(), m: new Date().getMonth() + 1, edit: false, shut: {} });
  view.append(h('div', { class: 'page-head' }, h('h1', null, '總覽', eyeButton('overview')),
    h('div', { class: 'head-btns' }, h('button', { class: 'btn sm ghost home-edit-btn', type: 'button', title: '選擇總覽要顯示哪些區塊、先後順序', onclick: () => openHomeLayoutDialog() }, '自訂首頁'))));
  if (S.st.notice) view.append(h('div', { class: 'banner' }, h('span', null, S.st.notice)));
  if (s.missing_rates.length) {
    view.append(h('div', { class: 'banner' }, h('span', null, `缺少 ${s.missing_rates.join('、')} 的匯率，這些帳戶還沒有算進總資產與報表。`),
      h('a', { class: 'btn sm', href: '#/settings' }, '去填匯率')));
  }
  const make = {
    summary: () => overviewTop(s, base),
    review: () => (typeof reviewBlock === 'function' ? reviewBlock() : null),
    goals: () => (typeof goalsBlock === 'function' ? goalsBlock() : null),
    networth: () => (typeof netWorthTrend === 'function' ? netWorthTrend({ compact: true }) : null),
    reminders: () => [recurringBanner(), owedBanner(), inboxBanner()],
    tiles: () => overviewTiles(),
    budget: () => budgetCard(),
    accounts: () => homeAccounts(ov, base),
    recent: () => homeRecent(),
  };
  const built = await Promise.all(shown.map((id) => make[id]()));              // the blocks that need data ask for it side by side
  const switchAfter = shown.includes('tiles') ? 'tiles' : shown.includes('summary') ? 'summary' : null;     // the 轉帳也算收支 switch sits under the numbers it changes
  shown.forEach((id, i) => {
    const nodes = [].concat(built[i]).filter((n) => n instanceof Node);        // a block gives one element, a few of them, or nothing
    if (nodes.length) view.append(...nodes);
    if (id === switchAfter) view.append(transfersSwitch(s.month.with_transfers ? `本月含 ${s.month.transfers} 筆轉帳：轉出算支出、轉入算收入（換匯與買賣股票也是轉帳）` : ''));
  });
  if (!shown.length) view.append(h('div', { class: 'empty' }, h('b', null, '首頁的區塊都隱藏了'), '按右上角的「自訂首頁」，選擇要顯示哪些區塊。'));
}
function homeAccounts(ov, base) {
  const rows = S.st.accounts.filter((a) => !a.archived || a.balance !== 0);
  return h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, '帳戶'), h('span', { class: 'head-btns' },
      h('button', { class: 'btn sm' + (ov.editAcc ? ' primary' : ' ghost'), type: 'button', 'aria-pressed': String(!!ov.editAcc), onclick: () => { ov.editAcc = !ov.editAcc; renderRoute(); } }, ov.editAcc ? '完成' : '編輯帳戶'),
      h('button', { class: 'btn sm ghost', onclick: () => openCalibrateDialog(null) }, '校正餘額'), h('a', { class: 'btn sm ghost', href: '#/accounts' }, '管理帳戶'))),
    h('p', { class: 'hint tile-hint' }, ov.editAcc ? '點一個帳戶來換圖示、改名、校正餘額；也可以直接拖曳磚塊換位置。' : '點一下看這個帳戶的交易；連點兩下編輯帳戶與圖示；拖曳磚塊換位置（手機先按住一下再拖）。'),
    accountTiles(rows, base));
}
async function homeRecent() {
  const recent = await api('GET', '/api/transactions?limit=8');
  return h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, '最近的紀錄'), h('a', { class: 'btn sm ghost', href: '#/transactions' }, '全部交易')),
    recent.items.length ? pickableList(recent.items) : txTable(recent.items, false));
}

// -------------------------------------------------------------- transactions
// `viewer` = the account the list is filtered to. A transfer is then shown from that account's side:
// money going out is a negative amount (like spending), money coming in is positive (like income).
function amountCell(t, viewer) {
  if (t.type === 'transfer' && viewer && S.txf.transfers) {
    if (t.account_id == viewer) return money(-t.amount, t.currency, { sign: true, tone: true });
    if (t.to_account_id == viewer) return money(t.to_amount, t.to_currency, { sign: true, tone: true });
  }
  if (t.type === 'transfer') {
    const cross = t.currency !== t.to_currency;
    return h('span', { class: 'num' }, `${num(t.amount, t.currency)} ${t.currency}`, cross ? h('span', { class: 'muted' }, ` → ${num(t.to_amount, t.to_currency)} ${t.to_currency}`) : null);
  }
  if (t.settle_of && t.no_stats) return h('span', { class: 'num', title: '報帳入帳：不算收入' }, `${num(t.amount, t.currency)} ${t.currency}`);
  const signed = t.type === 'expense' ? -t.amount : t.amount;
  return money(signed, t.currency, { sign: true, tone: true });
}
// Balance after the transaction. For a transfer seen from the receiving account, show that account's balance.
function balanceCell(t, viewer) {
  if (t.type === 'transfer' && viewer && S.txf.transfers && t.to_account_id == viewer)
    return h('td', { class: 'r muted c-bal', title: `${t.account} 轉出後：${num(t.new_balance, t.currency)} ${t.currency}` }, num(t.to_new_balance, t.to_currency));
  return h('td', { class: 'r muted c-bal', title: t.type === 'transfer' ? `${t.to_account} 轉入後：${num(t.to_new_balance, t.to_currency)} ${t.to_currency}` : '' }, num(t.new_balance, t.currency));
}
// A tap or click anywhere on a transaction row opens its editor. Things inside the row that do their own job (tick box, category icon,
// tags, receipt marks, the 編輯 button) keep doing it, and so does selecting text with the mouse.
const ROW_OWN = 'button, a, input, select, textarea, label, summary, [role=button], .chip-btn, .tag-chip, .receipt-mark, .inv-pricebox';
function rowOpen(t) { return rowTap(() => openTxDialog(t)); }
function rowTap(open) {
  let down = null;
  return {
    onpointerdown: (e) => { down = [e.clientX, e.clientY]; },
    onclick: (e) => {
      if (e.target.closest(ROW_OWN)) return;
      if (down && Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 6) return;       // a drag is not a tap
      const sel = window.getSelection && window.getSelection();
      if (sel && String(sel).length && e.pointerType !== 'touch') return;
      open();
    },
    onkeydown: (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target === e.currentTarget) { e.preventDefault(); open(); } },
  };
}
// One tap and two quick taps on the same row do different things (the single tap waits a moment to see whether a second one follows).
function rowTapDouble(single, dbl) {
  let timer = 0;
  return rowTap(() => { if (timer) { clearTimeout(timer); timer = 0; dbl(); } else timer = setTimeout(() => { timer = 0; single(); }, 280); });
}
const isPhone = () => window.matchMedia(PHONE_Q).matches;
const VIRTUAL_MIN = 30;                  // a day-grouped list with this many lines is drawn a window at a time (virtualBody in app-list.js)

// Record a past transaction again: the quick-add dialog opens with its fields filled in (time = now, no photos, no receipts).
function entryFromTx(tx) {
  return { type: tx.type, account_id: tx.account_id, to_account_id: tx.to_account_id, amount: String(tx.amount), to_amount: tx.to_amount == null ? '' : String(tx.to_amount),
    category: tx.category, note: tx.note, tags: (tx.tags || []).join(' '), advance: tx.advance || '', counterparty: tx.counterparty || '', due: tx.due || '',
    auto_settle: tx.auto_account_id || '', no_budget: !!tx.no_budget, no_stats: !!tx.no_stats };
}
async function swipeDelete(t) {
  S.sel.delete(t.id);
  try { const r = await api('DELETE', `/api/transactions/${t.id}`); await afterChange('已刪除（可以按「復原」）', undoAction(r.undo)); } catch (e) { fail(e); }
}
// One transaction line. On a phone it also slides sideways: left deletes (with 復原), right records the same thing again.
function txRowEl(t, withBalance, viewer, sel, days) {
  const tr = h('tr', { class: (sel && S.sel.has(t.id) ? 'picked ' : '') + 'tx-row', tabindex: '0', title: '點一下編輯這筆', ...rowOpen(t),
    ...(days ? { 'data-of': t.time.slice(0, 10), hidden: days.folded.has(t.time.slice(0, 10)) } : {}) },
    sel ? h('td', { class: 'c-sel' }, h('input', { type: 'checkbox', checked: S.sel.has(t.id), 'aria-label': `選取 ${shortTime(t.time)} ${t.note || t.category || ''}`, onchange: (e) => { if (e.target.checked) S.sel.add(t.id); else S.sel.delete(t.id); e.target.closest('tr').classList.toggle('picked', e.target.checked); sel.changed(); } })) : null,
    h('td', { class: 'when', title: shortTime(t.time) }, h('span', { class: 'yr' }, t.time.slice(0, 5)), shortTime(t.time).slice(5)),
    h('td', { class: 'c-kind' }, t.settle_of && t.no_stats ? h('span', { class: 'kind transfer', title: '公司還你的報帳款：視為轉帳，不是收入，也不算進收支統計' }, '轉帳') : h('span', { class: `kind ${t.type}`, title: t.settle_of ? '朋友還你的錢：算成收入' : '' }, TYPE_LABEL[t.type])),
    h('td', { class: 'c-cat' }, t.type === 'transfer' || t.type === 'adjust' || (t.settle_of && t.no_stats) ? typeChip(t.settle_of ? 'transfer' : t.type)
      : h('button', { class: 'chip-btn', type: 'button', title: `更換「${t.category || '未分類'}」的圖示`, 'aria-label': `更換「${t.category || '未分類'}」的圖示`, onclick: () => editCategoryIcon(t.category || '未分類') }, catChip(t.category || '未分類')),
      h('span', { class: 'cat-name' }, t.category || '')),
    h('td', { class: 'note', title: t.note }, t.note, advBadge(t), receiptMark(t), tagChips(t)),
    h('td', { class: 'c-acct' }, t.type === 'transfer' ? `${t.account} → ${t.to_account}` : t.settle_of && t.settle_from ? `${t.settle_from} → ${t.account}` : t.account),
    h('td', { class: 'r c-amt' }, amountCell(t, viewer)),
    withBalance ? balanceCell(t, viewer) : null,
    h('td', { class: 'act' }, h('button', { class: 'btn sm ghost', onclick: () => openTxDialog(t) }, '編輯')));
  tr._tx = t;                                                                      // the keyboard on the list (app-listkeys.js) needs the entry behind a line
  if (isPhone() && onTouch() && typeof enableSwipe === 'function') enableSwipe(tr, { onLeft: () => swipeDelete(t), onRight: t.settle_of ? null : () => openQuickAdd({ seed: entryFromTx(t), title: '再記一筆' }) });
  return tr;
}
function txTable(items, withBalance = true, viewer = null, sel = null, days = null) {
  if (!items.length) return h('div', { class: 'empty' }, h('b', null, '還沒有符合的交易'), '用上方的「記一筆」開始記帳。');
  const cols = (sel ? 1 : 0) + 7 + (withBalance ? 1 : 0);
  const head = h('thead', null, h('tr', null, sel ? h('th', { class: 'c-sel' }, '') : null, h('th', null, '時間'), h('th', null, '類型'), h('th', null, '類別'), h('th', null, '備註'), h('th', null, '帳戶'), h('th', { class: 'r' }, '金額'), withBalance ? h('th', { class: 'r c-bal' }, '餘額') : null, h('th', { class: 'c-act' }, '')));
  const dayOf = (t) => t.time.slice(0, 10);
  const swipeCls = isPhone() && onTouch() ? ' swipe' : '';
  if (days && typeof virtualBody === 'function' && items.length >= VIRTUAL_MIN) {         // thousands of lines: only the ones near the screen exist
    const entries = () => { const out = []; let last = ''; for (const t of items) { const d = dayOf(t); if (d !== last) { out.push({ key: 'd' + d, kind: 'day', day: d, folded: days.folded.has(d) }); last = d; } if (!days.folded.has(d)) out.push({ key: 't' + t.id, kind: 'tx', t }); } return out; };
    const tbody = h('tbody'); let v;
    const flip = (key) => { if (days.folded.has(key)) days.folded.delete(key); else days.folded.add(key); v.setEntries(entries()); const b = tbody.querySelector(`tr[data-day="${key}"] .day-toggle`); if (b) b.focus({ preventScroll: true }); };
    const table = h('table', { class: 'ledger tx virt' + swipeCls }, head, tbody);
    v = virtualBody(tbody, entries(), (e) => e.kind === 'day' ? dayHeadRow(days.map[e.day], e.day, days.base, cols, days.folded.has(e.day), flip) : txRowEl(e.t, withBalance, viewer, sel, null),
      { cols, estimate: isPhone() ? { day: 46, tx: 92 } : { day: 40, tx: 44 } });
    table._virt = v;
    table._update = (nextItems, nextDays) => { items = nextItems; days = nextDays; v.setEntries(entries()); };      // more lines arrived or days were folded: the lines already drawn stay
    return table;
  }
  return h('table', { class: 'ledger tx' + swipeCls }, head,
    h('tbody', null, items.flatMap((t, i) => [days && (i === 0 || dayOf(items[i - 1]) !== dayOf(t))
      ? dayHeadRow(days.map[dayOf(t)], dayOf(t), days.base, cols, days.folded.has(dayOf(t)),
        (key, row) => { const now = !days.folded.has(key); if (now) days.folded.add(key); else days.folded.delete(key); toggleDay(row.closest('table'), row, key, now); }) : null,
    txRowEl(t, withBalance, viewer, sel, days)].filter(Boolean))));
}

// The row under the search bar: income / expense over EVERY transaction that matches (not just the rows loaded below).
function tallyBar(r, filtered, onToggle) {
  const t = r.totals, base = t.base, c = t.count;
  const cell = (label, value, cls) => h('div', { class: 'tally-cell' }, h('span', { class: 'tally-label' }, label), h('b', { class: `tally-val ${cls}` }, value, h('span', { class: 'ccy' }, base)));
  const side = [];
  if (c.transfer) {
    if (t.transfers_counted) side.push(`含 ${c.transfer} 筆轉帳：轉出的帳戶算支出，轉入的帳戶算收入${t.both_sides ? '（沒有指定帳戶，所以兩邊都算，淨額不變）' : ''}`);
    else side.push(`另有 ${c.transfer} 筆轉帳沒有算進去`);
  }
  if (c.adjust) side.push(`${c.adjust} 筆歸零調整不算收入或支出`);
  const foreign = t.by_currency.filter((x) => x.currency !== base);
  if (foreign.length) side.push(`含 ${foreign.map((x) => x.currency).join('、')}，已依目前匯率換算成 ${base}`);
  if (t.missing_rates.length) side.push(`缺少 ${t.missing_rates.join('、')} 的匯率，這些金額沒有算進去`);
  return h('div', { class: 'tally', role: 'status', 'aria-label': '符合條件的統計' },
    h('div', { class: 'tally-cell' }, h('span', { class: 'tally-label' }, filtered ? '符合條件' : '全部交易'), h('b', { class: 'tally-val' }, `${r.total} 筆`)),
    cell('總收入', num(t.income, base), 'pos'),
    cell('總支出', num(t.expense, base), 'neg'),
    cell('淨額（收入 − 支出）', num(t.net, base, true), t.net >= 0 ? 'pos' : 'neg'),
    ...(() => {
      const toggle = h('label', { class: 'tally-toggle' }, h('input', { type: 'checkbox', checked: S.txf.transfers, onchange: (e) => onToggle(e.target.checked) }), h('span', null, '顯示轉帳'), h('small', { class: 'muted', title: '只影響這一頁的清單與合計，不會改動總覽、月曆、報表的「轉帳也算收支」設定' }, '（只影響這頁）'));
      const note = side.length ? h('div', { class: 'tally-note hint' }, side.join('；')) : null;
      return isPhone() ? [h('details', { class: 'tally-more' }, h('summary', null, '轉帳與換算說明'), toggle, note)] : [toggle, note];     // a phone keeps the list near the top: the small print folds away
    })());
}

const TX_TYPE_NAME = { income: '收入', expense: '支出', transfer: '轉帳', adjust: '調整' };
// The filters in force, as small tags (phone): tap one to take it off.
function filterChips(f) {
  const day = (v) => (v ? (v.slice(0, 4) === String(new Date().getFullYear()) ? v.slice(5).replace('-', '/') : v) : '…');
  const out = [], add = (label, clear) => out.push(h('button', { class: 'fchip', type: 'button', 'aria-label': `移除篩選：${label}`, onclick: () => { clear(); f.limit = TX_PAGE; f.back = null; renderRoute(); } }, h('span', null, label), h('b', { 'aria-hidden': 'true' }, '×')));
  if (f.q) add(`搜尋：${f.q}`, () => { f.q = ''; });
  if (f.type) add(TX_TYPE_NAME[f.type] || f.type, () => { f.type = ''; });
  if (f.account_id) add(acct(f.account_id) ? acct(f.account_id).name : '帳戶', () => { f.account_id = ''; });
  if (f.tag) add(`#${f.tag}`, () => { f.tag = ''; });
  if (f.from || f.to) add(`${day(f.from)} ~ ${day(f.to)}`, () => { f.from = ''; f.to = ''; });
  out.push(h('button', { class: 'fchip clear', type: 'button', onclick: () => { Object.assign(f, { q: '', type: '', account_id: '', from: '', to: '', tag: '', limit: TX_PAGE, back: null }); renderRoute(); } }, '全部清除'));
  return h('div', { class: 'fchips', role: 'group', 'aria-label': '目前的篩選' }, out);
}
// Phone: all the filters in one dialog.
function openTxFilterDialog(f) {
  const d = { q: f.q, type: f.type, account_id: f.account_id, tag: f.tag, from: f.from, to: f.to };
  const tags = [...new Set([...(S.st.tag_list || []).map((x) => x.tag), ...(f.tag ? [f.tag] : [])])];
  const body = h('div', { class: 'rows', style: 'padding:0;max-width:none' },
    h('label', { class: 'field' }, h('span', null, '搜尋'), h('input', { type: 'search', value: d.q, placeholder: '備註、類別、帳戶、標籤', autocomplete: 'off', oninput: (e) => { d.q = e.target.value; } })),
    h('label', { class: 'field' }, h('span', null, '類型'), h('select', { onchange: (e) => { d.type = e.target.value; } },
      [['', '全部'], ['income', '收入'], ['expense', '支出'], ['transfer', '轉帳'], ['adjust', '調整']].map(([v, l]) => h('option', { value: v, selected: d.type === v }, l)))),
    h('label', { class: 'field' }, h('span', null, '帳戶'), h('select', { onchange: (e) => { d.account_id = e.target.value; } },
      h('option', { value: '' }, '全部'), S.st.accounts.map((a) => h('option', { value: a.id, selected: String(a.id) === String(d.account_id) }, a.name)))),
    tags.length ? h('label', { class: 'field' }, h('span', null, '標籤'), h('select', { onchange: (e) => { d.tag = e.target.value; } },
      h('option', { value: '' }, '全部'), tags.map((t) => h('option', { value: t, selected: t === d.tag }, `#${t}`)))) : null,
    h('label', { class: 'field' }, h('span', null, '從'), h('input', { type: 'date', value: d.from, onchange: (e) => { d.from = e.target.value; } })),
    h('label', { class: 'field' }, h('span', null, '到'), h('input', { type: 'date', value: d.to, onchange: (e) => { d.to = e.target.value; } })));
  openDialog({
    title: '篩選交易', body,
    extraFoot: h('button', { class: 'btn', type: 'button', style: 'margin-right:auto', onclick: (e) => { Object.assign(f, { q: '', type: '', account_id: '', from: '', to: '', tag: '', limit: TX_PAGE, back: null }); e.target.closest('dialog').close(); renderRoute(); } }, '清除'),
    primary: { label: '套用', run: async () => { Object.assign(f, d, { limit: TX_PAGE, back: null }); renderRoute(); } },
  });
}
async function viewTransactions(view) {
  const f = S.txf;
  const phone = isPhone();
  const nFilters = [f.q, f.type, f.account_id, f.tag, f.from || f.to].filter(Boolean).length;
  if (phone) {                                  // the list comes first: a filter button, the filters in force as small tags, and a + button for a new entry
    view.append(h('div', { class: 'page-head tx-head' }, h('h1', null, '交易', eyeButton('transactions')),
      h('button', { class: 'btn' + (nFilters ? ' primary' : ''), type: 'button', 'aria-haspopup': 'dialog', onclick: () => openTxFilterDialog(f) }, nFilters ? `篩選（${nFilters}）` : '篩選')));
    if (nFilters) view.append(filterChips(f));
  } else view.append(h('div', { class: 'page-head' }, h('h1', null, '交易', eyeButton('transactions'))), entryBar());
  const listBox = h('div');
  const tallyBox = h('div');
  const selBox = h('div');
  let timer, shown = [];
  const paintBar = () => { selBox.replaceChildren(...(S.sel.size ? [selectionBar(shown, (full) => { if (full) paintList(); else paintBar(); })] : [])); };
  const paintList = (r, keep) => {                                     // keep: the same list got longer or days were folded, so the table already drawn is updated instead of made again
    if (r) listBox._r = r;
    r = listBox._r; if (!r) return;
    const base = r.totals.base;
    if (f.group === 'month' || f.group === 'year') {                     // one line per month / year; a click goes one level down
      shown = [];
      listBox.replaceChildren(periodTable(r.groups || [], f.group, base, (key) => {
        const [from, to] = periodRange(f.group, key);
        f.back = { group: f.group, from: f.from, to: f.to };
        Object.assign(f, { from, to, group: f.group === 'year' ? 'month' : 'day', limit: TX_PAGE });
        renderRoute();
      }), h('div', { class: 'hint', style: 'padding:10px' }, `共 ${r.total} 筆，${(r.groups || []).length} 個${f.group === 'year' ? '年' : '月'}　點一列看${f.group === 'year' ? '每月' : '每日'}明細`));
      paintBar();
      return;
    }
    shown = r.items;
    const live = new Set(shown.map((t) => t.id));
    S.sel.forEach((id) => { if (!live.has(id)) S.sel.delete(id); });       // a filter hid it: it is no longer selected
    const days = { base, folded: f.folded, map: Object.fromEntries((r.groups || []).map((g) => [g.key, g])) };
    const drawn = keep && listBox.children.length === 2 ? listBox.children[0] : null;
    if (drawn && drawn._update && r.items.length >= VIRTUAL_MIN) {
      drawn._update(r.items, days);
      listBox.children[1].replaceWith(moreBox(r));
      paintBar();
      return;
    }
    const table = txTable(r.items, true, f.account_id, { changed: paintBar }, days);
    listBox.replaceChildren(table, moreBox(r));
    if (table._virt) table._virt.refresh();
    paintBar();
  };
  // Under the list: how many are shown, and the rest arrives by itself as the end comes near (or press the button)
  let loadingMore = false;
  const more = async () => {
    const r0 = listBox._r;
    if (!r0 || loadingMore || r0.items.length >= r0.total) return;
    loadingMore = true;
    try {
      const qs = txQuery(); qs.set('limit', '300'); qs.set('offset', String(r0.items.length));
      const r = await api('GET', '/api/transactions?' + qs);
      if (listBox._r !== r0) return;                                    // the filters changed meanwhile
      const have = new Set(r0.items.map((x) => x.id)), keys = new Set((r0.groups || []).map((g) => g.key));
      const fresh = r.items.filter((x) => !have.has(x.id));
      if (!fresh.length) r0.exhausted = true;                           // nothing new came: stop asking by itself (the button still works)
      r0.items = r0.items.concat(fresh);
      r0.groups = (r0.groups || []).concat((r.groups || []).filter((g) => !keys.has(g.key)));
      paintList(r0, true);
    } catch (e) { fail(e); } finally { loadingMore = false; }
  };
  const moreBox = (r) => {
    if (r.total <= r.items.length) return h('div', { class: 'hint', style: 'padding:10px' }, `共 ${r.total} 筆`);
    const box = h('div', { class: 'more-box', style: 'padding:14px 0;text-align:center' }, h('span', { class: 'muted' }, `顯示 ${r.items.length} / ${r.total} 筆　`), h('button', { class: 'btn sm', type: 'button', onclick: more }, '載入更多'));
    if ('IntersectionObserver' in window && !r.exhausted) {
      const io = new IntersectionObserver((es) => { if (es.some((x) => x.isIntersecting)) { io.disconnect(); more(); } }, { rootMargin: '900px 0px' });
      setTimeout(() => io.observe(box), 0);
    }
    return box;
  };
  const txQuery = () => {
    const qs = new URLSearchParams({ limit: f.limit, group: f.group });
    if (f.tag) qs.set('tag', f.tag);
    if (!f.transfers) qs.set('transfers', '0');
    if (f.q) qs.set('q', f.q); if (f.type) qs.set('type', f.type); if (f.account_id) qs.set('account_id', f.account_id);
    if (f.from) qs.set('from', f.from); if (f.to) qs.set('to', f.to);
    return qs;
  };
  const load = async () => {
    try {
      const r = await api('GET', '/api/transactions?' + txQuery());
      tallyBox.replaceChildren(tallyBar(r, !!(f.q || f.type || f.account_id || f.from || f.to || f.tag), (on) => { f.transfers = on; f.limit = TX_PAGE; load(); }));
      paintList(r);
    } catch (e) { tallyBox.replaceChildren(); selBox.replaceChildren(); listBox._r = null; listBox.replaceChildren(h('div', { class: 'empty' }, e.message)); }
  };
  view.append(h('div', { class: 'period-bar' },
    periodSwitch(f.group, (k) => { f.group = k; f.back = null; f.limit = TX_PAGE; renderRoute(); }),
    f.group === 'day' ? h('span', { class: 'fold-btns' },
      h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { const r = listBox._r; if (r) { (r.groups || []).forEach((g) => f.folded.add(g.key)); paintList(undefined, true); } } }, '全部收合'),
      h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { f.folded.clear(); paintList(undefined, true); } }, '全部展開')) : null,
    f.back ? h('button', { class: 'btn ghost', type: 'button', onclick: () => {
      const b = f.back; Object.assign(f, { group: b.group, from: b.from, to: b.to, back: null, limit: TX_PAGE }); renderRoute();
    } }, `‹ 返回按${f.back.group === 'year' ? '年' : '月'}`) : null));
  if (!phone) view.append(h('div', { class: 'filters' },
    h('label', { class: 'field' }, h('span', null, '搜尋'), h('input', { type: 'search', value: f.q, placeholder: '備註、類別、帳戶、標籤', oninput: (e) => { f.q = e.target.value; clearTimeout(timer); timer = setTimeout(() => { f.limit = 100; load(); }, 250); } })),
    h('label', { class: 'field' }, h('span', null, '類型'), h('select', { onchange: (e) => { f.type = e.target.value; load(); } },
      [['', '全部'], ['income', '收入'], ['expense', '支出'], ['transfer', '轉帳'], ['adjust', '調整']].map(([v, l]) => h('option', { value: v, selected: f.type === v }, l)))),
    h('label', { class: 'field' }, h('span', null, '帳戶'), h('select', { onchange: (e) => { f.account_id = e.target.value; load(); } },
      h('option', { value: '' }, '全部'), S.st.accounts.map((a) => h('option', { value: a.id, selected: String(a.id) === String(f.account_id) }, a.name)))),
    (S.st.tag_list && S.st.tag_list.length) || f.tag ? h('label', { class: 'field' }, h('span', null, '標籤'), h('select', { onchange: (e) => { f.tag = e.target.value; f.limit = 100; load(); } },
      h('option', { value: '' }, '全部'), ...[...new Set([...(S.st.tag_list || []).map((x) => x.tag), ...(f.tag ? [f.tag] : [])])].map((t) => h('option', { value: t, selected: t === f.tag }, `#${t}`)))) : null,
    h('label', { class: 'field' }, h('span', null, '從'), h('input', { type: 'date', value: f.from, onchange: (e) => { f.from = e.target.value; load(); } })),
    h('label', { class: 'field' }, h('span', null, '到'), h('input', { type: 'date', value: f.to, onchange: (e) => { f.to = e.target.value; load(); } })),
    h('button', { class: 'btn ghost', onclick: () => { Object.assign(f, { q: '', type: '', account_id: '', from: '', to: '', tag: '', limit: TX_PAGE, back: null }); renderRoute(); } }, '清除篩選')));
  if (phone && onTouch() && lsGet('pw_swipe_hint') !== '1') view.append(h('div', { class: 'swipe-hint', role: 'note' }, h('span', null, '小提示：交易往左滑是刪除（可以復原），往右滑是「再記一筆」。'),
    h('button', { class: 'btn sm ghost', type: 'button', onclick: (e) => { lsSet('pw_swipe_hint', '1'); e.target.closest('.swipe-hint').remove(); } }, '知道了')));
  view.append(tallyBox, selBox, listBox);
  if (phone) view.append(h('button', { class: 'fab', type: 'button', 'aria-label': '記一筆', title: '記一筆', onclick: () => openQuickAdd({}) }, h('span', { 'aria-hidden': 'true' }, '+')));
  if (S.focusAdd) {
    S.focusAdd = false;
    S.afterShow = phone ? () => openQuickAdd({}) : () => { const a = $('input[name=amount]'); if (a) { a.scrollIntoView({ block: 'center' }); if (!onTouch()) a.focus(); } };
  }
  await load();
}

// ------------------------------------------------------------------ accounts
function currencyInput(value, disabled) {
  return h('label', { class: 'field' }, h('span', null, '幣別'),
    h('input', { name: 'currency', list: 'ccy-list', value, maxlength: 3, disabled, autocomplete: 'off', style: 'text-transform:uppercase' }),
    h('datalist', { id: 'ccy-list' }, S.st.currencies.map((c) => h('option', { value: c }))));
}
function openAccountDialog(a) {
  const isNew = !a;
  const name = h('input', { name: 'name', value: a ? a.name : '', maxlength: 40, autocomplete: 'off', placeholder: '例如 Wise USD、玉山銀行' });
  const cur = currencyInput(a ? a.currency : S.st.base, a && a.tx_count > 0);
  const opening = h('input', { name: 'opening', inputmode: 'decimal', value: a ? String(a.opening) : '0', autocomplete: 'off' });
  // icon: '' / '' = chosen automatically (bank, stock, cash...) until the user picks one
  const pick = { icon: a ? a.icon : '', color: a ? a.color : '' };
  const iconBtn = h('button', { class: 'btn ghost icon-pick', type: 'button' });
  const paintIcon = () => {
    const l = accLook({ name: name.value, stock: a && a.stock, icon: pick.icon, color: pick.color });
    iconBtn.replaceChildren(chipEl(l.icon, l.color), h('span', null, pick.icon || pick.color ? '更換圖示' : '圖示：自動（點一下更換）'));
  };
  iconBtn.addEventListener('click', () => {
    const l = accLook({ name: name.value, stock: a && a.stock, icon: pick.icon, color: pick.color });
    openIconPicker({ title: '帳戶圖示', sub: '這個帳戶會用這個圖示', name: name.value || '帳戶', icon: l.icon, color: l.color,
      onSave: async (icon, color) => { pick.icon = icon; pick.color = color; paintIcon(); },
      onReset: (pick.icon || pick.color) ? async () => { pick.icon = ''; pick.color = ''; paintIcon(); } : null });
  });
  name.addEventListener('input', paintIcon); paintIcon();
  const body = h('div', { class: 'rows', style: 'padding:0;max-width:none' },
    h('label', { class: 'field' }, h('span', null, '帳戶名稱'), name),
    h('div', { class: 'field' }, h('span', null, '圖示'), iconBtn),
    h('div', { class: 'grid2' }, cur,
      h('label', { class: 'field' }, h('span', null, '期初餘額'), opening, h('span', { class: 'hint' }, '開始記帳前，這個帳戶裡原本有的金額'))),
    a && a.tx_count > 0 ? h('p', { class: 'hint' }, '這個帳戶已有交易，幣別無法更改。') : null);
  const foot = a ? h('div', { style: 'margin-right:auto;display:flex;gap:8px' },
    h('button', { class: 'btn', type: 'button', onclick: async (e) => { try { await api('PUT', `/api/accounts/${a.id}`, { archived: !a.archived }); e.target.closest('dialog').close(); await afterChange(a.archived ? '已取消封存' : '已封存，帳戶清單不再顯示'); } catch (err) { fail(err); } } }, a.archived ? '取消封存' : '封存'),
    h('button', { class: 'btn danger', type: 'button', disabled: a.tx_count > 0, title: a.tx_count > 0 ? '有交易的帳戶不能刪除；請先「歸零」並選擇清除紀錄' : '', onclick: async (e) => {
      const dlg = e.target.closest('dialog');
      if (!(await confirmBox({ title: `刪除帳戶「${a.name}」？`, message: h('p', null, '這個帳戶沒有任何交易，刪除後無法復原。'), confirmLabel: '刪除', danger: true }))) return;
      try { await api('DELETE', `/api/accounts/${a.id}`); dlg.close(); await afterChange('已刪除帳戶'); } catch (err) { fail(err); }
    } }, '刪除帳戶')) : null;
  openDialog({
    title: isNew ? '新增帳戶' : `編輯帳戶：${a.name}`, body, extraFoot: foot,
    primary: {
      label: isNew ? '新增帳戶' : '儲存',
      run: async () => {
        const data = { name: name.value, opening: opening.value, icon: pick.icon, color: pick.color };
        const ccy = cur.querySelector('input').value.trim().toUpperCase();
        if (isNew || !cur.querySelector('input').disabled) data.currency = ccy;
        if (isNew) await api('POST', '/api/accounts', data); else await api('PUT', `/api/accounts/${a.id}`, data);
        const needRate = ccy && ccy !== S.st.base && !S.st.rates.rates.some((r) => r.currency === ccy && r.rate);
        await afterChange(isNew ? `已新增帳戶「${data.name}」` : '已儲存');
        if (needRate) toast(`${ccy} 還沒有匯率，請到「設定」填寫，才會算進總資產。`);
      },
    },
  });
}

// Balance calibration: pick an account, see what the book says, type what the bank really shows; the gap is
// recorded as an ordinary income/expense (category "difference", note "誤差").
function openCalibrateDialog(first) {
  const pool = S.st.accounts.filter((a) => !a.archived && !a.stock);
  if (!pool.length) return toast('沒有可以校正的帳戶');
  const byId = (id) => pool.find((a) => String(a.id) === String(id)) || pool[0];
  let acct = byId(first && first.id);
  const sel = h('select', { name: 'account', 'aria-label': '帳戶', onchange: (e) => { acct = byId(e.target.value); paint(); } },
    pool.map((a) => h('option', { value: a.id, selected: a.id === acct.id }, `${a.name}（${a.currency}）`)));
  const nowBox = h('div', { class: 'cal-now' });
  const actual = h('input', { name: 'actual', autocomplete: 'off', autocapitalize: 'off', placeholder: '帳戶實際顯示的餘額', 'aria-label': '實際餘額', oninput: () => paint() });
  const preview = h('div', { class: 'cal-preview', role: 'status' });
  const read = () => {
    const t = actual.value.replace(/[,\s]/g, '').replace('−', '-');
    if (t === '' || !/^-?\d*\.?\d+$/.test(t)) return null;
    return Number(t);
  };
  function paint() {
    nowBox.replaceChildren(h('span', { class: 'muted' }, '目前餘額（帳上）'), h('b', { class: 'num' + (acct.balance < 0 ? ' neg' : '') }, num(acct.balance, acct.currency, false, true), h('span', { class: 'ccy' }, acct.currency)));
    const v = read(), d = digits(acct.currency), k = 10 ** d;
    if (actual.value.trim() === '') { preview.className = 'cal-preview'; preview.textContent = '輸入實際餘額，這裡會顯示差額與會記下的內容。'; return; }
    if (v == null) { preview.className = 'cal-preview bad'; preview.textContent = '請輸入數字，例如 12345.6'; return; }
    const diff = Math.round(v * k - acct.balance * k) / k;
    if (diff === 0) { preview.className = 'cal-preview'; preview.textContent = '和帳上餘額一樣，不需要校正。'; return; }
    preview.className = 'cal-preview ' + (diff > 0 ? 'pos' : 'neg');
    preview.replaceChildren(
      h('div', null, `差額 `, h('b', { class: 'num' }, num(diff, acct.currency, true, true)), ` ${acct.currency}　→　記一筆`, h('b', null, diff > 0 ? '收入' : '支出'), `，`, h('b', { class: 'num' }, num(Math.abs(diff), acct.currency, false, true)), ` ${acct.currency}`),
      h('div', { class: 'muted' }, '類別 difference、備註「誤差」；校正後帳上餘額 = ', h('b', { class: 'num' }, num(v, acct.currency, false, true)), ` ${acct.currency}`));
  }
  const body = h('div', { class: 'rows', style: 'padding:0;max-width:none' },
    h('label', { class: 'field' }, h('span', null, '帳戶'), sel), nowBox,
    h('label', { class: 'field' }, h('span', null, '實際餘額'), actual), preview,
    h('p', { class: 'hint', style: 'margin:0' }, '漏記帳時用：差額會記成一筆收入（帳上比實際少）或支出（帳上比實際多），之後可以在「交易」頁看到或刪除。'));
  paint();
  openDialog({
    title: '校正帳戶餘額', body,
    primary: {
      label: '校正',
      run: async () => {
        if (read() == null) throw new Error('請輸入實際餘額（數字）');
        const r = await api('POST', `/api/accounts/${acct.id}/calibrate`, { actual: actual.value.replace(/[,\s]/g, '').replace('−', '-'), current: acct.balance });
        if (!r.changed) throw new Error('和帳上餘額一樣，不需要校正');
        await afterChange(`「${acct.name}」已校正：記了一筆${r.type === 'income' ? '收入' : '支出'} ${num(r.amount, r.currency, false, true)} ${r.currency}`);
      },
    },
  });
}

async function openResetDialog(a) {
  let prev;
  try { prev = await api('GET', `/api/accounts/${a.id}/wipe-preview`); } catch (e) { return fail(e); }
  let mode = 'adjust';
  const radios = [
    ['adjust', '保留紀錄，餘額調為 0', `新增一筆「歸零調整」交易（${num(-a.balance, a.currency, true)} ${a.currency}），之前的紀錄都留著，也不會算進收入或支出。`],
    ['wipe', '清除這個帳戶的所有紀錄，從零開始', `刪除 ${prev.count} 筆交易並把期初餘額設為 0。適合輸入錯誤太多、想重來的帳戶。執行前會自動備份。`],
  ];
  const warn = h('div', { class: 'banner', hidden: true });
  const typed = h('input', { type: 'text', autocomplete: 'off', 'aria-label': '輸入帳戶名稱確認' });
  const typedBox = h('label', { class: 'field', hidden: true }, h('span', null, `請輸入帳戶名稱「${a.name}」以確認`), typed);
  const sync = () => {
    warn.hidden = !(mode === 'wipe' && prev.transfers > 0);
    typedBox.hidden = mode !== 'wipe';
    const go = document.querySelector('dialog[open] button[type=submit]');
    if (go) { go.classList.toggle('danger', mode === 'wipe'); go.classList.toggle('solid', mode === 'wipe'); go.textContent = mode === 'wipe' ? '清除紀錄並歸零' : '歸零'; }
    if (!warn.hidden) warn.replaceChildren(`其中 ${prev.transfers} 筆是轉帳，刪除後「${prev.affected_accounts.join('、')}」的餘額也會跟著改變。`);
  };
  const body = h('div', { class: 'rows', style: 'padding:0;max-width:none' },
    h('p', { style: 'margin:0' }, `目前餘額：`, money(a.balance, a.currency, { tone: true })),
    radios.map(([v, t, d]) => h('label', { class: 'choice' }, h('input', { type: 'radio', name: 'mode', checked: v === 'adjust', onchange: () => { mode = v; sync(); } }), h('span', null, h('b', null, t), h('br'), h('span', { class: 'muted' }, d)))),
    warn, typedBox);
  openDialog({
    title: `歸零：${a.name}`, body,
    primary: {
      label: '歸零', danger: false,
      run: async () => {
        if (mode === 'wipe' && typed.value.trim() !== a.name) throw new Error('帳戶名稱不相符');
        const r = await api('POST', `/api/accounts/${a.id}/reset`, { mode });
        await afterChange(!r.changed ? '這個帳戶的餘額本來就是 0' : mode === 'adjust' ? `「${a.name}」已歸零` : `已清除 ${r.deleted} 筆交易，「${a.name}」已歸零（備份在 backups 資料夾）`);
      },
    },
  });
}

// Phone: one line per account (picture, name, balance); a tap opens the rest of it (opening balance, worth in the main currency, actions).
function accountList(rows, base) {
  return h('div', { class: 'acc-list' }, rows.map((a) => h('details', { class: 'acc-item' + (a.archived ? ' archived' : '') },
    h('summary', null, accChip(a, 'sm'), h('span', { class: 'acc-name' }, h('span', { class: 'acc-title' }, a.name), h('span', { class: 'badge' }, a.currency)),
      h('span', { class: 'acc-bal' }, money(a.balance, a.currency, { tone: true, tag: false })), h('span', { class: 'acc-chev', 'aria-hidden': 'true' }, '›')),
    h('div', { class: 'acc-more' },
      h('dl', null,
        h('div', null, h('dt', null, '期初餘額'), h('dd', null, num(a.opening, a.currency))),
        h('div', null, h('dt', null, `約合 ${base}`), h('dd', null, a.currency === base ? '—' : (a.base_value == null ? '需要匯率' : num(a.base_value, base)))),
        h('div', null, h('dt', null, '交易數'), h('dd', null, String(a.tx_count)))),
      h('div', { class: 'acc-acts' },
        h('button', { class: 'btn sm', type: 'button', onclick: () => openAccountDialog(a) }, '編輯'),
        a.archived || a.stock ? null : h('button', { class: 'btn sm', type: 'button', onclick: () => openCalibrateDialog(a) }, '校正'),
        h('button', { class: 'btn sm', type: 'button', onclick: () => openResetDialog(a) }, '歸零'),
        h('button', { class: 'btn sm ghost', type: 'button', onclick: () => { S.txf.account_id = String(a.id); S.txf.back = null; S.txf.limit = TX_PAGE; location.hash = '#/transactions'; } }, '看交易'))))));
}
// The net worth at the top: what you own, what you owe, and the total, in the main currency.
function netWorthCard(accounts, base) {
  const w = wealthParts(), missing = S.st.summary.missing_rates || [];
  return h('div', { class: 'net-card' },
    h('div', { class: 'net-main' }, h('span', { class: 'label muted' }, `總資產（${base}）`), h('b', { class: 'big num' }, num(w.gross, base), h('small', null, base))),
    wealthRow(w, base, 'in-card'),
    missing.length ? h('div', { class: 'hint net-note' }, `缺少 ${missing.join('、')} 的匯率，這些帳戶還沒有算進去。`) : null);
}
// The accounts page in the same three parts as the total on the overview: stock accounts, cash / bank accounts and debts (below zero, or a credit card).
function accountGroups(rows) {
  const isCard = (a) => /信用卡|credit|visa|master|jcb/i.test(a.name || '');
  const kind = (a) => ((a.base_value != null && a.base_value < 0) || (isCard(a) && !a.stock && !(a.base_value > 0)) ? 'debt' : a.stock ? 'stock' : 'cash');
  const defs = [['stock', '資產（股票）'], ['cash', '現金流（現金與銀行）'], ['debt', '負債']];
  return defs.map(([k, title]) => {
    const r = rows.filter((a) => kind(a) === k);
    const sum = r.reduce((t, a) => t + (a.base_value == null ? 0 : k === 'debt' ? Math.min(0, a.base_value) : a.base_value), 0);
    return { kind: k, title, rows: r, sum };
  }).filter((g) => g.rows.length);
}
async function viewAccounts(view) {
  const base = S.st.base, phone = isPhone();
  const active = S.st.accounts.filter((a) => !a.archived), archived = S.st.accounts.filter((a) => a.archived);
  const table = (rows) => h('table', { class: 'ledger' },
    h('thead', null, h('tr', null, h('th', null, '帳戶'), h('th', { class: 'r' }, '期初餘額'), h('th', { class: 'r' }, '目前餘額'), h('th', { class: 'r' }, `約合 ${base}`), h('th', { class: 'r' }, '交易數'), h('th', null, ''))),
    h('tbody', null, rows.map((a) => h('tr', { class: (a.archived ? 'archived ' : '') + 'tx-row', tabindex: '0', title: '點一下編輯這個帳戶', ...rowTap(() => openAccountDialog(a)) },
      h('td', { class: 'name' }, accChip(a, 'sm'), a.name, h('span', { class: 'badge' }, a.currency)),
      h('td', { class: 'r muted' }, num(a.opening, a.currency)),
      h('td', { class: 'r' }, money(a.balance, a.currency, { tone: true, tag: false })),
      h('td', { class: 'r muted' }, a.currency === base ? '' : (a.base_value == null ? '需要匯率' : num(a.base_value, base))),
      h('td', { class: 'r muted' }, a.tx_count),
      h('td', { class: 'act' },
        h('button', { class: 'btn sm ghost', onclick: () => openAccountDialog(a) }, '編輯'),
        a.archived || a.stock ? null : h('button', { class: 'btn sm ghost', onclick: () => openCalibrateDialog(a) }, '校正'),
        h('button', { class: 'btn sm ghost', onclick: () => openResetDialog(a) }, '歸零'))))));
  const list = (rows) => (phone ? accountList(rows, base) : table(rows));
  const about = '每個帳戶有自己的幣別。餘額由期初餘額加上所有交易算出，所以修改或刪除舊交易時，餘額會自動跟著對。';
  view.append(
    h('div', { class: 'page-head' }, h('div', null, h('h1', null, '帳戶', eyeButton('accounts')), phone ? null : h('p', { class: 'sub' }, about)),
      h('div', { class: 'head-btns' }, h('button', { class: 'btn', onclick: () => openCalibrateDialog(null) }, '校正餘額'), h('button', { class: 'btn primary', onclick: () => openAccountDialog(null) }, '新增帳戶'))),
    active.length ? netWorthCard(S.st.accounts, base) : null,
    active.length ? netWorthTrend({ compact: phone }) : null,
    ...(active.length ? accountGroups(active).map((g) => h('section', { class: 'section acc-group', 'data-kind': g.kind },
      h('div', { class: 'section-head' }, h('h2', null, g.title), h('span', { class: 'acc-sub num' + (g.sum < 0 ? ' neg' : '') }, num(g.sum, base), h('small', { class: 'ccy' }, base))), list(g.rows)))
      : [h('section', { class: 'section' }, h('div', { class: 'empty' }, h('b', null, '還沒有帳戶'), '按右上角「新增帳戶」開始。'))]));
  if (archived.length) view.append(h('section', { class: 'section' }, h('div', { class: 'section-head' }, h('h2', null, '已封存')), list(archived)));
  if (phone) view.append(h('p', { class: 'hint' }, about));
}

// ------------------------------------------------------------------- reports
function chartDefaults() {
  Chart.defaults.color = css('--ink-2'); Chart.defaults.borderColor = css('--line-2');
  if (!chartDefaults.font) chartDefaults.font = getComputedStyle(document.body).fontFamily;
  Chart.defaults.font.family = chartDefaults.font;
  // Every frame of a chart's opening animation is a full redraw on the main thread, which is what a phone is busy building the page with:
  // none there, a quick one on the computer. And a 3x screen gets a 2x picture (9 pixels per dot become 4; nobody can tell on a chart).
  const stock = chartDefaults.stock || (chartDefaults.stock = Chart.defaults.animation);       // the library's own settings object, kept so the computer's setting can come back
  stock.duration = 240; Chart.defaults.animation = isPhone() ? false : stock;
  Chart.defaults.devicePixelRatio = Math.min(window.devicePixelRatio || 1, 2);
}
const yAxis = () => ({ beginAtZero: true, ticks: { callback: (v) => (isHidden() ? '' : v) } });
function mkChart(canvas, cfg) { chartDefaults(); const c = new Chart(canvas, cfg); S.charts.push(c); return c; }
function groupTooltip(groups, base, total) {
  return {
    callbacks: {
      label: (ctx) => { const v = ctx.parsed.y ?? ctx.parsed; return ` ${num(v, base)} ${base}（${total ? (v / total * 100).toFixed(1) : 0}%）`; },
      afterLabel: (ctx) => { const g = groups[ctx.dataIndex]; return [`筆數：${g.count}`, g.accounts.length ? `帳戶：${g.accounts.join('、')}` : '', g.notes.length ? `備註：${g.notes.join('、')}` : ''].filter(Boolean); },
    },
  };
}
function colorsFor(groups) { return groups.map((g, i) => g.label === '其他' ? OTHER_COLOR : PALETTE[i % PALETTE.length]); }

// The list next to / under each chart: colour dot, the category's own picture, name, amount and share. Click a row (pie) to hide / show its slice.
function legendList(part, colors, byCategory, base, chart) {
  const total = part.total;
  const rows = part.groups.map((g, i) => {
    const look = !byCategory || g.label === '其他' ? null : g.label === '轉帳' ? typeChip('transfer') : catChip(g.label, 'sm');
    const row = h('button', { class: 'lg-row', type: 'button', disabled: !chart, title: chart ? '點一下隱藏／顯示這一塊' : '' },
      h('i', { class: 'lg-dot', style: `background:${colors[i]}` }), look, h('span', { class: 'lg-name' }, g.label),
      h('span', { class: 'lg-val' }, num(g.total, base), h('em', null, total ? ` ${(g.total / total * 100).toFixed(1)}%` : '')));
    if (chart) row.addEventListener('click', () => { chart.toggleDataVisibility(i); chart.update(); row.classList.toggle('off', !chart.getDataVisibility(i)); });
    return row;
  });
  return h('div', { class: 'legend', role: 'list', 'aria-label': '圖例' }, rows);
}
function drawBreakdown(box, data, kind, byCategory = true) {
  const base = data.base;
  for (const [key, title, tone] of [['income', '收入', 'pos'], ['expense', '支出', 'neg']]) {
    const part = data[key];
    const cv = h('canvas', { role: 'img', 'aria-label': `${title}${kind === 'pie' ? '圓餅圖' : '長條圖'}` });
    const holder = h('div', { class: 'legend-slot' });
    box.append(h('div', { class: 'chart-box' },
      h('h2', null, title, h('span', { class: `total ${tone}` }, num(part.total, base), h('span', { class: 'ccy' }, base))),
      part.groups.length ? h('div', { class: 'chart-wrap' }, cv) : h('div', { class: 'empty' }, `這段期間沒有${title}紀錄`), holder));
    if (!part.groups.length) continue;
    const labels = part.groups.map((g) => g.label), vals = part.groups.map((g) => g.total), colors = colorsFor(part.groups);
    let chart;
    if (kind === 'pie') {
      chart = mkChart(cv, { type: 'doughnut', data: { labels, datasets: [{ data: vals, backgroundColor: colors, borderColor: css('--surface'), borderWidth: 2 }] },
        options: { maintainAspectRatio: false, cutout: '55%', plugins: { legend: { display: false }, tooltip: groupTooltip(part.groups, base, part.total) } } });
    } else {
      mkChart(cv, { type: 'bar', data: { labels, datasets: [{ data: vals, backgroundColor: colors, borderRadius: 3 }] },
        options: { maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: groupTooltip(part.groups, base, part.total) }, scales: { y: yAxis() } } });
    }
    holder.append(legendList(part, colors, byCategory, base, chart));
  }
}

// The four numbers above the report charts: total spent, daily average, the biggest group and the change against the period before it.
// A month still going is compared with the same number of days of the month before; a year still going, with the whole months of the year before.
async function keyFigures(d, r) {
  const base = d.base, spent = Number(d.expense.total) || 0, now = new Date(), nowY = now.getFullYear(), nowM = now.getMonth() + 1;
  const sum = (a) => a.reduce((x, y) => x + (Number(y) || 0), 0);
  let days;
  if (r.month) {
    days = r.year > nowY || (r.year === nowY && r.month > nowM) ? 0 : (r.year === nowY && r.month === nowM) ? now.getDate() : new Date(r.year, r.month, 0).getDate();
  } else {
    const start = new Date(r.year, 0, 1), end = new Date(r.year + 1, 0, 1);
    days = r.year > nowY ? 0 : r.year === nowY ? Math.round((new Date(nowY, now.getMonth(), now.getDate()) - start) / 86400000) + 1 : Math.round((end - start) / 86400000);
  }
  const top = d.expense.groups[0], topName = { category: '最大類別', note: '最大備註', tag: '最大標籤' }[d.group_by] || '最大項目';
  const cell = (label, value, sub, cls) => h('div', { class: 'kpi' }, h('span', { class: 'kpi-label' }, label), h('b', { class: 'kpi-val num ' + (cls || '') }, value), h('small', { class: 'kpi-sub' }, sub));
  const cmp = h('div', { class: 'kpi' }, h('span', { class: 'kpi-label' }, r.month ? '比上月' : '比去年'), h('b', { class: 'kpi-val num' }, '…'), h('small', { class: 'kpi-sub' }, ' '));
  const box = h('div', { class: 'kpis', role: 'group', 'aria-label': '重點數字' },
    cell('總支出', [num(spent, base), h('span', { class: 'ccy' }, base)], `收入 ${num(d.income.total, base)} ${base}`, 'neg'),
    cell('日均支出', days ? num(spent / days >= 100 ? Math.round(spent / days) : roundTo(spent / days, digits(base)), base) : '—', days ? `${days} 天` : '還沒到這段期間'),
    cell(topName, top && top.total ? top.label : '—', top && top.total && spent ? `${num(top.total, base)} · 占 ${Math.round(top.total / spent * 100)}%` : ' '),
    cmp);
  const fill = (v, sub, cls) => { cmp.querySelector('.kpi-val').textContent = v; cmp.querySelector('.kpi-val').className = 'kpi-val num ' + (cls || ''); cmp.querySelector('.kpi-sub').textContent = sub; };
  (async () => {
    try {
      let now_v, prev_v, note;
      if (r.month) {
        const pm = r.month === 1 ? [r.year - 1, 12] : [r.year, r.month - 1];
        const t = await api('GET', `/api/reports/trend?year=${pm[0]}&month=${pm[1]}`);
        const live = r.year === nowY && r.month === nowM;
        now_v = spent; prev_v = sum(live ? t.expense.slice(0, now.getDate()) : t.expense);
        note = live ? `上月前 ${now.getDate()} 天 ${num(prev_v, base)}` : `上月 ${num(prev_v, base)}`;
      } else {
        const m = r.year === nowY ? nowM - 1 : 12;
        if (m < 1 || r.year > nowY) return fill('—', '要滿一個月才能比', '');
        const [a, b] = await Promise.all([api('GET', `/api/reports/trend?year=${r.year}`), api('GET', `/api/reports/trend?year=${r.year - 1}`)]);
        now_v = sum(a.expense.slice(0, m)); prev_v = sum(b.expense.slice(0, m));
        note = `去年 1–${m} 月 ${num(prev_v, base)}`;
      }
      if (!(prev_v > 0)) return fill('—', now_v > 0 ? '之前沒有支出可比' : '沒有支出', '');
      const pct = (now_v - prev_v) / prev_v * 100, r1 = Math.round(Math.abs(pct) * 10) / 10;
      fill(`${pct > 0 ? '▲' : pct < 0 ? '▼' : ''} ${r1}%`, note, pct > 0 ? 'neg' : pct < 0 ? 'pos' : '');
    } catch (e) { fill('—', '讀不到比較資料', ''); }
  })();
  return box;
}

async function viewReports(view) {
  const r = S.rp;
  const intro = pageIntro(`金額都換算成 ${S.st.base}（使用目前的匯率）。${S.st.prefs.count_transfers ? '轉帳也算收支：轉出算支出、轉入算收入，類別顯示為「轉帳」；歸零調整不算。' : '轉帳與歸零調整不算收入或支出。'}`);
  view.append(h('div', { class: 'page-head' }, h('div', null, h('h1', null, '報表', eyeButton('reports'), intro.btn), intro.p)));
  const out = h('div');
  const draw = async () => {
    S.charts.forEach((c) => c.destroy()); S.charts = [];
    out.replaceChildren();
    try {
      if (r.kind === 'pie' || r.kind === 'bar') {
        const d = await api('GET', `/api/reports/breakdown?year=${r.year}${r.month ? '&month=' + r.month : ''}&group_by=${r.group}&max=8`);
        const box = h('div', { class: 'charts' }); out.append(box); drawBreakdown(box, d, r.kind, r.group === 'category'); box.before(await keyFigures(d, r)); notice(d.missing_rates);
        if (r.group === 'tag') out.prepend(h('p', { class: 'hint', style: 'margin:10px 0 0' }, '一筆交易有好幾個標籤時，每個標籤各算一次；圖上方的總額每筆只算一次，所以各標籤加起來可能比總額大。沒有標籤的交易歸在「(沒有標籤)」。'));
      } else if (r.kind === 'compare') {
        await drawCompare(out, r);
      } else if (r.kind === 'invest') {
        await drawInvestShare(out, r);
      } else if (r.kind === 'trend') {
        const d = await api('GET', `/api/reports/trend?year=${r.year}${r.month ? '&month=' + r.month : ''}`);
        const cv = h('canvas', { role: 'img', 'aria-label': '收支趨勢折線圖' });
        out.append(h('div', { class: 'chart-box', style: 'margin-top:14px' }, h('h2', null, r.month ? `${r.year}-${pad(r.month)} 每日收支` : `${r.year} 每月收支`), h('div', { class: 'chart-wrap tall' }, cv)));
        mkChart(cv, { type: 'line', data: { labels: d.labels.map((l) => l.slice(r.month ? 8 : 5)), datasets: [
          { label: '收入', data: d.income, borderColor: css('--income'), backgroundColor: css('--income'), tension: .25, pointRadius: 2.5 },
          { label: '支出', data: d.expense, borderColor: css('--expense'), backgroundColor: css('--expense'), tension: .25, pointRadius: 2.5 }] },
          options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, scales: { y: yAxis() },
            plugins: { tooltip: { callbacks: { label: (c) => ` ${c.dataset.label}：${num(c.parsed.y, d.base)} ${d.base}` } } } } });
        notice(d.missing_rates);
      } else {
        await drawBalanceChart(out, r, notice);
      }
    } catch (e) { out.append(h('div', { class: 'empty' }, e.message)); }
  };
  const notice = (missing) => { if (missing && missing.length) out.prepend(h('div', { class: 'banner' }, `缺少 ${missing.join('、')} 的匯率，這些帳戶沒有算進圖表。`, h('a', { class: 'btn sm', href: '#/settings' }, '去填匯率'))); };
  const years = S.st.years;
  const kinds = [['pie', '圓餅圖'], ['bar', '長條圖'], ['trend', '收支趨勢'], ['balance', '帳戶餘額'], ['invest', '投資占比'], ['compare', '月比月']];
  const controls = h('div', { class: 'controls' },
    h('div', { class: 'seg', role: 'group', 'aria-label': '圖表種類' }, kinds.map(([k, l]) => h('button', { type: 'button', 'aria-pressed': String(r.kind === k), onclick: () => { r.kind = k; renderRoute(); } }, l))),
    r.kind === 'compare' ? h('div', { class: 'seg', role: 'group', 'aria-label': '比較方式' }, [['auto', '上月與去年同月'], ['custom', '自選月份'], ['years', '按年比較']].map(([k, l]) => h('button', { type: 'button', 'aria-pressed': String(r.cmpMode === k), onclick: () => { r.cmpMode = k; renderRoute(); } }, l))) : null,
    r.kind === 'invest' || (r.kind === 'balance' && r.range !== 'ym') || (r.kind === 'compare' && r.cmpMode !== 'auto') ? null : h('label', { class: 'field' }, h('span', null, '年'), h('select', { onchange: (e) => { r.year = +e.target.value; draw(); } }, years.map((y) => h('option', { value: y, selected: y === r.year }, y)))),
    r.kind === 'invest' || (r.kind === 'balance' && r.range !== 'ym') || (r.kind === 'compare' && r.cmpMode !== 'auto') ? null : h('label', { class: 'field' }, h('span', null, '月'), h('select', { onchange: (e) => { r.month = +e.target.value; draw(); } }, h('option', { value: 0, selected: !r.month }, '整年'), Array.from({ length: 12 }, (_, i) => h('option', { value: i + 1, selected: r.month === i + 1 }, `${i + 1} 月`)))),
    r.kind === 'compare' ? h('div', { class: 'seg', role: 'group', 'aria-label': '比較收入或支出' }, [['expense', '支出'], ['income', '收入']].map(([k, l]) => h('button', { type: 'button', 'aria-pressed': String(r.cmpKind === k), onclick: () => { r.cmpKind = k; renderRoute(); } }, l))) : null,
    r.kind === 'invest' ? h('div', { class: 'seg', role: 'group', 'aria-label': '占比圖種類' }, [['pie', '圓餅'], ['bar', '長條']].map(([k, l]) => h('button', { type: 'button', 'aria-pressed': String(r.shareKind === k), onclick: () => { r.shareKind = k; renderRoute(); } }, l))) : null,
    r.kind === 'invest' ? h('label', { class: 'field' }, h('span', null, '占比依'), h('select', { onchange: (e) => { r.shareBy = e.target.value; draw(); } }, [['value', '庫存市值（預估）'], ['cost', '付出成本']].map(([v, l]) => h('option', { value: v, selected: r.shareBy === v }, l)))) : null,
    (r.kind === 'pie' || r.kind === 'bar') ? h('label', { class: 'field' }, h('span', null, '依'), h('select', { onchange: (e) => { r.group = e.target.value; draw(); } }, [['category', '類別'], ['note', '備註'], ['tag', '標籤']].map(([v, l]) => h('option', { value: v, selected: r.group === v }, l)))) : null);
  view.append(controls);
  if (r.kind === 'pie' || r.kind === 'bar' || r.kind === 'trend' || r.kind === 'compare') view.append(transfersSwitch(''));
  if (r.kind === 'balance') {
    view.append(h('div', { class: 'controls' }, ...balanceControls(r, draw, () => renderRoute())));
    view.append(balanceChips(r, draw));
  }
  view.append(out);
  await draw();
}

// ------------------------------------------------------------------ settings
// Put the book back the way it was before an import (the backup is taken automatically right before every import).
async function undoImport(backup, done) {
  if (!(await confirmBox({ title: '還原到匯入前？', confirmLabel: '還原', danger: true,
    message: h('p', null, `帳本會退回${backup.time ? ' ' + shortTime(backup.time) : ''}匯入前的樣子，匯入之後新增或修改的紀錄也會一起退回。還原前會先自動再備份一次目前的資料，需要時還能從備份清單救回來。`) }))) return;
  try { await api('POST', '/api/backups/restore', { name: backup.name }); if (done) done(); await afterChange('已還原到匯入前'); } catch (e) { fail(e); }
}

function importReportDialog(rep, title = '匯入完成') {
  const list = (arr, max = 8) => arr.length ? h('ul', { class: 'report-list' }, arr.slice(0, max).map((x) => h('li', null, x)), arr.length > max ? h('li', null, `…還有 ${arr.length - max} 項`) : null) : null;
  let dlg = null;
  const undo = rep.backup ? h('button', { class: 'btn', type: 'button',
    onclick: () => undoImport({ name: rep.backup }, () => dlg && dlg.close()) }, '還原到匯入前') : null;
  dlg = openDialog({ title, wide: true, extraFoot: undo, body: h('div', { class: 'rows', style: 'padding:0;max-width:none' },
    h('p', { style: 'margin:0' }, `匯入 ${rep.imported} 筆交易；略過 ${rep.duplicates} 筆已存在的重複紀錄；`, rep.accounts_created.length ? `新增 ${rep.accounts_created.length} 個帳戶（${rep.accounts_created.join('、')}）。` : '沒有新增帳戶。'),
    rep.invalid.length ? h('div', null, h('b', null, `${rep.invalid.length} 列無法匯入`), list(rep.invalid)) : null,
    rep.warnings.length ? h('div', null, h('b', null, '提醒'), list(rep.warnings)) : null,
    rep.backup ? h('p', { class: 'hint', style: 'margin:0' }, '匯入前已自動備份。如果匯入的結果不對，可以按下面的「還原到匯入前」退回。') : null) });
}

// Settings are six folders that open and close, with a search box on top. The sections themselves are built exactly as before (settingsBody);
// they are only sorted into groups here, by their heading, so a new section just lands in 「關於」 until it is listed.
const SETTINGS_GROUPS = [
  ['外觀', ['外觀'], '主題 顏色 配色 隱藏 金額 眼睛 上次 記住 頁面 開啟 啟動'],
  ['帳務', ['類別', '分類規則', '幣別與匯率', '定期交易'], '類別 分類規則 自動 規則 匯率 幣別 主要幣別 固定 訂閱 房租'],
  ['同步', ['手機連線', '這支手機', 'Google 試算表', '離線模式'], 'sheets google 同步 金鑰 試算表 手機 tailscale 離線'],
  ['快速記帳', ['快速記帳', '自動記帳（待確認）'], '快速記帳 網址 連結 捷徑 shortcut 主畫面 iphone android qr code 書籤 待確認 自動記帳 背面輕點 apple pay 交易 自動化 收件匣'],
  ['資料', ['匯入資料', '匯出與備份', '備份與匯出', 'PIN 鎖', '危險區'], '匯入 匯出 csv 備份 還原 pin 密碼 鎖 清除 刪除'],
  ['關於', ['分享給其他人', '軟體更新', '發佈新版本', '意見回饋', '診斷紀錄', '關於這個版本', '切換版本'], '分享 朋友 其他人 下載 用戶版 qr code 網址 版本 更新 回饋 意見 診斷 紀錄 錯誤 閃退 當機 卡頓 記憶體 開機 自動啟動 結束 關閉'],
];
function groupSettings(nodes) {
  const titleOf = (n) => { const h2 = n.querySelector && n.querySelector('.section-head h2'); return h2 ? h2.textContent.trim() : ''; };
  const buckets = SETTINGS_GROUPS.map(() => []);
  for (const n of nodes) {
    let i = SETTINGS_GROUPS.findIndex(([, titles]) => titles.includes(titleOf(n)));
    if (i < 0) i = SETTINGS_GROUPS.length - 1;
    buckets[i].push(n);
  }
  let saved = {}; try { saved = JSON.parse(lsGet('pw_set_open') || '{}') || {}; } catch { saved = {}; }
  const defaultOpen = !isPhone();
  const groups = SETTINGS_GROUPS.map(([name, , words], i) => {
    if (!buckets[i].length) return null;
    buckets[i].forEach((n) => { if (titleOf(n) === name) n.classList.add('dup-title'); });
    const d = h('details', { class: 'set-group', 'data-group': name, 'data-words': words },
      h('summary', null, h('h2', null, name), h('span', { class: 'set-n' }, `${buckets[i].filter((n) => titleOf(n)).length || 1} 項`), h('span', { class: 'set-chev', 'aria-hidden': 'true' }, '›')),
      h('div', { class: 'set-body' }, buckets[i]));
    d.open = name in saved ? !!saved[name] : defaultOpen;
    d.addEventListener('toggle', () => { if (d.dataset.searching) return; saved[name] = d.open; lsSet('pw_set_open', JSON.stringify(saved)); });
    return d;
  }).filter(Boolean);
  const none = h('div', { class: 'empty', hidden: true }, h('b', null, '找不到符合的設定'), '換個關鍵字試試，例如「備份」「匯率」「顏色」。');
  const find = (q) => {
    q = q.trim().toLowerCase();
    let any = false;
    for (const d of groups) {
      const secs = [...d.querySelectorAll(':scope > .set-body > section')];
      if (!q) { secs.forEach((x) => { x.hidden = false; }); d.hidden = false; if (d.dataset.searching) { delete d.dataset.searching; d.open = !!saved[d.dataset.group]; } continue; }
      let hit = 0;
      for (const x of secs) {
        const ok = (x.textContent + ' ' + d.dataset.words + ' ' + d.dataset.group).toLowerCase().includes(q);
        x.hidden = !ok; if (ok) hit++;
      }
      d.hidden = !hit; if (hit) { d.dataset.searching = '1'; d.open = true; any = true; }
    }
    none.hidden = !q || any;
  };
  const box = h('input', { type: 'search', placeholder: '搜尋設定（例如：備份、匯率、顏色）', 'aria-label': '搜尋設定', autocomplete: 'off', oninput: (e) => find(e.target.value) });
  return [h('div', { class: 'set-search' }, box), ...groups, none];
}
// One place that says whether the data is safe: the last backup (and the second copy) and the Google sheet's state, each with a colour and a way to the setting.
function statusPanel() {
  const box = h('section', { class: 'section status-panel' }, h('div', { class: 'section-head' }, h('h2', null, '備份與同步狀態')), h('div', { class: 'sp-rows' }, h('div', { class: 'hint' }, '讀取中…')));
  const ago = (t) => { const d = (Date.now() - new Date(t).getTime()) / 86400000; return d < 1 / 24 ? '剛剛' : d < 1 ? `${Math.floor(d * 24)} 小時前` : `${Math.floor(d)} 天前`; };
  const row = (tone, title, text, ...acts) => h('div', { class: 'sp-row ' + tone }, h('span', { class: 'dot ' + (tone === 'ok' ? 'ok' : tone === 'bad' ? 'err' : tone === 'warn' ? 'off' : '') }, ''),
    h('div', { class: 'sp-main' }, h('b', null, title), h('span', null, text)), h('div', { class: 'sp-acts' }, ...acts));
  const openGroup = (name, find) => { const g = document.querySelector(`.set-group[data-group="${name}"]`); if (g) { g.open = true; const t = [...g.querySelectorAll('.section-head h2')].find((x) => x.textContent.includes(find)); (t || g).scrollIntoView({ block: 'start', behavior: 'smooth' }); } };
  (async () => {
    const rows = [];
    try {
      const [ab, bl] = await Promise.all([api('GET', '/api/autobackup').catch(() => null), api('GET', '/api/backups').catch(() => ({ items: [] }))]);
      const newest = (bl.items || [])[0], times = [ab && ab.last_ok, newest && newest.time].filter(Boolean).sort();
      const last = times[times.length - 1];
      const old = last && (Date.now() - new Date(last).getTime()) > 3 * 86400000;
      rows.push(row(!last ? 'warn' : old || (ab && ab.error) ? 'warn' : 'ok', '本機備份', last ? `最近一份在 ${shortTime(last)}（${ago(last)}）${ab && ab.error ? `；自動備份失敗：${ab.error}` : ''}` : '還沒有任何備份',
        h('button', { class: 'btn sm', type: 'button', onclick: async () => { try { await api('POST', '/api/backups'); toast('已建立備份'); S.settingsStatus && S.settingsStatus(); renderRoute(); } catch (e) { fail(e); } } }, '立即備份')));
      if (ab) rows.push(!ab.folder ? row('', '第二份存放處', '沒有設定（備份只在這台電腦上）', h('button', { class: 'btn sm ghost', type: 'button', onclick: () => openGroup('資料', '匯出與備份') }, '去設定'))
        : ab.second_error ? row('bad', '第二份存放處', `失敗：${ab.second_error}`, h('button', { class: 'btn sm ghost', type: 'button', onclick: () => openGroup('資料', '匯出與備份') }, '去看看'))
        : row(ab.last_second_ok ? 'ok' : 'warn', '第二份存放處', ab.last_second_ok ? `最近一次成功：${shortTime(ab.last_second_ok)}（${ago(ab.last_second_ok)}）` : '已設定，還沒有成功複製過'));
    } catch (e) { rows.push(row('warn', '本機備份', '讀不到備份資料')); }
    const sh = S.st.sheets;
    if (sh && !S.st.remote && !S.st.phone) {
      const go = h('button', { class: 'btn sm ghost', type: 'button', onclick: () => openGroup('同步', 'Google') }, sh.has_credentials && sh.key ? '測試／同步' : '去設定');
      const st = sh.status || {};
      if (!sh.has_credentials || !sh.key) rows.push(row('', 'Google 試算表', `${sh.has_credentials ? '' : '尚未上傳金鑰'}${!sh.has_credentials && !sh.key ? '、' : ''}${sh.key ? '' : '尚未設定試算表'}（不使用也沒關係）`, go));
      else if (st.state === 'error') rows.push(row('bad', 'Google 試算表', `同步失敗：${st.error || '原因不明'}${st.will_retry ? '（會自動重試）' : ''}`, go));
      else if (st.state === 'offline') rows.push(row('warn', 'Google 試算表', '目前離線，連線後會自動補上', go));
      else if (st.pending) rows.push(row('warn', 'Google 試算表', '有變動還沒上傳，會自動處理' + (sh.auto ? '' : '（自動同步是關閉的，要按「立即同步全部」）'), go));
      else if (!sh.auto) rows.push(row('warn', 'Google 試算表', `自動同步是關閉的${st.last_ok ? `；上次同步 ${shortTime(st.last_ok)}` : ''}`, go));
      else rows.push(row(st.last_ok ? 'ok' : 'warn', 'Google 試算表', st.last_ok ? `上次同步 ${shortTime(st.last_ok)}（${ago(st.last_ok)}），${st.rows} 筆` : '已設定，這次開啟後還沒同步過（有變動時會自動同步）', go));
    }
    const worst = rows.some((r) => r.classList.contains('bad')) ? 'bad' : rows.some((r) => r.classList.contains('warn')) ? 'warn' : 'ok';
    box.querySelector('h2').after(h('span', { class: 'sp-badge ' + worst }, { ok: '一切正常', warn: '有地方要留意', bad: '需要處理' }[worst]));
    box.querySelector('.sp-rows').replaceChildren(...rows);
  })();
  return box;
}

async function viewSettings(view) {
  const tmp = h('div');
  await settingsBody(tmp);
  const nodes = [...tmp.childNodes], head = nodes.shift();
  view.append(head, statusPanel(), ...groupSettings(nodes));
}

async function settingsBody(view) {
  const st = S.st, sh = st.sheets;
  view.append(h('div', { class: 'page-head' }, h('h1', null, '設定')));

  // --- appearance
  const colorNow = () => S.st.prefs.color;
  const hexIn = h('input', { class: 'hex', value: colorNow(), maxlength: 7, spellcheck: 'false', autocomplete: 'off', 'aria-label': 'Hex 色碼' });
  const picker = h('input', { type: 'color', value: colorNow().toLowerCase(), 'aria-label': '用色盤選顏色' });
  const hexHint = h('span', { class: 'hint' }, '');
  const swatches = h('div', { class: 'swatches', role: 'group', 'aria-label': '常用顏色' });
  const paintSwatches = () => swatches.replaceChildren(...Theme.PRESETS.map(([hex, name]) => h('button', {
    type: 'button', class: 'swatch', 'aria-pressed': String(colorNow() === hex), title: `${name}　${hex}`, onclick: () => choose(hex),
  }, h('i', { style: `background:${hex}` }), name)));
  const preview = (hex) => { Theme.apply(hex); };
  const choose = async (hex, { save = true } = {}) => {
    hex = Theme.normalize(hex);
    preview(hex); S.st.prefs.color = hex; lsSet('pw_color', hex);
    hexIn.value = hex; picker.value = hex.toLowerCase(); hexHint.textContent = ''; paintSwatches();
    if (save) { try { await api('PUT', '/api/settings', { ui_color: hex }); } catch (e) { fail(e); } }
  };
  hexIn.addEventListener('input', () => {
    const t = hexIn.value.trim();
    if (Theme.isHex(t)) { hexHint.textContent = ''; preview(Theme.normalize(t)); picker.value = Theme.normalize(t).toLowerCase(); }
    else hexHint.textContent = '請輸入 6 碼，例如 #E6E6FA';
  });
  hexIn.addEventListener('change', () => { if (Theme.isHex(hexIn.value)) choose(hexIn.value); else { hexHint.textContent = '請輸入 6 碼，例如 #E6E6FA'; Theme.apply(colorNow()); } });
  hexIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') hexIn.dispatchEvent(new Event('change')); });
  picker.addEventListener('input', () => { hexIn.value = picker.value.toUpperCase(); preview(picker.value); });
  picker.addEventListener('change', () => choose(picker.value));
  paintSwatches();
  const hideAllCb = h('input', { type: 'checkbox', checked: S.hideAll, onchange: (e) => setHideAll(e.target.checked) });
  const restoreCb = h('input', { type: 'checkbox', checked: restoreLastOn(), onchange: (e) => { lsSet(RESTORE_LAST, e.target.checked ? '1' : '0'); toast(e.target.checked ? '下次開啟會回到你最後看的頁面' : '下次開啟會從總覽開始'); } });
  const pageChecks = Object.entries(PAGE_NAMES).map(([k, name]) => h('label', { class: 'row-inline' },
    h('input', { type: 'checkbox', checked: !!S.hidePages[k], disabled: S.hideAll, onchange: (e) => setHidePage(k, e.target.checked) }), h('span', null, name)));
  view.append(h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, '外觀')),
    h('div', { class: 'rows' },
      h('div', { class: 'field' }, h('span', { style: 'font-weight:500' }, '介面顏色'), swatches),
      h('div', { class: 'row-inline hexrow' }, h('label', { class: 'field' }, h('span', null, '自訂 Hex 色碼'), h('div', { class: 'row-inline' }, picker, hexIn)),
        hexHint),
      h('p', { class: 'hint', style: 'margin:0' }, '淺色（例如薰衣草紫）會直接當作背景；較深或較飽和的顏色會當作重點色；很深的顏色會自動切成深色版面。文字對比會自動調整，換成什麼顏色都看得清楚。'),
      h('label', { class: 'row-inline' }, hideAllCb, h('span', null, h('b', null, '隱藏所有金額'), '（所有頁面都顯示成 ***）')),
      h('label', { class: 'row-inline' }, restoreCb, h('span', null, h('b', null, '開啟時回到上次的頁面'), '（只影響這台裝置；關掉就一律從總覽開始）')),
      h('div', { class: 'field' }, h('span', { style: 'font-weight:500' }, '各頁個別隱藏'),
        h('div', { class: 'row-inline', style: 'gap:18px' }, pageChecks),
        h('span', { class: 'hint' }, '每一頁標題旁的眼睛圖示可以單獨隱藏那一頁，彼此獨立，這裡也能設定。打開「隱藏所有金額」時，所有頁面都會隱藏，各頁的個別設定先保留；關閉後就恢復。')))));

  // --- categories live on their own page now
  view.append(h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, '類別')),
    h('div', { class: 'rows' },
      h('p', { class: 'hint', style: 'margin:0' }, '新增、改名、合併、刪除類別，以及更換每個類別的圖示與顏色，都在「類別」頁。'),
      h('div', null, h('a', { class: 'btn', href: '#/categories' }, '前往類別頁')))));

  // --- currency & rates
  const rateInputs = {};
  const baseSel = h('select', { 'aria-label': '主要幣別' }, st.currencies.map((c) => h('option', { value: c, selected: c === st.base }, c)));
  const rateRows = st.rates.rates.length ? st.rates.rates.map((r) => {
    const inp = h('input', { inputmode: 'decimal', value: r.rate == null ? '' : String(r.rate), placeholder: '尚未設定', 'aria-label': `1 ${r.currency} 等於多少 ${st.base}` });
    rateInputs[r.currency] = inp;
    return [h('span', null, `1 ${r.currency} =`), h('div', { class: 'row-inline' }, inp, h('span', { class: 'muted' }, st.base)), h('span', { class: 'hint' }, r.updated_at ? `更新於 ${shortTime(r.updated_at)}` : '')];
  }) : null;
  view.append(h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, '幣別與匯率')),
    h('div', { class: 'rows' },
      h('div', { class: 'row-inline' }, h('label', { class: 'field' }, h('span', null, '主要幣別（總資產與報表使用）'), baseSel),
        h('button', { class: 'btn', onclick: async () => { try { await api('PUT', '/api/settings', { base_currency: baseSel.value }); await afterChange('已切換主要幣別，匯率已重新換算'); } catch (e) { fail(e); } } }, '切換')),
      rateRows ? h('div', { class: 'kv' }, rateRows) : h('p', { class: 'hint', style: 'margin:0' }, '目前所有帳戶都是主要幣別，不需要匯率。新增其他幣別的帳戶後，這裡會出現匯率欄位。'),
      rateRows ? h('div', { class: 'row-inline' },
        h('button', { class: 'btn primary', onclick: async () => {
          const rates = {}; for (const [c, i] of Object.entries(rateInputs)) if (i.value.trim()) rates[c] = i.value.trim();
          try { await api('PUT', '/api/rates', { rates }); await afterChange('匯率已儲存'); } catch (e) { fail(e); } } }, '儲存匯率'),
        h('button', { class: 'btn', onclick: async (e) => { e.target.disabled = true; try { const r = await api('POST', '/api/rates/refresh'); await afterChange(`已更新 ${r.updated.join('、') || '無'}${r.missing.length ? `；查不到 ${r.missing.join('、')}` : ''}`); } catch (er) { fail(er); e.target.disabled = false; } } }, '從網路更新匯率')) : null,
      h('p', { class: 'hint', style: 'margin:0' }, '報表使用「目前」匯率換算，之後改匯率，過去月份的換算金額也會跟著變。帳戶自己的餘額不受影響。'))));

  view.append(catRulesSection());
  view.append(recurringSection());                           // the owner PC, a paired phone and the phone version all have it
  if (st.remote) {         // a paired phone: appearance + currency only. Files, backups and the Google connection stay on the computer.
    view.append(h('section', { class: 'section' }, h('div', { class: 'section-head' }, h('h2', null, '這支手機')),
      h('div', { class: 'rows' }, h('p', { class: 'hint', style: 'margin:0' }, '你正在用手機連到家裡電腦上的 Tallomi。Google 試算表、匯入匯出、備份與手機管理只能在電腦上操作。'),
        h('p', { class: 'hint', style: 'margin:0' }, '鍵盤打不出來？', h('a', { href: '/static/kb-a.html' }, '測試頁 A（完全沒有樣式）'), '　', h('a', { href: '/static/kb-b.html' }, '測試頁 B（套用 Tallomi 樣式）'), '　', h('a', { href: '/static/kb-c.html' }, '測試頁 C（對話框）'))))); 
    view.append(quickLinkSection(), inboxSection());
    { const sh = shareSection(); if (sh) view.append(sh); }
    view.append(locSection());
    if (LOC.mode === 'pc') view.append(offlineSection());
    view.append(diagSection());
    return;
  }
  if (st.phone) { await phoneSettings(view); view.append(quickLinkSection(), inboxSection()); { const sh = shareSection(); if (sh) view.append(sh); } view.append(diagSection()); return; }       // the phone version: no folders, Google connection, tray or shutdown
  await settingsPhone(view);
  view.append(quickLinkSection(), inboxSection());
  { const sh = shareSection(); if (sh) view.append(sh); }

  // --- google sheets
  const keyIn = h('input', { value: sh.key, placeholder: '貼上試算表網址或 ID', style: 'min-width:min(340px,100%)', 'aria-label': '試算表網址或 ID' });
  const wsIn = h('input', { value: sh.worksheet, 'aria-label': '工作表名稱' });
  const auto = h('input', { type: 'checkbox', checked: sh.auto });
  const fileIn = h('input', { type: 'file', accept: '.json,application/json', 'aria-label': '服務帳戶金鑰', onchange: async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const fd = new FormData(); fd.append('file', f);
    try { const r = await api('POST', '/api/sheets/service-account', fd, true); await afterChange(`已載入服務帳戶：${r.email}`); } catch (er) { fail(er); }
  } });
  const saveSheets = async () => { const r = await api('PUT', '/api/sheets/config', { key: keyIn.value, worksheet: wsIn.value, auto: auto.checked }); S.st.sheets = r; updateSyncLine(r); return r; };
  // "測試連線": not just "connected" but where a sync would land - is the chosen tab there, did Tallomi write it, do both sides hold the same number of entries
  function sheetsReport(r) {
    const line = (ok, text) => h('div', { class: 'sr-line' }, h('b', { class: ok === true ? 'pos' : ok === false ? 'neg' : '' }, ok === true ? '✓' : ok === false ? '✗' : '•'), h('span', null, text));
    const use = (name) => async () => { wsIn.value = name; try { await saveSheets(); dlg.close(); await afterChange(`之後會寫入分頁「${name}」`); } catch (e) { fail(e); } };
    const rows = [line(true, `已連上「${r.title}」，分頁：${r.worksheets.join('、') || '（沒有）'}`)];
    if (!r.exists) {
      rows.push(line(false, `找不到名為「${r.worksheet}」的分頁。現在按「立即同步全部」會新增一個叫「${r.worksheet}」的新分頁，而不是寫進你改過名的那一個。`));
      if ((r.suggest || []).length) rows.push(h('div', { class: 'sr-pick' }, h('span', null, '看起來是 Tallomi 寫的分頁：'), ...r.suggest.map((n) => h('button', { class: 'btn primary sm', type: 'button', onclick: use(n) }, `改用「${n}」`))));
      else rows.push(h('div', { class: 'sr-pick' }, h('span', null, '或改成其中一個現有分頁：'), ...r.worksheets.map((n) => h('button', { class: 'btn sm', type: 'button', onclick: use(n) }, n))));
    } else {
      rows.push(line(true, `會寫入的分頁「${r.worksheet}」找到了`));
      if (r.format === 'tallomi') rows.push(line(true, '分頁裡是 Tallomi 寫入的格式'));
      else if (r.format === 'other') rows.push(line(false, '分頁裡有不是 Tallomi 寫入的資料（可能是舊記帳表）。同步時會先問你要不要覆蓋，不會直接蓋掉。'));
      else if (r.format === 'empty') rows.push(line(null, '分頁是空的，第一次同步會把整份帳本寫進去'));
      if (r.format === 'tallomi' && r.sheet_rows != null && r.local_rows != null) {
        const gap = r.local_rows - r.sheet_rows;
        rows.push(gap === 0 ? line(true, `試算表 ${r.sheet_rows} 筆、這台電腦 ${r.local_rows} 筆，一致`)
          : line(false, `試算表 ${r.sheet_rows} 筆、這台電腦 ${r.local_rows} 筆（${gap > 0 ? `少 ${gap}` : `多 ${-gap}`} 筆），按「立即同步全部」就會補齊`));
      }
    }
    const dlg = openDialog({ title: '試算表連線檢查', body: h('div', { class: 'sr' }, ...rows) });
  }
  const autosave = (msg) => async () => { try { await saveSheets(); if (msg) toast(msg(auto.checked)); await refresh(); } catch (e) { fail(e); } };
  keyIn.addEventListener('change', autosave(() => '已儲存試算表設定'));
  wsIn.addEventListener('change', autosave(() => '已儲存工作表名稱'));
  auto.addEventListener('change', autosave((on) => (on ? '已開啟自動同步' : '已關閉自動同步，之後要按「立即同步全部」才會更新')));
  view.append(h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, 'Google 試算表')),
    h('div', { class: 'rows' },
      h('div', { class: 'status-line' }, h('span', { class: 'dot ' + (sh.status.state === 'ok' ? 'ok' : sh.status.state === 'error' ? 'err' : sh.status.state === 'offline' ? 'off' : '') }, ''),
        h('span', null, [`金鑰：${sh.has_credentials ? '已載入' : '尚未上傳'}`, `試算表：${sh.key ? '已設定' : '尚未設定'}`, `自動同步：${sh.auto ? '開啟' : '關閉'}`].join('　｜　'))),
      h('div', { class: 'hint', style: 'margin-top:-6px' }, sh.status.state === 'offline' ? '目前離線：記帳照常使用，資料都存在這台電腦。連線後會自動重試並補上離線期間的所有紀錄。' : sh.status.state === 'error' ? `上次同步失敗：${sh.status.error}` : sh.status.last_ok ? `上次同步 ${shortTime(sh.status.last_ok)}，${sh.status.rows} 筆` : (sh.configured ? '已就緒，下一次記帳就會同步，也可以按「立即同步全部」。' : '')),
      h('label', { class: 'field' }, h('span', null, '試算表'), keyIn),
      h('label', { class: 'field' }, h('span', null, '寫入的工作表名稱'), wsIn,
        h('span', { class: 'hint' }, '每次有變動，Tallomi 會把整份帳本重新寫進這個工作表（原本的內容會被覆蓋）。其他工作表不會被動到；找不到時會自動建立。')),
      h('label', { class: 'field' }, h('span', null, '服務帳戶金鑰（service_account.json）'), fileIn,
        h('span', { class: 'hint' }, sh.has_credentials ? `已載入：${sh.email}` : '尚未上傳')),
      h('label', { class: 'row-inline' }, auto, h('span', null, '有變動時自動同步到試算表')),
      h('div', { class: 'row-inline' },
        h('button', { class: 'btn primary', onclick: async () => { try { await saveSheets(); await afterChange('已儲存 Google 試算表設定'); } catch (e) { fail(e); } } }, '儲存設定'),
        h('button', { class: 'btn', onclick: async (e) => { e.target.disabled = true; try { await saveSheets(); const r = await api('POST', '/api/sheets/test'); sheetsReport(r); } catch (er) { fail(er); } e.target.disabled = false; } }, '測試連線'),
        h('button', { class: 'btn', onclick: async (e) => {
          e.target.disabled = true;
          try {
            await saveSheets();
            let r;
            try { r = await api('POST', '/api/sheets/push', {}); }
            catch (er) {
              if (er.status !== 409) throw er;
              const ok = await confirmBox({ title: '覆蓋這個工作表？', message: h('p', null, er.message), confirmLabel: '覆蓋並同步', danger: true });
              if (!ok) { e.target.disabled = false; return; }
              r = await api('POST', '/api/sheets/push', { force: true });
            }
            await afterChange(`已同步 ${r.rows} 筆到「${r.worksheet}」`);
          } catch (er) { fail(er); await refresh().catch(() => {}); }
          e.target.disabled = false;
        } }, '立即同步全部'),
        sh.key ? h('button', { class: 'btn', onclick: () => api('POST', '/api/sheets/open').catch(fail) }, '開啟試算表') : null,
        h('button', { class: 'btn', onclick: async () => {
          try {
            await saveSheets(); const info = await api('POST', '/api/sheets/test');
            const pickWs = h('select', null, info.worksheets.map((w) => h('option', { value: w }, w)));
            openDialog({ title: '從試算表匯入', body: h('div', { class: 'rows', style: 'padding:0;max-width:none' },
              h('p', { style: 'margin:0' }, '選擇舊版記帳表所在的工作表（需有 time、type、amount、account 等欄位）。已經在 Tallomi 裡的紀錄會自動略過，不會重複。'),
              h('label', { class: 'field' }, h('span', null, '工作表'), pickWs)),
              primary: { label: '匯入', run: async (dlg) => { const rep = await api('POST', '/api/sheets/import', { worksheet: pickWs.value }); dlg.close(); await refresh(); importReportDialog(rep); return false; } } });
          } catch (e) { fail(e); }
        } }, '從試算表匯入…')),
      h('details', null, h('summary', { class: 'hint', style: 'cursor:pointer' }, '第一次設定怎麼做？'),
        h('ol', { class: 'steps' },
          h('li', null, '到 Google Cloud Console 建立專案，啟用「Google Sheets API」。'),
          h('li', null, '建立「服務帳戶」，新增 JSON 金鑰並下載（就是你原本使用的 service_account.json）。'),
          h('li', null, '打開你的 Google 試算表，按「共用」，把服務帳戶的 email 加為「編輯者」。'),
          h('li', null, '回到這裡上傳金鑰、貼上試算表網址，按「測試連線」。'))))));

  // --- import
  view.append(importSection());

  // --- export & backup
  const backupBox = h('div');
  let picked = new Set();
  const delBackups = async (names, what) => {
    if (!names.length) return;
    if (!(await confirmBox({ title: `刪除 ${what}？`, confirmLabel: '刪除', danger: true,
      message: h('p', null, '刪除後無法復原（不會進資源回收筒）。目前正在使用的帳本不受影響。') }))) return;
    try { const r = await api('DELETE', '/api/backups', { names }); toast(`已刪除 ${r.deleted} 份備份`); picked = new Set(); await loadBackups(); } catch (e) { fail(e); }
  };
  const loadBackups = async () => {
    const r = await api('GET', '/api/backups');
    const items = r.items, names = new Set(items.map((b) => b.name));
    picked = new Set([...picked].filter((n) => names.has(n)));
    if (!items.length) { backupBox.replaceChildren(h('p', { class: 'hint', style: 'margin:0' }, '還沒有備份。')); return; }
    const delSel = h('button', { class: 'btn sm danger', type: 'button', disabled: !picked.size, onclick: () => delBackups([...picked], `選取的 ${picked.size} 份備份`) }, `刪除選取的（${picked.size}）`);
    const sync = () => { delSel.disabled = !picked.size; delSel.textContent = `刪除選取的（${picked.size}）`; all.checked = picked.size === items.length; };
    const all = h('input', { type: 'checkbox', 'aria-label': '全選', checked: picked.size === items.length, onchange: (e) => {
      picked = e.target.checked ? new Set(items.map((b) => b.name)) : new Set();
      backupBox.querySelectorAll('input.bk').forEach((c) => { c.checked = e.target.checked; }); sync();
    } });
    const keep = h('select', { 'aria-label': '只保留最近幾份', onchange: async (e) => {
      const n = +e.target.value; e.target.value = ''; if (!n) return;
      const old = items.slice(n).map((b) => b.name);                      // items are newest first
      if (!old.length) { toast(`目前只有 ${items.length} 份，不需要刪`); return; }
      await delBackups(old, `${old.length} 份較舊的備份（只保留最新 ${n} 份）`);
    } }, h('option', { value: '' }, '只保留最近…'), [3, 5, 10].map((n) => h('option', { value: n }, `最近 ${n} 份`)));
    backupBox.replaceChildren(
      h('div', { class: 'row-inline bk-bar' }, h('label', { class: 'row-inline' }, all, h('span', null, `全選（共 ${items.length} 份）`)), delSel, keep),
      h('div', { class: 'bk-list' }, h('table', { class: 'ledger' }, h('tbody', null, items.map((b) => h('tr', null,
        h('td', { class: 'bk-pick' }, h('input', { class: 'bk', type: 'checkbox', 'aria-label': `選取 ${b.name}`, checked: picked.has(b.name), onchange: (e) => { e.target.checked ? picked.add(b.name) : picked.delete(b.name); sync(); } })),
        h('td', { class: 'when' }, shortTime(b.time)), h('td', { class: 'note' }, b.name, /-auto/.test(b.name) ? h('span', { class: 'bk-tag' }, '自動') : null), h('td', { class: 'r muted' }, `${Math.max(1, Math.round(b.size / 1024))} KB`),
        h('td', { class: 'act' },
          h('button', { class: 'btn sm ghost', onclick: async () => {
            if (!(await confirmBox({ title: '還原這個備份？', message: h('p', null, `目前的資料會被 ${shortTime(b.time)} 的備份取代。還原前會先自動再備份一次目前的資料。`), confirmLabel: '還原', danger: true }))) return;
            try { await api('POST', '/api/backups/restore', { name: b.name }); await afterChange('已還原備份'); } catch (e) { fail(e); }
          } }, '還原'),
          h('button', { class: 'btn sm ghost', onclick: () => delBackups([b.name], `這份備份（${shortTime(b.time)}）`) }, '刪除'))))))));
  };
  // --- automatic daily backup + second folder
  const abBox = h('div', { class: 'ab-box' });
  const loadAuto = async () => {
    const i = await api('GET', '/api/autobackup');
    const folder = h('input', { name: 'abfolder', value: i.folder, placeholder: i.default_folder || 'D:\\pennyworth\\備份', autocomplete: 'off', spellcheck: 'false', 'aria-label': '第二份存放處' });
    const when = (t) => (t ? shortTime(t) : '尚未');
    abBox.replaceChildren(
      h('label', { class: 'tally-toggle' }, h('input', { type: 'checkbox', checked: i.enabled, onchange: async (e) => {
        try { await api('PUT', '/api/autobackup', { enabled: e.target.checked }); await loadAuto(); } catch (err) { e.target.checked = !e.target.checked; fail(err); } } }),
        h('span', null, `每天自動備份一次（只保留最近 ${i.keep} 份；按「結束 Tallomi」時若有變動，也會再備份一次）`)),
      h('div', { class: 'ab-folder' }, h('label', { class: 'field' }, h('span', null, '第二份存放處（每次自動備份都會複製一份到這裡；留空就不複製）'), folder),
        h('button', { class: 'btn', type: 'button', onclick: async () => { try { await api('PUT', '/api/autobackup', { folder: folder.value }); toast(folder.value.trim() ? '已儲存第二份存放處' : '已關閉第二份存放'); await loadAuto(); } catch (err) { fail(err); } } }, '儲存資料夾'),
        h('button', { class: 'btn', type: 'button', onclick: async () => { try { await api('POST', '/api/autobackup/run'); toast('已完成一次自動備份'); await loadAuto(); await loadBackups(); } catch (err) { fail(err); } } }, '現在就備份一次')),
      h('div', { class: 'ab-status' },
        h('span', null, `上次自動備份：${when(i.last_ok)}`),
        i.folder ? h('span', { class: i.second_error ? 'bad' : '' }, i.second_error ? `第二份存放處失敗：${i.second_error}` : `第二份存放處最近一次成功：${when(i.last_second_ok)}`) : h('span', null, '第二份存放處：未設定'),
        i.error ? h('span', { class: 'bad' }, `備份失敗：${i.error}`) : null));
  };
  view.append(h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, '匯出與備份')),
    h('div', { class: 'rows' },
      h('div', { class: 'row-inline' },
        h('button', { class: 'btn', onclick: async () => { try { await exported(await api('POST', '/api/export')); } catch (e) { fail(e); } } }, '匯出 CSV（Excel 可開）'),
        h('button', { class: 'btn', onclick: async () => { try { await api('POST', '/api/backups'); toast('已建立備份'); await loadBackups(); } catch (e) { fail(e); } } }, '立即備份'),
        h('button', { class: 'btn', onclick: () => api('POST', '/api/open-folder', { which: 'data' }).then((r) => toast(`資料夾：${r.path}`)).catch(fail) }, '開啟資料夾')),
      abBox,
      h('p', { class: 'hint', style: 'margin:0' }, receiptNote()),
      h('p', { class: 'hint', style: 'margin:0' }, '歸零（清除紀錄）、清除全部、還原備份之前，都會自動備份。手動備份最多保留 30 份；不想留的舊備份可以勾選後刪除，或用「只保留最近…」一次清掉舊的。'),
      backupBox)));
  loadAuto().catch(fail);
  loadBackups().catch(fail);

  view.append(lockSection());
  { const us = updateSection(); if (us) view.append(us); }
  { const op = typeof ownerPublishSection === 'function' ? ownerPublishSection() : null; if (op) view.append(op); }      // 1.72.2: owner's copy
  { const ms = modeSection(); if (ms) view.append(ms); }
  { const fs = feedbackSection(); if (fs) view.append(fs); }

  view.append(diagSection());
  // --- danger
  view.append(h('section', { class: 'section' },
    h('div', { class: 'section-head' }, h('h2', null, '危險區')),
    h('div', { class: 'rows' }, h('div', { class: 'danger-zone' },
      h('p', { style: 'margin-top:0' }, h('b', null, '清除所有交易，帳戶回到初始金額'), h('br'), h('span', { class: 'muted' }, '帳戶本身會保留，交易紀錄全部刪除。原有帳戶（Cash、Cube Bank …）回到舊版的初始金額，其他帳戶為 0。相當於舊版的「Clear and Reset Account」。執行前會自動備份。')),
      h('button', { class: 'btn danger', onclick: async () => {
        if (!(await confirmBox({ title: '清除所有交易？', message: h('p', null, '所有交易會被刪除，帳戶餘額回到初始金額。'), confirmLabel: '清除全部', danger: true, typed: '清除全部' }))) return;
        try { const r = await api('POST', '/api/clear-all', { confirm: '清除全部' }); await afterChange(`已清除 ${r.deleted} 筆交易`); } catch (e) { fail(e); }
      } }, '清除所有交易…')))));

  {
    const autoBox = h('div', { class: 'auto-start' });
    view.append(h('section', { class: 'section' }, h('div', { class: 'rows' }, autoBox, h('p', { class: 'hint', style: 'margin:0' }, '關掉 Tallomi 的視窗後，程式仍會留在背景執行（照常更新匯率、股價，手機也連得上）。Windows 右下角的通知區域（可能收在「^」裡）會有 Tallomi 圖示：點一下開啟，按右鍵可以開啟或結束。要完全關閉，請按下面的按鈕，或用那個圖示的「結束 Tallomi」。'), h('button', { class: 'btn', onclick: async () => {
      try { await api('POST', '/api/shutdown'); document.body.replaceChildren(h('p', { style: 'padding:40px' }, 'Tallomi 已關閉，可以關掉這個分頁。')); } catch (e) { fail(e); } } }, '結束 Tallomi'))));
    loadAutostart(autoBox).catch(() => {});
  }
}

// On a phone a wide table turns into a stack of cards (see style.css). Each cell gets its column name as a label.
// Tables are marked once when they appear; `.keep` tables stay tables, `.tx` has its own card layout.
function stackTable(t) {
  if (t.classList.contains('stack')) return;
  t.classList.add('stack');
  const labels = [...t.querySelectorAll('thead th')].map((th) => th.textContent.trim());
  t.querySelectorAll(':scope > tbody > tr').forEach((tr) => {          // only this table's own rows: a table nested inside a row has its own labels
    const cells = [...tr.children];
    if (cells.some((td) => td.colSpan > 1)) return;
    cells.forEach((td, i) => { if (labels[i]) td.dataset.label = labels[i]; });
  });
}
function watchTables() {
  const view = $('#view');
  const scan = () => view.querySelectorAll('table.ledger:not(.stack):not(.tx):not(.keep):not(.inv-lot-table)').forEach(stackTable);
  new MutationObserver(scan).observe(view, { childList: true, subtree: true });
  scan();
}

// ------------------------------------------------------- live refresh
// Everything that is written (from this computer's window, a phone, or a background update) raises a counter on the
// computer. This loop waits on it, so a change made anywhere shows up here within a moment.
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function busyTyping() {
  const el = document.activeElement;
  return !!(el && /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName) && el.closest('#view')) || !!document.querySelector('dialog[open]');
}
async function applyRemoteChange() {
  for (let i = 0; i < 400 && S.pendingChange; i++) {                   // never pull the page out from under a half-typed entry
    if (document.visibilityState === 'visible' && !busyTyping()) {
      S.pendingChange = false;
      const y = window.scrollY;
      try { await refresh(); window.scrollTo(0, y); } catch { /* computer unreachable: the next poll will say so */ }
      return;
    }
    await sleep(1500);
  }
}
// An update copied onto the computer changes the program's files; every open window and phone notices (the fingerprint in
// the page no longer matches) and reloads itself as soon as nothing is being typed.
const PW_BUILD = (document.querySelector('meta[name="pw-build"]') || {}).content || '';
async function reloadForUpdate() {
  let last = 0; try { last = Number(sessionStorage.getItem('pw_reloaded') || 0); } catch { /* ignore */ }
  if (Date.now() - last < 30000) return;                     // never loop
  for (let i = 0; i < 400; i++) {
    if (document.visibilityState === 'visible' && !busyTyping()) break;
    await sleep(1500);
  }
  try { sessionStorage.setItem('pw_reloaded', String(Date.now())); } catch { /* ignore */ }
  toast('Tallomi 有新版本，正在更新…');
  try { const reg = await navigator.serviceWorker.getRegistration(); if (reg) await reg.update(); } catch { /* no service worker */ }
  await sleep(600);
  location.reload();
}
let updating = false;
let revRunning = false;
const visibleAgain = () => new Promise((resolve) => {
  const f = () => { if (document.visibilityState === 'visible') { document.removeEventListener('visibilitychange', f); resolve(); } };
  document.addEventListener('visibilitychange', f);
});
const stopRevWait = () => { if (S.revAbort) { try { S.revAbort.abort(); } catch { /* done */ } } };
document.addEventListener('visibilitychange', () => { if (document.visibilityState !== 'visible') stopRevWait(); });
window.addEventListener('pagehide', stopRevWait);
// While the screen is off or another app is in front the phone must be quiet: no waiting request is left hanging, and the
// first thing after coming back is one quick look at whether anything changed.
async function revWatch() {
  if (revRunning) return;
  revRunning = true;
  let fails = 0;
  for (;;) {
    if (document.visibilityState !== 'visible') { await visibleAgain(); fails = 0; continue; }
    const ac = new AbortController(); S.revAbort = ac;
    const guard = setTimeout(() => ac.abort(), 35000);       // a request iOS froze while we were away never answers
    try {
      const since = S.rev == null ? -1 : S.rev;
      const r = await fetch(`/api/rev?since=${since}&wait=20`, { headers: { 'X-Pennyworth': '1' }, cache: 'no-store', signal: ac.signal });
      if (r.status === 401) {
        const j = await r.json().catch(() => ({}));
        if (j.locked) { await showLock(); continue; }
        location.replace('/pair'); return;
      }
      if (!r.ok) throw new Error(String(r.status));
      const d = await r.json();
      fails = 0;
      if (d.build && PW_BUILD && !PW_BUILD.startsWith('__') && d.build !== PW_BUILD && !updating) { updating = true; reloadForUpdate().finally(() => { updating = false; }); }
      if (S.rev == null) S.rev = d.rev;
      else if (d.rev !== S.rev) { S.rev = d.rev; S.pendingChange = true; applyRemoteChange(); }
      if (!d.waited) await sleep(4000);
    } catch (e) {
      if (e && e.name === 'AbortError') continue;           // we stopped it ourselves (screen off) or it hung: just start again
      fails += 1;
      if (typeof locOn === 'function' && locOn() && LOC.mode === 'pc' && !LOC.bypass) locEnter().catch(() => {});      // the computer stopped answering while the page is just open: switch to the phone's copy now, not at the next tap
      await sleep(Math.min(30000, 3000 * fails));
    } finally { clearTimeout(guard); if (S.revAbort === ac) S.revAbort = null; }
  }
}

// --------------------------------------------------------------------- boot
(async function boot() {
  const tRefresh0 = performance.now();
  let tEngine = 0;
  if (window.__phoneReady) window.__phoneReady.then(() => { tEngine = performance.now(); }).catch(() => {});
  try { await refresh(); } catch (e) {
    $('#view').replaceChildren(h('div', { class: 'empty' }, h('b', null, e.network ? '暫時連不上電腦' : '無法啟動'), h('p', null, e.message),
      e.network ? h('p', { class: 'hint' }, '電腦開機並執行 Tallomi 後就能連上。想在電腦沒開時也能用，請在連得上電腦時到「設定 → 電腦沒開也能用」開啟，手機就會存一份帳本。') : null,
      h('button', { class: 'btn primary', type: 'button', onclick: () => location.reload() }, '重試')));
  }
  if (window.pwDiag) {                                                       // the first page is drawn: a slow start is noted (設定 → 診斷紀錄)
    const now = performance.now(), sec = (ms) => `${(Math.max(0, ms) / 1000).toFixed(1)} 秒`;
    const parts = [S.st ? (S.st.phone ? '手機本機' : S.st.remote ? '連到電腦' : '電腦') : '沒有啟動成功'];        // 1.72.1: where the time went, so a slow start can be fixed
    parts.push(`載入網頁 ${sec(tRefresh0)}`);
    if (window.__phoneStale) parts.push('先用上次的畫面');
    else if (tEngine) parts.push(`等程式啟動 ${sec(tEngine - tRefresh0)}`, `讀帳本 ${sec(now - tEngine)}`);
    else parts.push(`讀帳本 ${sec(now - tRefresh0)}`);
    if (S.st && S.st.phone && !window.__phoneStale && S.st.lock && S.st.lock.enabled) parts.push('PIN 鎖開著，不先顯示上次的畫面');
    pwDiag.start(Math.round(now), parts.join('・'));
  }
  const remote = !!(S.st && S.st.remote);
  const phone = !!(S.st && S.st.phone);
  if (typeof outboxFlush === 'function') outboxFlush().catch(() => {});       // an entry that was tapped but never answered last time is sent now
  if (phone) phoneStartup();
  if (typeof ownerPendingCheck === 'function') { ownerPendingCheck(); setInterval(() => ownerPendingCheck(), 30 * 60 * 1000); }      // 1.72.2: Claude's update waiting (owner's copy)
  if (window.__phoneStale && typeof freshenAfterStale === 'function') freshenAfterStale();        // drawn from last time's answers: refresh as soon as the program is up
  if (S.st && S.st.onboarding && typeof onboardingWizard === 'function') onboardingWizard();
  if (typeof quickLinkStart === 'function') quickLinkStart();            // opened from a quick-entry link: show the filled-in form (never saves by itself); without a book it is kept for 重試
  const ping = () => { if (!remote && !phone) fetch('/api/ping').catch(() => {}); };
  setInterval(ping, 5000);
  if ((remote || offlineOn() || locOn()) && 'serviceWorker' in navigator && (location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname))) navigator.serviceWorker.register('/sw.js').catch(() => {});
  watchTables();
  // Phone keyboard (iPhone): the page does not shrink when the keyboard slides up, only the visible part does. Measure the gap,
  // lift bottom sheets above the keyboard, hide the tab bar while typing, and put the page back where it was once the keyboard is gone.
  (function keyboardGuard() {
    const vv = window.visualViewport; if (!vv) return;
    const root = document.documentElement;
    let was = false, y0 = 0;
    const update = () => {
      const kb = Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop));
      const a = document.activeElement;
      const typing = !!a && (a.tagName === 'TEXTAREA' || (a.tagName === 'INPUT' && !/^(checkbox|radio|button|submit|range|file|color)$/.test(a.type)));
      const open = kb > 90 && typing;                                        // a gap without a focused text box is scrolling / bounce, not a keyboard
      if (open && !was) y0 = window.scrollY;
      root.style.setProperty('--kb', open ? `${kb}px` : '0px');
      root.classList.toggle('kb-open', open);
      if (was && !open) setTimeout(() => {                                   // iOS can leave the page scrolled / shifted after the keyboard closes
        const a = document.activeElement;
        if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return;
        if (!document.querySelector('dialog[open]')) window.scrollTo(0, y0);
        if (vv.offsetTop) window.scrollTo(0, window.scrollY);
      }, 80);
      was = open;
    };
    vv.addEventListener('resize', update); vv.addEventListener('scroll', update);
    document.addEventListener('focusout', () => setTimeout(update, 120));
  })();
  // Phone keyboard: once it has slid up, keep the box being typed in on screen.
  document.addEventListener('focusin', (e) => {
    const el = e.target;
    if (!(el.tagName === 'INPUT' && /^(text|search|tel|url|email|number|password)$/.test(el.type)) && el.tagName !== 'TEXTAREA') return;
    if (window.matchMedia(PHONE_Q).matches) setTimeout(() => {
      if (document.activeElement !== el) return;
      if (el.closest('dialog')) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }       // a sheet is lifted above the keyboard; its own body scrolls
      const vv = window.visualViewport, seen = vv ? vv.height : window.innerHeight;                         // the part of the screen the keyboard leaves
      const r = el.getBoundingClientRect(), want = r.top + r.height / 2 - seen / 2;
      if (r.bottom > seen - 8 || r.top < 8) window.scrollBy({ top: want, behavior: 'smooth' });
    }, 350);
  });
  if (!phone) revWatch();
  // Screen locked / another app in front: remember when we left. Coming back, only a long absence or a new day reloads the
  // whole book; anything newer from the computer is picked up by the (restarted) change watcher.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') { S.hiddenAt = Date.now(); return; }
    ping();
    const away = S.hiddenAt ? Date.now() - S.hiddenAt : 0;
    if ((away > 30 * 60 * 1000 || (S.day && S.day !== nowLocal().slice(0, 10))) && !document.querySelector('dialog[open]')) refresh().catch(() => {});
  });
  window.addEventListener('offline', () => { toast(remote ? '手機目前沒有網路，連不上你的電腦' : '目前沒有網路：記帳照常使用，資料先存在這台電腦，連線後自動同步'); if (S.st) updateSyncLine(S.st.sheets); });
  window.addEventListener('online', async () => {
    toast('網路已恢復');
    try { await api('POST', '/api/sheets/retry'); } catch { /* not configured */ }
    watchSync(); try { updateSyncLine(await api('GET', '/api/sheets')); } catch { /* ignore */ }
  });
  setInterval(async () => {
    if (document.visibilityState !== 'visible' || remote || phone) return;        // only the computer's own window shows this line
    try { updateSyncLine(await api('GET', '/api/sheets')); } catch { /* server closed */ }
  }, 8000);
})();
