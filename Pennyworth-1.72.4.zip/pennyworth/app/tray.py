"""Windows notification-area ("system tray") icon, so a Tallomi that keeps running in the background after its window
was closed is still visible: left click / double click opens it, right click gives 開啟 / (extra shortcuts) / 結束.

Plain ctypes (no extra package to install, nothing for the exe build to collect). On any other system, or if anything
goes wrong, it simply does not show an icon: Tallomi works the same without it.
"""
import ctypes
import logging
import os
import sys
import threading
from pathlib import Path

TIP = "Tallomi（背景執行中）"
MENU_OPEN, MENU_QUIT = 1, 2
LABELS = {MENU_OPEN: "開啟 Tallomi", MENU_QUIT: "結束 Tallomi"}
MENU_EXTRA = 100                              # extra shortcuts get the ids 100, 101, ...


def menu_layout(extras=()):
    """What the right-click menu holds, top to bottom: (id, label) entries and None for a separator.
    `extras` is a list of (label, callback) pairs, with None between groups."""
    out = [(MENU_OPEN, LABELS[MENU_OPEN])]
    items = list(extras or ())
    for i, e in enumerate(items):
        out.append(None if e is None else (MENU_EXTRA + i, e[0]))
    out += [None, (MENU_QUIT, LABELS[MENU_QUIT])]
    cleaned = []                                   # never two separators in a row, never one right after the first entry
    for e in out:
        if e is None and (not cleaned or cleaned[-1] is None):
            continue
        cleaned.append(e)
    return cleaned

# Win32 constants
WM_CLOSE, WM_DESTROY, WM_NULL = 0x0010, 0x0002, 0x0000
WM_APP_TRAY = 0x8000 + 1                      # our own "something happened to the icon" message
WM_LBUTTONUP, WM_LBUTTONDBLCLK, WM_RBUTTONUP = 0x0202, 0x0203, 0x0205
NIM_ADD, NIM_MODIFY, NIM_DELETE = 0, 1, 2
NIF_MESSAGE, NIF_ICON, NIF_TIP, NIF_INFO = 1, 2, 4, 0x10
NIIF = {"info": 1, "warning": 2, "error": 3}           # the small icon in a notification
NIN_BALLOONUSERCLICK = 0x0405                          # the person clicked the notification
MF_STRING, MF_SEPARATOR = 0x0, 0x800
TPM_RIGHTBUTTON, TPM_RETURNCMD = 0x2, 0x100
IMAGE_ICON, LR_LOADFROMFILE = 1, 0x10
SM_CXSMICON = 49
IDI_APPLICATION = 32512


# ----- structures with explicit sizes (text fields are arrays of 16-bit units, which is what Windows' WCHAR is), so the layout
# is the same wherever they are built and can be checked in tests
def utf16(text, n):
    """Text as a fixed array of n UTF-16 code units, always ending in 0."""
    raw = text.encode("utf-16-le")[:(n - 1) * 2]
    units = [int.from_bytes(raw[i:i + 2], "little") for i in range(0, len(raw) - len(raw) % 2, 2)]
    return (ctypes.c_uint16 * n)(*units)


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_int32), ("y", ctypes.c_int32)]


class MSG(ctypes.Structure):
    _fields_ = [("hwnd", ctypes.c_void_p), ("message", ctypes.c_uint32), ("wParam", ctypes.c_size_t),
                ("lParam", ctypes.c_ssize_t), ("time", ctypes.c_uint32), ("pt", POINT)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [("style", ctypes.c_uint32), ("lpfnWndProc", ctypes.c_void_p), ("cbClsExtra", ctypes.c_int32),
                ("cbWndExtra", ctypes.c_int32), ("hInstance", ctypes.c_void_p), ("hIcon", ctypes.c_void_p),
                ("hCursor", ctypes.c_void_p), ("hbrBackground", ctypes.c_void_p), ("lpszMenuName", ctypes.c_wchar_p),
                ("lpszClassName", ctypes.c_wchar_p)]


class GUID(ctypes.Structure):
    _fields_ = [("a", ctypes.c_uint32), ("b", ctypes.c_uint16), ("c", ctypes.c_uint16), ("d", ctypes.c_ubyte * 8)]


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint32), ("hWnd", ctypes.c_void_p), ("uID", ctypes.c_uint32), ("uFlags", ctypes.c_uint32),
                ("uCallbackMessage", ctypes.c_uint32), ("hIcon", ctypes.c_void_p), ("szTip", ctypes.c_uint16 * 128),
                ("dwState", ctypes.c_uint32), ("dwStateMask", ctypes.c_uint32), ("szInfo", ctypes.c_uint16 * 256),
                ("uTimeout", ctypes.c_uint32), ("szInfoTitle", ctypes.c_uint16 * 64), ("dwInfoFlags", ctypes.c_uint32),
                ("guidItem", GUID), ("hBalloonIcon", ctypes.c_void_p)]


def action_for(message, lparam):
    """What a click on the icon means: 'open', 'menu' or None."""
    if message != WM_APP_TRAY:
        return None
    if lparam in (WM_LBUTTONUP, WM_LBUTTONDBLCLK, NIN_BALLOONUSERCLICK):        # 1.72.2: clicking a notification opens Tallomi too
        return "open"
    if lparam == WM_RBUTTONUP:
        return "menu"
    return None


def balloon(hwnd, title, text, kind="info"):
    """1.72.2 — what Windows needs to show a notification from the tray icon (bottom-right; a toast on Windows 10/11)."""
    nid = NOTIFYICONDATAW()
    nid.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
    nid.hWnd = hwnd
    nid.uID = 1
    nid.uFlags = NIF_INFO
    nid.szInfoTitle = utf16(title, 64)
    nid.szInfo = utf16(text, 256)
    nid.uTimeout = 10000
    nid.dwInfoFlags = NIIF.get(kind, NIIF["info"])
    return nid


def icon_source():
    """Where the icon comes from: the program's own icon when built as an exe, else assets/pennyworth.ico."""
    if getattr(sys, "frozen", False):
        return ("exe", sys.executable)
    ico = Path(__file__).resolve().parent.parent / "assets" / "pennyworth.ico"
    return ("file", str(ico)) if ico.is_file() else (None, None)


WM_TIMER = 0x0113
RETRY_TIMER_ID = 1


def retry_interval_ms(tries):
    """Right after sign-in the taskbar may not exist yet, so adding the icon can fail. Try again: every 2 s for the first minute,
    then every 10 s for about five more minutes; after that give up (Windows also tells us when the taskbar appears)."""
    if tries < 30:
        return 2000
    if tries < 60:
        return 10000
    return None


class Tray:
    def __init__(self, on_open, on_quit, tip=TIP, extras=()):
        self.on_open, self.on_quit, self.tip = on_open, on_quit, tip
        self.extras = list(extras or ())
        self.hwnd = None
        self._thread = None
        self._ready = threading.Event()
        self.ok = False

    def start(self, timeout=5.0):
        """Show the icon. Returns True if it is up. Never raises."""
        if os.name != "nt" or os.environ.get("PENNYWORTH_NO_TRAY"):
            return False
        self._thread = threading.Thread(target=self._guarded, name="tray", daemon=True)
        self._thread.start()
        self._ready.wait(timeout)
        return self.ok

    def stop(self):
        if os.name == "nt" and self.hwnd:
            try:
                ctypes.WinDLL("user32").PostMessageW(ctypes.c_void_p(self.hwnd), WM_CLOSE, 0, 0)
            except Exception:
                logging.exception("could not remove the tray icon")
        t = self._thread
        if t is not None and t is not threading.current_thread():
            t.join(2.0)                                   # let Windows take the icon away before the program exits (no ghost icon)

    def _guarded(self):
        try:
            self._run()
        except Exception:
            logging.exception("tray icon failed; Tallomi keeps running without it")
        finally:
            self._ready.set()

    def _run(self):
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        VP, UI, SZ, SSZ = ctypes.c_void_p, ctypes.c_uint32, ctypes.c_size_t, ctypes.c_ssize_t
        WNDPROC = ctypes.WINFUNCTYPE(SSZ, VP, UI, SZ, SSZ)

        def sig(fn, res, *args):
            fn.restype, fn.argtypes = res, list(args)
        sig(user32.DefWindowProcW, SSZ, VP, UI, SZ, SSZ)
        sig(user32.RegisterClassW, ctypes.c_uint16, ctypes.POINTER(WNDCLASSW))
        sig(user32.CreateWindowExW, VP, UI, ctypes.c_wchar_p, ctypes.c_wchar_p, UI, ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_int, VP, VP, VP, VP)
        sig(user32.DestroyWindow, ctypes.c_int, VP)
        sig(user32.GetMessageW, ctypes.c_int, ctypes.POINTER(MSG), VP, UI, UI)
        sig(user32.TranslateMessage, ctypes.c_int, ctypes.POINTER(MSG))
        sig(user32.DispatchMessageW, SSZ, ctypes.POINTER(MSG))
        sig(user32.PostMessageW, ctypes.c_int, VP, UI, SZ, SSZ)
        sig(user32.PostQuitMessage, None, ctypes.c_int)
        sig(user32.RegisterWindowMessageW, UI, ctypes.c_wchar_p)
        sig(user32.CreatePopupMenu, VP)
        sig(user32.AppendMenuW, ctypes.c_int, VP, UI, SZ, ctypes.c_wchar_p)
        sig(user32.TrackPopupMenu, ctypes.c_int, VP, UI, ctypes.c_int, ctypes.c_int, ctypes.c_int, VP, VP)
        sig(user32.DestroyMenu, ctypes.c_int, VP)
        sig(user32.SetForegroundWindow, ctypes.c_int, VP)
        sig(user32.GetCursorPos, ctypes.c_int, ctypes.POINTER(POINT))
        sig(user32.LoadImageW, VP, VP, ctypes.c_wchar_p, UI, ctypes.c_int, ctypes.c_int, UI)
        sig(user32.LoadIconW, VP, VP, VP)
        sig(user32.GetSystemMetrics, ctypes.c_int, ctypes.c_int)
        sig(user32.SetTimer, SZ, VP, SZ, UI, VP)
        sig(user32.KillTimer, ctypes.c_int, VP, SZ)
        sig(shell32.Shell_NotifyIconW, ctypes.c_int, UI, ctypes.POINTER(NOTIFYICONDATAW))
        sig(shell32.ExtractIconW, VP, VP, ctypes.c_wchar_p, UI)
        sig(kernel32.GetModuleHandleW, VP, ctypes.c_wchar_p)

        hinst = kernel32.GetModuleHandleW(None)
        kind, src = icon_source()
        hicon = None
        if kind == "exe":
            h = shell32.ExtractIconW(hinst, src, 0)
            hicon = h if h and h != 1 else None
        elif kind == "file":
            px = user32.GetSystemMetrics(SM_CXSMICON) or 16
            hicon = user32.LoadImageW(None, src, IMAGE_ICON, px, px, LR_LOADFROMFILE)
        if not hicon:
            hicon = user32.LoadIconW(None, ctypes.c_void_p(IDI_APPLICATION))
        taskbar_created = user32.RegisterWindowMessageW("TaskbarCreated")      # Explorer restarted: the icon must be added again

        nid = NOTIFYICONDATAW()
        nid.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        nid.uID = 1
        nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
        nid.uCallbackMessage = WM_APP_TRAY
        nid.hIcon = hicon
        nid.szTip = utf16(self.tip, 128)

        def add_icon():
            nid.hWnd = self.hwnd
            return bool(shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid)))

        tries = [0]

        def retry_later(hwnd):
            wait = retry_interval_ms(tries[0])
            if wait is None:
                user32.KillTimer(hwnd, RETRY_TIMER_ID)
                logging.warning("tray icon could not be added; giving up (Tallomi keeps running)")
            else:
                user32.SetTimer(hwnd, RETRY_TIMER_ID, wait, None)

        def show_menu(hwnd):
            menu = user32.CreatePopupMenu()
            try:
                for e in menu_layout(self.extras):
                    if e is None:
                        user32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
                    else:
                        user32.AppendMenuW(menu, MF_STRING, e[0], e[1])
                pt = POINT()
                user32.GetCursorPos(ctypes.byref(pt))
                user32.SetForegroundWindow(hwnd)                              # without this the menu does not close when you click elsewhere
                cmd = user32.TrackPopupMenu(menu, TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, 0, hwnd, None)
                user32.PostMessageW(hwnd, WM_NULL, 0, 0)
            finally:
                user32.DestroyMenu(menu)
            return cmd

        def run_async(fn):                                                    # never block the message loop
            threading.Thread(target=self._safe, args=(fn,), daemon=True).start()

        def wndproc(hwnd, msg, wparam, lparam):
            try:
                act = action_for(msg, lparam)
                if act == "open":
                    run_async(self.on_open)
                    return 0
                if act == "menu":
                    cmd = show_menu(hwnd)
                    if cmd == MENU_OPEN:
                        run_async(self.on_open)
                    elif cmd == MENU_QUIT:
                        run_async(self.on_quit)
                    elif cmd and cmd >= MENU_EXTRA and cmd - MENU_EXTRA < len(self.extras) and self.extras[cmd - MENU_EXTRA]:
                        run_async(self.extras[cmd - MENU_EXTRA][1])
                    return 0
                if msg == taskbar_created:
                    if add_icon():
                        user32.KillTimer(hwnd, RETRY_TIMER_ID)
                        logging.info("tray icon is up (the taskbar appeared)")
                    return 0
                if msg == WM_TIMER and wparam == RETRY_TIMER_ID:
                    tries[0] += 1
                    if add_icon():
                        user32.KillTimer(hwnd, RETRY_TIMER_ID)
                        logging.info("tray icon is up (after %d retries)", tries[0])
                    else:
                        retry_later(hwnd)
                    return 0
                if msg == WM_DESTROY:
                    shell32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(nid))
                    user32.PostQuitMessage(0)
                    return 0
            except Exception:
                logging.exception("tray message failed")
            return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

        proc = WNDPROC(wndproc)                                               # keep a reference: it must outlive the loop
        cls = WNDCLASSW()
        cls.lpfnWndProc = ctypes.cast(proc, ctypes.c_void_p).value
        cls.hInstance = hinst
        cls.lpszClassName = "PennyworthTray"
        if not user32.RegisterClassW(ctypes.byref(cls)) and ctypes.get_last_error() != 1410:    # 1410 = already registered
            raise OSError(f"RegisterClass failed ({ctypes.get_last_error()})")
        # A hidden top-level window (not message-only) so it also gets the "TaskbarCreated" broadcast. It is never shown.
        hwnd = user32.CreateWindowExW(0x80, "PennyworthTray", "Tallomi", 0, 0, 0, 0, 0, None, None, hinst, None)
        if not hwnd:
            raise OSError(f"CreateWindow failed ({ctypes.get_last_error()})")
        self.hwnd = hwnd
        self.ok = True
        if not add_icon():                       # just after sign-in the taskbar may not be ready: keep the window and try again
            logging.warning("taskbar not ready yet; will retry adding the tray icon")
            retry_later(hwnd)
        self._ready.set()
        msg = MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        self.hwnd = None

    def notify(self, title, text, kind="info"):
        """Show a Windows notification from the tray icon. Any thread may call it. Returns True when Windows took it; never raises."""
        if os.name != "nt" or not self.hwnd:
            return False
        try:
            shell32 = ctypes.WinDLL("shell32")
            shell32.Shell_NotifyIconW.restype = ctypes.c_int
            shell32.Shell_NotifyIconW.argtypes = [ctypes.c_uint32, ctypes.POINTER(NOTIFYICONDATAW)]
            return bool(shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(balloon(self.hwnd, title, text, kind))))
        except Exception:
            logging.exception("could not show a notification")
            return False

    @staticmethod
    def _safe(fn):
        try:
            fn()
        except Exception:
            logging.exception("tray action failed")
