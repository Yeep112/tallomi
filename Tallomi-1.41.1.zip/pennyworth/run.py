"""Tallomi launcher.

  python run.py              open the app window (pywebview/Edge WebView2) or fall back to the browser
  python run.py --browser    force browser mode
  python run.py --no-open    just serve (development / tests)
"""
import argparse
import atexit
import json
import logging
import logging.handlers
import os
import random
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

from app import config

PREFERRED_PORT = 48765          # fixed so a second launch can find the running instance
HOST = "127.0.0.1"


def _port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            if os.name != "nt":                      # like the server itself: connections still winding down do not count as "in use"
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((HOST, port))
            return True
        except OSError:
            return False


_LOCAL = urllib.request.build_opener(urllib.request.ProxyHandler({}))      # never go through a system / VPN proxy


def _is_pennyworth(port):
    try:
        with _LOCAL.open(f"http://{HOST}:{port}/api/ping", timeout=1.5) as r:
            return json.loads(r.read().decode()).get("app") == "pennyworth"
    except Exception:
        return False


def _running_version(port):
    try:
        with _LOCAL.open(f"http://{HOST}:{port}/api/ping", timeout=1.5) as r:
            return json.loads(r.read().decode()).get("version")
    except Exception:
        return None


def _stop_old_copy(port):
    """An older Tallomi is still running in the background (it stays up while phone access is on, or after an upgrade copied
    new files over it). Its screens would be new but its engine old, so ask it to quit and wait for the port. True = it is gone."""
    try:
        req = urllib.request.Request(f"http://{HOST}:{port}/api/shutdown", data=b"{}", method="POST",
                                     headers={"X-Pennyworth": "1", "Content-Type": "application/json"})
        _LOCAL.open(req, timeout=3).read()
    except Exception:
        logging.exception("could not ask the old copy to quit")
    for _ in range(60):
        if _port_free(port):
            return True
        time.sleep(0.2)
    return False


def _find_app_browser():
    """Edge (always on Windows 10/11) or Chrome, to open Tallomi as a bare app window (no tabs / address bar)."""
    if os.name != "nt":
        return None
    roots = [os.environ.get(k) for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
    rel = (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe")
    for r in rel:
        for root in roots:
            if root and os.path.isfile(os.path.join(root, r)):
                return os.path.join(root, r)
    return None


def _open_ui(url, plain_tab=False):
    exe = None if plain_tab else _find_app_browser()
    if exe:
        try:
            # Own browser profile: the window is its own app (own taskbar group, shows the honeycomb-T from the page icon),
            # separate from the user's normal Edge/Chrome tabs.
            profile = str(config.data_dir() / "app-window")
            subprocess.Popen([exe, f"--app={url}", "--window-size=1280,840", f"--user-data-dir={profile}",
                              "--no-first-run", "--no-default-browser-check"])
            return
        except Exception:
            logging.exception("could not open an app window, using the default browser")
    webbrowser.open(url)


def _open_folder(path):
    """Show a folder in the file explorer (the tray menu's shortcuts)."""
    try:
        path.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(str(path))  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        logging.exception("could not open the folder %s", path)


def _tray_extras(url, browser):
    """The extra right-click entries of the tray icon: add a transaction right away, jump to the backup / export folders."""
    root = config.book_dir()
    return [("記一筆", lambda: _open_ui(url + "?add=1#/transactions", browser)), None,
            ("開啟備份資料夾", lambda: _open_folder(root / "backups")),
            ("開啟匯出資料夾", lambda: _open_folder(root / "exports"))]


def _self_command():
    return [sys.executable] if getattr(sys, "frozen", False) else [sys.executable, os.path.abspath(sys.argv[0])]


def _restart_command(use_window):
    """The command that starts this program again with the same options (used after switching between the books)."""
    skip = {"--background", "--wait-port", "--restarted"}
    rest = [a for a in sys.argv[1:] if a not in skip]
    base = [sys.executable] if getattr(sys, "frozen", False) else [sys.executable, os.path.abspath(sys.argv[0])]
    # With a normal window the new copy opens its own window; otherwise the window that is already open reloads itself.
    return base + rest + (["--wait-port"] if use_window else ["--restarted"])


def _spawn_detached(cmd):
    kw = {"close_fds": True, "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if os.name == "nt":
        kw["creationflags"] = 0x00000008 | 0x00000200          # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    else:
        kw["start_new_session"] = True
    subprocess.Popen(cmd, **kw)


def _wait_for_old_copy(port, seconds=30):
    """After a switch the previous copy is still shutting down: wait until it has let go of the port."""
    end = time.time() + seconds
    while time.time() < end and not _port_free(port) and _is_pennyworth(port):
        time.sleep(0.2)


def _hide_console():
    if os.name != "nt":
        return
    try:
        import ctypes
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)       # SW_HIDE
    except Exception:
        pass


def _report(msg):
    """Tell the user something went wrong. A windowed exe / pythonw has no console, so use a message box."""
    if sys.stderr is not None:
        print(msg, file=sys.stderr)
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, msg, "Tallomi", 0x10)
    except Exception:
        pass


def _setup_logging():
    log_file = config.data_dir() / "pennyworth.log"
    h = logging.handlers.RotatingFileHandler(log_file, maxBytes=512_000, backupCount=2, encoding="utf-8")
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(h)
    logging.getLogger("waitress").setLevel(logging.ERROR)


def _remember_location(force=False):
    """Tell the desktop shortcut where this program folder is, so it still opens after the folder is moved."""
    if os.name != "nt" and not force:
        return
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        if not os.path.exists(os.path.join(here, ".pennyworth-home")):
            return
        target = config.data_dir() / "program_location.txt"
        if not target.exists() or target.read_text(encoding="utf-8-sig").strip() != here:
            target.write_text(here, encoding="utf-8")
    except Exception:
        logging.exception("could not remember the program location")


def _fetch_rates_only(force=False):
    """No window: used by the optional daily scheduled task. Skips quietly when today's update is already done."""
    from app.book import Book
    from app.fxauto import FxAuto
    from app.stockauto import StockAuto
    book = Book(config.data_dir())
    fx, st = FxAuto(book), StockAuto(book)
    if not force and not (fx.enabled() and not fx.done_today()):
        logging.info("rate update: nothing to do")
    else:
        ok = fx.run_once()
        logging.info("rate update (scheduled): %s", "ok" if ok else fx.status["state"])
    if not force and not (st.enabled() and not st.done_today()):
        logging.info("stock price update: nothing to do")
    else:
        ok = st.run_once()
        logging.info("stock price update (scheduled): %s", "ok" if ok else st.status["state"])
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--browser", action="store_true", help="use a normal browser tab instead of an app window")
    ap.add_argument("--no-open", action="store_true", help="do not open any window (and no tray icon: for tests / dev servers)")
    ap.add_argument("--background", action="store_true", help="start quietly: no window, only the tray icon (used by start at sign-in)")
    ap.add_argument("--port", type=int, default=0)
    ap.add_argument("--fetch-rates", action="store_true", help="read today's bank rates once (if not done today) and exit")
    ap.add_argument("--force", action="store_true", help="with --fetch-rates: even if today's update is already done")
    ap.add_argument("--wait-port", action="store_true", help="(used by the program itself after switching books) wait until the previous copy has quit")
    ap.add_argument("--restarted", action="store_true", help="(used by the program itself) quiet start without a window, after switching books")
    ap.add_argument("--hide-console", action="store_true", help="(Windows) hide the console window once started")
    args = ap.parse_args(argv)

    _setup_logging()
    _remember_location()
    if args.fetch_rates:
        return _fetch_rates_only(args.force)
    port = args.port or PREFERRED_PORT
    if args.restarted:
        args.background = True
    if args.restarted or args.wait_port:
        _wait_for_old_copy(port)
    if config.updates_enabled() and not args.fetch_rates and not (args.no_open and args.port) and (_port_free(port) or not _is_pennyworth(port)):
        try:                                           # an update that was downloaded earlier is put in place before anything starts
            from app.updater import Updater
            if Updater(book_dir=config.book_dir()).startup() == "restart":
                logging.info("program files changed, starting again")
                _spawn_detached(_self_command() + sys.argv[1:])
                return 0
        except Exception:
            logging.exception("update step failed, starting normally")
    if not _port_free(port):
        if _is_pennyworth(port):
            old = _running_version(port)
            if old and old != config.VERSION and not args.no_open and _stop_old_copy(port):
                logging.info("replaced the running copy %s with %s", old, config.VERSION)     # fall through: start this version
            else:                                      # already running (same version) -> just show it
                if not (args.no_open or args.background):
                    _open_ui(f"http://{HOST}:{port}/", args.browser)
                return 0
    if not _port_free(port):
        port = random.randint(49152, 65000)
        while not _port_free(port):
            port = random.randint(49152, 65000)
    url = f"http://{HOST}:{port}/"

    from app.server import create_app
    try:
        app = create_app()
    except Exception:
        logging.exception("could not open the book")
        raise
    stop = threading.Event()
    app.config["shutdown_cb"] = stop.set
    if not (args.no_open and args.port):            # (tests / dev servers started with --no-open --port do not phone the banks)
        app.config["fxauto"].start()
        app.config["stockauto"].start()
        app.config["market"].start()
        app.config["autobackup"].start()
        if app.config.get("updateworker"):
            app.config["updateworker"].start()

    use_window = False
    if not (args.browser or args.no_open or args.background):
        try:
            import webview  # noqa: F401
            use_window = True
        except Exception:
            use_window = False
    app.config["mode"] = "window" if use_window else "browser"

    tray = None

    def quit_all():                                  # 「結束 Tallomi」: stop the program, and the app window too if it is one of ours
        app.config["autobackup"].on_quit()           # one last automatic backup if anything changed since the previous one
        stop.set()
        if tray is not None:
            tray.stop()
        if use_window:
            try:
                import webview
                for w in list(webview.windows):
                    w.destroy()
            except Exception:
                logging.exception("could not close the window")
    app.config["shutdown_cb"] = quit_all

    def restart_self():                              # switching between my own book and the preview: start the program again
        try:
            _spawn_detached(_restart_command(use_window))
        except Exception:
            logging.exception("could not start the program again")
            return
        quit_all()
    app.config["restart_cb"] = restart_self

    def serve():
        try:
            from waitress import serve as wserve
            wserve(app, host=HOST, port=port, threads=6, ident="Tallomi")
        except ImportError:
            app.run(host=HOST, port=port, threaded=True, use_reloader=False)

    threading.Thread(target=serve, name="http", daemon=True).start()
    for _ in range(100):
        if _is_pennyworth(port):
            break
        time.sleep(0.1)
    else:
        logging.error("server did not start on port %s", port)
        _report(f"Tallomi could not start its local server on port {port}.\n"
                f"Details are in: {config.data_dir() / 'pennyworth.log'}")
        return 1
    logging.info("Tallomi %s serving on %s (mode=%s)", config.VERSION, url, app.config["mode"])
    if app.config.get("updater"):
        app.config["updater"].mark_healthy()          # this version came up fine: no need to go back to the previous one
    if args.background and not args.restarted:
        from app import autostart
        autostart.note_background_start()
        logging.info("quiet start (cwd=%s, python=%s)", os.getcwd(), sys.executable)

    if args.hide_console:
        _hide_console()
    if not args.no_open:
        from app import autostart
        autostart.refresh_if_enabled()

    if not args.no_open:                              # the notification-area icon: shows that Tallomi keeps running after its window is closed
        from app.tray import Tray
        tray = Tray(on_open=lambda: _open_ui(url, args.browser), on_quit=app.config["shutdown_cb"], extras=_tray_extras(url, args.browser))
        if tray.start():
            logging.info("tray started")
            atexit.register(tray.stop)
        else:
            tray = None

    if args.no_open or args.background:
        try:
            stop.wait()
        except KeyboardInterrupt:
            pass
        return 0

    if use_window:
        try:
            import webview
            webview.create_window("Tallomi", url, width=1280, height=840, min_size=(980, 640))
            webview.start()                      # blocks until the window is closed
            logging.info("window closed, staying in the background (Settings > 結束 Tallomi stops it)")
            stop.wait()
            return 0
        except Exception:
            logging.exception("window mode failed, falling back to browser")
            app.config["mode"] = "browser"

    # Browser / Edge-app mode: closing the window does NOT stop the program. It keeps running in the background (rate / price
    # updates, phone sync) until "結束 Tallomi" in Settings is pressed (or the process is ended in the Task Manager).
    # Starting Tallomi again while it runs just opens a new window on it.
    _open_ui(url, args.browser)
    stop.wait()
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception as e:
        logging.getLogger().exception("fatal error")
        _report(f"Tallomi could not start.\n\n{type(e).__name__}: {e}\n\n"
                f"Details are in: {config.data_dir() / 'pennyworth.log'}")
        code = 1
    sys.exit(code)
