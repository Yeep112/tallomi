@echo off
REM Undoes enable_phone_access.bat: phones can no longer reach this computer.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\phone_access.ps1" -Remove
echo.
pause
