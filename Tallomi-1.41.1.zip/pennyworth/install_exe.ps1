# Copies dist\Pennyworth to %LOCALAPPDATA%\Programs\Pennyworth and creates desktop + Start-menu shortcuts to the exe.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $root 'dist\Pennyworth'
$dst = Join-Path $env:LOCALAPPDATA 'Programs\Pennyworth'
if (-not (Test-Path (Join-Path $src 'Pennyworth.exe'))) { throw "Pennyworth.exe not found in $src" }

# A running copy would lock its files.
Get-Process -Name Pennyworth -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 700

New-Item -ItemType Directory -Force -Path $dst | Out-Null
robocopy $src $dst /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Copying files failed (robocopy exit code $LASTEXITCODE)" }
$global:LASTEXITCODE = 0

$exe = Join-Path $dst 'Pennyworth.exe'
$ws = New-Object -ComObject WScript.Shell
function New-Link($folder) {
    $path = Join-Path $folder 'Tallomi.lnk'
    $lnk = $ws.CreateShortcut($path)
    $lnk.TargetPath = $exe
    $lnk.WorkingDirectory = $dst
    $lnk.IconLocation = "$exe,0"
    $lnk.Description = 'Tallomi bookkeeping'
    $lnk.Save()
    Write-Host "Created: $path"
}
New-Link ([Environment]::GetFolderPath('Desktop'))
New-Link ([Environment]::GetFolderPath('Programs'))
Write-Host "Installed to: $dst"
Write-Host "Your data stays in: $env:APPDATA\Pennyworth"
