@echo off
setlocal
pushd "%~dp0"
set "HERE=%~dp0"
set "PSHERE=%HERE:'=''%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Recurse -Force -LiteralPath '%PSHERE%' | Unblock-File" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1" %*
if errorlevel 1 goto :fail
echo.
echo Done. Double-click "Tallomi" on your desktop to start.
echo You can move this program folder anywhere: the shortcut finds it again by itself.
echo (If you move it, the first start afterwards can take up to a minute while it searches.)
pause
exit /b 0

:fail
echo.
echo Could not create the shortcut. Please copy the messages above and send them over.
pause
exit /b 1
