@echo off
REM Lets your phone use Tallomi (through your own private Tailscale network). See README "手機版".
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\phone_access.ps1"
echo.
pause
