@echo off
setlocal
pushd "%~dp0"
set "HERE=%~dp0"
set "PSHERE=%HERE:'=''%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Recurse -Force -LiteralPath '%PSHERE%' | Unblock-File" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install.ps1"
if errorlevel 1 (
  echo.
  echo ===== Installation did not finish. Please copy ALL the messages above and send them over. =====
  pause
  exit /b 1
)
exit /b 0
