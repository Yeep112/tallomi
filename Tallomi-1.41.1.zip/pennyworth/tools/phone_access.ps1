﻿# Lets your phone reach Pennyworth on this computer, privately, through Tailscale (https://tailscale.com, free for personal use).
#   1. Makes `tailscale serve` pass https requests from YOUR devices to Tallomi (nothing is opened to the public internet).
#   2. Starts Tallomi in the background (no window) every time you sign in to Windows, so the phone can connect.
# Run it again any time; run it with -Remove to undo both.
param([switch]$Remove)
$ErrorActionPreference = 'Stop'
$port = 48765
$taskName = 'Pennyworth for phone (background)'

function Find-Tailscale {
    $cmd = Get-Command tailscale.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach ($p in @("$env:ProgramFiles\Tailscale\tailscale.exe", "${env:ProgramFiles(x86)}\Tailscale\tailscale.exe", "$env:LOCALAPPDATA\Tailscale\tailscale.exe")) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}

$ts = Find-Tailscale
if ($Remove) {
    if ($ts) { try { & $ts serve reset | Out-Null } catch { } }
    Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "Done. Phones can no longer reach this computer, and Tallomi no longer starts by itself at sign-in."
    exit 0
}
if (-not $ts) {
    Write-Host "Tailscale is not installed on this computer."
    Write-Host "  1. Install it from https://tailscale.com/download and sign in (the phone needs the same account)."
    Write-Host "  2. In the Tailscale admin page (login.tailscale.com/admin/dns) turn on 'MagicDNS' and 'HTTPS Certificates'."
    Write-Host "  3. Run this file again."
    exit 2
}

Write-Host "Using $ts"
Write-Host "Asking Tailscale to hand your devices' https requests to Tallomi (port $port)..."
Write-Host "If a web link shows up below, open it in a browser and switch the feature on (Tailscale asks once);"
Write-Host "this window then carries on by itself."
Write-Host ""
& $ts serve --bg $port
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "[!] tailscale serve did not work. If the message above mentions HTTPS or Serve being disabled, open the link it shows"
    Write-Host "    (or login.tailscale.com/admin/dns), switch on 'HTTPS Certificates', then run this file again."
    exit 3
}

# the address the phone should open
$url = $null
try {
    $st = & $ts status --json | ConvertFrom-Json
    $name = ([string]$st.Self.DNSName).TrimEnd('.')
    if ($name) { $url = "https://$name" }
} catch { }

# start Tallomi in the background at every sign-in (and right now)
$launcherDir = Join-Path $env:LOCALAPPDATA 'Pennyworth\launcher'
$vbs = Join-Path $launcherDir 'launch.vbs'
if (Test-Path $launcherDir) {                 # bring the launcher up to date (the new -Background option)
    foreach ($f in 'launch.ps1', 'launch.cmd', 'launch.vbs') { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $f) -Destination $launcherDir -Force -ErrorAction SilentlyContinue }
}
if (Test-Path $vbs) {
    $action = New-ScheduledTaskAction -Execute (Join-Path $env:SystemRoot 'System32\wscript.exe') -Argument ('//B //Nologo "' + $vbs + '" -Background')
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)
    try {
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
        Write-Host "Tallomi will now start quietly in the background each time you sign in."
    } catch {
        Write-Host "[info] Could not create the sign-in task ($($_.Exception.Message)). You can still open Tallomi yourself before using the phone."
    }
} else {
    Write-Host "[info] Run install_pennyworth.bat (or create_shortcut.bat) once first, so Tallomi can start by itself at sign-in."
}

Write-Host ""
Write-Host "=============================================================="
if ($url) {
    Write-Host " Open this address on your phone (Tailscale must be on):"
    Write-Host "     $url"
    try { Set-Clipboard -Value $url; Write-Host " (copied to the clipboard)" } catch { }
} else {
    Write-Host " Run:  tailscale serve status   to see the https address."
}
Write-Host ""
Write-Host " Next: open Tallomi > 設定 > 手機連線, switch on 允許手機連線,"
Write-Host " paste the address, press 產生配對碼 and scan the QR code with the phone."
Write-Host "=============================================================="
