@echo off
rem Stable entry point used by the desktop / Start menu / taskbar shortcuts. It lives outside the program
rem folder, so the shortcuts keep working when that folder is moved anywhere.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0launch.ps1" %*
