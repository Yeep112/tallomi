﻿# Finds the Pennyworth program folder wherever it has been moved to, then starts it.
#  1. Use the location remembered from the last run (%APPDATA%\Pennyworth\program_location.txt).
#  2. If the folder is no longer there, search for the marker file ".pennyworth-home": likely places first
#     (Desktop, Downloads, Documents, OneDrive), then the user profile, then every fixed drive.
#  3. Remember the new location, so later launches are instant.
param([switch]$FetchRates, [switch]$Background)
$ErrorActionPreference = 'SilentlyContinue'
$dataDir = Join-Path $env:APPDATA 'Pennyworth'
$locFile = Join-Path $dataDir 'program_location.txt'
$marker  = '.pennyworth-home'
$logFile = Join-Path $dataDir 'launch.log'
function Log([string]$m) { try { New-Item -ItemType Directory -Force -Path $dataDir | Out-Null; Add-Content -LiteralPath $logFile -Value ((Get-Date -Format 's') + ' ' + $m) -Encoding UTF8 } catch { } }

function Test-Home([string]$d) {
    if (-not $d) { return $false }
    return (Test-Path -LiteralPath (Join-Path $d $marker)) -and (Test-Path -LiteralPath (Join-Path $d 'start_pennyworth.bat'))
}

function Search-Under([string]$path, [int]$depth) {
    if (-not (Test-Path -LiteralPath $path)) { return @() }
    $hits = Get-ChildItem -LiteralPath $path -Filter $marker -Recurse -Depth $depth -File -Force -ErrorAction SilentlyContinue
    $dirs = @()
    foreach ($h in $hits) { if (Test-Home $h.DirectoryName) { $dirs += $h.DirectoryName } }
    return $dirs
}

function Newest([string[]]$dirs) {
    $best = $null; $bestTime = [datetime]::MinValue
    foreach ($d in $dirs) {
        $t = (Get-Item -LiteralPath (Join-Path $d 'start_pennyworth.bat')).LastWriteTime
        if ($t -gt $bestTime) { $best = $d; $bestTime = $t }
    }
    return $best
}

$dir = $null
if (Test-Path -LiteralPath $locFile) {
    $saved = (Get-Content -LiteralPath $locFile -Encoding UTF8 -TotalCount 1)
    if ($saved) { $saved = $saved.Trim() }
    if (Test-Home $saved) { $dir = $saved }
}

if (-not $dir) {
    $deadline = (Get-Date).AddSeconds(180)
    $profileDir = $env:USERPROFILE

    # stage 1: the usual places
    $likely = @("$profileDir\Desktop", "$profileDir\Downloads", "$profileDir\Documents", $env:OneDrive, $env:OneDriveConsumer, $env:OneDriveCommercial) | Where-Object { $_ }
    $found = @()
    foreach ($p in $likely) { $found += Search-Under $p 6 }
    $dir = Newest $found

    # stage 2: the rest of the user profile
    if (-not $dir -and (Get-Date) -lt $deadline) {
        $found = @()
        foreach ($c in (Get-ChildItem -LiteralPath $profileDir -Directory -Force -ErrorAction SilentlyContinue)) {
            if ($c.Name -in @('AppData', 'Desktop', 'Downloads', 'Documents')) { continue }
            if ((Get-Date) -gt $deadline) { break }
            $found += Search-Under $c.FullName 6
        }
        $dir = Newest $found
    }

    # stage 3: every fixed drive (skipping system folders)
    if (-not $dir -and (Get-Date) -lt $deadline) {
        $skip = @('Windows', 'Program Files', 'Program Files (x86)', 'ProgramData', '$Recycle.Bin', 'System Volume Information', 'Recovery', 'Users')
        $found = @()
        foreach ($drive in (Get-PSDrive -PSProvider FileSystem)) {
            $root = $drive.Root
            if (-not $root) { continue }
            if (Test-Home $root.TrimEnd('\')) { $found += $root.TrimEnd('\') }
            foreach ($c in (Get-ChildItem -LiteralPath $root -Directory -Force -ErrorAction SilentlyContinue)) {
                if ($skip -contains $c.Name) { continue }
                if ((Get-Date) -gt $deadline) { break }
                $found += Search-Under $c.FullName 6
            }
        }
        $dir = Newest $found
    }

    if ($dir) {
        New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
        Set-Content -LiteralPath $locFile -Value $dir -Encoding UTF8
    }
}

Log ("program folder: " + $dir)
if (-not $dir) {
    $msg = "找不到 Pennyworth 的程式資料夾。`n`n請打開你放 Pennyworth 的資料夾，雙擊 create_shortcut.bat 一次，之後不管搬到哪裡都能開啟。"
    try { $ws = New-Object -ComObject WScript.Shell; [void]$ws.Popup($msg, 0, 'Tallomi', 16) } catch { }
    exit 1
}

if ($FetchRates) {
    Log 'reading bank rates (scheduled)'
    Start-Process -FilePath (Join-Path $dir '.venv\Scripts\python.exe') -ArgumentList @('run.py', '--fetch-rates') -WorkingDirectory $dir -WindowStyle Hidden
    exit 0
}
if ($Background) {
    Log 'starting in the background (no window, for the phone)'
    Start-Process -FilePath (Join-Path $dir '.venv\Scripts\python.exe') -ArgumentList @('run.py', '--background') -WorkingDirectory $dir -WindowStyle Hidden
    exit 0
}
Log 'starting start_pennyworth.bat'
Start-Process -FilePath (Join-Path $dir 'start_pennyworth.bat') -WorkingDirectory $dir -WindowStyle Hidden
