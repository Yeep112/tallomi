"""Build the engine test add-on: a few extra files that go INTO the existing app/ folder of the update space (nothing else changes).

  python tools/build_engine_addon.py OUT_DIR

The add-on holds the engine test page (phone/engine.*) and other Pyodide builds kept in phone_runtime/engines/<version>/.
It is not part of any release; it only helps to find out which Python engine an iPhone can start.
"""
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def build(out):
    out = Path(out)
    if out.exists():
        shutil.rmtree(out)
    app = out / "app"
    app.mkdir(parents=True)
    for name in ("engine.html", "engine.js", "engine-worker.js"):
        shutil.copy2(ROOT / "phone" / name, app / name)
    eng = ROOT / "phone_runtime" / "engines"
    n = 0
    for d in sorted(p for p in eng.iterdir() if p.is_dir()):
        (app / "engines" / d.name).mkdir(parents=True)
        for f in d.iterdir():
            shutil.copy2(f, app / "engines" / d.name / f.name)
            n += 1
    files = [p for p in out.rglob("*") if p.is_file()]
    print(f"engine add-on: {out} ({len(files)} files, {sum(p.stat().st_size for p in files) // 1048576} MB)")
    return 0


if __name__ == "__main__":
    sys.exit(build(sys.argv[1] if len(sys.argv) > 1 else ROOT.parent / "engine_addon"))
