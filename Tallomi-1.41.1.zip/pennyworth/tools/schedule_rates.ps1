# Optional: reads the banks' board rates twice a day even when Tallomi is not open (no window appears).
# Creates two Task Scheduler tasks for the current user (no administrator rights needed on most PCs).
param([switch]$Remove)
$ErrorActionPreference = 'Stop'
$names = @('Pennyworth daily rates', 'Pennyworth rates at sign-in')
if ($Remove) {
    foreach ($n in $names) { Unregister-ScheduledTask -TaskName $n -Confirm:$false -ErrorAction SilentlyContinue }
    Write-Host "The scheduled rate updates were removed."
    exit 0
}
$vbs = Join-Path $env:LOCALAPPDATA 'Pennyworth\launcher\launch.vbs'
if (-not (Test-Path $vbs)) { throw "Run install_pennyworth.bat (or create_shortcut.bat) first." }
$action = New-ScheduledTaskAction -Execute (Join-Path $env:SystemRoot 'System32\wscript.exe') -Argument ('//B //Nologo "' + $vbs + '" -FetchRates')
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
$daily = @((New-ScheduledTaskTrigger -Daily -At '9:40AM'), (New-ScheduledTaskTrigger -Daily -At '2:10PM'))
Register-ScheduledTask -TaskName $names[0] -Action $action -Trigger $daily -Settings $settings -Force | Out-Null
Write-Host "Created: $($names[0])  (every day at 09:40 and 14:10, or as soon as the PC is on and online afterwards)"
try {
    $logon = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
    Register-ScheduledTask -TaskName $names[1] -Action $action -Trigger $logon -Settings $settings -Force | Out-Null
    Write-Host "Created: $($names[1])"
} catch {
    Write-Host "[info] The sign-in task could not be created on this PC (that is fine, the two daily times still work)."
}
Write-Host ""
Write-Host "Each run skips itself when that half of the day was already updated, and does nothing while offline."
