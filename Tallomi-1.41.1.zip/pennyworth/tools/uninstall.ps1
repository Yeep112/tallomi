param([string]$InstallDir)
$ErrorActionPreference = 'Continue'
$dest = (Resolve-Path -LiteralPath $InstallDir).Path.TrimEnd('\')
Write-Host "This removes Tallomi from: $dest"
$go = Read-Host "Continue? (y/N)"
if ($go -notmatch '^[Yy]') { Write-Host "Cancelled."; exit 0 }

Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($dest, [StringComparison]::OrdinalIgnoreCase) } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

# shortcuts (desktop, Start menu, taskbar pin)
$links = @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Pennyworth.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'Pennyworth.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Tallomi.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'Tallomi.lnk')
)
$pinned = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
if (Test-Path $pinned) { $links += (Get-ChildItem -LiteralPath $pinned -Filter '*.lnk' -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'Pennyworth*' -or $_.Name -like 'Tallomi*' } | ForEach-Object { $_.FullName }) }
foreach ($l in $links) { if (Test-Path -LiteralPath $l) { Remove-Item -LiteralPath $l -Force -ErrorAction SilentlyContinue } }

Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'Pennyworth' -ErrorAction SilentlyContinue
Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Pennyworth' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'Pennyworth') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $env:APPDATA 'Pennyworth\program_location.txt') -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Your books are stored in: $(Join-Path $env:APPDATA 'Pennyworth')"
$del = Read-Host "Delete your books and settings too? This cannot be undone. Type DELETE to confirm, or press Enter to keep them"
if ($del -ceq 'DELETE') {
    Remove-Item -LiteralPath (Join-Path $env:APPDATA 'Pennyworth') -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Books deleted."
} else {
    Write-Host "Books kept. Installing Tallomi again later will pick them up."
}

# delete the program folder after this script ends (it cannot delete the folder it was started from)
Start-Process -FilePath 'cmd.exe' -WindowStyle Hidden -ArgumentList ('/c ping 127.0.0.1 -n 4 >nul & rmdir /s /q "' + $dest + '"')
Write-Host "Tallomi was removed."
Start-Sleep -Seconds 2
