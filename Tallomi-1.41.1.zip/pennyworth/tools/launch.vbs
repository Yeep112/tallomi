'' Starts Tallomi with no window at all (the gold P icon is the only thing you see).
'' Optional argument -FetchRates: only read today's bank rates in the background, open no window.
Set sh = CreateObject("WScript.Shell")
here = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
extra = ""
For i = 0 To WScript.Arguments.Count - 1
  extra = extra & " " & WScript.Arguments(i)
Next
sh.Run "cmd.exe /c """"" & here & "launch.cmd""" & extra & """", 0, False
