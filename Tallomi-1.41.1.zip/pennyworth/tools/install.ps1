# Installs Tallomi like a normal program:
#   - copies it to %LOCALAPPDATA%\Programs\Pennyworth (the downloaded folder can be deleted afterwards)
#   - builds its private Python environment there
#   - adds Desktop + Start menu shortcuts
#   - registers it in Settings > Apps > Installed apps (with an Uninstall button)
# No administrator rights and no .exe are needed. Your books (%APPDATA%\Pennyworth) are never touched.
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$dest = Join-Path $env:LOCALAPPDATA 'Programs\Pennyworth'
$log = Join-Path $env:TEMP 'pennyworth_install.log'

function Step([string]$m) { Write-Host ""; Write-Host "== $m" }

if (-not (Test-Path (Join-Path $src 'run.py'))) { throw "run.py not found next to the installer ($src)." }
$version = '0'
$m = Select-String -LiteralPath (Join-Path $src 'app\config.py') -Pattern 'VERSION\s*=\s*"([^"]+)"' | Select-Object -First 1
if ($m) { $version = $m.Matches[0].Groups[1].Value }
Write-Host "Installing Tallomi $version to: $dest"

Step 'Closing a running copy (if any)'
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($dest, [StringComparison]::OrdinalIgnoreCase) } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 800

Step 'Copying program files'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$same = ((Resolve-Path -LiteralPath $src).Path.TrimEnd('\') -ieq (Resolve-Path -LiteralPath $dest).Path.TrimEnd('\'))
if (-not $same) {
    $skip = @('.venv', '__pycache__', '.pytest_cache', 'tests')
    Get-ChildItem -LiteralPath $src -Force | Where-Object { $skip -notcontains $_.Name -and $_.Extension -ne '.log' } | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $dest -Recurse -Force
    }
    # drop leftovers of an older version that no longer exist in the new one
    foreach ($d in @('app', 'tools', 'assets')) {
        $newRoot = Join-Path $src $d; $oldRoot = Join-Path $dest $d
        if (Test-Path $oldRoot) {
            Get-ChildItem -LiteralPath $oldRoot -Recurse -File -Force | ForEach-Object {
                $rel = $_.FullName.Substring($oldRoot.Length).TrimStart('\')
                if ($rel -notlike '*__pycache__*' -and -not (Test-Path (Join-Path $newRoot $rel))) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
            }
        }
    }
}

Step 'Preparing the Python environment (first install takes about a minute)'
$ErrorActionPreference = 'Continue'   # Windows PowerShell 5.1 treats any stderr text of a program as an error under 'Stop'
$venvPy = Join-Path $dest '.venv\Scripts\python.exe'
if (Test-Path $venvPy) {
    & $venvPy -c "import sys" 2>$null
    if ($LASTEXITCODE -ne 0) { Remove-Item -LiteralPath (Join-Path $dest '.venv') -Recurse -Force }
}
if (-not (Test-Path $venvPy)) {
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) { & py -3 -m venv (Join-Path $dest '.venv') } else {
        $p2 = Get-Command python -ErrorAction SilentlyContinue
        if (-not $p2) { throw "Python was not found. Install Python 3.12 or 3.13 from https://www.python.org/downloads/ (keep 'py launcher' ticked), then run the installer again." }
        & python -m venv (Join-Path $dest '.venv')
    }
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $venvPy)) { throw "Could not create the Python environment." }
}
& $venvPy -m pip install --disable-pip-version-check --no-cache-dir -r (Join-Path $dest 'requirements.txt') *> $log
if ($LASTEXITCODE -ne 0) { Get-Content $log; throw "Installing the required packages failed (log: $log)." }
& $venvPy -m pip install --disable-pip-version-check --no-cache-dir -r (Join-Path $dest 'requirements-window.txt') *>> $log
if ($LASTEXITCODE -ne 0) { Write-Host "[info] Native window support could not be installed; Tallomi will use an Edge/Chrome app window instead." }

$ErrorActionPreference = 'Stop'
Step 'Creating shortcuts'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dest 'create_shortcut.ps1')
if ($LASTEXITCODE -ne 0) { throw "Could not create the shortcuts." }

Step 'Registering in Settings > Apps'
$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Pennyworth'
New-Item -Path $key -Force | Out-Null
$uninst = Join-Path $dest 'uninstall_pennyworth.bat'
$vals = @{
    DisplayName = 'Tallomi'; DisplayVersion = $version; Publisher = 'Tallomi'
    InstallLocation = $dest; DisplayIcon = (Join-Path $dest 'assets\pennyworth.ico')
    UninstallString = ('cmd.exe /c ""' + $uninst + '""')
}
foreach ($k in $vals.Keys) { New-ItemProperty -Path $key -Name $k -Value $vals[$k] -PropertyType String -Force | Out-Null }
New-ItemProperty -Path $key -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $key -Name NoRepair -Value 1 -PropertyType DWord -Force | Out-Null

Write-Host ""
Write-Host "Tallomi $version is installed."
Write-Host "Open it from the desktop icon or the Start menu. You can pin it to the taskbar from there."
Write-Host "The folder you downloaded can now be deleted (your books are stored separately and stay safe)."
$ans = Read-Host "Start Tallomi now? (Y/n)"
if ($ans -eq '' -or $ans -match '^[Yy]') {
    Start-Process -FilePath (Join-Path $dest 'start_pennyworth.bat') -WorkingDirectory $dest -WindowStyle Minimized
}
