@echo off
setlocal
pushd "%~dp0"
set "HERE=%~dp0"
set "PSHERE=%HERE:'=''%"
set "PY=%HERE%.venv\Scripts\python.exe"

REM Remove the "downloaded from the internet" flag from every file in this folder.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Recurse -Force -LiteralPath '%PSHERE%' | Unblock-File" >nul 2>&1

where py >nul 2>&1
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.12 or 3.13 from https://www.python.org/downloads/
  echo and keep "py launcher" ticked during setup. Then run this file again.
  pause
  exit /b 1
)

set "STEP=creating the virtual environment"
REM A .venv whose Python is gone (Python updated / uninstalled) cannot run: rebuild it.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys" >nul 2>&1
  if errorlevel 1 rmdir /s /q .venv
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 goto :fail
)
REM The program folder may have been moved: always call the venv's python.exe directly (never "activate"),
REM so nothing depends on the folder's old location.

set "STEP=installing packages"
echo Checking packages (the first run takes about a minute)...
"%PY%" -m pip install --disable-pip-version-check --no-cache-dir -r requirements.txt > pip_install.log 2>&1
if errorlevel 1 (
  type pip_install.log
  goto :fail
)
"%PY%" -m pip install --disable-pip-version-check --no-cache-dir -r requirements-window.txt > pip_window.log 2>&1
if errorlevel 1 echo [info] Native window support could not be installed. Tallomi will open in your browser instead.

set "STEP=starting Pennyworth"
"%PY%" run.py %*
if errorlevel 1 goto :fail
exit /b 0

:fail
echo.
echo ===== Something went wrong while %STEP% =====
"%PY%" --version 2>&1
echo Log files: pip_install.log in this folder, and %APPDATA%\Pennyworth\pennyworth.log
echo Please copy ALL the messages above and send them over.
pause
exit /b 1
