# Creates the "Tallomi" shortcuts (desktop, Start menu, and updates the one pinned to the taskbar).
# The shortcuts point at a small launcher kept OUTSIDE the program folder, which remembers (and if needed searches
# for) the program folder - so you can move the folder anywhere and the shortcuts keep working.
param([switch]$Classic)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path (Join-Path $root '.venv\Scripts\python.exe'))) { throw "Run run_dev.bat once first (it sets up .venv)." }

$launcherDir = Join-Path $env:LOCALAPPDATA 'Pennyworth\launcher'
New-Item -ItemType Directory -Force -Path $launcherDir | Out-Null
Copy-Item -LiteralPath (Join-Path $root 'tools\launch.ps1') -Destination $launcherDir -Force
Copy-Item -LiteralPath (Join-Path $root 'tools\launch.cmd') -Destination $launcherDir -Force
Copy-Item -LiteralPath (Join-Path $root 'tools\launch.vbs') -Destination $launcherDir -Force
Copy-Item -LiteralPath (Join-Path $root 'assets\pennyworth.ico') -Destination $launcherDir -Force

$dataDir = Join-Path $env:APPDATA 'Pennyworth'
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
Set-Content -LiteralPath (Join-Path $dataDir 'program_location.txt') -Value $root -Encoding UTF8

$launch = Join-Path $launcherDir 'launch.cmd'
$icon = Join-Path $launcherDir 'pennyworth.ico'
$ws = New-Object -ComObject WScript.Shell

function Set-Link([string]$path) {
    $lnk = $ws.CreateShortcut($path)
    if ($Classic) {
        # fallback: cmd.exe -> launch.cmd (a minimized window flashes on the taskbar for a moment)
        $lnk.TargetPath = Join-Path $env:SystemRoot 'System32\cmd.exe'
        $lnk.Arguments = '/c ""' + $launch + '""'
    } else {
        # default: wscript.exe -> launch.vbs, so nothing but the app window ever appears
        $lnk.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
        $lnk.Arguments = '//B //Nologo "' + (Join-Path $launcherDir 'launch.vbs') + '"'
    }
    $lnk.WorkingDirectory = $launcherDir
    $lnk.WindowStyle = 7
    $lnk.IconLocation = $icon + ',0'
    $lnk.Description = 'Tallomi bookkeeping'
    $lnk.Save()
    Write-Host "Created: $path"
}
Set-Link (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Tallomi.lnk')
Set-Link (Join-Path ([Environment]::GetFolderPath('Programs')) 'Tallomi.lnk')
# The program used to be called Pennyworth: drop the old desktop / Start-menu shortcuts so there is only one icon.
foreach ($oldDir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $oldLnk = Join-Path $oldDir 'Pennyworth.lnk'
    if (Test-Path -LiteralPath $oldLnk) { Remove-Item -LiteralPath $oldLnk -Force -ErrorAction SilentlyContinue }
}

# Shortcuts already pinned to the taskbar keep their old target. Repoint (a) ours and (b) any pinned Edge/Chrome
# "app window" for 127.0.0.1 - that old pin only opens an empty window ("127.0.0.1 refused the connection")
# because it does not start the program first.
$pinned = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar'
$desktop = [Environment]::GetFolderPath('Desktop')
$fixed = 0
foreach ($folder in @($pinned, $desktop)) {
    if (-not (Test-Path $folder)) { continue }
    Get-ChildItem -LiteralPath $folder -Filter '*.lnk' -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $old = $ws.CreateShortcut($_.FullName)
            $stale = ($old.Arguments -match '127\.0\.0\.1') -and ($old.TargetPath -match 'msedge|chrome')
            $ours = ($_.Name -like 'Pennyworth*.lnk') -or ($_.Name -like 'Tallomi*.lnk')
            if ($stale -or $ours) { Set-Link $_.FullName; $fixed++ }
        } catch { }
    }
}
if ($fixed -gt 0) { Write-Host "Repointed $fixed existing shortcut(s) (taskbar/desktop). If a taskbar icon still misbehaves, unpin it and pin the desktop icon again." }
Write-Host "Program folder remembered: $root"
