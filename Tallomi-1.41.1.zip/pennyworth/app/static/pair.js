'use strict';
const form = document.getElementById('pair-form'), msg = document.getElementById('msg'), code = document.getElementById('code'), name = document.getElementById('devname');
if (!name.value) {
  const ua = navigator.userAgent;
  name.placeholder = /iPhone/.test(ua) ? '我的 iPhone' : /iPad/.test(ua) ? '我的 iPad' : /Android/.test(ua) ? '我的 Android 手機' : '我的手機';
}
const fromLink = (location.hash || '').replace(/[^0-9]/g, '').slice(0, 8);      // the QR code carries the code after the #
if (fromLink.length === 8) { code.value = fromLink; history.replaceState(null, '', '/pair'); }
if (/iPhone|iPad|iPod/.test(navigator.userAgent) && !navigator.standalone) document.getElementById('ios-hint').hidden = false;
code.addEventListener('input', () => { code.value = code.value.replace(/[^0-9]/g, '').slice(0, 8); });
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  msg.textContent = '';
  const go = document.getElementById('go');
  go.disabled = true;
  try {
    const r = await fetch('/api/pair', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Pennyworth': '1' },
      body: JSON.stringify({ code: code.value, name: name.value || name.placeholder }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || `連接失敗（${r.status}）`);
    location.replace('/');
  } catch (err) {
    msg.textContent = err.message || '連接失敗';
    go.disabled = false;
  }
});
