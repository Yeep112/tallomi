'use strict';
/* Tallomi service worker. Keeps the program's own files (not your data) so the app opens instantly on the phone,
   and shows a clear message when the computer cannot be reached. Data is never cached: it only lives on the computer. */
const CACHE = 'pennyworth-shell-__VERSION__';       // the server fills in the program version, so an upgrade starts with a clean copy
const SHELL_CACHE = 'tallomi-offline';             // the page itself, kept only while offline mode is on (see app-offline.js); data stays in IndexedDB
const SHELL = ['/static/style.css', '/static/theme.js', '/static/app.js', '/static/app-categories.js', '/static/app-extras.js', '/static/app-tags.js', '/static/app-compare.js', '/static/app-periods.js', '/static/app-advance.js', '/static/app-tiles.js', '/static/app-calendar.js', '/static/app-exchange.js', '/static/app-emoji.js', '/static/app-icons.js', '/static/app-market.js', '/static/app-invest.js', '/static/app-phone.js', '/static/app-onphone.js', '/static/app-import.js', '/static/app-onboard.js', '/static/app-lock.js', '/static/app-mode.js', '/static/app-update.js', '/static/app-offline.js', '/static/app-recurring.js', '/static/app-bills.js', '/static/vendor/qrcode.js', '/static/pair.js',
  '/static/vendor/chart.umd.js', '/static/icon-192.png', '/static/icon-512.png', '/static/apple-touch-icon.png', '/static/manifest.webmanifest', ...__EMOJI__];      // __EMOJI__: every bundled icon picture, so icons also show when the computer cannot be reached

self.addEventListener('install', (e) => { self.skipWaiting(); e.waitUntil(caches.open(CACHE).then((c) => Promise.allSettled(SHELL.map((u) => c.add(u))))); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE && k !== SHELL_CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

const OFFLINE = `<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Tallomi</title><body style="font:16px system-ui,sans-serif;margin:0;padding:48px 28px;background:#16233A;color:#fff;line-height:1.7">
<h1 style="font-size:22px;margin:0 0 12px">連不上你的電腦</h1>
<p>Tallomi 的資料放在你家的電腦裡。請確認：</p>
<ul><li>電腦已開機，<b>Tallomi 正在執行</b>（在電腦上開啟 Tallomi 即可）</li><li>電腦與手機都開著 Tailscale 並已登入</li><li>手機有網路</li></ul>
<p id="s" style="opacity:.8">電腦回來後會自動連線，不用重新開啟。</p>
<p><button onclick="location.reload()" style="font:inherit;padding:10px 20px;border-radius:8px;border:0">重試</button></p>
<script>var t0=Date.now();
setInterval(function(){var s=Math.floor((Date.now()-t0)/1000);document.getElementById('s').textContent='電腦回來後會自動連線，不用重新開啟（已等待 '+Math.floor(s/60)+' 分 '+(s%60)+' 秒）';},1000);
setInterval(function(){fetch('/api/ping',{cache:'no-store'}).then(function(r){if(r.status<500)location.reload();}).catch(function(){});},4000);
</script></body></html>`;

self.addEventListener('fetch', (e) => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;     // data always goes to the computer
  if (req.mode === 'navigate') {
    const offline = async () => {
      if (url.pathname === '/' || url.pathname === '/index.html') {      // offline mode on: open the kept copy of the app, it shows the data kept on the phone
        const kept = await caches.open(SHELL_CACHE).then((c) => c.match('/__shell')).catch(() => null);
        if (kept) return kept;
      }
      return new Response(OFFLINE, { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    };
    // "Bad gateway / unavailable" comes from Tailscale itself when Tallomi is not running on the computer: show the same message instead of a blank page
    e.respondWith(fetch(req).then(async (r) => {
      if (r.status === 502 || r.status === 503 || r.status === 504) return offline();
      if (r.ok && !r.redirected && (url.pathname === '/' || url.pathname === '/index.html') && await caches.has(SHELL_CACHE)) {
        const copy = r.clone(); caches.open(SHELL_CACHE).then((c) => c.put('/__shell', copy));       // keep the kept copy as new as the program
      }
      return r;
    }).catch(offline));
    return;
  }
  if (url.pathname.startsWith('/static/')) {          // the program's files: always the newest from the computer; the saved copy is only for when it cannot be reached
    e.respondWith(fetch(req).then((r) => { if (r.ok) { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); } return r; })
      .catch(() => caches.match(req)));
  }
});
