"""Core bookkeeping logic: accounts, transactions, running balances, FX rates.

Design notes
- Balance of an account is *derived*: opening balance + the effect of every
  transaction. Nothing is stored as "current balance", so editing or deleting
  an old transaction can never leave balances inconsistent.
- Amounts are integers in the currency's minor unit (see money.py).
- Transfers carry two amounts so that cross-currency transfers are exact:
  amount_minor (leaves `account`) and to_amount_minor (arrives in `to_account`).
"""
import json
import logging
import re
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

from . import bankfetch, config, db, money
from .bills import BillsMixin
from .invest import InvestMixin
from .recurring import RecurringMixin
from .config import (DEFAULT_ACCOUNTS, DEFAULT_BASE_CURRENCY, DEFAULT_CATEGORIES, INITIAL_AMOUNTS, default_ui_color)
from .timeutil import normalize_time, now_iso

TX_TYPES = ("income", "expense", "transfer")
ADJUST_CATEGORY = "歸零調整"
CALIBRATE_CATEGORY = "difference"      # balance corrections are ordinary income/expense with this category ...
MAX_LIBRARY = 60                        # remembered uploaded pictures (the oldest are dropped beyond this)
MAX_PICTURE_ICON = 60_000               # characters of a data: URL (a 128 px PNG is usually 3-15 KB)
CALIBRATE_NOTE = "誤差"                 # ... and this note


class BookError(ValueError):
    """User-facing error (shown verbatim in the UI)."""

    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def initial_amount(name, currency):
    """Initial (opening) amount of one of the original accounts, in minor units; 0 for anything else."""
    if currency != DEFAULT_BASE_CURRENCY:
        return 0
    for k, v in INITIAL_AMOUNTS.items():
        if k.lower() == str(name).lower():
            return money.to_minor(v, currency)
    return 0


class Book(InvestMixin, RecurringMixin, BillsMixin):
    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data_dir / "pennyworth.db"
        self.backup_dir = self.data_dir / "backups"
        self.export_dir = self.data_dir / "exports"
        self._lock = threading.RLock()
        self._rev_cond = threading.Condition()
        self.rev = 0
        self._listeners = []
        self.notice = ""
        self.changed_on_start = False
        moved = db.set_aside_if_foreign(self.db_path)
        if moved:
            dest, why = moved
            logging.getLogger("pennyworth").warning("existing database set aside as %s (%s)", dest, why)
            self.notice = (f"在資料夾裡發現一個結構不同的舊資料庫，已原封不動改名保存為「{dest.name}」，"
                           "並建立全新的帳本。資料沒有被刪除。")
        with self.session() as c:
            db.init_db(c)
            if self.get_setting(c, "seeded") != "1":
                if c.execute("SELECT COUNT(*) FROM accounts").fetchone()[0] == 0:
                    for i, name in enumerate(DEFAULT_ACCOUNTS):
                        c.execute(
                            "INSERT INTO accounts(name,currency,opening_minor,sort_order,created_at) VALUES(?,?,?,?,?)",
                            (name, DEFAULT_BASE_CURRENCY, initial_amount(name, DEFAULT_BASE_CURRENCY), i, now_iso()))
                self.set_setting(c, "seeded", "1")
            if self.get_setting(c, "initial_amounts_applied") != "1":
                # Books created before 1.0.4 have these accounts at 0. Give them the old notebook's initial
                # amounts once, but only where the opening balance is still untouched (0).
                changed = []
                for a in c.execute("SELECT id,name,currency,opening_minor FROM accounts").fetchall():
                    amt = initial_amount(a["name"], a["currency"])
                    if amt and a["opening_minor"] == 0:
                        c.execute("UPDATE accounts SET opening_minor=? WHERE id=?", (amt, a["id"]))
                        changed.append(a["name"])
                self.set_setting(c, "initial_amounts_applied", "1")
                if changed:
                    self.changed_on_start = True
                    self.notice = (self.notice + " " if self.notice else "") + \
                        "已把舊版的初始金額設為這些帳戶的期初餘額：" + "、".join(changed) + "。"
            if self.get_setting(c, "base_currency") is None:
                self.set_setting(c, "base_currency", DEFAULT_BASE_CURRENCY)
            if config.DEFAULT_SHEET_KEY and self.get_setting(c, "sheets_key") is None:
                # Owner's copy only: keep the sheet in the book itself, so the link survives a copy of the program without the profile.
                self.set_setting(c, "sheets_key", config.DEFAULT_SHEET_KEY)
            self._link_presets(c)
            seeded = self._seed_holdings(c)
            if seeded:
                self.changed_on_start = True
                self.notice = (self.notice + " " if self.notice else "") + \
                    "已登錄現有持股：" + "、".join(seeded) + "（到「投資」頁查看；沒有動到任何帳戶餘額）。"

    # ------------------------------------------------------------ plumbing
    @contextmanager
    def session(self, notify=False, quiet=False):
        changed = False
        with self._lock:
            conn = db.connect(self.db_path)
            try:
                before = conn.total_changes
                yield conn
                changed = conn.total_changes != before
                conn.commit()
            except BaseException:
                conn.rollback()
                changed = False
                raise
            finally:
                conn.close()
        if changed and not quiet:
            self.bump_rev()
        if notify:
            self._notify()

    # A counter that goes up whenever anything is written. Other windows / the phone wait on it to know when to refresh.
    def bump_rev(self):
        with self._rev_cond:
            self.rev += 1
            self._rev_cond.notify_all()

    def wait_rev(self, since, timeout):
        """-> the current revision; returns early when it is newer than `since`."""
        with self._rev_cond:
            if self.rev <= since:
                self._rev_cond.wait(timeout)
            return self.rev

    def on_change(self, fn):
        self._listeners.append(fn)

    def _notify(self):
        for fn in self._listeners:
            try:
                fn()
            except Exception:
                pass

    # ------------------------------------------------------------ settings
    @staticmethod
    def get_setting(conn, key, default=None):
        r = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

    @staticmethod
    def set_setting(conn, key, value):
        conn.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    HIDE_PAGES = ("overview", "transactions", "accounts", "reports", "exchange", "invest", "tags", "calendar", "advances")

    def ui_prefs(self, conn):
        """Look-and-feel choices kept with the book: interface colour and which pages hide their amounts.
        `hide` is the master switch (Settings): every page hidden. `pages` are the per-page eye icons."""
        try:
            pages = set(json.loads(self.get_setting(conn, "ui_hide_pages", "[]")))
        except ValueError:
            pages = set()
        return {"color": self.get_setting(conn, "ui_color", default_ui_color()),
                "hide": self.get_setting(conn, "ui_hide", "0") == "1",
                "count_transfers": self.count_transfers(conn),
                "tile_order": self.tile_order(conn),
                "pages": {p: p in pages for p in self.HIDE_PAGES}}

    def set_ui_prefs(self, color=None, hide=None, pages=None):
        with self.session() as c:
            if color is not None:
                text = str(color).strip()
                if not re.fullmatch(r"#?[0-9A-Fa-f]{6}", text):
                    raise BookError("顏色需要是 6 碼 Hex 色碼，例如 #E6E6FA")
                self.set_setting(c, "ui_color", "#" + text.lstrip("#").upper())
            if hide is not None:
                self.set_setting(c, "ui_hide", "1" if hide else "0")
            if pages is not None:
                if not isinstance(pages, dict) or any(k not in self.HIDE_PAGES for k in pages):
                    raise BookError("不認得的頁面")
                cur = {p for p, on in self.ui_prefs(c)["pages"].items() if on}
                for k, v in pages.items():
                    (cur.add if v else cur.discard)(k)
                self.set_setting(c, "ui_hide_pages", json.dumps(sorted(cur)))
            return self.ui_prefs(c)

    def tile_order(self, conn):
        """The order the user dragged the overview tiles into: {"expense": [names], "income": [names]}."""
        try:
            d = json.loads(self.get_setting(conn, "tile_order", "{}"))
        except ValueError:
            d = {}
        return {k: [str(x) for x in d.get(k, []) if isinstance(x, str)] for k in ("expense", "income")} if isinstance(d, dict) else {"expense": [], "income": []}

    def set_tile_order(self, kind, names):
        if kind not in ("expense", "income") or not isinstance(names, list):
            raise BookError("排序資料不正確")
        clean, seen = [], set()
        for n in names[:300]:
            n = str(n).strip()[:60]
            if n and n not in seen:
                seen.add(n); clean.append(n)
        with self.session() as c:
            cur = self.tile_order(c)
            cur[kind] = clean
            self.set_setting(c, "tile_order", json.dumps(cur, ensure_ascii=False))

    def count_transfers(self, conn):
        """Whether monthly totals and reports also count transfers (out = expense, in = income)."""
        return self.get_setting(conn, "count_transfers", "0") == "1"

    def set_count_transfers(self, on):
        with self.session() as c:
            self.set_setting(c, "count_transfers", "1" if on else "0")

    TRANSFER_LABEL = "轉帳"

    def flows(self, rows, accts, with_transfers=False, tags=None):
        """Income / expense lines of the ledger for the totals and reports. A transfer is two lines when
        `with_transfers` is on: the sending account's side is an expense, the receiving account's side an income
        (in its own currency, so an exchange shows its spread). Zeroing adjustments are never counted."""
        for r in rows:
            if r["type"] in ("income", "expense"):
                if r.get("no_stats"):                       # an advance for a friend / a claim: money moved, but it is not really spending
                    continue
                a = accts[r["account_id"]]
                yield {"type": r["type"], "time": r["time"], "ccy": a["currency"], "minor": r["amount_minor"],
                       "category": r["category"], "note": r["note"], "account": a["name"], "tags": (tags or {}).get(r["id"], []),
                       "no_budget": bool(r.get("no_budget"))}
            elif r["type"] == "transfer" and with_transfers:
                a, b = accts[r["account_id"]], accts[r["to_account_id"]]
                yield {"type": "expense", "time": r["time"], "ccy": a["currency"], "minor": r["amount_minor"],
                       "category": self.TRANSFER_LABEL, "note": r["note"], "account": a["name"], "transfer": True,
                       "tags": (tags or {}).get(r["id"], [])}
                yield {"type": "income", "time": r["time"], "ccy": b["currency"], "minor": r["to_amount_minor"],
                       "category": self.TRANSFER_LABEL, "note": r["note"], "account": b["name"], "transfer": True,
                       "tags": (tags or {}).get(r["id"], [])}

    def base_currency(self, conn):
        return self.get_setting(conn, "base_currency", DEFAULT_BASE_CURRENCY)

    # --------------------------------------------------------------- rates
    def get_rates(self, conn):
        """{currency: Decimal} where 1 currency = rate base units. Base is always 1."""
        base = self.base_currency(conn)
        rates = {r["currency"]: Decimal(r["rate"]) for r in conn.execute("SELECT currency,rate FROM rates")}
        rates[base] = Decimal(1)
        return rates

    def rates_info(self, conn):
        base = self.base_currency(conn)
        stored = {r["currency"]: (r["rate"], r["updated_at"]) for r in conn.execute("SELECT * FROM rates")}
        used = sorted({r["currency"] for r in conn.execute("SELECT DISTINCT currency FROM accounts")} | set(stored))
        out = []
        for ccy in used:
            if ccy == base:
                continue
            rate, upd = stored.get(ccy, (None, None))
            out.append({"currency": ccy, "rate": float(rate) if rate else None, "updated_at": upd})
        return {"base": base, "rates": out}

    def set_rates(self, mapping):
        with self.session(notify=True) as c:
            base = self.base_currency(c)
            for ccy, val in mapping.items():
                ccy = money.normalize_currency(ccy)
                if ccy == base:
                    continue
                try:
                    d = Decimal(str(val).replace(",", "").strip())
                except Exception:
                    raise BookError(f"{ccy} 的匯率格式不正確") from None
                if not d.is_finite() or d <= 0:
                    raise BookError(f"{ccy} 的匯率必須大於 0")
                self._store_rate(c, ccy, d)

    @staticmethod
    def _store_rate(c, ccy, d: Decimal):
        d = d.quantize(Decimal("0.0000000001"), rounding=ROUND_HALF_UP)
        c.execute("INSERT INTO rates(currency,rate,updated_at) VALUES(?,?,?) "
                  "ON CONFLICT(currency) DO UPDATE SET rate=excluded.rate, updated_at=excluded.updated_at",
                  (ccy, format(d, "f"), now_iso()))

    def refresh_rates(self, fetcher=None):
        """Pull live rates. `fetcher(base) -> {code: units of code per 1 base}`."""
        from .fx import fetch_rates
        fetcher = fetcher or fetch_rates
        with self.session(notify=True) as c:
            base = self.base_currency(c)
            wanted = ({r["currency"] for r in c.execute("SELECT DISTINCT currency FROM accounts")}
                      | {r["currency"] for r in c.execute("SELECT currency FROM rates")}) - {base}
            if not wanted:
                return {"updated": [], "missing": []}
            table = fetcher(base)
            updated, missing = [], []
            for ccy in sorted(wanted):
                x = table.get(ccy)
                if not x or Decimal(str(x)) <= 0:
                    missing.append(ccy)
                    continue
                self._store_rate(c, ccy, Decimal(1) / Decimal(str(x)))
                updated.append(ccy)
            return {"updated": updated, "missing": missing}

    def set_base_currency(self, new_base):
        new_base = money.normalize_currency(new_base)
        with self.session(notify=True) as c:
            old = self.base_currency(c)
            if new_base == old:
                return
            rates = self.get_rates(c)
            if new_base not in rates:
                if len(rates) > 1:                 # stored rates are all "per old base": they cannot be re-expressed without this one
                    raise BookError(f"請先在匯率表設定 1 {new_base} 等於多少 {old}，再切換主要幣別")
                # no rates entered yet (a brand-new book): there is nothing to convert, just switch
                self.set_setting(c, "base_currency", new_base)
                return
            k = rates[new_base]
            for ccy, r in list(rates.items()):
                if ccy == new_base:
                    continue
                self._store_rate(c, ccy, r / k)
            c.execute("DELETE FROM rates WHERE currency=?", (new_base,))
            self.set_setting(c, "base_currency", new_base)

    # ------------------------------------------------------------- ledger
    def ledger(self, conn, snapshots=False):
        """Replay all transactions in time order.
        Returns (rows, final_balances{id:minor}, accounts{id:Row})."""
        accts = {r["id"]: r for r in conn.execute("SELECT * FROM accounts")}
        bal = {i: a["opening_minor"] for i, a in accts.items()}
        rows = []
        for t in conn.execute("SELECT * FROM transactions ORDER BY time, id"):
            r = dict(t)
            a, amt = t["account_id"], t["amount_minor"]
            r["prev_minor"] = bal[a]
            if t["type"] == "transfer":
                bal[a] -= amt
                to = t["to_account_id"]
                r["to_prev_minor"] = bal[to]
                bal[to] += t["to_amount_minor"]
                r["to_new_minor"] = bal[to]
            elif t["type"] == "expense":
                bal[a] -= amt
            else:  # income, adjust (signed)
                bal[a] += amt
            r["new_minor"] = bal[a]
            if snapshots:
                r["snap"] = dict(bal)
            rows.append(r)
        return rows, bal, accts

    @staticmethod
    def repaid_map(rows):
        """{advance id: minor already paid back}, from the ledger rows."""
        out = {}
        for r in rows:
            if r.get("settle_of"):
                out[r["settle_of"]] = out.get(r["settle_of"], 0) + r["amount_minor"]
        return out

    def format_tx(self, r, accts, tags=None, receipts=None, repaid=None):
        a = accts[r["account_id"]]
        ccy = a["currency"]
        out = {
            "id": r["id"], "time": r["time"], "type": r["type"], "category": r["category"],
            "note": r["note"], "account_id": r["account_id"], "account": a["name"],
            "currency": ccy, "amount": money.from_minor(r["amount_minor"], ccy),
            "to_account_id": None, "to_account": None, "to_currency": None, "to_amount": None,
            "prev_balance": None, "new_balance": None, "to_prev_balance": None, "to_new_balance": None,
            "tags": (tags or {}).get(r["id"], []), "receipts": (receipts or {}).get(r["id"], []),
            "advance": r.get("advance") or "", "counterparty": r.get("counterparty") or "", "no_budget": bool(r.get("no_budget")),
            "no_stats": bool(r.get("no_stats")), "settle_of": r.get("settle_of"), "written_off": bool(r.get("written_off")),
        }
        if r.get("advance"):
            got = (repaid or {}).get(r["id"], 0)
            out.update(repaid=money.from_minor(got, ccy), remaining=money.from_minor(max(r["amount_minor"] - got, 0), ccy),
                       state="off" if r.get("written_off") else "done" if got >= r["amount_minor"] else "partial" if got else "open")
        out["bill_id"] = r.get("bill_id")
        auto = r.get("auto_account_id") if r.get("advance") and not r.get("settle_of") else None
        out["auto_account_id"] = auto
        out["auto_account"] = accts[auto]["name"] if auto in accts else ""
        due = r.get("due_date") or ""
        out["due"] = due if r.get("advance") else ""
        if out["due"] and out.get("state") in ("open", "partial"):
            out["due_in"] = (datetime.strptime(due, "%Y-%m-%d").date() - datetime.now().date()).days      # negative = days overdue
        if r["type"] == "transfer":
            ta = accts[r["to_account_id"]]
            out.update(to_account_id=ta["id"], to_account=ta["name"], to_currency=ta["currency"],
                       to_amount=money.from_minor(r["to_amount_minor"], ta["currency"]),
                       prev_balance=money.from_minor(r["prev_minor"], ccy),
                       new_balance=money.from_minor(r["new_minor"], ccy),
                       to_prev_balance=money.from_minor(r["to_prev_minor"], ta["currency"]),
                       to_new_balance=money.from_minor(r["to_new_minor"], ta["currency"]))
        else:
            out.update(prev_balance=money.from_minor(r["prev_minor"], ccy),
                       new_balance=money.from_minor(r["new_minor"], ccy))
        return out

    # ------------------------------------------------------------ accounts
    def list_accounts(self, conn, include_archived=True):
        rows, bal, accts = self.ledger(conn)
        counts = {i: 0 for i in accts}
        for r in rows:
            counts[r["account_id"]] += 1
            if r["to_account_id"]:
                counts[r["to_account_id"]] += 1
        rates = self.get_rates(conn)
        stock = {r[0] for r in conn.execute("SELECT account_id FROM securities")}
        out = []
        for a in sorted(accts.values(), key=lambda a: (a["sort_order"], a["id"])):
            if a["archived"] and not include_archived:
                continue
            ccy = a["currency"]
            rate = rates.get(ccy)
            base_val = None
            if rate is not None:
                base = self.base_currency(conn)
                base_val = float((money.to_major(bal[a["id"]], ccy) * rate)
                                 .quantize(Decimal(1).scaleb(-money.exponent(base)), rounding=ROUND_HALF_UP))
            out.append({
                "id": a["id"], "name": a["name"], "currency": ccy,
                "opening": money.from_minor(a["opening_minor"], ccy),
                "balance": money.from_minor(bal[a["id"]], ccy),
                "base_value": base_val, "archived": bool(a["archived"]), "stock": a["id"] in stock,
                "icon": a["icon"], "color": a["color"],
                "tx_count": counts[a["id"]],
            })
        return out

    def _get_account(self, conn, account_id):
        a = conn.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
        if not a:
            raise BookError("找不到這個帳戶", 404)
        return a

    @staticmethod
    def _clean_name(name):
        name = str(name or "").strip()
        if not name:
            raise BookError("請輸入帳戶名稱")
        if len(name) > 40:
            raise BookError("帳戶名稱最多 40 個字")
        if "->" in name:
            raise BookError("帳戶名稱不能包含「->」")
        return name

    @staticmethod
    def _clean_icon(icon, color):
        """Emoji (any short text the user typed or pasted) and '#RRGGBB'; empty means "choose for me"."""
        icon = str(icon or "").strip()
        color = str(color or "").strip()
        if icon.startswith("data:image/"):        # a picture the user uploaded (shrunk to a small PNG by the screen)
            if len(icon) > MAX_PICTURE_ICON or not re.fullmatch(r"data:image/png;base64,[A-Za-z0-9+/]+={0,2}", icon):
                raise BookError("圖片太大或格式不支援，請換一張圖片")
        elif len(icon) > 16 or any(ch.isspace() for ch in icon):
            raise BookError("圖示請選一個表情符號")
        if color and not re.fullmatch(r"#[0-9A-Fa-f]{6}", color):
            raise BookError("顏色格式不正確")
        return icon, color.upper()

    def create_account(self, name, currency=DEFAULT_BASE_CURRENCY, opening=0, icon="", color=""):
        name = self._clean_name(name)
        icon, color = self._clean_icon(icon, color)
        try:
            ccy = money.normalize_currency(currency)
            opening_minor = money.to_minor(opening or 0, ccy)
        except ValueError as e:
            raise BookError(str(e)) from None
        with self.session(notify=True) as c:
            nxt = c.execute("SELECT COALESCE(MAX(sort_order),-1)+1 FROM accounts").fetchone()[0]
            try:
                cur = c.execute(
                    "INSERT INTO accounts(name,currency,opening_minor,sort_order,created_at,icon,color) VALUES(?,?,?,?,?,?,?)",
                    (name, ccy, opening_minor, nxt, now_iso(), icon, color))
            except Exception as e:
                if "UNIQUE" in str(e):
                    raise BookError(f"已經有名為「{name}」的帳戶") from None
                raise
            self._remember_picture(c, icon)
            return cur.lastrowid

    def update_account(self, account_id, data):
        with self.session(notify=True) as c:
            a = self._get_account(c, account_id)
            name, ccy, opening, archived = a["name"], a["currency"], a["opening_minor"], a["archived"]
            used = c.execute("SELECT COUNT(*) FROM transactions WHERE account_id=? OR to_account_id=?",
                             (account_id, account_id)).fetchone()[0]
            if "currency" in data:
                try:
                    new_ccy = money.normalize_currency(data["currency"])
                except ValueError as e:
                    raise BookError(str(e)) from None
                if new_ccy != ccy:
                    if used:
                        raise BookError("這個帳戶已有交易，不能更改幣別。請先清除紀錄，或另建新帳戶。")
                    # re-express the opening balance in the new currency's minor unit
                    opening = money.to_minor(money.to_major(opening, ccy), new_ccy)
                    ccy = new_ccy
            if "name" in data:
                name = self._clean_name(data["name"])
            if "opening" in data:
                try:
                    opening = money.to_minor(data["opening"] or 0, ccy)
                except ValueError as e:
                    raise BookError(str(e)) from None
            if "archived" in data:
                archived = 1 if data["archived"] else 0
            icon, color = self._clean_icon(data.get("icon", a["icon"]), data.get("color", a["color"]))
            try:
                c.execute("UPDATE accounts SET name=?, currency=?, opening_minor=?, archived=?, icon=?, color=? WHERE id=?",
                          (name, ccy, opening, archived, icon, color, account_id))
            except Exception as e:
                if "UNIQUE" in str(e):
                    raise BookError(f"已經有名為「{name}」的帳戶") from None
                raise
            self._remember_picture(c, icon)

    def delete_account(self, account_id):
        with self.session(notify=True) as c:
            a = self._get_account(c, account_id)
            n = c.execute("SELECT COUNT(*) FROM transactions WHERE account_id=? OR to_account_id=?",
                          (account_id, account_id)).fetchone()[0]
            if n:
                raise BookError(f"「{a['name']}」已有 {n} 筆交易，無法刪除。"
                                "可以先「清除紀錄並歸零」再刪除，或改用「封存」把它從清單隱藏。")
            c.execute("DELETE FROM accounts WHERE id=?", (account_id,))

    def calibrate_account(self, account_id, actual, expected_current=None):
        """Bring an account's balance to what the bank really says (a forgotten entry somewhere).
        The gap is recorded as an ordinary income (balance was too low) or expense (too high) with the
        category "difference" and the note "誤差", so it shows up in totals and reports like any other entry."""
        with self.session(notify=True) as c:
            a = self._get_account(c, account_id)
            ccy = a["currency"]
            if a["archived"]:
                raise BookError(f"「{a['name']}」已封存，請先取消封存")
            if c.execute("SELECT 1 FROM securities WHERE account_id=?", (account_id,)).fetchone():
                raise BookError("股票帳戶的餘額由「投資」頁的買賣紀錄算出，不能用校正餘額。請到「投資」頁修改紀錄。")
            try:
                want = money.to_minor(actual, ccy)
                seen = None if expected_current in (None, "") else money.to_minor(expected_current, ccy)
            except ValueError as e:
                raise BookError(str(e)) from None
            _, bal, _ = self.ledger(c)
            cur = bal[account_id]
            if seen is not None and seen != cur:
                raise BookError(f"「{a['name']}」的餘額剛剛有變動（現在是 {money.to_major(cur, ccy)} {ccy}），請關掉這個視窗再重新開啟校正。", 409)
            diff = want - cur
            before = money.from_minor(cur, ccy)
            if diff == 0:
                return {"changed": False, "balance": before, "currency": ccy}
            now = now_iso()
            typ = "income" if diff > 0 else "expense"
            c.execute(
                "INSERT INTO transactions(time,type,category,note,amount_minor,account_id,created_at,updated_at)"
                " VALUES(?,?,?,?,?,?,?,?)",
                (now, typ, CALIBRATE_CATEGORY, CALIBRATE_NOTE, abs(diff), account_id, now, now))
            return {"changed": True, "type": typ, "amount": money.from_minor(abs(diff), ccy), "before": before,
                    "balance": money.from_minor(want, ccy), "currency": ccy}

    def reset_account(self, account_id, mode="adjust"):
        """Zero an account.
        adjust: keep history, add one adjustment so the balance becomes 0.
        wipe:   (after an automatic backup) delete every transaction touching the
                account and set its opening balance to 0."""
        if mode not in ("adjust", "wipe"):
            raise BookError("不支援的歸零方式")
        with self._lock:
            with self.session() as c:
                a = self._get_account(c, account_id)
            if mode == "wipe":
                db.make_backup(self.db_path, self.backup_dir, "wipe")
            with self.session(notify=True) as c:
                a = self._get_account(c, account_id)
                ccy = a["currency"]
                _, bal, accts = self.ledger(c)
                if mode == "adjust":
                    cur = bal[account_id]
                    if cur == 0:
                        return {"mode": mode, "changed": False}
                    now = now_iso()
                    note = f"歸零前餘額 {money.to_major(cur, ccy)} {ccy}"
                    c.execute(
                        "INSERT INTO transactions(time,type,category,note,amount_minor,account_id,created_at,updated_at)"
                        " VALUES(?,?,?,?,?,?,?,?)",
                        (now, "adjust", ADJUST_CATEGORY, note, -cur, account_id, now, now))
                    return {"mode": mode, "changed": True, "removed_balance": money.from_minor(cur, ccy)}
                rows = c.execute(
                    "SELECT id,type,account_id,to_account_id FROM transactions WHERE account_id=? OR to_account_id=?",
                    (account_id, account_id)).fetchall()
                others = set()
                transfers = 0
                for r in rows:
                    if r["type"] == "transfer":
                        transfers += 1
                        others.add(r["to_account_id"] if r["account_id"] == account_id else r["account_id"])
                c.execute("DELETE FROM transactions WHERE account_id=? OR to_account_id=?", (account_id, account_id))
                c.execute("DELETE FROM stock_trades WHERE account_id=? OR pay_account_id=?", (account_id, account_id))
                c.execute("UPDATE accounts SET opening_minor=0 WHERE id=?", (account_id,))
                return {"mode": mode, "changed": True, "deleted": len(rows), "transfers": transfers,
                        "affected_accounts": sorted(accts[i]["name"] for i in others if i)}

    def wipe_preview(self, account_id):
        with self.session() as c:
            a = self._get_account(c, account_id)
            rows = c.execute("SELECT type,account_id,to_account_id FROM transactions "
                             "WHERE account_id=? OR to_account_id=?", (account_id, account_id)).fetchall()
            names = {r["id"]: r["name"] for r in c.execute("SELECT id,name FROM accounts")}
            others = {r["to_account_id"] if r["account_id"] == account_id else r["account_id"]
                      for r in rows if r["type"] == "transfer"}
            return {"name": a["name"], "count": len(rows),
                    "transfers": sum(1 for r in rows if r["type"] == "transfer"),
                    "affected_accounts": sorted(names[i] for i in others)}

    def clear_everything(self):
        """Port of the notebook's "clear all and reset" cell: no transactions, accounts back to their initial amounts."""
        with self._lock:
            db.make_backup(self.db_path, self.backup_dir, "clearall")
            with self.session(notify=True) as c:
                n = c.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
                c.execute("DELETE FROM transactions")
                c.execute("DELETE FROM stock_trades")
                for a in c.execute("SELECT id,name,currency FROM accounts").fetchall():
                    c.execute("UPDATE accounts SET opening_minor=? WHERE id=?",
                              (initial_amount(a["name"], a["currency"]), a["id"]))
                return {"deleted": n}

    # -------------------------------------------------------- transactions
    def _normalize_tx(self, c, p, existing=None):
        typ = p.get("type") or (existing["type"] if existing else None)
        if existing and existing["type"] == "adjust":
            typ = "adjust"
        if typ == "adjust" and not existing:
            raise BookError("調整交易只能由「歸零」功能建立")
        if typ not in TX_TYPES + ("adjust",):
            raise BookError("交易類型必須是 收入、支出 或 轉帳")
        try:
            when = normalize_time(p.get("time") or now_iso())
        except ValueError as e:
            raise BookError(str(e)) from None

        def acct(key):
            try:
                aid = int(p.get(key))
            except (TypeError, ValueError):
                return None
            return c.execute("SELECT * FROM accounts WHERE id=?", (aid,)).fetchone()

        a = acct("account_id")
        if not a:
            raise BookError("請選擇帳戶" if typ != "transfer" else "請選擇轉出帳戶")
        if a["archived"] and not (existing and existing["account_id"] == a["id"]):
            raise BookError(f"「{a['name']}」已封存，請先取消封存")
        try:
            amount = money.parse_amount(p.get("amount"))
        except ValueError as e:
            raise BookError(str(e)) from None
        if typ == "adjust":
            if amount == 0:
                raise BookError("金額不可為 0")
        elif amount <= 0:
            raise BookError("金額必須大於 0")
        amount_minor = money.to_minor(amount, a["currency"])
        if amount_minor == 0:
            raise BookError("金額太小，四捨五入後為 0")

        category = str(p.get("category") or "").strip()[:60]
        note = str(p.get("note") or "").strip()[:500]
        out = dict(time=when, type=typ, category=category, note=note, amount_minor=amount_minor,
                   account_id=a["id"], to_account_id=None, to_amount_minor=None)
        if typ == "transfer":
            t = acct("to_account_id")
            if not t:
                raise BookError("請選擇轉入帳戶")
            if t["id"] == a["id"]:
                raise BookError("轉出與轉入不能是同一個帳戶")
            if t["archived"] and not (existing and existing["to_account_id"] == t["id"]):
                raise BookError(f"「{t['name']}」已封存，請先取消封存")
            raw = p.get("to_amount")
            if raw is None or str(raw).strip() == "":
                if t["currency"] == a["currency"]:
                    to_minor = amount_minor
                else:
                    rates = self.get_rates(c)
                    if a["currency"] not in rates or t["currency"] not in rates:
                        raise BookError(f"{a['currency']} → {t['currency']} 需要匯率：請輸入轉入金額，或先到設定頁填匯率")
                    to_minor = money.convert_minor(amount_minor, a["currency"], t["currency"],
                                                   rates[a["currency"]], rates[t["currency"]])
            else:
                try:
                    to_minor = money.to_minor(raw, t["currency"])
                except ValueError as e:
                    raise BookError(str(e)) from None
            if to_minor <= 0:
                raise BookError("轉入金額必須大於 0")
            out.update(to_account_id=t["id"], to_amount_minor=to_minor)
        elif not category:
            out["category"] = ADJUST_CATEGORY if typ == "adjust" else "未分類"
        out.update(self._advance_fields(p, existing, typ))
        return out

    @staticmethod
    def _advance_fields(p, existing, typ):
        """Advance / budget / statistics flags of an entry. A repayment (settle_of) keeps what it was made with."""
        keep = lambda k, d: (existing[k] if existing is not None else d)
        if existing is not None and existing["settle_of"]:
            return {k: existing[k] for k in ("advance", "counterparty", "no_budget", "no_stats", "settle_of", "written_off", "due_date")}
        if typ not in ("income", "expense"):
            return {"advance": "", "counterparty": "", "no_budget": 0, "no_stats": 0, "settle_of": None, "written_off": 0, "due_date": ""}
        adv = str(p["advance"] if "advance" in p else keep("advance", "") or "").strip()
        if adv not in ("", "friend", "claim"):
            raise BookError("代墊類型只能是 幫朋友付 或 先付待報帳")
        if typ != "expense":
            adv = ""
        who = " ".join(str(p["counterparty"] if "counterparty" in p else keep("counterparty", "") or "").split())[:40]
        if adv and not who:
            raise BookError("請填對象：幫誰付的，或要向誰報帳")
        flag = lambda k: 1 if (bool(p[k]) if k in p else bool(keep(k, 0))) else 0
        due = str(p["due"] if "due" in p else keep("due_date", "") or "").strip()
        if due:
            try:
                due = datetime.strptime(due[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
            except ValueError:
                raise BookError("到期日的格式不對，請選一個日期") from None
        return {"advance": adv, "counterparty": who if adv else "", "no_budget": flag("no_budget"), "no_stats": flag("no_stats"),
                "settle_of": None, "written_off": keep("written_off", 0) if adv else 0, "due_date": due if adv else ""}

    # ----------------------------------------------------- tags, receipts
    MAX_TAGS = 10
    MAX_RECEIPTS = 4
    MAX_RECEIPT_BYTES = 400_000

    @staticmethod
    def clean_tags(raw):
        """'日本旅行, #出差  日本旅行' / ['a', 'b'] -> ['日本旅行', '出差'] (no #, no duplicates ignoring case, 30 characters each)."""
        if raw is None:
            return []
        parts = re.split(r"[,，、;；\s]+", raw) if isinstance(raw, str) else [str(x) for x in raw]
        out, seen = [], set()
        for t in parts:
            t = " ".join(t.replace("#", " ").split())[:30]
            if t and t.casefold() not in seen:
                seen.add(t.casefold())
                out.append(t)
        if len(out) > Book.MAX_TAGS:
            raise BookError(f"一筆交易最多 {Book.MAX_TAGS} 個標籤")
        return out

    def tags_map(self, conn):
        res = {}
        for r in conn.execute("SELECT tx_id, tag FROM tx_tags ORDER BY tag COLLATE NOCASE"):
            res.setdefault(r["tx_id"], []).append(r["tag"])
        return res

    def tag_list(self, conn):
        return [{"tag": r["tag"], "count": r["n"]} for r in conn.execute(
            "SELECT tag, COUNT(*) n FROM tx_tags GROUP BY tag COLLATE NOCASE ORDER BY n DESC, tag COLLATE NOCASE")]

    @staticmethod
    def _set_tags(c, tx_id, tags):
        c.execute("DELETE FROM tx_tags WHERE tx_id=?", (tx_id,))
        c.executemany("INSERT INTO tx_tags(tx_id,tag) VALUES(?,?)", [(tx_id, t) for t in tags])

    def receipts_map(self, conn):
        res = {}
        for r in conn.execute("SELECT id, tx_id FROM receipts ORDER BY id"):
            res.setdefault(r["tx_id"], []).append(r["id"])
        return res

    @staticmethod
    def _image_kind(data):
        if data[:3] == b"\xff\xd8\xff":
            return "image/jpeg"
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            return "image/png"
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp"
        return None

    def add_receipt(self, tx_id, data):
        if not data:
            raise BookError("沒有收到圖片")
        if len(data) > self.MAX_RECEIPT_BYTES:
            raise BookError(f"圖片太大（上限 {self.MAX_RECEIPT_BYTES // 1000} KB）；畫面會先自動縮小，請重新選擇")
        mime = self._image_kind(data)
        if not mime:
            raise BookError("只能附 JPEG、PNG 或 WebP 圖片")
        with self.session(notify=True) as c:
            if not c.execute("SELECT 1 FROM transactions WHERE id=?", (tx_id,)).fetchone():
                raise BookError("找不到這筆交易", 404)
            if c.execute("SELECT COUNT(*) FROM receipts WHERE tx_id=?", (tx_id,)).fetchone()[0] >= self.MAX_RECEIPTS:
                raise BookError(f"一筆交易最多附 {self.MAX_RECEIPTS} 張照片")
            return c.execute("INSERT INTO receipts(tx_id,mime,data,created_at) VALUES(?,?,?,?)",
                             (tx_id, mime, data, now_iso())).lastrowid

    def get_receipt(self, rid):
        with self.session() as c:
            r = c.execute("SELECT mime, data FROM receipts WHERE id=?", (rid,)).fetchone()
        if not r:
            raise BookError("找不到這張照片", 404)
        return r["mime"], bytes(r["data"])

    def delete_receipt(self, rid):
        with self.session(notify=True) as c:
            if not c.execute("DELETE FROM receipts WHERE id=?", (rid,)).rowcount:
                raise BookError("找不到這張照片", 404)

    def receipt_stats(self, conn):
        r = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(LENGTH(data)),0) b FROM receipts").fetchone()
        return {"count": r["n"], "bytes": r["b"]}

    # ----------------------------------------------------- undo of deletes
    UNDO_SECONDS = 60
    _TX_COLS = ("id", "time", "type", "category", "note", "amount_minor", "account_id", "to_account_id",
                "to_amount_minor", "created_at", "updated_at", "advance", "counterparty", "no_budget", "no_stats",
                "settle_of", "written_off", "due_date", "bill_id", "auto_account_id")

    def _snapshot(self, c, tx_id):
        row = c.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
        return {"tx": {k: row[k] for k in self._TX_COLS},
                "tags": [r["tag"] for r in c.execute("SELECT tag FROM tx_tags WHERE tx_id=?", (tx_id,))],
                "receipts": [(r["mime"], bytes(r["data"]), r["created_at"]) for r in
                             c.execute("SELECT mime,data,created_at FROM receipts WHERE tx_id=? ORDER BY id", (tx_id,))]}

    @staticmethod
    def _edit_snap(c, row):
        return {"edit": {"id": row["id"], "category": row["category"], "updated_at": row["updated_at"],
                         "tags": [r["tag"] for r in c.execute("SELECT tag FROM tx_tags WHERE tx_id=?", (row["id"],))]}}

    def _remember_undo(self, snaps):
        import secrets
        import time as _t
        with self._lock:
            now = _t.time()
            store = self.__dict__.setdefault("_undo", {})
            for k in [k for k, (exp, _) in store.items() if exp < now]:
                del store[k]
            while len(store) >= 20:
                del store[next(iter(store))]
            token = secrets.token_hex(8)
            store[token] = (now + self.UNDO_SECONDS, snaps)
            return token

    def undo(self, token):
        """Put back what a delete (single or bulk) removed in the last minute - same ids, tags and photos - or undo a bulk category / tag change."""
        import time as _t
        with self._lock:
            store = self.__dict__.setdefault("_undo", {})
            hit = store.pop(str(token or ""), None)
        if not hit or hit[0] < _t.time():
            raise BookError("已經超過復原時間（刪除後 1 分鐘內才能復原）", 410)
        snaps = hit[1]
        try:
            with self.session(notify=True) as c:
                for s in snaps:
                    if "edit" in s:                      # a bulk category / tag change: put the old values back
                        e = s["edit"]
                        if c.execute("SELECT 1 FROM transactions WHERE id=?", (e["id"],)).fetchone():
                            c.execute("UPDATE transactions SET category=?, updated_at=? WHERE id=?", (e["category"], e["updated_at"], e["id"]))
                            self._set_tags(c, e["id"], e["tags"])
                        continue
                    t = s["tx"]
                    c.execute(f"INSERT INTO transactions({','.join(self._TX_COLS)}) VALUES({','.join('?' * len(self._TX_COLS))})",
                              tuple(t[k] for k in self._TX_COLS))
                    self._set_tags(c, t["id"], s["tags"])
                    for mime, data, created in s["receipts"]:
                        c.execute("INSERT INTO receipts(tx_id,mime,data,created_at) VALUES(?,?,?,?)", (t["id"], mime, data, created))
        except Exception as e:
            import sqlite3
            if isinstance(e, sqlite3.IntegrityError):
                raise BookError("無法復原：相關的帳戶或交易已經改變") from None
            raise
        return len(snaps)

    # ----------------------------------------------------- bulk actions
    def bulk_transactions(self, ids, action, category=None, tag=None):
        """Change or delete many entries at once. Entries the action does not fit (a transfer cannot have a category,
        an investment trade is managed on the investment page) are skipped and counted."""
        try:
            ids = list(dict.fromkeys(int(i) for i in ids or []))
        except (TypeError, ValueError):
            raise BookError("請先勾選交易")
        if not ids or len(ids) > 1000:
            raise BookError("請先勾選交易（一次最多 1000 筆）")
        if action not in ("delete", "category", "tag_add", "tag_remove"):
            raise BookError("不明的批次動作")
        cat = str(category or "").strip()[:60]
        tags = []
        if action == "category":
            if not cat:
                raise BookError("請輸入新的類別")
            if cat in self.RESERVED_CATEGORIES:
                raise BookError(f"「{cat}」是系統保留的名稱，請換一個")
        if action in ("tag_add", "tag_remove"):
            tags = self.clean_tags(tag)
            if not tags:
                raise BookError("請輸入標籤")
        done = skipped = 0
        snaps = []
        with self.session(notify=True) as c:
            for tid in ids:
                row = c.execute("SELECT * FROM transactions WHERE id=?", (tid,)).fetchone()
                if not row:
                    skipped += 1
                    continue
                if action in ("delete", "category") and c.execute("SELECT 1 FROM stock_trades WHERE tx_id=?", (tid,)).fetchone():
                    skipped += 1
                    continue
                if action == "delete":
                    if c.execute("SELECT 1 FROM transactions WHERE settle_of=?", (tid,)).fetchone():
                        skipped += 1                                  # an advance that has repayments: delete those first
                        continue
                    snaps.append(self._snapshot(c, tid))
                    c.execute("DELETE FROM transactions WHERE id=?", (tid,))
                elif action == "category":
                    if row["type"] not in ("income", "expense"):
                        skipped += 1
                        continue
                    snaps.append(self._edit_snap(c, row))
                    c.execute("UPDATE transactions SET category=?, updated_at=? WHERE id=?", (cat, now_iso(), tid))
                else:
                    have = [r["tag"] for r in c.execute("SELECT tag FROM tx_tags WHERE tx_id=?", (tid,))]
                    low = {t.casefold() for t in tags}
                    new = have + [t for t in tags if t.casefold() not in {h.casefold() for h in have}] if action == "tag_add" \
                        else [h for h in have if h.casefold() not in low]
                    if len(new) > self.MAX_TAGS:
                        skipped += 1
                        continue
                    snaps.append(self._edit_snap(c, row))
                    self._set_tags(c, tid, new)
                    c.execute("UPDATE transactions SET updated_at=? WHERE id=?", (now_iso(), tid))
                done += 1
        out = {"changed": done, "skipped": skipped}
        if snaps:
            out["undo"] = self._remember_undo(snaps)
        return out

    # -------------------------------------------------------- transactions
    def _insert_tx(self, c, p):
        """Validate and insert one entry inside the caller's session. -> its id."""
        v = self._normalize_tx(c, p)
        now = now_iso()
        cur = c.execute(
            "INSERT INTO transactions(time,type,category,note,amount_minor,account_id,to_account_id,"
            "to_amount_minor,created_at,updated_at,advance,counterparty,no_budget,no_stats,settle_of,written_off,due_date) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (v["time"], v["type"], v["category"], v["note"], v["amount_minor"], v["account_id"],
             v["to_account_id"], v["to_amount_minor"], now, now, v["advance"], v["counterparty"], v["no_budget"],
             v["no_stats"], v["settle_of"], v["written_off"], v["due_date"]))
        if "tags" in p:
            self._set_tags(c, cur.lastrowid, self.clean_tags(p["tags"]))
        if v["advance"] and not v["settle_of"]:
            self._set_auto_settle(c, cur.lastrowid, p)
        return cur.lastrowid

    def add_transaction(self, p):
        with self.session(notify=True) as c:
            return self._insert_tx(c, p)

    @staticmethod
    def _guard_trade_tx(c, tx_id, what):
        if c.execute("SELECT 1 FROM stock_trades WHERE tx_id=?", (tx_id,)).fetchone():
            raise BookError(f"這筆轉帳是投資買賣產生的，不能在這裡{what}。請到「投資」頁刪除該筆買賣紀錄。")

    def update_transaction(self, tx_id, p):
        with self.session(notify=True) as c:
            self._guard_trade_tx(c, tx_id, "修改")
            ex = c.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
            if not ex:
                raise BookError("找不到這筆交易（可能已被刪除）", 404)
            v = self._normalize_tx(c, p, existing=ex)
            c.execute(
                "UPDATE transactions SET time=?,type=?,category=?,note=?,amount_minor=?,account_id=?,"
                "to_account_id=?,to_amount_minor=?,updated_at=?,advance=?,counterparty=?,no_budget=?,no_stats=?,written_off=?,due_date=? WHERE id=?",
                (v["time"], v["type"], v["category"], v["note"], v["amount_minor"], v["account_id"],
                 v["to_account_id"], v["to_amount_minor"], now_iso(), v["advance"], v["counterparty"], v["no_budget"],
                 v["no_stats"], v["written_off"], v["due_date"], tx_id))
            self._set_auto_settle(c, tx_id, p, ex)
            if v["advance"] != (ex["advance"] or "") and not v["advance"]:      # no longer an advance: its repayments become ordinary income
                c.execute("UPDATE transactions SET settle_of=NULL, no_stats=0, no_budget=0 WHERE settle_of=?", (tx_id,))
            if "tags" in p:
                self._set_tags(c, tx_id, self.clean_tags(p["tags"]))

    @staticmethod
    def _guard_repaid(c, tx_id):
        if c.execute("SELECT 1 FROM transactions WHERE settle_of=?", (tx_id,)).fetchone():
            raise BookError("這筆代墊已經有收款紀錄，請先刪除收款紀錄（到「代墊」頁展開這筆），再刪除代墊本身。")

    def delete_transaction(self, tx_id):
        with self.session(notify=True) as c:
            self._guard_trade_tx(c, tx_id, "刪除")
            self._guard_repaid(c, tx_id)
            if not c.execute("SELECT 1 FROM transactions WHERE id=?", (tx_id,)).fetchone():
                raise BookError("找不到這筆交易（可能已被刪除）", 404)
            snap = self._snapshot(c, tx_id)
            c.execute("DELETE FROM transactions WHERE id=?", (tx_id,))
        return self._remember_undo([snap])

    # ----------------------------------------------- advances (paid for a friend / paid first, reimbursed later)
    def advances(self, conn, state="open"):
        """Entries marked as an advance with how much has come back. state: open (still owed), done (all back or given up), all.
        `by_party` adds up what is still owed per person, per currency."""
        rows, _, accts = self.ledger(conn)
        repaid = self.repaid_map(rows)
        tags, receipts = self.tags_map(conn), self.receipts_map(conn)
        pays = {}
        for r in rows:
            if r.get("settle_of"):
                pays.setdefault(r["settle_of"], []).append({"id": r["id"], "time": r["time"], "amount": money.from_minor(r["amount_minor"], accts[r["account_id"]]["currency"]),
                                                            "currency": accts[r["account_id"]]["currency"], "account": accts[r["account_id"]]["name"], "note": r["note"]})
        items, owed = [], {}
        bills = self.bills_view(conn, rows, accts, lambda r: {**self.format_tx(r, accts, tags, receipts, repaid), "payments": pays.get(r["id"], [])}, receipts, state)
        for r in reversed(rows):
            if not r.get("advance"):
                continue
            f = self.format_tx(r, accts, tags, receipts, repaid)
            f["payments"] = pays.get(r["id"], [])
            is_open = f["state"] in ("open", "partial")
            if r.get("bill_id"):                                  # shown on its bill's card; still counted for who owes what
                if is_open and (state != "done"):
                    items.append({**f, "_bill": True})
                    key = (f["counterparty"], f["advance"], f["currency"])
                    owed[key] = owed.get(key, 0) + f["remaining"]
                continue
            if state == "open" and not is_open or state == "done" and is_open:
                continue
            items.append(f)
            if is_open:
                key = (f["counterparty"], f["advance"], f["currency"])
                owed[key] = owed.get(key, 0) + f["remaining"]
        if state == "open":
            items.sort(key=lambda f: f["due"] or "9999-99-99")                      # the ones due first on top (stable: no date keeps newest first)
        party = {}
        for (who, kind, ccy), amount in sorted(owed.items()):
            g = party.setdefault((who, kind), {"counterparty": who, "advance": kind, "remaining": [], "count": 0})
            g["remaining"].append({"currency": ccy, "amount": round(amount, 2)})
        late = soon = 0
        for f in items:
            if f["state"] in ("open", "partial"):
                g = party[(f["counterparty"], f["advance"])]
                g["count"] += 1
                if f.get("due_in") is not None and f["due_in"] < 0:
                    g["overdue"] = g.get("overdue", 0) + 1; late += 1
                elif f.get("due_in") is not None and f["due_in"] <= self.DUE_SOON_DAYS:
                    soon += 1
        return {"items": [f for f in items if not f.get("_bill")], "bills": bills, "by_party": list(party.values()),
                "alerts": {"overdue": late, "soon": soon, "soon_days": self.DUE_SOON_DAYS}}

    def settle_advance(self, tx_id, p):
        """Record that (part of) an advance came back: an income line into one of your accounts, linked to the advance.
        It never counts as income in the reports. When everything is back the advance is closed."""
        with self.session(notify=True) as c:
            ex = c.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
            if not ex or not ex["advance"]:
                raise BookError("找不到這筆代墊", 404)
            if ex["written_off"]:
                raise BookError("這筆已經決定不收了")
            acc_id = p.get("account_id") or ex["account_id"]
            a = c.execute("SELECT * FROM accounts WHERE id=?", (int(acc_id),)).fetchone()
            orig = c.execute("SELECT currency FROM accounts WHERE id=?", (ex["account_id"],)).fetchone()
            if not a:
                raise BookError("請選擇收款的帳戶")
            if a["archived"]:
                raise BookError(f"「{a['name']}」已封存，請先取消封存")
            if a["currency"] != orig["currency"]:
                raise BookError(f"收款帳戶要和當初墊付的帳戶同幣別（{orig['currency']}）")
            got = c.execute("SELECT COALESCE(SUM(amount_minor),0) FROM transactions WHERE settle_of=?", (tx_id,)).fetchone()[0]
            left = ex["amount_minor"] - got
            if left <= 0:
                raise BookError("這筆已經收齊了")
            raw = p.get("amount")
            try:
                minor = left if raw is None or str(raw).strip() == "" else money.to_minor(money.parse_amount(raw), a["currency"])
            except ValueError as e:
                raise BookError(str(e)) from None
            if minor <= 0:
                raise BookError("金額必須大於 0")
            if minor > left:
                raise BookError(f"超過還沒收的金額（還剩 {money.from_minor(left, a['currency'])}）")
            try:
                when = normalize_time(p.get("time") or now_iso())
            except ValueError as e:
                raise BookError(str(e)) from None
            note = str(p.get("note") or "").strip()[:500] or f"{ex['counterparty']}{'還款' if ex['advance'] == 'friend' else '報帳入帳'}：{ex['note'] or ex['category']}"[:500]
            now = now_iso()
            cur = c.execute(
                "INSERT INTO transactions(time,type,category,note,amount_minor,account_id,created_at,updated_at,advance,counterparty,no_budget,no_stats,settle_of,written_off) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (when, "income", self.REPAY_CATEGORY, note, minor, a["id"], now, now, "", ex["counterparty"], 1, 1, tx_id, 0))
            return {"id": cur.lastrowid, "closed": minor == left}

    def write_off_advance(self, tx_id):
        """Give up collecting what is left: the advance now counts as an ordinary expense (statistics and budget)."""
        with self.session(notify=True) as c:
            ex = c.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
            if not ex or not ex["advance"]:
                raise BookError("找不到這筆代墊", 404)
            c.execute("UPDATE transactions SET written_off=1, no_stats=0, no_budget=0, updated_at=? WHERE id=?", (now_iso(), tx_id))

    def reopen_advance(self, tx_id):
        with self.session(notify=True) as c:
            ex = c.execute("SELECT * FROM transactions WHERE id=?", (tx_id,)).fetchone()
            if not ex or not ex["advance"]:
                raise BookError("找不到這筆代墊", 404)
            c.execute("UPDATE transactions SET written_off=0, no_stats=1, no_budget=1, updated_at=? WHERE id=?", (now_iso(), tx_id))

    # ------------------------------------------------------------- quick templates
    DUE_SOON_DAYS = 3
    MAX_TEMPLATES = 40

    def templates(self, conn):
        return [{"id": r["id"], "name": r["name"], "type": r["type"], "category": r["category"], "note": r["note"], "amount": r["amount"],
                 "account_id": r["account_id"], "to_account_id": r["to_account_id"], "tags": r["tags"], "advance": r["advance"],
                 "counterparty": r["counterparty"], "no_budget": bool(r["no_budget"]), "no_stats": bool(r["no_stats"]), "ask_amount": bool(r["ask_amount"])}
                for r in conn.execute("SELECT * FROM templates ORDER BY sort_order, id")]

    def _clean_template(self, c, p):
        name = " ".join(str(p.get("name") or "").split())[:30]
        if not name:
            raise BookError("請幫範本取個名字")
        typ = p.get("type")
        if typ not in TX_TYPES:
            raise BookError("範本的類型必須是 支出、收入 或 轉帳")
        amount = str(p.get("amount") or "").replace(",", "").strip()
        if amount:
            try:
                if money.parse_amount(amount) <= 0:
                    raise ValueError
            except ValueError:
                raise BookError("範本的金額請輸入大於 0 的數字，或留空") from None
        acct = lambda k: (lambda i: i if i and c.execute("SELECT 1 FROM accounts WHERE id=?", (i,)).fetchone() else None)(int(p[k]) if str(p.get(k) or "").isdigit() else None)
        adv = p.get("advance") if p.get("advance") in ("friend", "claim") and typ == "expense" else ""
        who = " ".join(str(p.get("counterparty") or "").split())[:40] if adv else ""
        return (name, typ, "" if typ == "transfer" else str(p.get("category") or "").strip()[:60], str(p.get("note") or "").strip()[:500], amount,
                acct("account_id"), acct("to_account_id") if typ == "transfer" else None, " ".join(self.clean_tags(p.get("tags") or "")), adv, who,
                1 if p.get("no_budget") else 0, 1 if p.get("no_stats") else 0, 1 if p.get("ask_amount") else 0)

    def save_template(self, p, tpl_id=None):
        with self.session(notify=True) as c:
            vals = self._clean_template(c, p)
            if tpl_id is None:
                if c.execute("SELECT COUNT(*) FROM templates").fetchone()[0] >= self.MAX_TEMPLATES:
                    raise BookError(f"範本最多 {self.MAX_TEMPLATES} 個，請先刪掉不用的")
                top = c.execute("SELECT COALESCE(MAX(sort_order),0)+1 FROM templates").fetchone()[0]
                return c.execute("INSERT INTO templates(name,type,category,note,amount,account_id,to_account_id,tags,advance,counterparty,no_budget,no_stats,ask_amount,sort_order) "
                                 "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (*vals, top)).lastrowid
            if not c.execute("SELECT 1 FROM templates WHERE id=?", (tpl_id,)).fetchone():
                raise BookError("找不到這個範本", 404)
            c.execute("UPDATE templates SET name=?,type=?,category=?,note=?,amount=?,account_id=?,to_account_id=?,tags=?,advance=?,counterparty=?,no_budget=?,no_stats=?,ask_amount=? WHERE id=?",
                      (*vals, tpl_id))
            return tpl_id

    @staticmethod
    def frequent_key(key):
        """Stable id of an entry kind: type | category | note | account | to-account."""
        return "|".join("" if x is None else str(x) for x in key)

    def hidden_frequent(self, conn):
        try:
            v = json.loads(self.get_setting(conn, "frequent_hidden", "[]"))
        except ValueError:
            v = []
        return [x for x in v if isinstance(x, str)] if isinstance(v, list) else []

    def hide_frequent(self, key):
        key = str(key or "").strip()[:700]
        if not key:
            raise BookError("沒有指定要隱藏哪一筆")
        with self.session() as c:
            cur = self.hidden_frequent(c)
            if key not in cur:
                self.set_setting(c, "frequent_hidden", json.dumps((cur + [key])[-500:], ensure_ascii=False))

    def restore_frequent(self):
        with self.session() as c:
            self.set_setting(c, "frequent_hidden", "[]")

    def frequent(self, conn, limit=8):
        """Entries the user has typed before, most repeated first: the same type / category / note / account.
        Each one carries the latest amount and settings, so it works as an automatic quick template."""
        saved = {(t["type"], t["category"], t["note"].strip(), t["account_id"]) for t in self.templates(conn)}
        hidden = set(self.hidden_frequent(conn))
        ccy = {r["id"]: r["currency"] for r in conn.execute("SELECT id, currency FROM accounts")}
        groups = {}
        for r in conn.execute("SELECT * FROM transactions WHERE type IN ('expense','income','transfer') AND settle_of IS NULL ORDER BY time DESC, id DESC LIMIT 3000"):
            if r["category"] in self.RESERVED_CATEGORIES or r["account_id"] not in ccy:
                continue
            key = (r["type"], r["category"], r["note"].strip(), r["account_id"], r["to_account_id"] if r["type"] == "transfer" else None)
            g = groups.get(key)
            if g is None:
                groups[key] = {"row": r, "count": 1}
            else:
                g["count"] += 1
        tags = self.tags_map(conn)
        out = []
        ranked = sorted(groups.items(), key=lambda kv: (kv[1]["count"], kv[1]["row"]["time"]), reverse=True)
        for key, g in ranked:
            r = g["row"]
            fkey = self.frequent_key(key)
            if key[:4] in saved or fkey in hidden:
                continue
            label = r["note"].strip() or r["category"] or {"expense": "支出", "income": "收入", "transfer": "轉帳"}[r["type"]]
            out.append({"name": label[:30], "type": r["type"], "category": r["category"], "note": r["note"], "amount": format(money.to_major(r["amount_minor"], ccy[r["account_id"]]).normalize(), "f"),
                        "account_id": r["account_id"], "to_account_id": r["to_account_id"] if r["type"] == "transfer" else None,
                        "tags": " ".join(tags.get(r["id"], [])), "advance": r["advance"], "counterparty": r["counterparty"],
                        "no_budget": bool(r["no_budget"]) and bool(r["advance"]), "no_stats": bool(r["no_stats"]) and bool(r["advance"]), "count": g["count"], "auto": True, "key": fkey})
            if len(out) >= limit:
                break
        return out

    def reorder_templates(self, ids):
        """Put the templates in the given order (ids not mentioned keep their relative order after them)."""
        if not isinstance(ids, list):
            raise BookError("排序資料不正確")
        with self.session() as c:
            have = [r["id"] for r in c.execute("SELECT id FROM templates ORDER BY sort_order, id")]
            first = [i for i in dict.fromkeys(int(x) for x in ids if str(x).lstrip("-").isdigit()) if i in have]
            for pos, tid in enumerate(first + [i for i in have if i not in first]):
                c.execute("UPDATE templates SET sort_order=? WHERE id=?", (pos, tid))

    def reorder_accounts(self, ids):
        """Put the accounts in the given order (ids not mentioned keep their relative order after them)."""
        if not isinstance(ids, list):
            raise BookError("排序資料不正確")
        with self.session() as c:
            have = [r["id"] for r in c.execute("SELECT id FROM accounts ORDER BY sort_order, id")]
            first = [i for i in dict.fromkeys(int(x) for x in ids if str(x).lstrip("-").isdigit()) if i in have]
            for pos, aid in enumerate(first + [i for i in have if i not in first]):
                c.execute("UPDATE accounts SET sort_order=? WHERE id=?", (pos, aid))

    def delete_template(self, tpl_id):
        with self.session(notify=True) as c:
            if not c.execute("DELETE FROM templates WHERE id=?", (tpl_id,)).rowcount:
                raise BookError("找不到這個範本", 404)

    def list_transactions(self, conn, q="", typ="", account_id=None, category="",
                          date_from="", date_to="", limit=200, offset=0, transfers=True, tag="", group=""):
        rows, _, accts = self.ledger(conn)
        q = (q or "").strip().lower()
        tags = self.tags_map(conn)
        tag = (tag or "").strip().casefold()
        res = []
        for r in rows:
            if tag and tag not in {t.casefold() for t in tags.get(r["id"], [])}:
                continue
            if typ and r["type"] != typ:
                continue
            if account_id and account_id not in (r["account_id"], r["to_account_id"]):
                continue
            if category and r["category"] != category:
                continue
            if date_from and r["time"][:10] < date_from:
                continue
            if date_to and r["time"][:10] > date_to:
                continue
            if q:
                hay = " ".join([r["note"], r["category"], " ".join(tags.get(r["id"], [])), accts[r["account_id"]]["name"],
                                accts[r["to_account_id"]]["name"] if r["to_account_id"] else ""]).lower()
                if q not in hay:
                    continue
            res.append(r)
        totals = self._tally(conn, res, accts, q, account_id, transfers)
        res.reverse()  # newest first
        total = len(res)
        group = group if group in ("day", "month", "year") else ""
        width = {"day": 10, "month": 7, "year": 4}.get(group, 0)
        out = {"total": total, "totals": totals}
        if group in ("month", "year"):                    # one summary line per month / year, no individual rows
            out["items"] = []
        else:
            receipts = self.receipts_map(conn)
            repaid = self.repaid_map(rows)
            out["items"] = [self.format_tx(r, accts, tags, receipts, repaid) for r in res[offset:offset + limit]]
        if group:
            out["group"] = group
            wanted = {r["time"][:width] for r in res[offset:offset + limit]} if group == "day" else None
            buckets = {}
            for r in res:                                  # newest first, so the buckets are too
                key = r["time"][:width]
                if wanted is None or key in wanted:
                    buckets.setdefault(key, []).append(r)
            groups = []
            for key, rs in buckets.items():
                t = self._tally(conn, rs, accts, q, account_id, transfers)
                groups.append({"key": key, "count": len(rs), "income": t["income"], "expense": t["expense"], "net": t["net"],
                               "missing_rates": t["missing_rates"]})
            out["groups"] = groups
        return out

    def _tally(self, conn, rows, accts, q="", account_id=None, transfers=True):
        """Income / expense over ALL rows that match the filter (not just the page shown).
        Zeroing adjustments are never income or expense. A transfer (Cube Bank -> Post, 1000) is seen from each
        side: 1000 expense for Cube Bank, 1000 income for Post. With `transfers=False` it is left out entirely.
        Which sides count follows the filter: filtering on an account counts only that account's side; a text
        search that matches just one of the two account names counts just that side; otherwise both sides."""
        base = self.base_currency(conn)
        rates = self.get_rates(conn)
        per = {}                                   # currency -> [income_minor, expense_minor]
        counts = {"income": 0, "expense": 0, "transfer": 0, "adjust": 0}
        both = 0                                   # transfers counted on both sides (no account / name narrowed it down)

        def add(ccy, idx, minor):
            per.setdefault(ccy, [0, 0])[idx] += minor

        for r in rows:
            counts[r["type"]] += 1
            if r["type"] in ("income", "expense"):
                if r.get("no_stats"):
                    continue
                add(accts[r["account_id"]]["currency"], 0 if r["type"] == "income" else 1, r["amount_minor"])
            elif r["type"] == "transfer" and transfers:
                out_side = in_side = True
                if account_id:
                    out_side, in_side = r["account_id"] == account_id, r["to_account_id"] == account_id
                elif q:
                    a_out, a_in = accts[r["account_id"]], accts[r["to_account_id"]]
                    if q not in f"{r['note']} {r['category']}".lower():
                        hit_out, hit_in = q in a_out["name"].lower(), q in a_in["name"].lower()
                        if hit_out != hit_in:
                            out_side, in_side = hit_out, hit_in
                both += out_side and in_side
                if out_side:
                    add(accts[r["account_id"]]["currency"], 1, r["amount_minor"])
                if in_side:
                    add(accts[r["to_account_id"]]["currency"], 0, r["to_amount_minor"])
        inc = exp = Decimal(0)
        missing = []
        by_ccy = []
        for ccy, (i_min, e_min) in sorted(per.items()):
            by_ccy.append({"currency": ccy, "income": money.from_minor(i_min, ccy), "expense": money.from_minor(e_min, ccy)})
            if ccy not in rates:
                missing.append(ccy)
                continue
            inc += money.to_major(i_min, ccy) * rates[ccy]
            exp += money.to_major(e_min, ccy) * rates[ccy]
        return {"base": base, "income": float(inc), "expense": float(exp), "net": float(inc - exp),
                "count": counts, "by_currency": by_ccy, "missing_rates": missing, "transfers_counted": bool(transfers),
                "both_sides": both > 0}

    # ------------------------------------------------------ bank rates / exchange
    # Rates are "base currency per 1 unit of foreign currency", exactly as the banks' apps show them.
    #   side "sell": the bank sells the foreign currency to you (you buy it with TWD)  -> "我要買外幣"
    #   side "buy":  the bank buys the foreign currency from you (you get TWD)         -> "我要賣外幣"
    @staticmethod
    def bank_of(name):
        low = str(name or "").lower()
        for key in config.BANKS:
            if low.startswith(key.lower()):
                return key
        return None

    @staticmethod
    def _clean_bank(bank):
        for key in config.BANKS:
            if str(bank or "").strip().lower() == key.lower():
                return key
        raise BookError("請選擇銀行：" + "、".join(config.BANKS))

    @staticmethod
    def _parse_rate(v, label):
        try:
            d = Decimal(str(v).replace(",", "").strip())
        except Exception:
            raise BookError(f"{label}的匯率格式不正確") from None
        if not d.is_finite() or d <= 0 or d > Decimal("100000000"):
            raise BookError(f"{label}的匯率必須大於 0")
        return d.quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP).normalize()

    def _record_rate(self, c, bank, ccy, side, d, source, at=None):
        """Append to the rate history unless it is the same number already recorded today."""
        at = at or now_iso()
        text = format(d, "f")
        last = c.execute("SELECT rate, at FROM bank_rates WHERE bank=? AND currency=? AND side=? ORDER BY at DESC, id DESC LIMIT 1",
                         (bank, ccy, side)).fetchone()
        if last and Decimal(last["rate"]) == d and last["at"][:10] == at[:10]:
            return False
        c.execute("INSERT INTO bank_rates(bank,currency,side,rate,at,source) VALUES(?,?,?,?,?,?)", (bank, ccy, side, text, at, source))
        return True

    def set_bank_rates(self, bank, currency, buy=None, sell=None, source="manual"):
        bank = self._clean_bank(bank)
        source = source if source in ("manual", "web", "exchange") else "manual"
        try:
            ccy = money.normalize_currency(currency)
        except ValueError as e:
            raise BookError(str(e)) from None
        with self.session() as c:
            if ccy == self.base_currency(c):
                raise BookError("換匯要選外幣，不能是本位幣")
            saved = []
            for side, v, label in (("buy", buy, "銀行買進"), ("sell", sell, "銀行賣出")):
                if v is None or str(v).strip() == "":
                    continue
                if self._record_rate(c, bank, ccy, side, self._parse_rate(v, label), source):
                    saved.append(side)
            return saved

    def bank_board(self, conn, currency):
        try:
            ccy = money.normalize_currency(currency)
        except ValueError as e:
            raise BookError(str(e)) from None
        rows = []
        for key, zh in config.BANKS.items():
            row = {"bank": key, "name": zh, "buy": None, "sell": None}
            for side in ("buy", "sell"):
                r = conn.execute("SELECT rate, at, source FROM bank_rates WHERE bank=? AND currency=? AND side=? ORDER BY at DESC, id DESC LIMIT 1",
                                 (key, ccy, side)).fetchone()
                if r:
                    row[side] = {"rate": float(Decimal(r["rate"])), "text": r["rate"], "at": r["at"], "source": r["source"]}
            rows.append(row)
        rates = self.get_rates(conn)
        mk = conn.execute("SELECT rate, updated_at FROM rates WHERE currency=?", (ccy,)).fetchone()
        return {"currency": ccy, "base": self.base_currency(conn), "banks": rows,
                "market": ({"rate": float(Decimal(mk["rate"])), "at": mk["updated_at"]} if mk else None)}

    def fx_currencies(self, conn):
        """Foreign currencies worth keeping up to date: those with an open account, plus any rated recently."""
        base = self.base_currency(conn)
        since = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%dT00:00:00")
        found = {r["currency"] for r in conn.execute("SELECT DISTINCT currency FROM accounts WHERE archived=0")}
        found |= {r["currency"] for r in conn.execute("SELECT DISTINCT currency FROM bank_rates WHERE at>=?", (since,))}
        return sorted(c for c in found if c != base and c in bankfetch.CCY_WORDS)

    def fetch_web_rates(self, currency, save=True, fetcher=None):
        """Read the four banks' own rate pages. Each bank succeeds or fails on its own; what was read is stored
        as history (source "web") and can always be corrected afterwards."""
        try:
            ccy = money.normalize_currency(currency)
        except ValueError as e:
            raise BookError(str(e)) from None
        with self.session() as c:
            if ccy == self.base_currency(c):
                raise BookError("換匯要選外幣，不能是本位幣")
            mk = c.execute("SELECT rate FROM rates WHERE currency=?", (ccy,)).fetchone()
            ref = float(Decimal(mk["rate"])) if mk else None
        results = (fetcher or bankfetch.fetch_all)(ccy, ref)
        saved = []
        if save:
            for r in results:
                if r.get("ok"):
                    if self.set_bank_rates(r["bank"], ccy, buy=r["buy"], sell=r["sell"], source="web"):
                        saved.append(r["bank"])
        return {"currency": ccy, "results": results, "saved": saved}

    def bank_history(self, conn, bank, currency, side, days=7):
        bank = self._clean_bank(bank)
        ccy = money.normalize_currency(currency)
        if side not in ("buy", "sell"):
            raise BookError("side 必須是 buy 或 sell")
        since = (datetime.now() - timedelta(days=int(days))).strftime("%Y-%m-%dT00:00:00")
        pts = {}
        for r in conn.execute("SELECT rate, at FROM bank_rates WHERE bank=? AND currency=? AND side=? AND at>=? ORDER BY at, id",
                              (bank, ccy, side, since)):
            pts[r["at"][:10]] = float(Decimal(r["rate"]))          # last record of each day
        series = [{"date": d, "rate": v} for d, v in sorted(pts.items())]
        vals = [p["rate"] for p in series]
        return {"bank": bank, "currency": ccy, "side": side, "days": int(days), "points": series,
                "high": max(vals) if vals else None, "low": min(vals) if vals else None}

    def exchange(self, p):
        """One currency exchange at a bank = a transfer between a base-currency account and a foreign-currency
        account, remembering the rate that was quoted."""
        bank = self._clean_bank(p.get("bank"))
        with self.session() as c:
            base = self.base_currency(c)
            def acct(key):
                try:
                    return c.execute("SELECT * FROM accounts WHERE id=?", (int(p.get(key)),)).fetchone()
                except (TypeError, ValueError):
                    return None
            a, t = acct("account_id"), acct("to_account_id")
            if not a or not t:
                raise BookError("請選擇轉出與轉入帳戶")
            if (a["currency"] == base) == (t["currency"] == base):
                raise BookError(f"換匯必須是 {base} 與外幣之間互換（一邊是 {base}，另一邊是外幣）")
            buying = a["currency"] == base                     # TWD -> foreign: the bank SELLS foreign to us
            ccy = t["currency"] if buying else a["currency"]
            side = "sell" if buying else "buy"
            rate = self._parse_rate(p.get("rate"), "銀行" + ("賣出" if buying else "買進"))
            try:
                amount = money.parse_amount(p.get("amount"))
            except ValueError as e:
                raise BookError(str(e)) from None
            if amount <= 0:
                raise BookError("金額必須大於 0")
            raw = p.get("to_amount")
            if raw is None or str(raw).strip() == "":
                to_amt = amount / rate if buying else amount * rate
            else:
                try:
                    to_amt = money.parse_amount(raw)
                except ValueError as e:
                    raise BookError(str(e)) from None
        note_rate = format(rate, "f")
        extra = str(p.get("note") or "").strip()
        note = f"換匯 {bank} {ccy} @{note_rate}" + (f" {extra}" if extra else "")
        tx_id = self.add_transaction({"type": "transfer", "account_id": a["id"], "to_account_id": t["id"], "amount": str(amount),
                                      "to_amount": str(to_amt), "time": p.get("time") or None, "note": note, "category": ""})
        self.set_bank_rates(bank, ccy, **{side: note_rate}, source="exchange")
        return {"id": tx_id, "currency": ccy, "side": side, "rate": float(rate)}

    REPAY_CATEGORY = "代墊收回"                    # the income line made when a friend / company pays an advance back
    RESERVED_CATEGORIES = ("未分類", "轉帳", REPAY_CATEGORY)

    def _category_usage(self, conn):
        """{name: {"income": n, "expense": n}} counted over income/expense transactions (empty and 未分類 left out)."""
        use = {}
        for r in conn.execute("SELECT category, type, COUNT(*) n FROM transactions "
                              "WHERE type IN ('income','expense') GROUP BY category, type"):
            name = (r["category"] or "").strip()
            if name and name != "未分類" and name != Book.REPAY_CATEGORY:
                use.setdefault(name, {"income": 0, "expense": 0})[r["type"]] += r["n"]
        return use

    def category_info(self, conn):
        """Everything the screens need about categories:
        `all`      – the unified A-Z list (every category ever used or added by hand),
        `income` / `expense` – the lists for one kind of entry (a category used both ways is in both),
        `usage`    – how many entries each one has, per kind,
        `defined`  – the ones added by hand: {name: kind}."""
        use = self._category_usage(conn)
        defined = {r["name"]: r["kind"] for r in conn.execute("SELECT name, kind FROM categories")}
        inc, exp = set(), set()
        for name, u in use.items():
            if u["income"]:
                inc.add(name)
            if u["expense"]:
                exp.add(name)
        for name, kind in defined.items():
            if kind in ("income", "both"):
                inc.add(name)
            if kind in ("expense", "both"):
                exp.add(name)
        every = inc | exp
        if not every:                                   # nothing entered yet: the built-in suggestions
            inc = {c for c in DEFAULT_CATEGORIES if c in ("salary", "investment", "other")}
            exp = {c for c in DEFAULT_CATEGORIES if c != "salary"}
            every = inc | exp
        key = lambda c: (c.casefold(), c)
        return {"all": sorted(every, key=key), "income": sorted(inc, key=key), "expense": sorted(exp, key=key),
                "usage": use, "defined": defined}

    def categories(self, conn):
        return self.category_info(conn)["all"]

    @staticmethod
    def _clean_category_name(name):
        name = " ".join(str(name or "").split())
        if not name:
            raise BookError("請輸入類別名稱")
        if len(name) > 60:
            raise BookError("類別名稱最多 60 個字")
        if name in Book.RESERVED_CATEGORIES:
            raise BookError(f"「{name}」是系統保留的名稱，請換一個")
        return name

    # ------------------------------------------------------------ budgets
    def budgets(self, conn):
        """{category: monthly limit (float, in the base currency)}"""
        return {r["category"]: float(r["amount"]) for r in conn.execute("SELECT category, amount FROM budgets")}

    @staticmethod
    def shorthand_amount(amount):
        """'2700' -> '2700'; '2.7k' / '2k7' -> '2700'; '1.5萬' -> '15000'; '3千' -> '3000'. Anything else is returned as typed (commas removed)."""
        raw = str(amount if amount is not None else "").replace(",", "").replace("，", "").replace(" ", "").strip()
        m = re.fullmatch(r"(\d+(?:\.\d+)?)(k|K|千|萬|万|w|W)", raw)
        if m:
            mult = {"k": 1000, "千": 1000, "萬": 10000, "万": 10000, "w": 10000}[m.group(2).lower() if m.group(2) in "kKwW" else m.group(2)]
            return format((Decimal(m.group(1)) * mult).normalize(), "f")
        m = re.fullmatch(r"(\d+)[kK](\d+)", raw)                    # 2k7 = 2.7k
        if m:
            return format((Decimal(f"{m.group(1)}.{m.group(2)}") * 1000).normalize(), "f")
        return raw

    def set_budget(self, category, amount):
        """Set (or, with an empty / zero amount, remove) the monthly spending limit of a category."""
        category = str(category or "").strip()
        raw = self.shorthand_amount(amount)
        try:
            value = Decimal(raw) if raw else Decimal(0)
        except InvalidOperation:
            raise BookError("預算請輸入數字，例如 2700、2.7k 或 2k7")
        if value < 0 or value > Decimal("1000000000"):
            raise BookError("預算要介於 0 到 10 億之間")
        with self.session(notify=True) as c:
            if value == 0:
                c.execute("DELETE FROM budgets WHERE category=?", (category,))
                return
            if category not in self.category_info(c)["all"]:
                raise BookError("找不到這個類別", 404)
            c.execute("INSERT INTO budgets(category,amount) VALUES(?,?) ON CONFLICT(category) DO UPDATE SET amount=excluded.amount",
                      (category, format(value.quantize(Decimal("0.01")).normalize(), "f")))

    def add_category(self, name, kind="both"):
        name = self._clean_category_name(name)
        if kind not in ("income", "expense", "both"):
            raise BookError("類型必須是收入、支出或兩者")
        with self.session(notify=True) as c:
            info = self.category_info(c)
            if name in info["all"] and name not in info["defined"] and name not in info["usage"]:
                pass                                    # only a built-in suggestion: becomes a real one now
            elif name in info["all"]:
                raise BookError(f"已經有「{name}」這個類別了")
            c.execute("INSERT INTO categories(name,kind) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET kind=excluded.kind", (name, kind))

    def rename_category(self, name, new_name, kind=None):
        """Rename a category everywhere. A name that already exists merges the two (all entries, the icon of the
        target is kept). `kind` (income/expense/both) only applies to a category no entry uses yet."""
        name = str(name or "").strip()
        new_name = self._clean_category_name(new_name)
        if kind not in (None, "income", "expense", "both"):
            raise BookError("類型必須是收入、支出或兩者")
        with self.session(notify=True) as c:
            info = self.category_info(c)
            if name not in info["all"]:
                raise BookError("找不到這個類別（可能已被刪除）", 404)
            merged = new_name != name and new_name in info["all"]
            moved = 0
            if new_name != name:
                moved = c.execute("UPDATE transactions SET category=?, updated_at=? WHERE category=? AND type IN ('income','expense')",
                                  (new_name, now_iso(), name)).rowcount
                self._follow_category(c, name, new_name)
                old_icon = c.execute("SELECT icon,color FROM category_icons WHERE category=?", (name,)).fetchone()
                if old_icon and not c.execute("SELECT 1 FROM category_icons WHERE category=?", (new_name,)).fetchone():
                    c.execute("INSERT INTO category_icons(category,icon,color) VALUES(?,?,?)", (new_name, old_icon["icon"], old_icon["color"]))
                c.execute("DELETE FROM category_icons WHERE category=?", (name,))
                mine = c.execute("SELECT amount FROM budgets WHERE category=?", (name,)).fetchone()
                if mine:                                    # the budget moves along; merging two budgets adds them up
                    theirs = c.execute("SELECT amount FROM budgets WHERE category=?", (new_name,)).fetchone()
                    total = Decimal(mine["amount"]) + (Decimal(theirs["amount"]) if theirs else 0)
                    c.execute("DELETE FROM budgets WHERE category IN (?,?)", (name, new_name))
                    c.execute("INSERT INTO budgets(category,amount) VALUES(?,?)", (new_name, format(total.normalize(), "f")))
                kinds = {info["defined"][n] for n in (name, new_name) if n in info["defined"]}
                c.execute("DELETE FROM categories WHERE name IN (?,?)", (name, new_name))
                if kinds:
                    c.execute("INSERT INTO categories(name,kind) VALUES(?,?)", (new_name, kinds.pop() if len(kinds) == 1 else "both"))
            if kind and name not in info["usage"] and not merged:
                c.execute("INSERT INTO categories(name,kind) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET kind=excluded.kind", (new_name, kind))
            return {"merged": merged, "moved": moved}

    def _follow_category(self, c, name, new_name):
        """Everything that remembers a category by name follows a rename (new_name) or a delete (None): the quick templates,
        the entries hidden from the 記過 list, and the order the overview tiles were dragged into."""
        c.execute("UPDATE templates SET category=? WHERE category=? AND type IN ('income','expense')", (new_name or "", name))
        c.execute("UPDATE recurring SET category=? WHERE category=? AND type IN ('income','expense')", (new_name or "", name))
        hid = []
        for key in self.hidden_frequent(c):
            for typ in ("expense", "income"):
                head = f"{typ}|{name}|"
                if key.startswith(head):
                    key = None if new_name is None else f"{typ}|{new_name}|" + key[len(head):]
                    break
            if key is not None and key not in hid:
                hid.append(key)
        self.set_setting(c, "frequent_hidden", json.dumps(hid, ensure_ascii=False))
        order = self.tile_order(c)
        for kind, names in order.items():
            mapped = [(new_name if n == name else n) for n in names]
            order[kind] = [n for i, n in enumerate(mapped) if n and n not in mapped[:i]]
        self.set_setting(c, "tile_order", json.dumps(order, ensure_ascii=False))

    def delete_category(self, name):
        """Remove a category. Entries that used it are kept and become 未分類."""
        name = str(name or "").strip()
        with self.session(notify=True) as c:
            n = c.execute("UPDATE transactions SET category='未分類', updated_at=? WHERE category=? AND type IN ('income','expense')",
                          (now_iso(), name)).rowcount
            gone = c.execute("DELETE FROM categories WHERE name=?", (name,)).rowcount
            c.execute("DELETE FROM category_icons WHERE category=?", (name,))
            c.execute("DELETE FROM budgets WHERE category=?", (name,))
            self._follow_category(c, name, None)
            if not n and not gone:
                raise BookError("找不到這個類別（可能已被刪除）", 404)
            return {"moved": n}

    def _remember_picture(self, c, icon):
        if icon.startswith("data:image/"):
            c.execute("INSERT OR IGNORE INTO icon_library(icon, added_at) VALUES(?,?)", (icon, now_iso()))
            c.execute("DELETE FROM icon_library WHERE icon NOT IN (SELECT icon FROM icon_library ORDER BY added_at DESC, rowid DESC LIMIT ?)", (MAX_LIBRARY,))

    def icon_library(self, conn):
        """Pictures the user has uploaded before, newest first."""
        return [r[0] for r in conn.execute("SELECT icon FROM icon_library ORDER BY added_at DESC, rowid DESC")]

    def add_library_icon(self, icon):
        icon, _ = self._clean_icon(icon, "")
        if not icon.startswith("data:image/"):
            raise BookError("只能保存上傳的圖片")
        with self.session(notify=True) as c:
            self._remember_picture(c, icon)

    def remove_library_icon(self, icon):
        with self.session(notify=True) as c:
            c.execute("DELETE FROM icon_library WHERE icon=?", (str(icon or ""),))

    def category_icons(self, conn):
        """Icons the user chose: {category: {"icon": emoji or "", "color": "#RRGGBB" or ""}}. Everything else is picked
        automatically by the screen from the category's name, so the same category always shares one icon."""
        return {r["category"]: {"icon": r["icon"], "color": r["color"]}
                for r in conn.execute("SELECT category, icon, color FROM category_icons")}

    def set_category_icon(self, category, icon="", color=""):
        category = str(category or "").strip()
        if not category or len(category) > 60:
            raise BookError("找不到這個類別")
        icon, color = self._clean_icon(icon, color)
        with self.session(notify=True) as c:
            if not icon and not color:
                c.execute("DELETE FROM category_icons WHERE category=?", (category,))
            else:
                c.execute("INSERT INTO category_icons(category,icon,color) VALUES(?,?,?) "
                          "ON CONFLICT(category) DO UPDATE SET icon=excluded.icon, color=excluded.color", (category, icon, color))
                self._remember_picture(c, icon)

    def years(self, conn):
        ys = {int(r[0]) for r in conn.execute("SELECT DISTINCT substr(time,1,4) FROM transactions")}
        ys.add(datetime.now().year)
        return sorted(ys, reverse=True)

    # ------------------------------------------------------------- summary
    def summary(self, conn):
        base = self.base_currency(conn)
        accounts = self.list_accounts(conn)
        active = [a for a in accounts if not a["archived"] or a["balance"]]
        total = Decimal(0)
        by_ccy = {}
        missing = set()
        for a in active:
            by_ccy[a["currency"]] = by_ccy.get(a["currency"], Decimal(0)) + Decimal(str(a["balance"]))
            if a["base_value"] is None:
                missing.add(a["currency"])
            else:
                total += Decimal(str(a["base_value"]))
        now = datetime.now()
        prefix = f"{now.year:04d}-{now.month:02d}"
        rates = self.get_rates(conn)
        rows, _, accts = self.ledger(conn)
        inc = exp = Decimal(0)
        with_tr = self.count_transfers(conn)
        n_transfer = 0
        spent = {}                                          # category -> this month's expense (budgets count real spending only)
        for f in self.flows(rows, accts, with_tr):
            if f["time"][:7] != prefix:
                continue
            ccy = f["ccy"]
            if ccy not in rates:
                missing.add(ccy)
                continue
            v = money.to_major(f["minor"], ccy) * rates[ccy]
            if f["type"] == "income":
                inc += v
            else:
                exp += v
                if not f.get("transfer") and not f.get("no_budget"):
                    spent[f["category"]] = spent.get(f["category"], Decimal(0)) + v
            n_transfer += bool(f.get("transfer")) and f["type"] == "expense"
        budgets = []
        for cat, limit in self.budgets(conn).items():
            used = spent.get(cat, Decimal(0))
            budgets.append({"category": cat, "limit": limit, "spent": float(used), "ratio": float(used / Decimal(str(limit))) if limit else 0})
        budgets.sort(key=lambda b: (-b["ratio"], b["category"]))
        return {
            "base": base, "total": float(total),
            "by_currency": [{"currency": k, "balance": float(v)} for k, v in sorted(by_ccy.items())],
            "month": {"label": prefix, "income": float(inc), "expense": float(exp), "with_transfers": with_tr, "transfers": n_transfer},
            "missing_rates": sorted(missing), "budgets": budgets,
        }

    # ------------------------------------------------------ export / sheets
    def balance_table(self, conn):
        """Same shape as the notebook's transactions_balances.csv, plus currency/to_amount."""
        rows, _, accts = self.ledger(conn, snapshots=True)
        base = self.base_currency(conn)
        rates = self.get_rates(conn)
        ordered = sorted(accts.values(), key=lambda a: a["id"])
        names = [a["name"] for a in ordered]
        headers = ["time", "type", "category", "amount", "note", "account", "prev_balance", "new_balance"] \
            + names + ["total_amount", "currency", "to_amount"]
        base_exp = money.exponent(base)
        out = []
        for r in rows:
            a = accts[r["account_id"]]
            ccy = a["currency"]
            if r["type"] == "transfer":
                t = accts[r["to_account_id"]]
                account = f"{a['name']}->{t['name']}"
                prev = new = ""
                to_amt = money.from_minor(r["to_amount_minor"], t["currency"])
            else:
                account, to_amt = a["name"], ""
                prev, new = money.from_minor(r["prev_minor"], ccy), money.from_minor(r["new_minor"], ccy)
            total = Decimal(0)
            for acc in ordered:
                if acc["currency"] in rates:
                    total += money.to_major(r["snap"][acc["id"]], acc["currency"]) * rates[acc["currency"]]
            row = [r["time"], r["type"], r["category"], money.from_minor(r["amount_minor"], ccy),
                   r["note"], account, prev, new]
            row += [money.from_minor(r["snap"][acc["id"]], acc["currency"]) for acc in ordered]
            row += [float(total.quantize(Decimal(1).scaleb(-base_exp), rounding=ROUND_HALF_UP)), ccy, to_amt]
            out.append(row)
        return headers, out

    # -------------------------------------------------------------- backup
    def backup(self, reason="manual"):
        with self._lock:
            return db.make_backup(self.db_path, self.backup_dir, reason)

    def list_backups(self):
        if not self.backup_dir.exists():
            return []
        items = []
        for p in sorted(self.backup_dir.iterdir(), reverse=True):
            if db.BACKUP_RE.match(p.name):
                st = p.stat()
                items.append({"name": p.name, "size": st.st_size,
                              "time": datetime.fromtimestamp(st.st_mtime).replace(microsecond=0).isoformat()})
        return items

    def client_op(self, cid):
        """The transaction a phone already sent under this id (an entry made offline is sent again until it is acknowledged)."""
        with self.session() as c:
            r = c.execute("SELECT tx_id FROM client_ops WHERE cid=?", (cid,)).fetchone()
            if r and c.execute("SELECT 1 FROM transactions WHERE id=?", (r["tx_id"],)).fetchone():
                return r["tx_id"]
            return None

    def remember_client_op(self, cid, tx_id):
        with self.session(quiet=True) as c:
            c.execute("INSERT OR REPLACE INTO client_ops(cid,tx_id,at) VALUES(?,?,?)", (cid, tx_id, now_iso()))
            c.execute("DELETE FROM client_ops WHERE at < ?", ((datetime.now() - timedelta(days=45)).replace(microsecond=0).isoformat(),))

    def onboarding_needed(self, conn):
        """A brand-new book that has not been through the first-start setup yet (nothing recorded, never dismissed)."""
        if self.get_setting(conn, "onboarded") is not None:
            return False
        return conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0] == 0

    def mark_onboarded(self):
        with self.session() as c:
            self.set_setting(c, "onboarded", "1")

    def last_import_backup(self):
        """The newest backup taken right before an import (list_backups is newest first), or None."""
        for b in self.list_backups():
            if "-beforeimport" in b["name"]:
                return b
        return None

    def delete_backups(self, names):
        """Delete backup files the user picked (by name). Only files that look like our own backups are ever touched."""
        if not isinstance(names, list) or not names or len(names) > 500:
            raise BookError("請選擇要刪除的備份")
        deleted = 0
        with self._lock:
            for name in dict.fromkeys(str(n or "") for n in names):
                if not db.BACKUP_RE.match(name):
                    raise BookError("備份檔名不正確")
                f = self.backup_dir / name
                if f.is_file():
                    f.unlink()
                    deleted += 1
        if not deleted:
            raise BookError("找不到這些備份（可能已被刪除）", 404)
        return deleted

    def restore_backup(self, name):
        if not db.BACKUP_RE.match(str(name or "")):
            raise BookError("備份檔名不正確")
        src = self.backup_dir / name
        if not src.exists():
            raise BookError("找不到這個備份", 404)
        if not db.is_valid_book(src):
            raise BookError("這個備份檔已損毀，無法還原")
        with self._lock:
            db.make_backup(self.db_path, self.backup_dir, "beforerestore")
            db.replace_file(src, self.db_path)
            conn = db.connect(self.db_path)          # an older backup may predate newer tables
            try:
                db.init_db(conn)
                conn.commit()
            finally:
                conn.close()
        self._notify()
