@echo off
REM Starts Tallomi quietly (used by the shortcuts). The console window hides itself once the app is up.
REM If anything is wrong, it opens run_dev.bat in a normal window so the real error is visible.
pushd "%~dp0"
if not exist ".venv\Scripts\python.exe" goto :full
".venv\Scripts\python.exe" run.py --hide-console
if errorlevel 1 goto :full
exit /b 0

:full
start "Tallomi setup" "%~dp0run_dev.bat"
exit /b 0
