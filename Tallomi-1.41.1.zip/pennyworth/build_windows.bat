@echo off
REM Build Tallomi as a real Windows program and install it for the current user.
REM Needs Python 3.12 or 3.13 on this PC (the built program itself needs no Python).
REM Result: %LOCALAPPDATA%\Programs\Pennyworth\Pennyworth.exe + desktop and Start-menu shortcuts.
setlocal
pushd "%~dp0"
set "HERE=%~dp0"
set "PSHERE=%HERE:'=''%"
set "PY=%HERE%.venv\Scripts\python.exe"

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Recurse -Force -LiteralPath '%PSHERE%' | Unblock-File" >nul 2>&1

where py >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3.12 or 3.13 from https://www.python.org/downloads/
  pause
  exit /b 1
)

set "STEP=creating the virtual environment"
if exist .venv\Scripts\python.exe (
  .venv\Scripts\python.exe -c "import sys" >nul 2>&1
  if errorlevel 1 rmdir /s /q .venv
)
if not exist .venv\Scripts\python.exe (
  py -3 -m venv .venv
  if errorlevel 1 goto :fail
)

set "STEP=installing build tools"
echo Installing build tools (a few minutes the first time)...
"%PY%" -m pip install --disable-pip-version-check --no-cache-dir --upgrade pip > build_pip.log 2>&1
"%PY%" -m pip install --disable-pip-version-check --no-cache-dir -r requirements-dev.txt >> build_pip.log 2>&1
if errorlevel 1 (
  type build_pip.log
  goto :fail
)
"%PY%" -m pip install --disable-pip-version-check --no-cache-dir -r requirements-window.txt >> build_pip.log 2>&1
if errorlevel 1 echo [info] Native window support could not be installed. The program will open in your browser instead.

set "STEP=running the tests"
echo.
echo === Running tests ===
"%PY%" -m pytest -q tests
if errorlevel 1 goto :fail

set "STEP=building the program"
echo.
echo === Building the program ===
"%PY%" -m PyInstaller --noconfirm --clean --windowed --name Pennyworth ^
  --icon "assets\pennyworth.ico" ^
  --add-data "app\static;app\static" ^
  --collect-submodules google.auth --collect-submodules google.oauth2 ^
  --collect-submodules webview ^
  run.py > build_pyinstaller.log 2>&1
if errorlevel 1 (
  type build_pyinstaller.log
  goto :fail
)

set "STEP=installing the program and shortcuts"
echo.
echo === Installing ===
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_exe.ps1"
if errorlevel 1 goto :fail

echo.
echo Done. "Tallomi" is on your desktop and in the Start menu.
echo To pin it to the taskbar: right-click it ^> Show more options ^> Pin to taskbar.
pause
exit /b 0

:fail
echo.
echo ===== Something went wrong while %STEP% =====
"%PY%" --version 2>&1
echo Log files in this folder: build_pip.log, build_pyinstaller.log
echo.
echo If the messages mention "Device Guard" / "App Control" / "blocked by your organization",
echo this PC does not allow unsigned programs. Use create_shortcut.bat instead (no exe needed).
echo Please copy ALL the messages above and send them over.
pause
exit /b 1
