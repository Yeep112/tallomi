@echo off
REM Optional: also read the bank rates twice a day when Tallomi is not open.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\schedule_rates.ps1"
if errorlevel 1 (
  echo.
  echo Could not create the scheduled tasks. Please copy the messages above and send them over.
)
pause
