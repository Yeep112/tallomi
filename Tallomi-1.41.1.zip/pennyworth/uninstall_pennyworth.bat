@echo off
REM Copies the real uninstaller to %TEMP% first, because it deletes this very folder.
copy /y "%~dp0tools\uninstall.ps1" "%TEMP%\pennyworth_uninstall.ps1" >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\pennyworth_uninstall.ps1" -InstallDir "%~dp0."
if errorlevel 1 pause
exit /b 0
