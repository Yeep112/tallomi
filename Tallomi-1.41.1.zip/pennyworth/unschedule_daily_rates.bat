@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\schedule_rates.ps1" -Remove
pause
