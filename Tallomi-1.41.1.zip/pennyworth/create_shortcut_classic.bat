@echo off
REM Fallback if this PC blocks wscript.exe: shortcuts that go through cmd.exe instead.
call "%~dp0create_shortcut.bat" -Classic
