"""Paths and constants shared by the whole app."""
import json
import os
from pathlib import Path

APP_NAME = "Tallomi"
DATA_DIR_NAME = "Pennyworth"      # the folder of the books keeps its first name: renaming it would hide everybody's data
VERSION = "1.67.1"
OWNER_UI_COLOR = "#E6E6FA"        # 薰衣草紫: only the owner's own book starts with this
PUBLIC_UI_COLOR = "#ECEEF0"       # 霧灰: what everybody else starts with
FEEDBACK_URL = os.environ.get("PENNYWORTH_FEEDBACK_URL") or "https://docs.google.com/forms/d/e/1FAIpQLSfdnU3eAuRQWsQNpj7djQlSnrEJ3VQOYxD9h1Oq6FWKNxgLsw/viewform"     # public Google Form (fill-in link only)
DEFAULT_BASE_CURRENCY = "TWD"

def _base_path() -> Path:
    """The folder holding everything of this installation (no side effects). Windows: %APPDATA%\\Pennyworth"""
    env = os.environ.get("PENNYWORTH_DATA_DIR")
    if env:
        return Path(env)
    if os.name == "nt":
        return Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming") / DATA_DIR_NAME
    return Path.home() / ".pennyworth"


PROFILE_FILE = Path(__file__).with_name("owner_profile.json")
# Only the owner's own copy has the private profile. Only that copy can switch to the "as another person sees it" preview.
HAS_PROFILE = PROFILE_FILE.exists() and not os.environ.get("PENNYWORTH_NO_OWNER_PROFILE")
MODE_FILE = "mode.txt"
PREVIEW_DIR = "public_preview"           # the preview's own book: a sub-folder, completely apart from the owner's book


def _read_mode():
    if not HAS_PROFILE:
        return "owner"
    try:
        return "public" if (_base_path() / MODE_FILE).read_text(encoding="utf-8-sig").strip() == "public" else "owner"
    except OSError:
        return "owner"


MODE = _read_mode()                      # "owner" = my own book, "public" = the empty book other people start with (preview)


def default_ui_color():
    """Interface colour of a book that never picked one. Evaluated at call time (MODE is known by then)."""
    return OWNER_UI_COLOR if (HAS_PROFILE and MODE == "owner") else PUBLIC_UI_COLOR


def _load_owner_profile():
    """The owner's private defaults (own sheet, balances, holdings). The file only exists in the owner's own copy;
    builds for other people never contain it, so everybody else starts from an empty book with just Cash.
    In the preview mode it is deliberately not read, so the preview looks exactly like a stranger's first start."""
    if not HAS_PROFILE or MODE != "owner":
        return {}
    try:
        with open(PROFILE_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


OWNER = _load_owner_profile()

# 預設要同步的 Google 試算表。一般使用者是空白，由首次設定精靈或設定頁填入；只是試算表 ID，不含任何金鑰。
DEFAULT_SHEET_KEY = OWNER.get("sheet_key", "")

# 新帳本只有一個 Cash（餘額 0），其他帳戶由使用者自己新增。
# INITIAL_AMOUNTS：「清除所有交易」時各帳戶回到的期初金額（單位 TWD）；一般使用者是空的。
INITIAL_AMOUNTS = dict(OWNER.get("initial_amounts", {}))

# 換匯頁面支援的銀行：帳戶名稱 → 銀行中文名（帳戶名稱以此開頭，就視為該銀行的帳戶）
BANKS = {
    "Cube Bank": "國泰世華",
    "Fuban Bank": "富邦",
    "Sinopac Bank": "永豐",
    "CTBC Bank": "中信",
}

# 各銀行官網的外幣牌告匯率頁（換匯頁的「抓取目前匯率」會讀這些網址）
BANK_RATE_URLS = {
    "Cube Bank": "https://www.cathaybk.com.tw/cathaybk/personal/product/deposit/currency-billboard/",
    "Fuban Bank": "https://www.fubon.com/banking/personal/deposit/exchange_rate/exchange_rate_tw.htm",
    "Sinopac Bank": "https://bank.sinopac.com/MMA8/bank/html/rate/bank_ExchangeRate.html",
    "CTBC Bank": "https://www.ctbcbank.com/twrbo/zh_tw/dep_index/dep_ratequery/dep_foreign_rates.html",
}

DEFAULT_ACCOUNTS = list(OWNER.get("accounts") or ["Cash"])

# 投資頁：帳戶名稱 → (股票代號, 名稱, 市場)。帳戶名稱符合就自動歸為該股票的投資帳戶。
SECURITY_PRESETS = {
    "TSMC": ("2330", "台積電", "TW"),
    "0050": ("0050", "元大台灣50", "TW"),
    "0056": ("0056", "元大高股息", "TW"),
    "UMC": ("2303", "聯電", "TW"),
    "NVDA": ("NVDA", "NVIDIA 輝達", "US"),
}
MARKET_CURRENCY = {"TW": "TWD", "US": "USD"}

# 現有持股只存在於擁有者自己的設定檔（只對「還沒有任何買賣紀錄」的股票帳戶生效，不會動到任何帳戶餘額）。
# 每個股票：{"price": 單價, "lots": [[日期, 股數, 券商單價或 null, 付出成本], ...]}
HOLDINGS_AS_OF = OWNER.get("holdings_as_of", "")
INITIAL_HOLDINGS = dict(OWNER.get("holdings", {}))
# 台股預設手續費 0.1425%（可打折，買賣表單可逐筆修改）；證交稅：一般股票 0.3%、ETF 0.1%
TW_FEE_RATE = "0.001425"
TW_TAX_STOCK = "0.003"
TW_TAX_ETF = "0.001"

DEFAULT_CATEGORIES = [
    "food", "transport", "shopping", "housing", "utilities",
    "entertainment", "health", "education", "salary", "investment", "other",
]

COMMON_CURRENCIES = [
    "TWD", "USD", "JPY", "EUR", "CNY", "HKD", "KRW", "GBP", "AUD", "CAD",
    "SGD", "CHF", "THB", "VND", "MYR", "NZD",
]

STATIC_DIR = Path(__file__).resolve().parent / "static"
PROGRAM_DIR = Path(__file__).resolve().parents[1]           # the folder with run.py

# Software updates (people other than the owner). The program asks this address for a small signed list of versions.
# Everything is checked against the public key in update_pubkey.txt before it is used; the private key stays with the owner.
UPDATE_URL = os.environ.get("PENNYWORTH_UPDATE_URL") or "https://yeep112.github.io/tallomi/"
UPDATE_PUBKEY_FILE = Path(__file__).with_name("update_pubkey.txt")


def update_pubkey():
    try:
        v = UPDATE_PUBKEY_FILE.read_text(encoding="ascii").strip()
        return bytes.fromhex(v) if len(v) == 64 else None
    except (OSError, ValueError):
        return None


# The phone version runs inside the phone's browser (Pyodide). There is no computer behind it: no windows, folders, tray, shutdown,
# Google Sheets sync or self-replacing program files, and the book lives in the browser's own storage.
PHONE = os.environ.get("PENNYWORTH_PHONE") == "1"
# 1.63.0 — the owner's phone keeps a working copy of the book (see app/localcopy.py) and runs this same program on it while the computer is not
# running. That copy must not do the computer's own housekeeping (recurring entries come due on the computer, not twice).
LOCAL_COPY = os.environ.get("PENNYWORTH_LOCAL_COPY") == "1"
LOCAL_RECURRING = os.environ.get("PENNYWORTH_LOCAL_RECURRING") == "1"      # the phone's copy records the entries that come due while the computer is away (the computer records its own again when it is back: same dates, so nothing is doubled)


def updates_enabled():
    """Only the copies for other people update themselves; the owner's own copy is replaced by hand."""
    if PHONE:                                    # the phone version is refreshed by its service worker, not by this updater
        return False
    if os.environ.get("PENNYWORTH_UPDATES") == "1":
        return update_pubkey() is not None
    return (not HAS_PROFILE) and update_pubkey() is not None


def data_dir() -> Path:
    """The installation folder (settings that belong to the program: shortcut location, log, window profile, mode)."""
    p = _base_path()
    p.mkdir(parents=True, exist_ok=True)
    return p


def book_dir() -> Path:
    """The folder of the book that is open: the owner's own, or in preview mode the separate empty one."""
    base = data_dir()
    if MODE != "public":
        return base
    p = base / PREVIEW_DIR
    flag = base / "preview_reset.flag"
    if flag.exists():                                      # "start over as a new user": only ever clears the preview's own folder
        import shutil
        shutil.rmtree(p, ignore_errors=True)
        flag.unlink(missing_ok=True)
    p.mkdir(parents=True, exist_ok=True)
    return p


def set_mode(mode, reset=False):
    """Remember which book to open next time (takes effect after a restart). Needs the owner's profile file."""
    if not HAS_PROFILE:
        raise ValueError("這份程式沒有切換功能")
    if mode not in ("owner", "public"):
        raise ValueError("未知的模式")
    base = data_dir()
    (base / MODE_FILE).write_text(mode, encoding="utf-8")
    flag = base / "preview_reset.flag"
    if mode == "public" and reset:
        flag.write_text("1", encoding="utf-8")
    elif mode == "owner":
        flag.unlink(missing_ok=True)
