"""Phone-layout audit: opens every page (and the dialogs each page offers) at several phone widths and reports layout problems.

    python tools/mobile_audit.py [--shots DIR] [--widths 320 360 390 430]

What it flags (per page / dialog / width):
  - sideways scroll of the whole page
  - an element sticking out past the screen edge (outside a deliberate scroll strip)
  - a tap target (button, link-button, box, select) under 30 px
  - text smaller than 10 px
  - text cut off by a box that hides its overflow without an ellipsis
  - a dialog taller than the screen with no way to scroll it

A tap target is flagged under 30 px tall / 28 px wide (a checkbox counts the label or cell it sits in).
Exit code 0 = nothing found. Needs playwright + chromium; the pytest wrapper skips itself when they are missing.
Runs against a throw-away data folder filled with made-up data, never the real book.
"""
import argparse
import logging
import os
import sys
import tempfile
import threading
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
H = {"X-Pennyworth": "1"}
ROUTES = ["overview", "calendar", "advances", "transactions", "exchange", "invest", "accounts", "reports", "categories", "tags", "settings"]
DANGER = ("刪除", "清除", "重置", "結束", "登出", "鎖定", "全部", "歸零", "還原", "關閉程式", "解除", "移除")
OPENERS = ("新增", "記一筆", "記帳", "編輯", "校正", "分帳", "匯入", "匯出", "管理", "新建", "買進", "賣出", "買賣", "轉帳", "範本", "定期", "設定", "＋", "+", "收款", "調整", "篩選", "換匯", "加")


def seed(app):
    c = app.test_client()
    c.put("/api/settings", json={"onboarded": True}, headers=H)
    acc = {}
    for name, cur, op in [("現金", "TWD", "8000"), ("玉山銀行活期存款帳戶", "TWD", "186000"), ("國泰世華 Cube 信用卡", "TWD", "-12000"),
                          ("Wise 美元", "USD", "2400"), ("日圓零用錢", "JPY", "52000")]:
        r = c.post("/api/accounts", json={"name": name, "currency": cur, "opening": op}, headers=H)
        acc[name] = r.get_json().get("id")
    state = c.get("/api/state", headers=H).get_json()
    A = {a["name"]: a["id"] for a in state["accounts"]}
    c.put("/api/rates", json={"USD": "32.1", "JPY": "0.215"}, headers=H)
    today = date.today()
    notes = ["午餐", "超長的備註文字用來測試換行與截斷是不是會把版面撐破掉的情況 abcdefghijklmnopqrstuvwxyz0123456789",
             "捷運悠遊卡儲值", "咖啡", "房租", "薪資入帳", "網購：機械鍵盤與滑鼠墊與螢幕掛燈", "停車費"]
    cats = ["餐飲", "交通", "購物", "娛樂", "居住", "其他"]
    for i in range(36):
        d = today - timedelta(days=i % 27)
        kind = "income" if i % 9 == 0 else "expense"
        c.post("/api/transactions", json={"type": kind, "amount": str(80 + i * 37), "account_id": A["玉山銀行活期存款帳戶"] if i % 3 else A["現金"],
                                          "category": "薪水" if kind == "income" else cats[i % len(cats)], "note": notes[i % len(notes)],
                                          "tags": "日本旅行,報帳" if i % 4 == 0 else "", "time": d.isoformat() + f"T{8 + i % 12:02d}:{(i * 7) % 60:02d}"}, headers=H)
    c.post("/api/transactions", json={"type": "transfer", "amount": "3000", "account_id": A["玉山銀行活期存款帳戶"], "to_account_id": A["現金"],
                                      "note": "提款", "time": today.isoformat() + "T09:00"}, headers=H)
    c.post("/api/transactions", json={"type": "expense", "amount": "700", "account_id": A["日圓零用錢"], "category": "餐飲", "note": "拉麵",
                                      "time": today.isoformat() + "T12:00"}, headers=H)
    c.post("/api/bills", json={"title": "週末聚餐", "account_id": A["玉山銀行活期存款帳戶"], "mine": {"amount": "450", "category": "餐飲"},
                               "shares": [{"name": "小明", "amount": "500", "due": (today + timedelta(days=5)).isoformat()}, {"name": "阿華", "amount": "700"}]}, headers=H)
    c.post("/api/recurring", json={"type": "expense", "account_id": A["玉山銀行活期存款帳戶"], "amount": "15000", "category": "居住", "note": "房租",
                                   "freq": "monthly", "next_due": (today + timedelta(days=9)).isoformat()}, headers=H)
    c.post("/api/templates", json={"name": "早餐", "type": "expense", "account_id": A["現金"], "amount": "65", "category": "餐飲"}, headers=H)
    c.put("/api/budgets", json={"budgets": {"餐飲": "9000", "交通": "2000"}}, headers=H)
    r = c.post("/api/invest/securities", json={"symbol": "2330", "name": "台積電", "market": "TW"}, headers=H)
    st = [a for a in c.get("/api/state", headers=H).get_json()["accounts"] if "2330" in a["name"] or "台積電" in a["name"]]
    if st:
        sid = st[0]["id"]
        c.put("/api/invest/price", json={"symbol": "2330", "price": "980", "source": "manual"}, headers=H)
        for side, sh, px, t in [("buy", 1000, 880, "10-01T10:00"), ("buy", 100, 910, "10-05T10:00"), ("sell", 50, 960, "10-20T10:00")]:
            c.post("/api/invest/trades", json={"account_id": sid, "side": side, "shares": str(sh), "price": str(px), "fee": "20",
                                               "tax": "0" if side == "buy" else "30", "pay_account_id": A["玉山銀行活期存款帳戶"], "time": f"{today.year}-{t}"}, headers=H)
    return A


JS_METRICS = r"""
(scope) => {
  const root = scope ? document.querySelector(scope) : document.body;
  const W = document.documentElement.clientWidth, out = [];
  if (!root) return { W, sw: document.documentElement.scrollWidth, items: [] };
  const vis = (e) => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
  const label = (e) => (e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (typeof e.className === 'string' && e.className.trim() ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '') + ' "' + (e.innerText || e.value || e.getAttribute('aria-label') || '').trim().slice(0, 16).replace(/\n/g, ' ') + '"');
  const inStrip = (e) => { for (let p = e.parentElement; p && p !== document.body; p = p.parentElement) { const s = getComputedStyle(p); if (/(auto|scroll)/.test(s.overflowX) && p.scrollWidth > p.clientWidth + 1) return true; } return false; };
  const all = [...root.querySelectorAll('*')].filter(vis);
  for (const e of all) {
    const r = e.getBoundingClientRect(), s = getComputedStyle(e);
    if (e.closest('svg') && e.tagName !== 'svg') continue;
    if ((r.right > W + 1 || r.left < -1) && !inStrip(e) && s.position !== 'fixed' && !e.closest('.nav, .toast, canvas')) out.push(['out', label(e), Math.round(r.left) + '..' + Math.round(r.right)]);
    if (/^(BUTTON|A|SELECT|SUMMARY)$/.test(e.tagName) || (e.tagName === 'INPUT' && /checkbox|radio|button|submit/.test(e.type)) || e.getAttribute('role') === 'button') {
      if (e.tagName === 'A' && !e.classList.contains('btn') && !e.closest('.nav, .tab, .chip')) continue;
      let hh = Math.round(r.height), ww = Math.round(r.width);
      if (e.tagName === 'INPUT') { const box = e.closest('label, td, .c-sel, .field'); if (box) { const br = box.getBoundingClientRect(); hh = Math.max(hh, Math.round(br.height)); ww = Math.max(ww, Math.round(br.width)); } }
      const af = getComputedStyle(e, '::after'); if (af.content !== 'none' && af.position === 'absolute') { hh = Math.max(hh, parseFloat(af.height) || 0); ww = Math.max(ww, parseFloat(af.width) || 0); }
      if (hh < 30 || ww < 28) out.push(['tap', label(e), ww + 'x' + hh]);
    }
    if (e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())) {
      const fs = parseFloat(s.fontSize); if (fs < 10) out.push(['font', label(e), fs + 'px']);
    }
    if (/(hidden|clip)/.test(s.overflowX) && e.scrollWidth > e.clientWidth + 2 && s.textOverflow !== 'ellipsis' && !e.closest('svg') && e.clientWidth > 0 && !/^(BODY|HTML)$/.test(e.tagName) && s.position !== 'fixed' && !e.matches('.cal-grid, .cal-cell, .cal-day') ) out.push(['clip', label(e), e.scrollWidth + '>' + e.clientWidth]);
  }
  return { W, sw: document.documentElement.scrollWidth, items: out };
}
"""


def run(widths=(320, 360, 390, 430), shots=None, routes=ROUTES, max_dialogs=7, log=print):
    os.environ["PENNYWORTH_DATA_DIR"] = tempfile.mkdtemp()
    os.environ["PENNYWORTH_NO_OWNER_PROFILE"] = "1"
    sys.path.insert(0, str(ROOT))
    from werkzeug.serving import make_server
    from app import server
    from playwright.sync_api import sync_playwright
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    app = server.create_app()
    seed(app)
    srv = make_server("127.0.0.1", 0, app, threaded=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_port}/"
    found = []                                       # (width, where, kind, element, detail)
    if shots:
        Path(shots).mkdir(parents=True, exist_ok=True)

    def add(w, where, m):
        if m["sw"] > m["W"] + 1:
            found.append((w, where, "page-scroll", "document", f'{m["sw"]}>{m["W"]}'))
        seen = set()
        for kind, el, det in m["items"]:
            if (kind, el) in seen:
                continue
            seen.add((kind, el)); found.append((w, where, kind, el, det))

    with sync_playwright() as p:
        b = p.chromium.launch()
        for w in widths:
            ctx = b.new_context(viewport={"width": w, "height": 780 if w < 400 else 844}, has_touch=True, is_mobile=True, device_scale_factor=2)
            pg = ctx.new_page()
            errs = []
            pg.on("pageerror", lambda e: errs.append(str(e)))
            for r in routes:
                pg.goto(url + f"#/{r}"); pg.wait_for_selector("#view > *", timeout=15000); pg.wait_for_timeout(500)
                pg.evaluate("window.scrollTo(0,0)")
                add(w, r, pg.evaluate(JS_METRICS, "#view"))
                nav = pg.evaluate(JS_METRICS, ".nav")
                add(w, "tabbar", {"W": nav["W"], "sw": 0, "items": [i for i in nav["items"] if i[0] in ("tap", "font")]}) if r == routes[0] else None
                if shots:
                    pg.screenshot(path=f"{shots}/{w}_{r}.png", full_page=True)
                # open the dialogs this page offers, one by one
                names = pg.evaluate("""(args) => { const [op, dg] = args; const seen = new Set(), out = [];
                    for (const b of document.querySelectorAll('#view button, #view a.btn, .side button, .topbar button')) {
                      const t = (b.innerText || b.getAttribute('aria-label') || '').trim(); if (!t || t.length > 14 || seen.has(t)) continue;
                      if (dg.some((d) => t.includes(d))) continue; if (!op.some((o) => t.includes(o))) continue;
                      const r = b.getBoundingClientRect(); if (!r.width || !r.height) continue; seen.add(t); out.push(t); }
                    return out; }""", [list(OPENERS), list(DANGER)])
                for t in names[:max_dialogs]:
                    pg.goto(url + f"#/{r}"); pg.wait_for_selector("#view > *", timeout=15000); pg.wait_for_timeout(350)
                    loc = pg.locator(f"#view button:has-text('{t}'), #view a.btn:has-text('{t}'), .side button:has-text('{t}'), .topbar button:has-text('{t}')").first
                    try:
                        loc.scroll_into_view_if_needed(timeout=2000); loc.click(timeout=2000)
                    except Exception:
                        continue
                    pg.wait_for_timeout(450)
                    if pg.locator("dialog[open]").count() == 0:
                        continue
                    where = f"{r} › {t}"
                    add(w, where, pg.evaluate(JS_METRICS, "dialog[open]"))
                    sc = pg.evaluate("""() => { const d = document.querySelector('dialog[open]'), b = d.querySelector('.dlg-body'), f = d.querySelector('.dlg-foot'), H = innerHeight;
                        const dr = d.getBoundingClientRect(), fr = f ? f.getBoundingClientRect() : null;
                        return { tall: dr.height > H + 1, bodyScroll: b ? getComputedStyle(b).overflowY : '', footVisible: fr ? (fr.bottom <= H + 1 && fr.top >= 0) : true, h: Math.round(dr.height), H }; }""")
                    if sc["tall"] or not sc["footVisible"]:
                        found.append((w, where, "dialog-fit", "dialog", f'h={sc["h"]} screen={sc["H"]} foot-visible={sc["footVisible"]}'))
                    if shots:
                        pg.screenshot(path=f"{shots}/{w}_{r}__{t.replace('/', '-')}.png")
                    pg.keyboard.press("Escape"); pg.wait_for_timeout(150)
                    if pg.locator("dialog[open]").count():
                        pg.evaluate("document.querySelectorAll('dialog[open]').forEach(d=>d.close())")
            for e in errs:
                found.append((w, "console", "js-error", e[:120], ""))
            ctx.close()
        b.close()
    srv.shutdown()
    return found


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shots"); ap.add_argument("--widths", type=int, nargs="*", default=[320, 360, 390, 430])
    ap.add_argument("--routes", nargs="*", default=ROUTES)
    a = ap.parse_args()
    f = run(a.widths, a.shots, a.routes)
    for row in sorted(set(f), key=lambda x: (x[2], x[1], x[0])):
        print("%-4s %-22s %-11s %-60s %s" % row)
    print(f"\n{len(set(f))} finding(s)")
    return 1 if f else 0


if __name__ == "__main__":
    sys.exit(main())
