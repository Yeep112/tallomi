"""Recurring entries: rent, subscriptions, insurance. Set one up once and the program records it by itself on every due day.

How it works
- A rule holds what to record (type / account / amount / category / note / tags) and WHEN: weekly, monthly or yearly, the next day it
  is due (`next_due`) and the day of the month it was meant for (`anchor_day`, so a rule made for the 31st lands on 28 / 29 / 30 in
  short months and goes back to the 31st afterwards).
- `run_recurring` records every occurrence that is due (today or earlier) and moves `next_due` forward, all in ONE database
  transaction, so an entry can never be recorded twice. If the computer was off for a while, the days that were missed are
  recorded too (each with its own date), up to CATCH_UP_CAP per rule per run.
- A rule that cannot be recorded (the account was archived, a rate is missing...) is paused with the reason in `last_error`;
  the overview shows it, and nothing is lost.
- Resuming a paused rule skips the days that passed while it was paused (it does not record a pile of old entries).
"""
import calendar
import time as _time
from datetime import date, timedelta

FREQS = ("weekly", "monthly", "yearly")
FREQ_LABEL = {"weekly": "每週", "monthly": "每月", "yearly": "每年"}
MAX_RECURRING = 40
CATCH_UP_CAP = 60
POST_HOUR = "09:00"                  # recorded entries carry this time of day (the date is the due day)
CHECK_EVERY = 60                     # seconds between two "is anything due?" checks


def _err(msg, status=400):
    from .book import BookError
    return BookError(msg, status)


def parse_day(value, label="日期", allow_empty=False):
    s = str(value or "").strip()
    if not s:
        if allow_empty:
            return None
        raise _err(f"請選擇{label}")
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        raise _err(f"{label}的格式不正確（要像 2026-12-05）") from None


def next_date(d, freq, anchor):
    """The occurrence after `d`."""
    if freq == "weekly":
        return d + timedelta(days=7)
    if freq == "monthly":
        y, m = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
    else:
        y, m = d.year + 1, d.month
    return date(y, m, min(anchor, calendar.monthrange(y, m)[1]))


def first_on_or_after(d, today, freq, anchor):
    """Skip the occurrences before `today` (used when a paused rule is resumed)."""
    n = 0
    while d < today and n < 20000:
        d = next_date(d, freq, anchor)
        n += 1
    return d


class RecurringMixin:
    _recur_checked = (0.0, "")

    # ---------------------------------------------------------------- read
    def recurring(self, conn, today=None):
        today = today or date.today()
        ccy = {r["id"]: r["currency"] for r in conn.execute("SELECT id, currency FROM accounts")}
        names = {r["id"]: r["name"] for r in conn.execute("SELECT id, name FROM accounts")}
        out = []
        for r in conn.execute("SELECT * FROM recurring ORDER BY active DESC, next_due, id"):
            ended = bool(r["end_date"]) and r["next_due"] > r["end_date"]
            status = "error" if r["last_error"] else "ended" if ended else "active" if r["active"] else "paused"
            out.append({"id": r["id"], "name": r["name"], "type": r["type"], "category": r["category"], "note": r["note"], "amount": r["amount"],
                        "account_id": r["account_id"], "to_account_id": r["to_account_id"], "account": names.get(r["account_id"], ""),
                        "to_account": names.get(r["to_account_id"], ""), "currency": ccy.get(r["account_id"], ""), "tags": r["tags"],
                        "no_budget": bool(r["no_budget"]), "no_stats": bool(r["no_stats"]), "freq": r["freq"], "anchor_day": r["anchor_day"],
                        "next_due": r["next_due"], "end_date": r["end_date"], "active": bool(r["active"]), "last_posted": r["last_posted"],
                        "last_error": r["last_error"], "status": status})
        return out

    def recurring_alerts(self, conn):
        """Rules that stopped because they could not be recorded: [{id, name, error}]."""
        return [{"id": r["id"], "name": r["name"], "error": r["last_error"]}
                for r in conn.execute("SELECT id, name, last_error FROM recurring WHERE last_error != '' ORDER BY id")]

    # --------------------------------------------------------------- write
    def _clean_recurring(self, c, p):
        from .book import TX_TYPES
        typ = p.get("type")
        if typ not in TX_TYPES:
            raise _err("定期交易的類型必須是 支出、收入 或 轉帳")
        freq = p.get("freq")
        if freq not in FREQS:
            raise _err("請選擇重複的頻率（每週、每月或每年）")
        due = parse_day(p.get("next_due") or date.today().isoformat(), "下一次入帳日")
        end = parse_day(p.get("end_date"), "結束日", allow_empty=True)
        if end and end < due:
            raise _err("結束日不能早於下一次入帳日")
        try:
            anchor = int(p.get("anchor_day") or due.day)
        except (TypeError, ValueError):
            anchor = due.day
        anchor = anchor if 1 <= anchor <= 31 else due.day
        amount = str(p.get("amount") or "").replace(",", "").strip()
        category = "" if typ == "transfer" else str(p.get("category") or "").strip()[:60]
        note = str(p.get("note") or "").strip()[:500]
        tags = " ".join(self.clean_tags(p.get("tags") or ""))
        flags = (1 if p.get("no_budget") else 0, 1 if p.get("no_stats") else 0)
        # try it once without saving: a rule that could never be recorded is refused now, with the reason
        probe = self._normalize_tx(c, {"type": typ, "time": f"{due.isoformat()}T{POST_HOUR}", "account_id": p.get("account_id"),
                                       "to_account_id": p.get("to_account_id"), "amount": amount, "category": category, "note": note})
        name = " ".join(str(p.get("name") or "").split())[:30] or (note or category or {"expense": "支出", "income": "收入", "transfer": "轉帳"}[typ])[:30]
        return dict(name=name, type=typ, category=probe["category"] if typ != "transfer" else "", note=note, amount=amount, account_id=probe["account_id"],
                    to_account_id=probe["to_account_id"], tags=tags, no_budget=flags[0], no_stats=flags[1], freq=freq, anchor_day=anchor,
                    next_due=due.isoformat(), end_date=end.isoformat() if end else "")

    def save_recurring(self, p, rid=None):
        """Create (or, with rid, replace) a rule, then record whatever is already due. -> {"id", "posted"}."""
        from .timeutil import now_iso
        with self.session(notify=True) as c:
            v = self._clean_recurring(c, p)
            if rid is None:
                if c.execute("SELECT COUNT(*) FROM recurring").fetchone()[0] >= MAX_RECURRING:
                    raise _err(f"定期交易最多 {MAX_RECURRING} 個，請先刪掉不用的")
                cols = ", ".join(v)
                rid = c.execute(f"INSERT INTO recurring({cols}, active, last_posted, last_error, created_at) VALUES({', '.join('?' * len(v))}, 1, '', '', ?)",
                                (*v.values(), now_iso())).lastrowid
            else:
                if not c.execute("SELECT 1 FROM recurring WHERE id=?", (rid,)).fetchone():
                    raise _err("找不到這個定期交易", 404)
                sets = ", ".join(f"{k}=?" for k in v)
                c.execute(f"UPDATE recurring SET {sets}, active=CASE WHEN last_error != '' THEN 1 ELSE active END, last_error='' WHERE id=?", (*v.values(), rid))
        return {"id": rid, "posted": self.run_recurring()}

    def set_recurring_active(self, rid, on):
        with self.session(notify=True) as c:
            r = c.execute("SELECT * FROM recurring WHERE id=?", (rid,)).fetchone()
            if not r:
                raise _err("找不到這個定期交易", 404)
            if on:                                          # days that passed while it was paused are skipped, not recorded
                nxt = first_on_or_after(date.fromisoformat(r["next_due"]), date.today(), r["freq"], r["anchor_day"])
                c.execute("UPDATE recurring SET active=1, last_error='', next_due=? WHERE id=?", (nxt.isoformat(), rid))
            else:
                c.execute("UPDATE recurring SET active=0 WHERE id=?", (rid,))
        return {"posted": self.run_recurring() if on else 0}

    def delete_recurring(self, rid):
        with self.session(notify=True) as c:
            if not c.execute("DELETE FROM recurring WHERE id=?", (rid,)).rowcount:
                raise _err("找不到這個定期交易", 404)

    # ----------------------------------------------------------- recording
    def run_recurring(self, today=None):
        """Record every occurrence that is due (today or earlier). -> how many entries were recorded."""
        today = today or date.today()
        with self.session() as c:                           # a quick look first: nothing due means nothing is written
            if not c.execute("SELECT 1 FROM recurring WHERE active=1 AND next_due<=? AND (end_date='' OR next_due<=end_date) LIMIT 1", (today.isoformat(),)).fetchone():
                return 0
        posted = 0
        with self.session(notify=True) as c:
            rules = c.execute("SELECT * FROM recurring WHERE active=1 AND next_due<=? AND (end_date='' OR next_due<=end_date) ORDER BY next_due, id", (today.isoformat(),)).fetchall()
            for r in rules:
                due = date.fromisoformat(r["next_due"])
                end = date.fromisoformat(r["end_date"]) if r["end_date"] else None
                n, last = 0, ""
                while due <= today and (end is None or due <= end) and n < CATCH_UP_CAP:
                    p = {"type": r["type"], "time": f"{due.isoformat()}T{POST_HOUR}", "account_id": r["account_id"], "to_account_id": r["to_account_id"],
                         "amount": r["amount"], "category": r["category"], "note": r["note"], "no_budget": r["no_budget"], "no_stats": r["no_stats"], "tags": r["tags"]}
                    c.execute("SAVEPOINT rec")
                    try:
                        self._insert_tx(c, p)
                    except Exception as e:                  # a BookError (archived account, missing rate...) or anything else: pause the rule, keep the rest
                        c.execute("ROLLBACK TO rec")
                        c.execute("RELEASE rec")
                        why = str(e) or "不明原因"
                        c.execute("UPDATE recurring SET active=0, last_error=? WHERE id=?", (why[:200], r["id"]))
                        break
                    c.execute("RELEASE rec")
                    posted += 1
                    n += 1
                    last = due.isoformat()
                    due = next_date(due, r["freq"], r["anchor_day"])
                if last:
                    c.execute("UPDATE recurring SET next_due=?, last_posted=? WHERE id=?", (due.isoformat(), last, r["id"]))
        return posted

    def maybe_run_recurring(self, force=False):
        """run_recurring, but at most once a minute (called on every state / ping request) and never raising."""
        now = _time.time()
        day = date.today().isoformat()
        at, seen = self._recur_checked
        if not force and now - at < CHECK_EVERY and seen == day:
            return 0
        self._recur_checked = (now, day)
        try:
            n = self.run_recurring()
        except Exception:
            n = 0
        try:
            self.run_auto_settle()                      # advances set to be received by themselves on the due day
        except Exception:
            pass
        return n
