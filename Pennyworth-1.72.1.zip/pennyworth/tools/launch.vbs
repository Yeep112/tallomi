'' Starts Tallomi with no window at all (the gold P icon is the only thing you see).
'' Optional argument -FetchRates / -Background: handled by the PowerShell launcher (launch.cmd), as before.
'' 1.71.0: a plain start goes straight to pythonw.exe of the remembered program folder (no cmd.exe, no PowerShell, no console at all, about a
'' second quicker). Anything unusual (folder moved, no .venv yet, an argument) falls back to the old route through launch.cmd, which can search and set up.
Set sh = CreateObject("WScript.Shell")
here = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
extra = ""
For i = 0 To WScript.Arguments.Count - 1
  extra = extra & " " & WScript.Arguments(i)
Next

Sub Note(msg)
  On Error Resume Next
  Set fso2 = CreateObject("Scripting.FileSystemObject")
  d = sh.ExpandEnvironmentStrings("%APPDATA%") & "\Pennyworth"
  If fso2.FolderExists(d) Then
    Set f = fso2.OpenTextFile(d & "\launch.log", 8, True)
    f.WriteLine Now & " [launch.vbs] " & msg
    f.Close
  End If
End Sub

Function FastStart()
  FastStart = False
  On Error Resume Next
  If extra <> "" Then Exit Function
  Set fso = CreateObject("Scripting.FileSystemObject")
  loc = sh.ExpandEnvironmentStrings("%APPDATA%") & "\Pennyworth\program_location.txt"
  If Not fso.FileExists(loc) Then Exit Function
  Set st = CreateObject("ADODB.Stream")
  st.Type = 2
  st.Charset = "utf-8"
  st.Open
  st.LoadFromFile loc
  txt = st.ReadText(-1)
  st.Close
  If Err.Number <> 0 Then Exit Function
  txt = Replace(txt, ChrW(&HFEFF), "")
  txt = Replace(txt, vbCr, "")
  dir = Trim(Split(txt & vbLf, vbLf)(0))
  If dir = "" Then Exit Function
  py = dir & "\.venv\Scripts\pythonw.exe"
  If Not (fso.FileExists(dir & "\.pennyworth-home") And fso.FileExists(dir & "\run.py") And fso.FileExists(py)) Then Exit Function
  sh.CurrentDirectory = dir
  sh.Run """" & py & """ run.py", 0, False
  If Err.Number <> 0 Then Exit Function
  Note "fast start: " & dir
  FastStart = True
End Function

If Not FastStart() Then
  Note "fast start not possible, using launch.cmd"
  sh.Run "cmd.exe /c """"" & here & "launch.cmd""" & extra & """", 0, False
End If
